"""Fetch the pinned Linux build tools and verify hashes. Java, Node and Python are prerequisites."""
import hashlib,json,os,pathlib,urllib.request,zipfile
project=pathlib.Path(__file__).resolve().parent
root=pathlib.Path(os.environ.get('REPERTORY_TOOLS','/workspace/tools'));root.mkdir(parents=True,exist_ok=True)
for item in json.loads((project/'TOOLS.lock.json').read_text()):
 path=root/item['file']
 if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
  print('Downloading',item['file'],flush=True);urllib.request.urlretrieve(item['url'],path)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],'Tool checksum mismatch: '+item['file']
 if path.suffix=='.zip':
  target=root/'android';target.mkdir(exist_ok=True)
  with zipfile.ZipFile(path) as archive:
   for entry in archive.infolist():
    destination=(target/entry.filename).resolve()
    assert destination.is_relative_to(target.resolve()),'Unexpected archive path'
   archive.extractall(target)
  for file in target.rglob('*'):file.chmod(file.stat().st_mode|0o500)
print('Build tools are ready in',root)
