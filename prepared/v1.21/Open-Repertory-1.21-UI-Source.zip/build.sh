#!/usr/bin/env bash
set -euo pipefail
project="$(cd -- "$(dirname -- "$0")" && pwd)"
tool_root="${REPERTORY_TOOLS:-/workspace/tools}"
bt="$tool_root/android/android-15"
platform="$tool_root/android/android-35/android.jar"
# An update must retain the installed signing identity. Never replace a missing key.
if [[ ! -f "$project/build/development.p12" ]]; then
 echo 'Existing Android signing key is missing. Restore its secure backup; refusing to create a replacement.' >&2
 exit 1
fi
python "$project/scripts/generate_release_config.py"
version_code="$(python -c 'import json,sys; print(json.load(open(sys.argv[1]))["versionCode"])' "$project/release-config.json")"
version_name="$(python -c 'import json,sys; print(json.load(open(sys.argv[1]))["versionName"])' "$project/release-config.json")"
mkdir -p "$project/build/classes" "$project/dist"
rm -rf "$project/build/classes"
mkdir -p "$project/build/classes"
python "$project/prepare_data.py"
"$project/tooling/node_modules/.bin/esbuild" "$project"/web-src/js/*.js --target=chrome66 --outdir="$project/apk/assets/www/js"
for script in "$project"/apk/assets/www/js/*.js; do node --check "$script"; done
java -jar "$tool_root/ecj.jar" -source 8 -target 8 -proc:none -bootclasspath "$platform:$bt/core-lambda-stubs.jar" -d "$project/build/classes" "$project"/native/com/openrepertory/app/*.java
find "$project/build/classes" -name '*.class' -print > "$project/build/class-list.txt"
"$bt/d8" --min-api 23 --lib "$platform" --output "$project/build" "@$project/build/class-list.txt"
"$bt/aapt2" compile --dir "$project/android/app/src/main/res" -o "$project/build/resources.zip"
python - "$project" <<'PYMANIFEST'
import sys,pathlib,xml.etree.ElementTree as ET
p=pathlib.Path(sys.argv[1]);ET.register_namespace('android','http://schemas.android.com/apk/res/android')
manifest=ET.parse(p/'android/app/src/main/AndroidManifest.xml');manifest.getroot().set('package','com.openrepertory.app.dev');manifest.write(p/'build/AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
PYMANIFEST
"$bt/aapt2" link -I "$platform" --manifest "$project/build/AndroidManifest.xml" --min-sdk-version 23 --target-sdk-version 35 --version-code "$version_code" --version-name "$version_name" -A "$project/apk/assets" "$project/build/resources.zip" -o "$project/build/unsigned-base.apk"
python - "$project" <<'PYBUILD'
import sys,pathlib,zipfile
p=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(p/'build/unsigned-base.apk') as src,zipfile.ZipFile(p/'build/unsigned.apk','w') as dst:
 for entry in src.infolist():
  if not entry.filename.endswith('.dex'):dst.writestr(entry,src.read(entry.filename))
 dst.write(p/'build/classes.dex','classes.dex',compress_type=zipfile.ZIP_DEFLATED)
PYBUILD
"$bt/zipalign" -f -p 4 "$project/build/unsigned.apk" "$project/build/aligned.apk"
# Retained identity for existing installations; never include this key in delivery archives.
"$bt/apksigner" sign --ks "$project/build/development.p12" --ks-pass pass:repertory-development --key-pass pass:repertory-development --out "$project/dist/Open-Repertory-Clarke-Dev.apk" "$project/build/aligned.apk"
"$bt/apksigner" verify --verbose "$project/dist/Open-Repertory-Clarke-Dev.apk"
python "$project/scripts/prepare_release.py" --verify-apk-only "$project/dist/Open-Repertory-Clarke-Dev.apk"
sha256sum "$project/dist/Open-Repertory-Clarke-Dev.apk" > "$project/dist/CLARKE-SHA256SUMS"
