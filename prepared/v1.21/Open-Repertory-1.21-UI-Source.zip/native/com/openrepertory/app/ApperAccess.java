package com.openrepertory.app;

import android.content.*;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Settings;
import android.security.keystore.*;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Owner-approved Apper access. No password, clinical record or API secret is stored here. */
public final class ApperAccess {
    public static final String PROJECT="54be7eef4ac24f7c907d0576b168ccff";
    public static final String ORIGIN="https://preview--openrepertory-eminent.apper.so";
    private static final String ALIAS="openrepertory.apper-access.v1";
    private static final long DAY=86400000L;
    private final Context context;
    private final SharedPreferences prefs;
    private JSONObject cache;
    private String device;
    public ApperAccess(Context context) throws Exception {
        this.context=context;
        prefs=context.getSharedPreferences(ALIAS,0);
        try { cache=read(); } catch(Exception error) { cache=new JSONObject();prefs.edit().clear().commit(); }
        deviceId();
    }
    public static boolean trusted(Uri uri) {
        return uri!=null&&"https".equals(uri.getScheme())&&"preview--openrepertory-eminent.apper.so".equals(uri.getHost())
            &&(uri.getPort()==-1||uri.getPort()==443)&&uri.getUserInfo()==null;
    }
    public synchronized String deviceId() throws Exception {
        if(device!=null)return device;
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        // Preserve the installation fingerprint of the archived access provider.
        String name=ks.containsAlias("openrepertory.access.open-repertory.device")?"openrepertory.access.open-repertory.device":"openrepertory.device.v1";
        if(!ks.containsAlias(name)) {
            KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA","AndroidKeyStore");
            gen.initialize(new KeyGenParameterSpec.Builder(name,KeyProperties.PURPOSE_SIGN|KeyProperties.PURPOSE_VERIFY).setKeySize(2048)
                .setDigests(KeyProperties.DIGEST_SHA256).setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1).build());
            gen.generateKeyPair();
        }
        byte[] hash=MessageDigest.getInstance("SHA-256").digest(ks.getCertificate(name).getPublicKey().getEncoded());
        StringBuilder hex=new StringBuilder();for(byte b:hash)hex.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
        device=hex.toString();return device;
    }
    private SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(ALIAS))return (SecretKey)ks.getKey(ALIAS,null);
        KeyGenerator gen=KeyGenerator.getInstance("AES","AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
        return gen.generateKey();
    }
    private JSONObject read() throws Exception {
        String encoded=prefs.getString("approval",null);if(encoded==null)return new JSONObject();
        byte[] bytes=Base64.decode(encoded,Base64.NO_WRAP);if(bytes.length<29)throw new IOException();
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,java.util.Arrays.copyOf(bytes,12)));cipher.updateAAD(ALIAS.getBytes("UTF-8"));
        return new JSONObject(new String(cipher.doFinal(java.util.Arrays.copyOfRange(bytes,12,bytes.length)),"UTF-8"));
    }
    private void save() throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());cipher.updateAAD(ALIAS.getBytes("UTF-8"));
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();bytes.write(cipher.getIV());bytes.write(cipher.doFinal(cache.toString().getBytes("UTF-8")));
        if(!prefs.edit().putString("approval",Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP)).commit())throw new IOException("Approval could not be saved");
    }
    public synchronized void clear() { cache=new JSONObject();prefs.edit().remove("approval").commit(); }
    public synchronized String email(){return cache.optString("email");}
    public synchronized String uid(){return cache.optString("uid");}
    /** UI gate only; Apper's server profile permissions/RLS enforce every grant write. */
    public synchronized boolean owner(){return cachedAllowed()&&"Owner_c".equals(cache.optString("profile"));}
    private int boot(){try{return Settings.Global.getInt(context.getContentResolver(),"boot_count");}catch(Exception e){return -1;}}
    public static boolean offlineValid(JSONObject c,String device,int boot,long now) {
        long checked=c.optLong("elapsed",-1);
        return PROJECT.equals(c.optString("project"))&&!c.optString("uid").isEmpty()&&device.equals(c.optString("device"))
            &&boot>=0&&boot==c.optInt("boot",-2)&&checked>=0&&now>=checked&&now-checked<DAY;
    }
    public synchronized long remainingApprovalMillis(){return offlineValid(cache,device,boot(),SystemClock.elapsedRealtime())?Math.max(0,DAY-(SystemClock.elapsedRealtime()-cache.optLong("elapsed"))):0;}
    public synchronized boolean cachedAllowed(){return remainingApprovalMillis()>0&&bound();}
    private boolean bound(){SharedPreferences b=context.getSharedPreferences("openrepertory.vault-owner",0);return "apper".equals(b.getString("provider",""))&&uid().equals(b.getString("uid",null));}
    /** Pure receipt validation, independent of any UI status or role. */
    public static boolean approved(JSONObject receipt,String nonce,String device) {
        JSONObject user=receipt.optJSONObject("user"),request=receipt.optJSONObject("request"),grant=receipt.optJSONObject("grant");
        if(receipt.optInt("protocol")!=1||!PROJECT.equals(receipt.optString("projectId"))||!nonce.equals(receipt.optString("nonce"))
            ||!"live".equals(receipt.optString("mode"))||!"approved".equals(receipt.optString("status"))||user==null||request==null||grant==null)return false;
        String uid=user.optString("id");
        return !uid.isEmpty()&&!"null".equals(uid)&&uid.equals(request.optString("ownerId"))&&!request.optString("id").isEmpty()
            &&!grant.optString("id").isEmpty()&&request.optString("id").equals(grant.optString("requestId"))
            &&device.matches("[a-f0-9]{64}")&&device.equals(request.optString("device"))&&device.equals(grant.optString("device"))
            &&"approved".equals(grant.optString("status"))&&grant.optLong("version")>=1;
    }
    /** Returns approved, migration, records, or a closed-gate status. */
    public synchronized String accept(JSONObject receipt,String nonce) throws Exception {
        if(!approved(receipt,nonce,device)) {clear();return "approved".equals(receipt.optString("status"))?"invalid":receipt.optString("status","error");}
        JSONObject user=receipt.getJSONObject("user");
        cache=new JSONObject().put("project",PROJECT).put("uid",user.getString("id")).put("email",user.optString("email"))
            .put("profile",user.optString("profile")).put("device",device).put("boot",boot()).put("elapsed",SystemClock.elapsedRealtime());
        SharedPreferences binding=context.getSharedPreferences("openrepertory.vault-owner",0);
        String previous=binding.getString("uid",null);
        if(previous==null) {
            if(!binding.edit().putString("provider","apper").putString("uid",uid()).commit()) {clear();return "error";}
        } else if(!bound()) {
            save();
            return !"apper".equals(binding.getString("provider",""))&&"Owner_c".equals(user.optString("profile"))?"migration":"records";
        }
        save();return "approved";
    }
    public synchronized boolean migrateLegacyOwner() throws Exception {
        SharedPreferences b=context.getSharedPreferences("openrepertory.vault-owner",0);
        if(!"Owner_c".equals(cache.optString("profile"))||"apper".equals(b.getString("provider",""))
            ||!offlineValid(cache,device,boot(),SystemClock.elapsedRealtime()))return false;
        return b.edit().putString("provider","apper").putString("uid",uid()).commit();
    }
    public String details(){return "Provider: Apper\nProject: "+PROJECT+"\nPortal: "+ORIGIN+"\nAccount: "+email()+"\nAccount ID: "+uid()+"\nDevice ID: "+device+"\n\nRequest access in the APK. The owner approves the matching account and phone under Device requests. No Firestore document is used. These details contain no password or patient data.";}
}
