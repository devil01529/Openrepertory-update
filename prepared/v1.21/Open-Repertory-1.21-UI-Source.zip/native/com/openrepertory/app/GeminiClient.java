package com.openrepertory.app;

import android.content.*;
import android.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

/** HTTPS-only transport. Cancellation closes the active socket, not just its UI callback. */
public final class GeminiClient {
    private final Context context;
    private final SharedPreferences legacy;
    private final RecordStore records;
    private volatile String model;
    public GeminiClient(Context context, RecordStore records) { this.context=context; this.records=records; legacy=context.getSharedPreferences("open_repertory_secure",Context.MODE_PRIVATE); }
    private String key() throws Exception {
        String saved=records.read("openrepertory_gemini_key");
        if(saved!=null)return new JSONTokener(saved).nextValue().toString();
        String plain=legacy.getString("gemini_key_private",null), blob=legacy.getString("gemini_blob_v2",null);
        if(plain==null && blob!=null) {
            String[] parts=blob.split("\\.",2);
            if(parts.length==2) {
                KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
                Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE,ks.getKey("OpenRepertoryGeminiKeyV2",null),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
                plain=new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),"UTF-8");
            }
        }
        if(plain!=null && !plain.isEmpty() && saveKey(plain)) { legacy.edit().remove("gemini_key_private").remove("gemini_blob_v2").remove("gemini_blob").commit(); }
        return plain;
    }
    public boolean hasKey() { try { String key=key();return key!=null&&!key.isEmpty(); }catch(Exception e){return false;} }
    public boolean saveKey(String key) {
        if(key==null || key.trim().length()<20 || key.length()>512 || key.matches(".*[\\r\\n].*"))return false;
        try {records.write(new JSONObject().put("openrepertory_gemini_key",JSONObject.quote(key.trim())));model=null;return true;}catch(Exception e){return false;}
    }
    public void clearKey() throws Exception {
        records.write(new JSONObject().put("openrepertory_gemini_key",JSONObject.quote("")));
        legacy.edit().remove("gemini_key_private").remove("gemini_blob_v2").remove("gemini_blob").commit();model=null;
    }
    public static final class Request {
        private final AtomicBoolean cancelled=new AtomicBoolean();
        volatile HttpURLConnection connection;
        public synchronized void cancel(){cancelled.set(true);if(connection!=null)connection.disconnect();}
        public void check() throws InterruptedIOException {if(cancelled.get()||Thread.currentThread().isInterrupted())throw new InterruptedIOException("cancelled");}
        synchronized void attach(HttpURLConnection c) throws InterruptedIOException {check();connection=c;}
    }
    public static final class ProviderException extends IOException {
        public final String code;
        ProviderException(String code){super(code);this.code=code;}
    }
    public static String errorForStatus(int status) {
        if(status==401 || status==403)return "invalid_key";
        if(status==429)return "rate_limited";
        if(status==404)return "model_unavailable";
        if(status>=500)return "provider_unavailable";
        return "request_rejected";
    }
    private JSONObject call(String path,String key,JSONObject body,Request request) throws Exception {
        request.check();
        HttpURLConnection connection=(HttpURLConnection)new URL("https://generativelanguage.googleapis.com/v1beta/"+path).openConnection();
        request.attach(connection);
        connection.setConnectTimeout(15000);connection.setReadTimeout(25000);connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("x-goog-api-key",key);connection.setRequestProperty("Accept","application/json");
        try {
            if(body!=null){connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json; charset=utf-8");byte[] data=body.toString().getBytes("UTF-8");connection.setFixedLengthStreamingMode(data.length);try(OutputStream out=connection.getOutputStream()){out.write(data);}}
            request.check();int status=connection.getResponseCode();
            if(status<200 || status>=300)throw new ProviderException(errorForStatus(status));
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream in=connection.getInputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=in.read(buffer))!=-1){request.check();bytes.write(buffer,0,n);if(bytes.size()>1024*1024)throw new IOException("Response too large");}
            }
            request.check();return new JSONObject(new String(bytes.toByteArray(),"UTF-8"));
        } finally {connection.disconnect();request.connection=null;}
    }
    public static String chooseModel(JSONObject response) throws JSONException {
        JSONArray models=response.optJSONArray("models");List<String> candidates=new ArrayList<>();
        if(models!=null)for(int i=0;i<models.length();i++){
            JSONObject m=models.getJSONObject(i);String name=m.optString("name","");JSONArray methods=m.optJSONArray("supportedGenerationMethods");boolean supported=false;
            if(methods!=null)for(int j=0;j<methods.length();j++)if("generateContent".equals(methods.optString(j)))supported=true;
            if(supported && name.matches("models/[A-Za-z0-9._-]+") && name.contains("gemini") && !name.contains("embedding") && !name.contains("image") && !name.contains("tts"))candidates.add(name);
        }
        for(String preferred:new String[]{"models/gemini-2.5-flash-lite","models/gemini-2.5-flash","models/gemini-2.0-flash"})if(candidates.contains(preferred))return preferred;
        Collections.sort(candidates);
        for(String name:candidates)if(name.contains("flash")&&!name.contains("preview"))return name;
        return candidates.isEmpty()?null:candidates.get(0);
    }
    public static String extract(JSONObject response) throws Exception {
        JSONArray candidates=response.optJSONArray("candidates");
        if(candidates==null||candidates.length()==0)throw new ProviderException("blocked_or_empty");
        JSONObject content=candidates.getJSONObject(0).optJSONObject("content");JSONArray parts=content==null?null:content.optJSONArray("parts");StringBuilder text=new StringBuilder();
        if(parts!=null)for(int i=0;i<parts.length();i++){JSONObject part=parts.getJSONObject(i);if(!part.optBoolean("thought",false))text.append(part.optString("text",""));}
        String result=text.toString().trim();
        if(result.startsWith("```"))result=result.replaceFirst("^```(?:json)?\\s*","").replaceFirst("\\s*```$","").trim();
        Object json=new JSONTokener(result).nextValue();if(!(json instanceof JSONObject))throw new ProviderException("invalid_response");
        return json.toString();
    }
    public String interpret(String prompt,boolean test,Request request) throws Exception {
        String key=key();if(key==null||key.isEmpty())throw new ProviderException("not_granted");
        if(model==null)model=chooseModel(call("models?pageSize=1000",key,null,request));
        if(model==null)throw new ProviderException("model_unavailable");
        if(test)return new JSONObject().put("ok",true).put("model",model).toString();
        JSONObject body=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",new JSONArray().put(new JSONObject().put("text",prompt)))))
            .put("generationConfig",new JSONObject().put("temperature",0.1).put("maxOutputTokens",2048).put("responseMimeType","application/json"));
        try{return extract(call(model+":generateContent",key,body,request));}catch(ProviderException error){if("model_unavailable".equals(error.code))model=null;throw error;}
    }
}
