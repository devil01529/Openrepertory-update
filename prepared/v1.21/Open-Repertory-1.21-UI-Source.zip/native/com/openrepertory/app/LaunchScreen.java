package com.openrepertory.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** A native cover while access is checked and the first clinical frame is prepared. */
public final class LaunchScreen extends FrameLayout {
    private final TextView message, detail;
    private final ProgressBar progress;
    private final Button retry;
    private int generation;
    public LaunchScreen(Context context, Runnable retryAction) {
        super(context);
        setBackgroundColor(0xfff4f6f9);
        setClickable(true);setFocusable(true);
        LinearLayout content=new LinearLayout(context);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER);
        int pad=dp(32);content.setPadding(pad,pad,pad,pad);
        addView(content,new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER));
        ImageView logo=new ImageView(context);
        int icon=getResources().getIdentifier("ic_launcher","drawable",context.getPackageName());
        if(icon!=0)logo.setImageResource(icon);
        logo.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        LinearLayout.LayoutParams iconLayout=new LinearLayout.LayoutParams(dp(76),dp(76));iconLayout.bottomMargin=dp(22);content.addView(logo,iconLayout);
        TextView brand=label(context,"Open Repertory",24,0xff193252);brand.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));content.addView(brand);
        progress=new ProgressBar(context);progress.setIndeterminateTintList(ColorStateList.valueOf(0xffa77b2b));
        LinearLayout.LayoutParams spinnerLayout=new LinearLayout.LayoutParams(dp(30),dp(30));spinnerLayout.topMargin=dp(28);spinnerLayout.bottomMargin=dp(18);content.addView(progress,spinnerLayout);
        message=label(context,"Signing in…",18,0xff193252);message.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);content.addView(message);
        detail=label(context,"Checking your approved access",14,0xff667085);detail.setPadding(0,dp(10),0,0);content.addView(detail);
        retry=new Button(context);retry.setAllCaps(false);retry.setText("Try again");retry.setVisibility(GONE);retry.setOnClickListener(v->retryAction.run());
        LinearLayout.LayoutParams retryLayout=new LinearLayout.LayoutParams(-2,dp(48));retryLayout.topMargin=dp(20);content.addView(retry,retryLayout);
    }
    private TextView label(Context context,String value,int size,int color){TextView text=new TextView(context);text.setText(value);text.setTextSize(size);text.setTextColor(color);text.setGravity(Gravity.CENTER);text.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return text;}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    public void show(String title,String subtitle){generation++;animate().cancel();setAlpha(1);message.setText(title);detail.setText(subtitle);progress.setVisibility(VISIBLE);retry.setVisibility(GONE);setVisibility(VISIBLE);bringToFront();}
    public void problem(String title,String subtitle){show(title,subtitle);progress.setVisibility(GONE);retry.setVisibility(VISIBLE);}
    public void hide(boolean fade){final int current=++generation;animate().cancel();if(!fade){setVisibility(GONE);setAlpha(1);return;}animate().alpha(0).setDuration(120).withEndAction(()->{if(generation==current){setVisibility(GONE);setAlpha(1);}}).start();}
    public void dispose(){generation++;animate().cancel();}
}
