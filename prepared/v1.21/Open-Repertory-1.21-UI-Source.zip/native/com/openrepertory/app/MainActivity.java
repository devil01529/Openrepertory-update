package com.openrepertory.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;

/** Fully editable host. Device credentials are validated by Android, never by the app. */
public class MainActivity extends Activity {
    protected WebView webView;
    protected boolean authenticated, authenticationInProgress;
    private long backgroundAt;
    private boolean foreground;
    static final int UNLOCK = 4101;
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        webView = new WebView(this);
        webView.setVisibility(View.INVISIBLE);
        android.widget.FrameLayout root=new android.widget.FrameLayout(this);
        root.setBackgroundColor(0xff24365c);
        root.addView(webView,new android.widget.FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view,insets)->{
                android.graphics.Insets visible=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.ime());
                android.widget.FrameLayout.LayoutParams layout=(android.widget.FrameLayout.LayoutParams)webView.getLayoutParams();
                if(layout.leftMargin!=visible.left||layout.topMargin!=visible.top||layout.rightMargin!=visible.right||layout.bottomMargin!=visible.bottom){layout.setMargins(visible.left,visible.top,visible.right,visible.bottom);webView.setLayoutParams(layout);}
                return insets;
            });root.requestApplyInsets();
        }
    }
    protected void requestUnlock() {
        if (authenticated || authenticationInProgress || isFinishing()) return;
        webView.setVisibility(View.INVISIBLE);
        KeyguardManager manager = (KeyguardManager)getSystemService(KEYGUARD_SERVICE);
        if (manager == null || !manager.isDeviceSecure()) { showNoScreenLockMessage(); return; }
        if (Build.VERSION.SDK_INT >= 30) {
            android.hardware.biometrics.BiometricManager biometrics=(android.hardware.biometrics.BiometricManager)getSystemService(BIOMETRIC_SERVICE);
            int allowed=android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK|android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL;
            if(biometrics!=null && biometrics.canAuthenticate(allowed)==android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS){
                authenticationInProgress=true;
                new android.hardware.biometrics.BiometricPrompt.Builder(this).setTitle("Unlock Open Repertory").setAllowedAuthenticators(allowed).build()
                    .authenticate(new CancellationSignal(),getMainExecutor(),new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback(){
                        @Override public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult result){unlock();}
                        @Override public void onAuthenticationError(int code,CharSequence message){authenticationInProgress=false;showLockedMessage();}
                    });return;
            }
        }
        Intent credential = manager.createConfirmDeviceCredentialIntent("Unlock Open Repertory", "Confirm your device PIN, pattern, or password.");
        if (credential == null) { showNoScreenLockMessage(); return; }
        authenticationInProgress = true;
        try { startActivityForResult(credential, UNLOCK); }
        catch (Exception e) { authenticationInProgress = false; showNoScreenLockMessage(); }
    }
    protected void showNoScreenLockMessage() {
        if (authenticationInProgress || isFinishing()) return;
        authenticationInProgress = true;
        new AlertDialog.Builder(this).setTitle("Set a device lock first")
            .setMessage("Protect your records with an Android PIN, pattern, or password. Configure a screen lock, then return to the app.")
            .setPositiveButton("Security settings", (dialog, which) -> {
                authenticationInProgress = false;
                try { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); } catch (Exception e) { finish(); }
            }).setNeutralButton("Try again", (dialog, which) -> { authenticationInProgress = false; requestUnlock(); })
            .setNegativeButton("Exit", (dialog, which) -> finish()).setCancelable(false).show();
    }
    private void showLockedMessage(){
        if(isFinishing())return;
        new AlertDialog.Builder(this).setTitle("App locked").setMessage("Use your Android biometric or device credential to continue.")
            .setPositiveButton("Unlock",(d,w)->requestUnlock()).setNegativeButton("Exit",(d,w)->finish()).setCancelable(false).show();
    }
    protected void unlock() {
        authenticated = true; authenticationInProgress = false; backgroundAt = 0;
        updateCaptureProtection();
        if (webView != null) webView.setVisibility(View.VISIBLE);
    }
    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        if (authenticated && backgroundAt > 0 && SystemClock.elapsedRealtime() - backgroundAt >= 60000) authenticated = false;
        updateCaptureProtection();
        if (!authenticated && !authenticationInProgress && webView != null) webView.post(this::requestUnlock);
    }
    /** Screenshots are allowed for the owner-requested UI review, after device unlock.
     * Keep the locked/background window protected. No Android screenshot permission exists. */
    protected void updateCaptureProtection() {
        if (authenticated && foreground) getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }
    @Override protected void onPause() {
        if (webView != null) webView.evaluateJavascript("window.OR&&OR.flushDrafts&&OR.flushDrafts()", null);
        foreground = false;
        updateCaptureProtection();
        backgroundAt = SystemClock.elapsedRealtime();
        super.onPause();
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == UNLOCK) {
            authenticationInProgress = false;
            if (result == RESULT_OK) unlock();
            else if (!isFinishing()) new AlertDialog.Builder(this).setTitle("App locked")
                .setMessage("Unlock with your Android device credential to continue.")
                .setPositiveButton("Unlock", (d,w) -> requestUnlock()).setNegativeButton("Exit", (d,w) -> finish()).setCancelable(false).show();
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
