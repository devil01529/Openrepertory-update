package com.openrepertory.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.security.keystore.*;
import android.util.AtomicFile;
import java.io.*;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.*;

/** Transactional SQLite index with a separately authenticated AES-GCM value for each record.
 * Patient/case IDs are structural keys; names, notes and all clinical values are encrypted. */
public final class RecordStore {
    public static final String FILE = "records-v2.db";
    private static final String ALIAS = "openrepertory_records_v1";
    private static final int MAX = 64 * 1024 * 1024;
    private final Context context;
    private final File path;
    private final boolean legacy;
    private final File legacyPath;
    private SQLiteDatabase db;
    private boolean ready;
    private SecretKey encryptionKey;
    private SecretKey secret() throws Exception { if(encryptionKey==null)encryptionKey=key();return encryptionKey; }
    private final Map<String,String> hashes = new HashMap<>();
    public RecordStore(Context context) { this(context, new File(context.getFilesDir(), FILE), true); }
    private RecordStore(Context context, File path, boolean legacy) { this(context,path,legacy,new File(context.getFilesDir(),"clinical-v1.enc")); }
    RecordStore(Context context, File path, File legacyPath) {this(context,path,true,legacyPath);}
    private RecordStore(Context context,File path,boolean legacy,File legacyPath){this.context=context;this.path=path;this.legacy=legacy;this.legacyPath=legacyPath;}
    static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey)store.getKey(ALIAS, null);
        KeyGenerator gen = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
        return gen.generateKey();
    }
    private void open() throws Exception {
        if (db != null && db.isOpen() && ready) return;
        if (db != null) {db.close();db=null;}
        try {
        db = SQLiteDatabase.openOrCreateDatabase(path, null);
        try(Cursor secure=db.rawQuery("PRAGMA secure_delete=ON",null)){secure.moveToFirst();}
        if (db.getVersion() != 0 && db.getVersion() != 2) throw new IOException("Unsupported record schema");
        db.execSQL("CREATE TABLE IF NOT EXISTS records (name TEXT PRIMARY KEY, cipher BLOB NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS metadata (name TEXT PRIMARY KEY, value TEXT NOT NULL)");
        if(db.getVersion()==0)db.setVersion(2);
        boolean initialized;
        try (Cursor rows = db.rawQuery("SELECT value FROM metadata WHERE name='initialized'", null)) { initialized = rows.moveToFirst(); }
        if (!initialized) {
            try(Cursor existing=db.rawQuery("SELECT COUNT(*) FROM records",null)){existing.moveToFirst();if(existing.getInt(0)>0)throw new IOException("Migration marker is missing from existing records");}
            JSONObject changes = new JSONObject();
            File old = legacyPath;
            if (legacy && (old.exists() || new File(old+".bak").exists())) {
                byte[] bytes = new AtomicFile(old).readFully();
                if (bytes.length < 29 || bytes.length > MAX) throw new IOException("Legacy record file is invalid");
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, secret(), new GCMParameterSpec(128, Arrays.copyOfRange(bytes, 0, 12)));
                changes = new JSONObject(new String(cipher.doFinal(Arrays.copyOfRange(bytes, 12, bytes.length)), "UTF-8"));
            }
            transact(changes, true); // Mark initialized in the same transaction as the verified migration.
        }
        ready=true;
        } catch(Exception error) { if(db!=null){db.close();db=null;}ready=false;hashes.clear();throw error; }
    }
    private static void validateKey(String name) {
        if (name == null || !name.matches("(?:openrepertory_[A-Za-z0-9_]+|or\\.[A-Za-z0-9_]+)")) throw new IllegalArgumentException("Invalid storage key");
    }
    private static String field(String name) {
        if (name.equals("openrepertory_patients")) return "patients";
        if (name.equals("openrepertory_cases")) return "cases";
        if (name.equals("openrepertory_mmnotes")) return "";
        return null;
    }
    private static String prefix(String name) { return name.equals("openrepertory_patients") ? "patient:" : name.equals("openrepertory_cases") ? "case:" : "note:"; }
    private String decrypt(String name, byte[] bytes) throws Exception {
        if (bytes.length < 29 || bytes.length > MAX) throw new IOException("Invalid record");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, secret(), new GCMParameterSpec(128, Arrays.copyOfRange(bytes, 0, 12)));
        cipher.updateAAD(("record-v2:"+name).getBytes("UTF-8"));
        return new String(cipher.doFinal(Arrays.copyOfRange(bytes, 12, bytes.length)), "UTF-8");
    }
    private String row(String name) throws Exception {
        try (Cursor rows = db.rawQuery("SELECT cipher FROM records WHERE name=?", new String[]{name})) {
            if (!rows.moveToFirst()) return null;
            String value = decrypt(name, rows.getBlob(0)); hashes.put(name, digest(value)); return value;
        }
    }
    public synchronized String read(String name) throws Exception {
        validateKey(name); open(); String meta = row(name); if (meta == null) return null;
        String field = field(name); if (field == null) return meta;
        JSONObject result = new JSONObject(meta), records = new JSONObject(); String prefix = prefix(name);
        try (Cursor rows = db.rawQuery("SELECT name,cipher FROM records WHERE name LIKE ?", new String[]{prefix+"%"})) {
            while (rows.moveToNext()) {
                String key = rows.getString(0), value = decrypt(key, rows.getBlob(1));
                hashes.put(key, digest(value)); records.put(key.substring(prefix.length()), new JSONTokener(value).nextValue());
            }
        }
        JSONArray expected=result.optJSONArray("_record_ids");
        if(expected==null || expected.length()!=records.length())throw new IOException("Record collection is incomplete");
        for(int i=0;i<expected.length();i++)if(!records.has(expected.getString(i)))throw new IOException("Record is missing");
        result.remove("_split_version");result.remove("_record_ids");
        if (field.isEmpty()) return records.toString();
        result.put(field, records); return result.toString();
    }
    private static String digest(String text) throws Exception {
        return android.util.Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(text.getBytes("UTF-8")), android.util.Base64.NO_WRAP);
    }
    private void put(String name, String value) throws Exception {
        if (value == null) { db.delete("records", "name=?", new String[]{name}); hashes.remove(name); return; }
        if (value.getBytes("UTF-8").length > MAX) throw new IOException("Record exceeds the supported size");
        String hash = digest(value); if (hash.equals(hashes.get(name))) return;
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, secret());
        cipher.updateAAD(("record-v2:"+name).getBytes("UTF-8"));
        byte[] encrypted = cipher.doFinal(value.getBytes("UTF-8")), bytes = new byte[12+encrypted.length];
        System.arraycopy(cipher.getIV(),0,bytes,0,12); System.arraycopy(encrypted,0,bytes,12,encrypted.length);
        ContentValues row = new ContentValues(); row.put("name",name); row.put("cipher",bytes);
        if (db.insertWithOnConflict("records",null,row,SQLiteDatabase.CONFLICT_REPLACE) < 0) throw new IOException("Record write failed");
        hashes.put(name,hash);
    }
    private void writeGroup(String name, String raw) throws Exception {
        String field = field(name), prefix = prefix(name); JSONObject meta = raw == null ? null : new JSONObject(raw);
        JSONObject records = meta == null ? new JSONObject() : field.isEmpty() ? meta : meta.getJSONObject(field);
        Set<String> keys = new HashSet<>(); Iterator<String> iterator = records.keys();
        while (iterator.hasNext()) {
            String id = iterator.next();
            if (id.length() > 160 || id.contains("\u0000") || id.equals("__proto__") || id.equals("constructor") || id.equals("prototype")) throw new IOException("Invalid record ID");
            Object value = records.get(id); String json = value instanceof String ? JSONObject.quote((String)value) : String.valueOf(value);
            put(prefix+id,json); keys.add(prefix+id);
        }
        List<String> removed = new ArrayList<>();
        try (Cursor rows = db.rawQuery("SELECT name FROM records WHERE name LIKE ?", new String[]{prefix+"%"})) {
            while (rows.moveToNext()) if (!keys.contains(rows.getString(0))) removed.add(rows.getString(0));
        }
        for (String removedKey : removed) put(removedKey,null);
        if (meta == null) put(name,null);
        else {
            if (!field.isEmpty()) meta.remove(field); else meta = new JSONObject();
            List<String> ids=new ArrayList<>();Iterator<String> names=records.keys();while(names.hasNext())ids.add(names.next());Collections.sort(ids);
            meta.put("_split_version",2).put("_record_ids",new JSONArray(ids));put(name,meta.toString());
        }
    }
    private void transact(JSONObject changes, boolean initialized) throws Exception {
        db.beginTransaction();
        try {
            Iterator<String> keys = changes.keys();
            while (keys.hasNext()) {
                String key = keys.next(); validateKey(key); String raw = changes.isNull(key) ? null : changes.getString(key);
                if (field(key) == null) put(key,raw); else writeGroup(key,raw);
            }
            if (initialized) db.execSQL("INSERT OR REPLACE INTO metadata(name,value) VALUES('initialized','2')");
            db.setTransactionSuccessful();
        } catch (Exception e) { hashes.clear(); throw e; }
        finally { try{db.endTransaction();}catch(RuntimeException error){hashes.clear();throw error;} }
    }
    public synchronized void write(JSONObject changes) throws Exception { open(); transact(changes,false); }
    public synchronized void patchPatient(String raw, String activeId) throws Exception {
        JSONObject patient=new JSONObject(raw);String id=patient.getString("id");
        if(!id.matches("[A-Za-z0-9_-]{1,120}") || !(patient.get("name") instanceof String))throw new IOException("Invalid patient");
        open();db.beginTransaction();
        try {
            put("patient:"+id,patient.toString());
            String existing=row("openrepertory_patients");JSONObject meta=existing==null?new JSONObject():new JSONObject(existing);
            JSONArray oldIds=meta.optJSONArray("_record_ids");Set<String> ids=new TreeSet<>();if(oldIds!=null)for(int i=0;i<oldIds.length();i++)ids.add(oldIds.getString(i));ids.add(id);
            meta.put("activeId",activeId==null?JSONObject.NULL:activeId).put("_split_version",2).put("_record_ids",new JSONArray(ids));
            put("openrepertory_patients",meta.toString());
            db.setTransactionSuccessful();
        }catch(Exception error){hashes.clear();throw error;}finally{try{db.endTransaction();}catch(RuntimeException error){hashes.clear();throw error;}}
    }
    public synchronized void health() throws Exception {
        open();
        for (String key : new String[]{"openrepertory_cases","openrepertory_patients","openrepertory_mmnotes"}) read(key);
    }
    public synchronized void close() { ready=false;hashes.clear(); if (db != null) { db.close(); db = null; } }
    public synchronized RecordStore restore(JSONObject changes) throws Exception {
        if (changes.length()!=3 || !changes.has("openrepertory_patients") || !changes.has("openrepertory_cases") || !changes.has("openrepertory_mmnotes")) throw new IOException("Incomplete recovery");
        File temporary = new File(context.getFilesDir(),"records-recovery-"+UUID.randomUUID()+".db");
        RecordStore prepared = new RecordStore(context,temporary,false);
        try { prepared.write(changes); prepared.health(); } finally { prepared.close(); }
        close();
        File archived = new File(context.getFilesDir(),"records-damaged-"+System.currentTimeMillis()+".db");
        boolean moved = path.exists();
        if (moved && !path.renameTo(archived)) throw new IOException("Original records could not be preserved");
        File journal = new File(path+"-journal");
        boolean movedJournal=journal.exists();
        if (journal.exists() && !journal.renameTo(new File(archived+"-journal"))) {
            if (moved) archived.renameTo(path); throw new IOException("Original journal could not be preserved");
        }
        if (!temporary.renameTo(path)) { if (moved) archived.renameTo(path); if(movedJournal)new File(archived+"-journal").renameTo(journal);throw new IOException("Recovered records could not be activated"); }
        RecordStore restored = new RecordStore(context); restored.health(); return restored;
    }
}
