(async function () {
  try {
    if(window.openrepertorySecure?.storageHealth && openrepertorySecure.storageHealth()!=='ok')throw new Error('Encrypted storage requires recovery.');
    ORStorage.migrate();await OR.start();
    if(OR.lifecycle)OR.lifecycle.start();
  } catch(error){ORRecovery.show(error);}
})();
