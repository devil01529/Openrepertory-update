(function () {
  "use strict";
  const OR = window.OR, S = OR.state, esc = OR.escapeHTML, $ = OR.$;
  const KEY = "openrepertory_patients";

  let db = { patients: {}, activeId: null };
  let committedDb = ORClone(db);

  const DEMO = [
    ["name", "Full name"], ["age", "Age"], ["sex", "Sex"],
    ["phone", "Phone"], ["occupation", "Occupation"], ["address", "Address / city"]
  ];
  const SEX = ["", "Female", "Male", "Other"];
  const CLIN = [
    ["chief", "Presenting complaints", "Main complaints, onset, duration, character…"],
    ["hpi", "History of present illness", "How it began, what changed, previous treatment…"],
    ["mind", "Mental & emotional state", "Fears, temperament, life events, delusions, dreams…"],
    ["generals", "Physical generals", "Thermal state, thirst, appetite, cravings/aversions, sleep, stool, urine, perspiration, menses…"],
    ["modalities", "Modalities  (< worse  /  > better)", "Time, weather, position, motion, food, company…"],
    ["past", "Past history", "Illnesses, surgeries, vaccinations, suppressions…"],
    ["family", "Family history", ""],
    ["notes", "Other notes", ""]
  ];

  function safeId(value) { return typeof value === "string" && /^[A-Za-z0-9_-]{1,120}$/.test(value) ? value : null; }
  function text(value) { return value == null ? "" : String(value); }
  function normalizeVisit(v) {
    if (!v || typeof v !== "object") return null;
    return { id: safeId(v.id) || OR.uid(), date: text(v.date), complaint: text(v.complaint), rx: text(v.rx), potency: text(v.potency), notes: text(v.notes), followup: text(v.followup) };
  }
  function normalizePatient(p, fallbackId) {
    if (!p || typeof p !== "object") return null;
    const id = safeId(p.id) || safeId(fallbackId) || OR.uid();
    return Object.assign({ id, name: "", age: "", sex: "", phone: "", occupation: "", address: "", chief: "", hpi: "", mind: "", generals: "", modalities: "", past: "", family: "", notes: "", createdAt: Date.now(), updatedAt: Date.now() }, p, { id, name: text(p.name), visits: Array.isArray(p.visits) ? p.visits.map(normalizeVisit).filter(Boolean) : [] });
  }

  // ---------- storage ----------
  function load() {
    const d = OR.store.get(KEY);
    if (d && d.patients && typeof d.patients === "object") {
      const patients = {};
      Object.entries(d.patients).forEach(([key, value]) => { const p = normalizePatient(value, key); if (p) patients[p.id] = p; });
      db = { patients, activeId: safeId(d.activeId) || null };
    }
    if (db.activeId && !db.patients[db.activeId]) db.activeId = null;
    committedDb=ORClone(db);
  }
  function save() {
    if(!OR.store.set(KEY,db)){ORRestoreObject(db,committedDb);throw new Error("Patient changes were not saved. Previous records are unchanged; retry while this form is open.");}
    committedDb=ORClone(db);
  }
  OR.hooks.start.push(load);

  const list = () => Object.values(db.patients)
    .sort((a, b) => (a.name || "").toLowerCase().localeCompare((b.name || "").toLowerCase()));
  OR.patientList = list;
  OR.patientName = id => (db.patients[id] && db.patients[id].name) || "";

  const today = () => {
    const d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  };
  const fmtDate = s => {
    if (!s) return "";
    const d = new Date(s + "T00:00:00");
    return isNaN(d) ? s : d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
  };
  const casesOf = id => Object.values(S.cases).filter(c => c.patientId === id);
  const lastVisit = p => (p.visits || []).reduce((m, v) => (v.date > m ? v.date : m), "");

  function refreshMenu() {
    $("patientCount").textContent = list().length;
    const p = db.patients[db.activeId];
    $("miFileSub").textContent = p ? (p.name || "Unnamed patient") : "Case-taking, visits & cases";
    $("menuDot").style.display = dueList().some(d => d.days <= 0) ? "" : "none";
  }

  // follow-ups: a visit's follow-up date is "open" until the patient has a later visit
  function dueList() {
    const t0 = new Date(today() + "T00:00:00").getTime(), out = [];
    Object.values(db.patients).forEach(p => {
      (p.visits || []).forEach(v => {
        if (!v.followup) return;
        if ((p.visits || []).some(o => o.date > v.date)) return;
        const days = Math.round((new Date(v.followup + "T00:00:00").getTime() - t0) / 86400000);
        if (!isNaN(days) && days <= 7) out.push({ p, v, days });
      });
    });
    return out.sort((a, b) => a.days - b.days);
  }

  function renderDue() {
    const box = $("dueStrip");
    const d = dueList();
    if (!d.length) { box.innerHTML = ""; return; }
    box.innerHTML = `<div class="due-strip"><b>Follow-ups</b>` + d.map(x => {
      const cls = x.days < 0 ? "over" : (x.days === 0 ? "today" : "soon");
      const when = x.days < 0 ? `${-x.days} day${x.days === -1 ? "" : "s"} overdue` : (x.days === 0 ? "today" : `in ${x.days} day${x.days === 1 ? "" : "s"}`);
      return `<button type="button" class="due ${cls}" data-id="${esc(x.p.id)}">${esc(x.p.name || "Unnamed")}<span>${esc(fmtDate(x.v.followup))} · ${when}</span></button>`;
    }).join("") + `</div>`;
  }
  $("dueStrip").addEventListener("click", e => { const b = e.target.closest(".due"); if (b) openFile(b.dataset.id); });

  // ================= PATIENTS LIST =================
  const listEl = $("patientList");

  function renderList() {
    const warn = $("storageWarn");
    if (!OR.store.ok) {
      warn.style.display = "";
      warn.textContent = "Records could not be saved. Keep this screen open and use Backup & restore to export a copy.";
    } else {
      warn.style.display = "";
      warn.textContent = "Records stay on this device. Android records are encrypted. Use Menu → Backup & restore to keep an encrypted copy.";
    }
    renderDue();
    const tokens = OR.tokenize($("patientSearch").value);
    let items = list();
    if (tokens.length) {
      items = items.filter(p => {
        const hay = [p.name, p.phone, p.occupation, p.chief, p.address].join(" ").toLowerCase();
        return tokens.every(t => hay.indexOf(t) !== -1);
      });
    }
    if (!items.length) {
      listEl.innerHTML = `<div class="empty-state">${list().length
        ? "No patients match your search."
        : "No patients yet.<br><br>Tap <b>+ New patient</b> to create the first record."}</div>`;
      return;
    }
    listEl.innerHTML = items.map(p => {
      const nCases = casesOf(p.id).length, nVis = (p.visits || []).length, lv = lastVisit(p);
      const meta = [p.age ? p.age + " yrs" : "", p.sex, p.phone].filter(Boolean).join(" · ");
      return `<button type="button" class="patient-card" data-id="${esc(p.id)}">
        <div class="pc-name">${esc(p.name || "Unnamed patient")}</div>
        ${meta ? `<div class="pc-meta">${esc(meta)}</div>` : ""}
        ${p.chief ? `<div class="pc-chief">${esc(p.chief.length > 140 ? p.chief.slice(0, 140) + "…" : p.chief)}</div>` : ""}
        <div class="pc-chips"><span>${nVis} visit${nVis === 1 ? "" : "s"}</span><span>${nCases} case${nCases === 1 ? "" : "s"}</span>${lv ? `<span>last: ${esc(fmtDate(lv))}</span>` : ""}</div>
      </button>`;
    }).join("");
  }
  listEl.addEventListener("click", e => {
    const card = e.target.closest(".patient-card");
    if (card) openFile(card.dataset.id);
  });
  let ptDebounce;
  $("patientSearch").addEventListener("input", () => { clearTimeout(ptDebounce); ptDebounce = setTimeout(renderList, 150); });
  $("patientNew").addEventListener("click", newPatientDialog);

  function newPatientDialog(resume) {
    if(!resume?.context)resume=OR.drafts?.list()["patient-new"];
    const draftContext=resume?.context?.type==='patient'?resume.context:{type:'patient',id:OR.uid()};
    if(db.patients[draftContext.id]){openFile(draftContext.id);OR.drafts.remove('patient-new');OR.toast('This draft was already saved.');return;}
    OR.modal({
      title: "New patient", draftKey:'patient-new',draftContext,
      html: `<div class="form-grid">
        <label class="fld full"><span>Full name *</span><input data-k="name" type="text"></label>
        <label class="fld"><span>Age</span><input data-k="age" type="text" inputmode="numeric"></label>
        <label class="fld"><span>Sex</span><select data-k="sex">${SEX.map(x => `<option>${x}</option>`).join("")}</select></label>
        <label class="fld full"><span>Phone</span><input data-k="phone" type="tel"></label>
        <label class="fld full"><span>Chief complaint</span><textarea data-k="chief" rows="3"></textarea></label>
      </div><p class="err" id="npErr" style="display:none">Please enter a name.</p>`,
      actions: [
        { label: "Cancel" },
        {
          label: "Create patient", primary: true,
          onClick: m => {
            const v = {};
            m.querySelectorAll("[data-k]").forEach(el => { v[el.dataset.k] = el.value.trim(); });
            if (!v.name) { m.querySelector("#npErr").style.display = ""; return false; }
            const id = draftContext.id;
            db.patients[id] = Object.assign({ id, createdAt: Date.now(), updatedAt: Date.now(), visits: [] }, v);
            db.activeId = id;
            save();
            refreshMenu();
            OR.renderCaseSelect();
            openFile(id);
          }
        }
      ]
    });
  }

  OR.pages.patients = { onShow: renderList };

  // ================= PATIENT FILE =================
  const root = $("fileRoot");

  function openFile(id) {
    if (!db.patients[id]) return;
    db.activeId = id;
    save();
    refreshMenu();
    OR.showPage("file");
  }

  function renderFile() {
    const p = db.patients[db.activeId];
    if (!p) {
      root.innerHTML = `<div class="empty-state">No patient selected.<br><br>
        <button class="primary-btn" id="fpChoose" type="button">Choose a patient</button>
        <button class="ghost-btn" id="fpNew" type="button">+ New patient</button></div>`;
      $("fpChoose").addEventListener("click", () => OR.showPage("patients"));
      $("fpNew").addEventListener("click", newPatientDialog);
      return;
    }
    const demo = DEMO.map(([k, label]) => k === "sex"
      ? `<label class="fld"><span>${label}</span><select data-f="sex">${SEX.map(x => `<option ${p.sex === x ? "selected" : ""}>${x}</option>`).join("")}</select></label>`
      : `<label class="fld ${k === "name" || k === "address" ? "full" : ""}"><span>${label}</span><input data-f="${k}" type="text" value="${esc(p[k] || "")}"></label>`).join("");
    const clin = CLIN.map(([k, label, ph]) =>
      `<label class="fld full"><span>${label}</span><textarea data-f="${k}" rows="2" placeholder="${esc(ph)}">${esc(p[k] || "")}</textarea></label>`).join("");

    root.innerHTML = `
      <div class="file-head">
        <div class="fh-main">
          <h2 id="fhName">${esc(p.name || "Unnamed patient")}</h2>
          <div class="muted" id="fhMeta"></div>
        </div>
        <div class="fh-actions">
          <button class="ghost-btn" data-act="back" type="button">← All patients</button>
          <button class="ghost-btn" data-act="copy" type="button">Copy as text</button>
          <button class="ghost-btn" data-act="print" type="button">Print</button>
          <button class="danger-btn" data-act="delete" type="button">Delete</button>
        </div>
      </div>
      <div id="saveInd" class="save-ind"></div>

      <section class="card"><h3>Details</h3><div class="form-grid">${demo}</div></section>
      <section class="card"><div class="card-head"><h3>Case-taking</h3>
        <button class="mini-btn plain" data-act="aifind" type="button" title="Turn these notes into repertory rubrics">✨ Find rubrics from these notes</button></div>
        <div class="form-grid">${clin}</div></section>

      <section class="card" id="fileCases"></section>
      <section class="card" id="fileVisits"></section>`;
    updateMeta(p);
    root.querySelectorAll("textarea").forEach(autoGrow);
    renderFileCases(p);
    renderVisits(p);
  }

  function updateMeta(p) {
    const el = $("fhMeta");
    if (el) el.textContent = [p.age ? p.age + " yrs" : "", p.sex, p.phone, p.occupation].filter(Boolean).join(" · ");
    const n = $("fhName");
    if (n) n.textContent = p.name || "Unnamed patient";
  }
  function autoGrow(ta) {
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight + 2, 420) + "px";
  }

  let indTimer;
  function savePatientFields() {
    const p=db.patients[db.activeId];if(!p)return;
    const next=ORClone(p);
    root.querySelectorAll('[data-f]').forEach(el=>{next[el.dataset.f]=el.value;});next.updatedAt=Date.now();
    const indicator=$('saveInd');
    try {
      ORStorage.patient(next,db.activeId);
      ORRestoreObject(p,next);committedDb.patients[p.id]=ORClone(next);
      updateMeta(p);refreshMenu();OR.renderCaseSelect();
      if(indicator)indicator.textContent='Saved ✓';
      clearTimeout(indTimer);indTimer=setTimeout(()=>{if($('saveInd'))$('saveInd').textContent='';},1800);
      return true;
    }catch(error){if(indicator)indicator.textContent='Not saved — keep this screen open and retry';ORReportError(error.message);return false;}
  }
  root.addEventListener('input',event=>{
    const el=event.target.closest('[data-f]');if(!el)return;
    if(el.tagName==='TEXTAREA')autoGrow(el);
    savePatientFields();
  });
  OR.flushPatientEdits=()=>{if(S.page==='file')savePatientFields();};

  // ---- cases block and unified clinical workspace
  let workspaceCaseId = null;
  function renderFileCases(p) {
    const box = $("fileCases");
    const cs = casesOf(p.id);
    const unlinked = Object.values(S.cases).filter(c => !c.patientId);
    if (!cs.some(c => c.id === workspaceCaseId)) workspaceCaseId = cs[0] ? cs[0].id : null;
    const rows = cs.map(c => {
      const r = OR.rankCase(c)[0];
      const top = r ? `Top: <b>${esc(r.abbr)}</b> (${r.count}/${c.analysis.length})` : "no rubrics yet";
      return `<div class="row-card"><div class="rc-main"><b>${esc(c.name)}</b>
        <div class="muted small-note">${c.analysis.length} rubric${c.analysis.length === 1 ? "" : "s"} · ${top}</div></div>
        <button class="mini-btn plain" data-workspace-case="${esc(c.id)}" type="button">Open workspace</button><button class="mini-btn plain" data-open-case="${esc(c.id)}" type="button">Analysis</button></div>`;
    }).join("");
    box.innerHTML = `
      <div class="card-head"><h3>Repertory cases</h3>
        <button class="mini-btn plain" data-act="newcase" type="button">+ New case</button></div>
      ${rows || `<p class="muted small-note">No repertorisation cases linked to this patient yet.</p>`}
      ${unlinked.length ? `<div class="link-row"><select id="linkCaseSel" class="sel">${unlinked.map(c => `<option value="${esc(c.id)}">${esc(c.name)} (${c.analysis.length})</option>`).join("")}</select>
        <button class="mini-btn plain" data-act="linkcase" type="button">Link existing case</button></div>` : ""}
      <div id="caseWorkspace"></div>`;
    renderCaseWorkspace(p, cs.find(c => c.id === workspaceCaseId));
  }

  function renderCaseWorkspace(p, c) {
    const root = $("caseWorkspace");
    if (!root) return;
    if (!c) { root.innerHTML = `<div class="case-workspace-empty">Select or create a case to open the clinical workspace.</div>`; return; }
    const top = OR.rankCase(c).slice(0, 3);
    const latest = (p.visits || []).slice().sort((a, b) => (b.date || "").localeCompare(a.date || ""))[0];
    const prescriptions = (p.visits || []).filter(v => v.rx).slice().sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    const symptoms = CLIN.filter(([key]) => (p[key] || "").trim()).slice(0, 5);
    root.innerHTML = `<section class="case-workspace"><div class="case-workspace-head"><div><span class="eyebrow">CASE WORKSPACE</span><h3>${esc(c.name)}</h3><p>${esc([p.name || "Unnamed patient", c.analysis.length + " selected rubrics"].join(" · "))}</p></div><div class="case-workspace-actions"><button class="primary-btn" data-open-workspace-analysis="${esc(c.id)}" type="button">Open analysis</button><button class="ghost-btn" data-act="snapshot-case" type="button">Save snapshot</button></div></div>
      <div class="case-workspace-grid"><section class="case-section"><h4>Symptoms and case-taking</h4>${symptoms.length ? symptoms.map(([key, label]) => `<div class="case-note"><b>${esc(label)}</b><span>${esc(p[key])}</span></div>`).join("") : `<p class="muted small-note">No case-taking notes recorded yet.</p>`}</section>
      <section class="case-section"><h4>Selected rubrics <span class="tab-badge">${c.analysis.length}</span></h4>${c.analysis.length ? `<div class="case-rubric-list">${c.analysis.slice(0, 8).map(item => `<button class="case-rubric" data-workspace-rubric="${esc(item.text)}" type="button"><span>${esc(item.chapter)}</span><b>${esc(item.text)}</b></button>`).join("")}${c.analysis.length > 8 ? `<p class="muted small-note">+ ${c.analysis.length - 8} more rubrics in Analysis</p>` : ""}</div>` : `<p class="muted small-note">Add rubrics from the Repertory.</p>`}</section>
      <section class="case-section"><h4>Analysis and evidence</h4>${top.length ? `<div class="case-remedy-list">${top.map((r, i) => `<button class="case-remedy" data-workspace-remedy="${esc(r.abbr)}" type="button"><span class="remedy-rank">${i + 1}</span><span><b>${esc(OR.state.remedies[r.abbr] || r.abbr)}</b><small>${r.coveragePct}% coverage${c.repertoryId==='clarke' ? "" : ` · average grade ${r.averageGrade.toFixed(2)}`}</small></span></button>`).join("")}</div>` : `<p class="muted small-note">Run repertorisation after selecting rubrics.</p>`}</section>
      <section class="case-section"><h4>Prescription history</h4>${prescriptions.length ? prescriptions.slice(0, 4).map(v => `<div class="case-history-row"><span><b>${esc(v.rx)}</b><small>${esc(fmtDate(v.date))}${v.potency ? " · " + esc(v.potency) : ""}</small></span></div>`).join("") : `<p class="muted small-note">No prescription recorded yet.</p>`}</section>
      <section class="case-section"><h4>Follow-up status</h4>${latest && latest.followup ? `<div class="followup-summary"><b>Next follow-up</b><span>${esc(fmtDate(latest.followup))}</span>${latest.complaint ? `<small>${esc(latest.complaint)}</small>` : ""}</div>` : `<p class="muted small-note">No follow-up scheduled. Add a visit to record response and next date.</p>`}</section>
      <section class="case-section"><h4>Snapshot history <span class="tab-badge">${(c.snapshots || []).length}</span></h4>${c.snapshots && c.snapshots.length ? c.snapshots.slice().reverse().slice(0, 4).map(s => `<div class="case-history-row"><span><b>${esc(new Date(s.savedAt).toLocaleDateString())}</b><small>${esc(s.method || "analysis")} · ${(s.ranking || []).length} remedies preserved</small></span></div>`).join("") : `<p class="muted small-note">No snapshots saved yet.</p>`}</section></div></section>`;
  }

  // ---- visits block
  function renderVisits(p) {
    const box = $("fileVisits");
    const vs = (p.visits || []).slice().sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    box.innerHTML = `
      <div class="card-head"><h3>Visits &amp; prescriptions <span class="tab-badge">${vs.length}</span></h3>
        <button class="mini-btn plain" data-act="addvisit" type="button">+ Add visit</button></div>
      ${vs.length ? vs.map(v => `
        <div class="visit" data-vid="${esc(v.id)}">
          <div class="v-top"><span class="v-date">${esc(fmtDate(v.date))}</span>
            ${v.rx ? `<span class="v-rx">℞ ${esc(v.rx)}${v.potency ? " · " + esc(v.potency) : ""}</span>` : ""}
            ${v.followup ? `<span class="v-fu">↻ follow-up ${esc(fmtDate(v.followup))}</span>` : ""}
            <span class="v-btns"><button class="mini-btn plain" data-edit-visit="${esc(v.id)}" type="button">Edit</button>
            <button class="mini-btn danger" data-del-visit="${esc(v.id)}" type="button">Delete</button></span></div>
          ${v.complaint ? `<div class="v-text">${esc(v.complaint)}</div>` : ""}
          ${v.notes ? `<div class="v-notes">${esc(v.notes)}</div>` : ""}
        </div>`).join("") : `<p class="muted small-note">No visits recorded. Add the first consultation, prescription or follow-up.</p>`}`;
  }

  function visitDialog(p, v, resume) {
    const isNew = !v;
    v = v || { id: resume?.context?.visitId || OR.uid(), date: today(), complaint: "", rx: "", potency: "", notes: "", followup: "" };
    OR.modal({
      title: isNew ? "Add visit" : "Edit visit", wide: true,
      draftKey:`visit_${p.id}_${v.id}`, draftContext:{type:"visit",patientId:p.id,visitId:v.id},
      html: `<div class="form-grid">
        <label class="fld"><span>Date</span><input data-k="date" type="date" value="${esc(v.date)}"></label>
        <label class="fld"><span>Prescription (remedy)</span><input data-k="rx" type="text" value="${esc(v.rx)}" placeholder="e.g. Puls."></label>
        <label class="fld"><span>Potency &amp; dose</span><input data-k="potency" type="text" value="${esc(v.potency)}" placeholder="e.g. 200C, single dose"></label>
        <label class="fld"><span>Follow-up on</span><input data-k="followup" type="date" value="${esc(v.followup || "")}"></label>
        <label class="fld full"><span>Complaint / progress</span><textarea data-k="complaint" rows="3">${esc(v.complaint)}</textarea></label>
        <label class="fld full"><span>Notes / follow-up plan</span><textarea data-k="notes" rows="4">${esc(v.notes)}</textarea></label>
      </div>`,
      actions: [
        { label: "Cancel" },
        {
          label: "Save visit", primary: true,
          onClick: m => {
            m.querySelectorAll("[data-k]").forEach(el => { v[el.dataset.k] = el.value.trim(); });
            if (!v.date) v.date = today();
            p.visits = p.visits || [];
            if (isNew) p.visits.push(v);
            p.updatedAt = Date.now();
            save();
            refreshMenu();
            renderVisits(p); renderFileCases(p);
          }
        }
      ]
    });
  }

  // ---- delegated clicks inside the file
  root.addEventListener("click", async e => {
    try {
    const p = db.patients[db.activeId];
    if (!p) return;
    const t = e.target.closest("button");
    if (!t) return;
    if (t.dataset.workspaceCase) { workspaceCaseId = t.dataset.workspaceCase; renderFileCases(p); return; }
    if (t.dataset.openWorkspaceAnalysis) { OR.openCase(t.dataset.openWorkspaceAnalysis); return; }
    if (t.dataset.workspaceRemedy) { OR.openMateriaRemedy(t.dataset.workspaceRemedy); return; }
    if (t.dataset.workspaceRubric) { OR.showPage("repertory"); OR.runSearch(t.dataset.workspaceRubric); return; }
    if (t.dataset.openCase) return OR.openCase(t.dataset.openCase);
    if (t.dataset.editVisit) {
      const v = (p.visits || []).find(x => x.id === t.dataset.editVisit);
      if (v) visitDialog(p, v);
      return;
    }
    if (t.dataset.delVisit) {
      if (await OR.confirm("Delete visit", "Delete this visit entry? This can't be undone.")) {
        p.visits = p.visits.filter(x => x.id !== t.dataset.delVisit);
        save(); renderVisits(p); renderFileCases(p);
      }
      return;
    }
    switch (t.dataset.act) {
      case "back": OR.showPage("patients"); break;
      case "snapshot-case": {
        const c = S.cases[workspaceCaseId];
        if (!c || !c.analysis.length) { OR.toast("Add rubrics before saving a snapshot."); break; }
        OR.setActiveCase(c.id);
        if (OR.saveCaseSnapshot(c)) renderCaseWorkspace(p, c);
        break;
      }
      case "addvisit": visitDialog(p, null); break;
      case "newcase": {
        const name = await OR.ask("New case", `${p.name || "Patient"} — case ${casesOf(p.id).length + 1}`, "Case name");
        if (name === null) return;
        OR.newCase(name, p.id);
        OR.showPage("analysis");
        break;
      }
      case "linkcase": {
        const sel = $("linkCaseSel");
        if (sel && S.cases[sel.value]) {
          S.cases[sel.value].patientId = p.id;
          OR.saveCases(); OR.renderCaseSelect(); renderFileCases(p);
        }
        break;
      }
      case "aifind": {
        const parts = CLIN.slice(0, 5).filter(([k]) => (p[k] || "").trim())
          .map(([k, label]) => `${label.split("  ")[0]}: ${p[k].trim()}`);
        if (!parts.length) { OR.toast("Fill in the case-taking notes first."); break; }
        const cs = casesOf(p.id).slice(-1)[0];
        if (cs) OR.setActiveCase(cs.id); else OR.newCase(`${p.name || "Patient"} — case 1`, p.id);
        OR.finder.open(parts.join("\n"), { run: true });
        break;
      }
      case "copy": copyText(p); break;
      case "print": try { window.ORPrint(patientText(p), `Patient file — ${p.name || "Unnamed"}`); } catch (err) { OR.toast("Printing isn't available here — use Copy as text."); } break;
      case "delete":
        if (await OR.confirm("Delete patient", `Delete ${p.name || "this patient"} and all their visits? Linked repertory cases are kept but unlinked. This can't be undone.`)) {
          const nextDb=ORClone(db),nextCases=ORClone(S.cases);
          Object.values(nextCases).filter(c=>c.patientId===p.id).forEach(c=>{c.patientId=null;});
          delete nextDb.patients[p.id];nextDb.activeId=null;
          if(!OR.store.batch({[KEY]:nextDb,openrepertory_cases:{cases:nextCases,activeCaseId:S.activeCaseId}}))throw new Error('Patient deletion was not saved. Existing records remain unchanged.');
          db=nextDb;committedDb=ORClone(db);S.cases=nextCases;OR.rememberCases();
          refreshMenu();OR.renderCaseSelect();
          OR.showPage("patients");
        }
        break;
    }
    }catch(error){ORReportError(error.message);OR.toast("Changes were not saved. Please retry.");}
  });

  function patientText(p) {
    const L = [`PATIENT FILE — ${p.name || "Unnamed"}`];
    const meta = [p.age ? p.age + " yrs" : "", p.sex, p.phone, p.occupation, p.address].filter(Boolean).join(" · ");
    if (meta) L.push(meta);
    CLIN.forEach(([k, label]) => { if (p[k]) L.push("", label.split("  ")[0].toUpperCase(), p[k]); });
    const cs = casesOf(p.id);
    if (cs.length) {
      L.push("", "REPERTORY CASES");
      cs.forEach(c => {
        const r = OR.rankCase(c)[0];
        L.push(`- ${c.name}: ${c.analysis.length} rubrics${r ? `, top ${r.abbr} (${r.count}/${c.analysis.length})` : ""}`);
      });
    }
    const vs = (p.visits || []).slice().sort((a, b) => (a.date || "").localeCompare(b.date || ""));
    if (vs.length) {
      L.push("", "VISITS");
      vs.forEach(v => {
        L.push(`${fmtDate(v.date)}${v.rx ? " — Rx " + v.rx + (v.potency ? " " + v.potency : "") : ""}${v.followup ? " (follow-up " + fmtDate(v.followup) + ")" : ""}`);
        if (v.complaint) L.push("  " + v.complaint);
        if (v.notes) L.push("  " + v.notes.replace(/\n/g, "\n  "));
      });
    }
    return L.join("\n");
  }
  async function copyText(p) {
    const text = patientText(p);
    try { await navigator.clipboard.writeText(text); OR.toast("Patient file copied."); return true; }
    catch (e) {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      let ok = false; try { ok = document.execCommand("copy"); } catch (e2) { ok = false; }
      document.body.removeChild(ta);
      if (ok) { OR.toast("Patient file copied."); return true; }
    }
    OR.toast("Copy failed. Select the text manually and try again."); return false;
  }

  OR.pages.file = { onShow: renderFile };

  // called from Analysis: "Save ranking to patient file"
  function addVisitFromCase(pid, caseName, note) {
    const p = db.patients[pid];
    if (!p) return;
    p.visits = p.visits || [];
    p.visits.push({ id: OR.uid(), date: today(), complaint: `Repertorisation — ${caseName}`, rx: "", potency: "", notes: note, followup: "" });
    p.updatedAt = Date.now();
    save();
  }

  OR.patients = { open: openFile, refreshMenu, addVisitFromCase, openBackup,
    validateBackup:validateImport,
    resumeDraft(key){
      const draft=OR.drafts.list()[key];if(!draft)return;
      if(draft.context.type==='patient')return newPatientDialog(draft);
      const p=db.patients[draft.context.patientId];if(!p){OR.toast('The patient for this draft is unavailable.');return;}
      const v=(p.visits||[]).find(v=>v.id===draft.context.visitId);visitDialog(p,v||null,draft);
    }
  };

  // keep Analysis' patient dropdown & file in sync when cases change elsewhere
  OR.hooks.casesChanged.push(() => { if (S.page === "file") renderFile(); });

  // ================= BACKUP / RESTORE =================
  function snapshot() {
    return {
      app: "openrepertory", version: 1, exportedAt: new Date().toISOString(),
      cases: { cases: S.cases, activeCaseId: S.activeCaseId },
      patients: db,
      mmNotes: OR.mmNotes || {}
    };
  }

  async function saveFile(name, text) {
    if (window.openrepertorySecure) {
      const result = await ORNativeRequest("saveDocument", [name, text], null, 600000);
      return result === "saved";
    }
    try {
      const dl = window.claude && window.claude.use ? await window.claude.use("downloads") : null;
      if (dl) { await dl.save({ filename: name, data: text }); return true; }
    } catch (e) {
      if (e && e.code === "declined") return false;
    }
    try {
      const url = URL.createObjectURL(new Blob([text], { type: "application/json" }));
      const a = document.createElement("a");
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      return true;
    } catch (e) { return false; }
  }

  function isRecord(value) { return !!value && typeof value === "object" && !Array.isArray(value); }
  function validateImport(data) {
    if (!isRecord(data) || data.app !== "openrepertory") throw new Error("This isn't an Open Repertory backup file.");
    function safeTree(value,depth=0){
      if(depth>32)throw new Error('Backup nesting exceeds the supported limit.');
      if(value&&typeof value==='object')for(const key of Object.keys(value)){
        if(['__proto__','constructor','prototype'].includes(key))throw new Error('Backup contains an unsafe field.');
        safeTree(value[key],depth+1);
      }
    }
    safeTree(data);
    if (data.version !== 1) throw new Error("This backup version is not supported.");
    const patientsData = data.patients;
    const casesData = data.cases;
    if (!isRecord(patientsData) || !isRecord(casesData)) throw new Error("The backup is missing its patients or cases section.");
    const inP = patientsData.patients;
    const inC = casesData.cases;
    const notes = data.mmNotes === undefined ? {} : data.mmNotes;
    if (!isRecord(inP) || !isRecord(inC) || !Object.keys(inC).length || !isRecord(notes)) {
      throw new Error("The backup has an invalid patients, cases, or notes collection.");
    }
    if ((patientsData.activeId != null && typeof patientsData.activeId !== "string") || (casesData.activeCaseId != null && typeof casesData.activeCaseId !== "string")) {
      throw new Error("The backup has an invalid active patient or case reference.");
    }
    const safeIdKey = key => /^[A-Za-z0-9_-]{1,120}$/.test(key) && !["__proto__", "constructor", "prototype"].includes(key);
    const safeKeys = map => Object.keys(map).every(key => !["__proto__", "constructor", "prototype"].includes(key) && safeIdKey(key));
    if (!safeKeys(inP) || !safeKeys(inC) || !Object.keys(notes).every(key => key.length <= 120 && !/[\x00-\x1f]/.test(key) && !["__proto__", "constructor", "prototype"].includes(key))) throw new Error("The backup contains an unsafe record key.");
    for (const [id, patient] of Object.entries(inP)) {
      if (!isRecord(patient) || patient.id !== id || typeof patient.name !== "string" || (patient.visits !== undefined && !Array.isArray(patient.visits))) {
        throw new Error("A patient record is incomplete or malformed.");
      }
      if ([...DEMO, ...CLIN].some(([key]) => patient[key] !== undefined && typeof patient[key] !== "string")) throw new Error("A patient field must contain text.");
      if (patient.visits && patient.visits.some(visit => !isRecord(visit) || !safeIdKey(String(visit.id || "")) || ["date", "complaint", "rx", "potency", "notes", "followup"].some(k => visit[k] !== undefined && typeof visit[k] !== "string"))) throw new Error("A patient visit record is malformed.");
    }
    for (const [id, item] of Object.entries(inC)) {
      if (!isRecord(item) || item.id !== id || typeof item.name !== "string" || !Array.isArray(item.analysis)) {
        throw new Error("A case record is incomplete or malformed.");
      }
      if (item.analysis.some(rubric => !isRecord(rubric) || typeof rubric.uid !== "string" || typeof rubric.chapter !== "string" || typeof rubric.text !== "string" || !Array.isArray(rubric.remedies) || (rubric.w !== undefined && ![1, 2, 3, 4, 5].includes(Number(rubric.w))) || rubric.remedies.some(remedy => !isRecord(remedy) || typeof remedy.r !== "string" || ![1, 2, 3].includes(Number(remedy.g))))) {
        throw new Error("A case contains a malformed rubric or remedy grade.");
      }
      if (item.snapshots !== undefined) {
        if (!Array.isArray(item.snapshots)) throw new Error("A case contains malformed snapshots.");
        for (const snap of item.snapshots) {
          if (!isRecord(snap) || !Array.isArray(snap.rubrics)) throw new Error("A snapshot is malformed.");
          for (const rubric of snap.rubrics) {
            if (!isRecord(rubric) || typeof rubric.uid !== "string" || typeof rubric.chapter !== "string" || typeof rubric.text !== "string" || !Array.isArray(rubric.remedies)) throw new Error("A snapshot rubric is malformed.");
            if (rubric.remedies.some(r => !isRecord(r) || typeof r.r !== "string" || ![1,2,3].includes(Number(r.g)))) throw new Error("A snapshot remedy grade is invalid.");
          }
        }
      }
    }
    if (Object.values(notes).some(note => typeof note !== "string")) throw new Error("A remedy note must be text.");
    return { inP, inC, notes, activeId: patientsData.activeId, activeCaseId: casesData.activeCaseId };
  }

  function applyImport(data, replace) {
    const { inP, inC, notes, activeId, activeCaseId } = validateImport(data);
    const nextDb = replace ? { patients: inP, activeId: activeId || null }
      : { patients: { ...db.patients, ...inP }, activeId: db.activeId };
    const nextCases = replace ? inC : { ...S.cases, ...inC };
    const nextNotes = replace ? notes : { ...(OR.mmNotes || {}), ...notes };
    let nextActive = replace ? activeCaseId : S.activeCaseId;
    if (!nextCases[nextActive]) nextActive = Object.keys(nextCases)[0];
    if (nextDb.activeId && !nextDb.patients[nextDb.activeId]) nextDb.activeId = null;
    // All three collections and recovery state commit in one encrypted atomic file write.
    const values = {
      [KEY]: nextDb,
      openrepertory_cases: { cases: nextCases, activeCaseId: nextActive },
      openrepertory_mmnotes: nextNotes,
      openrepertory_preimport_recovery: snapshot()
    };
    if (!OR.store.batch(values)) throw new Error("Import was not saved. Existing records remain unchanged.");
    db = nextDb; committedDb=ORClone(db); S.cases = nextCases; S.activeCaseId = nextActive; OR.mmNotes = nextNotes;OR.rememberCases();if(OR.rememberMMNotes)OR.rememberMMNotes();
    OR.hooks.casesChanged.forEach(fn => fn());
    refreshMenu(); OR.renderCaseSelect();
    if (OR.pages[S.page] && OR.pages[S.page].onShow) OR.pages[S.page].onShow();
    return { patients: Object.keys(inP).length, cases: Object.keys(inC).length };
  }

  const encryptBackup=password=>ORBackup.encrypt(snapshot(),password);
  const decryptBackup=(text,password)=>ORBackup.decrypt(text,password);

  function openBackup() {
    const json = JSON.stringify(snapshot(), null, 1);
    const stamp = today();
    OR.modal({
      title: "Backup & restore", wide: true,
      html: `
        <h4 class="mh">Export</h4>
        <p class="muted small-note">${Object.keys(db.patients).length} patient(s), ${Object.keys(S.cases).length} case(s), ${Object.keys(OR.mmNotes || {}).length} remedy note(s). The file contains patient data — keep it private.</p>
        <div class="btn-row"><button class="ghost-btn" id="bkSave" type="button">Export unencrypted JSON</button>
        <button class="ghost-btn" id="bkCopy" type="button">Copy to clipboard</button></div>
        <label class="fld"><span>Encryption password (8+ characters)</span><input id="bkEncPass" type="password" autocomplete="new-password"></label>
        <div class="btn-row"><button class="primary-btn" id="bkSaveEnc" type="button">Save encrypted backup</button></div>
        <h4 class="mh">Recovery</h4><button class="ghost-btn" id="bkRecover" type="button">Restore state before last import</button><h4 class="mh">Import</h4>
        <label class="fld"><span>Choose a backup file</span><input type="file" id="bkFile" accept=".json,.orbk,application/json,application/octet-stream"></label>
        <label class="fld"><span>…or paste backup text</span><textarea id="bkText" rows="4" placeholder="Paste the backup JSON or ORBK2 encrypted backup here"></textarea></label>
        <label class="fld"><span>Password for encrypted backup</span><input id="bkImportPass" type="password" autocomplete="current-password"></label>
        <div class="btn-row"><button class="ghost-btn" id="bkMerge" type="button">Import &amp; merge</button>
        <button class="danger-btn" id="bkReplace" type="button">Import &amp; replace all</button></div>
        <p class="muted small-note"><b>Merge</b> adds records and overwrites ones with the same id. <b>Replace</b> discards everything currently in this browser.</p>
        <p class="msg" id="bkMsg"></p>`,
      actions: [{ label: "Close", primary: true }],
      noFocus: true,
      onMount: m => {
        const msg = t => { m.querySelector("#bkMsg").textContent = t; };
        m.querySelector("#bkRecover").addEventListener("click", async () => {
          const recovery = OR.store.get("openrepertory_preimport_recovery");
          if (!recovery) return msg("No previous import recovery is available.");
          if (!await OR.confirm("Restore previous state", "Restore the records saved immediately before the last import?", "Restore")) return;
          try { applyImport(recovery, true); msg("Previous records restored."); } catch (error) { msg(error.message); }
        });
        m.querySelector("#bkSave").addEventListener("click", async () => {
          if (!await OR.confirm("Unencrypted export", "This file contains readable patient information. Save an unencrypted copy?", "Export")) return;
          const ok = await saveFile(`openrepertory-backup-${stamp}.json`, JSON.stringify(snapshot(), null, 1));
          msg(ok ? "Backup saved." : "Export cancelled.");
        });
        m.querySelector("#bkSaveEnc").addEventListener("click", async () => {
          const pass = m.querySelector("#bkEncPass").value;
          if (pass.length < 8) return msg("Use an encryption password of at least 8 characters.");
          try {
            const enc = await encryptBackup(pass);
            const ok = await saveFile(`openrepertory-backup-${stamp}.orbk`, enc);
            if (ok) {
              let reminderWarning = "";
              try { OR.store.set("openrepertory_backup_meta", {savedAt:Date.now()}); }
              catch (_) { reminderWarning = " The backup reminder could not be updated on this device."; }
              msg("Encrypted backup saved. Keep the password safe — it cannot be recovered." + reminderWarning);
            } else msg("Export cancelled.");
          } catch (e) { msg(e.message || "Encryption or saving failed. Please retry."); }
        });
        m.querySelector("#bkCopy").addEventListener("click", async () => {
          try { await navigator.clipboard.writeText(json); msg("Backup copied to clipboard."); }
          catch (e) { msg("Clipboard is blocked here — use “Save backup file” instead."); }
        });
        m.querySelector("#bkFile").addEventListener("change", e => {
          const f = e.target.files && e.target.files[0];
          if (!f) return;
          if (f.size > 16 * 1024 * 1024) return msg("Backup must be smaller than 16 MB.");
          const r = new FileReader();
          r.onerror = () => msg("File could not be read. Choose another file.");
          r.onload = () => { m.querySelector("#bkText").value = String(r.result); msg("File loaded — choose Merge or Replace."); };
          r.readAsText(f);
        });
        async function doImport(replace) {
          const raw = m.querySelector("#bkText").value.trim();
          if (raw.length > 16 * 1024 * 1024) return msg("Backup must be smaller than 16 MB.");
          if (!raw) return msg("Choose a file or paste backup text first.");
          let data;
          try {
            data = raw.startsWith("ORBK2.")
              ? await decryptBackup(raw, m.querySelector("#bkImportPass").value)
              : JSON.parse(raw);
          } catch (e) { return msg(e.message || "That text isn't valid JSON."); }
          if (replace && !await OR.confirm("Replace everything", "This replaces all patients, cases and remedy notes in this browser with the backup. Continue?", "Replace")) return;
          try {
            const n = applyImport(data, replace);
            msg(`Imported ${n.patients} patient(s) and ${n.cases} case(s).`);
          } catch (e) { msg(e.message); }
        }
        m.querySelector("#bkMerge").addEventListener("click", () => doImport(false));
        m.querySelector("#bkReplace").addEventListener("click", () => doImport(true));
      }
    });
  }
})();
