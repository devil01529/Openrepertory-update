/* Search semantics shared by the background worker's indexing and query stages. */
(function(scope){
  'use strict';
  function norm(a){return a.toLowerCase().replace(/\.$/,'');}
  function distance(a,b){if(a===b)return 0;if(Math.abs(a.length-b.length)>2)return 99;let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const row=[i];for(let j=1;j<=b.length;j++)row[j]=Math.min(row[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=row;}return prev[b.length];}
  scope.ORSearchEngine={
    build(rep){
      const entries=[],terms=new Map(),chapters=new Map();
      const add=entry=>{const i=entries.length;entries.push(entry);if(!chapters.has(entry.chapter))chapters.set(entry.chapter,[]);chapters.get(entry.chapter).push(i);new Set((entry.path+' '+entry.remedies.join(' ')).split(/[^a-z0-9-]+/).filter(Boolean)).forEach(term=>{if(!terms.has(term))terms.set(term,new Set());terms.get(term).add(i);});};
      rep.chapters.forEach(ch=>ch.rubrics.forEach(r=>{
        const path=(ch.name+' '+r.text).toLowerCase();
        add({chapter:ch.name,id:r.id,sub:-1,path,words:path.split(/[^a-z0-9]+/).filter(Boolean),remedies:(r.remedies||[]).reduce((out,x)=>out.concat([norm(x.r)].concat(x.sourceAbbreviation?[norm(x.sourceAbbreviation).replace(/\s+/g,'')]:[])),[])});
        (r.sub||[]).forEach((s,si)=>{const full=path+' '+s.text.toLowerCase();add({chapter:ch.name,id:r.id,sub:si,path:full,words:full.split(/[^a-z0-9]+/).filter(Boolean),remedies:(s.remedies||[]).reduce((out,x)=>out.concat([norm(x.r)].concat(x.sourceAbbreviation?[norm(x.sourceAbbreviation).replace(/\s+/g,'')]:[])),[])});});
      }));
      return{entries,terms,chapters};
    },
    query(index,variants,chapter){
      const final=new Map();
      for(const variant of variants){
        const tokens=variant.toLowerCase().split(/[\s,]+/).filter(Boolean),sets=tokens.map(t=>index.terms.get(t));let candidate;
        if(sets.every(Boolean)){const ordered=sets.slice().sort((a,b)=>a.size-b.size);candidate=[...ordered[0]].filter(i=>ordered.every(set=>set.has(i)));}
        else candidate=chapter?(index.chapters.get(chapter)||[]):index.entries.map((_,i)=>i);
        const groups=new Map();
        for(const i of candidate){
          const e=index.entries[i];if(chapter&&e.chapter!==chapter)continue;
          if(!tokens.every(t=>e.path.includes(t)||e.remedies.includes(t)||(t.length>=5&&e.words.some(w=>distance(w,t)<=(t.length>=8?2:1)))))continue;
          const key=e.chapter+'||'+e.id;if(!groups.has(key))groups.set(key,{chapter:e.chapter,id:e.id,subs:[],topMatch:false,matchReason:''});const g=groups.get(key);
          if(e.sub<0){g.topMatch=true;g.matchReason=e.path.includes(tokens.join(' '))?'Exact heading/path match':'Heading or remedy match';}else{g.subs.push(e.sub);if(!g.topMatch)g.matchReason='Sub-rubric match';}
        }
        for(const [key,value]of groups)final.set(key,value);
      }
      return [...final.values()].sort((a,b)=>Number(b.topMatch)-Number(a.topMatch)||a.chapter.localeCompare(b.chapter));
    }
  };
})(typeof self!=='undefined'?self:window);
