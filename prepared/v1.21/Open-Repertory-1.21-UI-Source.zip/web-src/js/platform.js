/* Native integration shared by the packaged APK and browser development preview. */
(function () {
  'use strict';
  const native = window.openrepertorySecure;
  const pending = new Map();
  let seq = 0;
  window.ORNativeComplete = (id, value, error) => {
    const request = pending.get(id);
    if (!request) return;
    pending.delete(id); request.cleanup();
    if (error) request.reject(new Error(error)); else request.resolve(value);
  };
  window.ORNativeRequest = (method, args, signal, timeout = 90000) => new Promise((resolve, reject) => {
    if (!native || typeof native[method] !== 'function') return reject(new Error('Android feature is unavailable'));
    const id = 'req_' + Date.now() + '_' + (++seq);
    let timer;
    const abort = () => {
      try { native.cancel(id); } catch (_) {}
      const error = new Error('Stopped.'); error.code = 'cancelled';
      pending.delete(id); cleanup(); reject(error);
    };
    const cleanup = () => { clearTimeout(timer); if (signal) signal.removeEventListener('abort', abort); };
    if (signal && signal.aborted) return abort();
    pending.set(id, { resolve, reject, cleanup });
    if (signal) signal.addEventListener('abort', abort, { once: true });
    timer = setTimeout(() => {
      try { native.cancel(id); } catch (_) {}
      pending.delete(id); cleanup(); reject(new Error('Request timed out. Please retry.'));
    }, timeout);
    try { native[method](id, ...args); }
    catch (error) { pending.delete(id); cleanup(); reject(error); }
  });

  window.ORPrint = (text,title) => {
    if(typeof text==='string'){
      let report=document.getElementById('printReport');if(!report){report=document.createElement('article');report.id='printReport';document.body.appendChild(report);}
      report.textContent="";const h=document.createElement('h1');h.textContent=title||'Open Repertory report';const body=document.createElement('pre');body.textContent=text;report.append(h,body);document.body.classList.add('report-mode');
    }else document.body.classList.remove('report-mode');
    if(native?.printDocument)native.printDocument();else window.print();
  };

  const ENVELOPE = 'openrepertory_browser_store_v2';
  const sensitive = ['openrepertory_cases', 'openrepertory_analysis', 'openrepertory_patients', 'openrepertory_mmnotes'];
  function readMap() { return JSON.parse(localStorage.getItem(ENVELOPE) || '{}'); }
  window.ORClone = value => JSON.parse(JSON.stringify(value));
  window.ORRestoreObject = function restore(target,source) {
    for(const key of Object.keys(target))if(!(key in source))delete target[key];
    for(const [key,value] of Object.entries(source)){
      if(value && typeof value==='object' && target[key] && typeof target[key]==='object' && Array.isArray(value)===Array.isArray(target[key]))restore(target[key],value);
      else target[key]=value && typeof value==='object'?ORClone(value):value;
    }
    if(Array.isArray(target))target.length=source.length;
    return target;
  };
  const storage = window.ORStorage = {
    native: !!native,
    read(key) { const raw = native ? native.read(key) : readMap()[key]; return raw == null ? null : String(raw); },
    batch(values) {
      const raw = Object.fromEntries(Object.entries(values).map(([k, v]) => [k, v === null ? null : JSON.stringify(v)]));
      if (native) {
        if (native.writeBatch(JSON.stringify(raw)) !== 'ok') throw new Error('Encrypted records could not be saved. Keep this screen open and export a backup.');
      } else {
        const next = readMap();
        for (const [k,v] of Object.entries(raw)) { if (v === null) delete next[k]; else next[k] = v; }
        localStorage.setItem(ENVELOPE, JSON.stringify(next));
      }
    },
    patient(record, activeId) {
      if(native?.writePatient){if(native.writePatient(JSON.stringify(record),activeId)!=='ok')throw new Error('Patient changes were not saved. Keep this screen open and retry.');}
      else {const current=JSON.parse(storage.read('openrepertory_patients')||'{"patients":{},"activeId":null}');current.patients[record.id]=record;current.activeId=activeId;storage.batch({openrepertory_patients:current});}
    },
    migrate() {
      const changes = {}, remove = [];
      for (const key of sensitive) {
        const old = localStorage.getItem(key);
        if (old !== null) {
          if (storage.read(key) === null) changes[key] = JSON.parse(old);
          remove.push(key);
        }
      }
      if (Object.keys(changes).length) storage.batch(changes);
      for (const key of remove) localStorage.removeItem(key);
      // Previous builds persisted patient wording in recent searches. Keep it in memory now.
      localStorage.removeItem('openrepertory_ai_recent');
    }
  };
  window.ORReportError = message => {
    let banner = document.getElementById('persistentError');
    if (!banner) {
      banner = document.createElement('div'); banner.id = 'persistentError';
      banner.setAttribute('role', 'alert'); document.body.prepend(banner);
    }
    banner.textContent = message;
  };
  window.addEventListener('error', e => { if (e.error) window.ORReportError('An operation failed. ' + e.error.message); });
  window.addEventListener('unhandledrejection', e => window.ORReportError('An operation failed. ' + (e.reason?.message || 'Please retry.')));
})();
