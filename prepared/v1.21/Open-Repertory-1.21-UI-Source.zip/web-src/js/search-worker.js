importScripts('search-engine.js');
let ready=null;
self.onmessage=async event=>{
  const {id,file,variants,chapter}=event.data;
  try{
    if(!ready)ready=fetch('../data/'+file).then(r=>{if(!r.ok)throw new Error('Book unavailable');return r.json();}).then(rep=>ORSearchEngine.build(rep));
    const index=await ready;self.postMessage({id,items:ORSearchEngine.query(index,variants,chapter)});
  }catch(error){ready=null;self.postMessage({id,error:'Search worker is unavailable'});}
};
