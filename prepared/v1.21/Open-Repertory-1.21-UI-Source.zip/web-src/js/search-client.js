(function(){
  'use strict';
  let worker=null,file=null,seq=0;const requests=new Map();
  function reset(){if(worker)worker.terminate();worker=null;for(const pending of requests.values()){clearTimeout(pending.timer);pending.reject(new Error('Search changed'));}requests.clear();}
  window.ORSearch={
    query(source,variants,chapter){
      if(typeof Worker==='undefined')return Promise.reject(new Error('Worker unavailable'));
      if(source!==file){reset();file=source;}
      if(!worker){
        worker=new Worker('js/search-worker.js');
        worker.onmessage=event=>{const request=requests.get(event.data.id);if(!request)return;requests.delete(event.data.id);clearTimeout(request.timer);if(event.data.error)request.reject(new Error(event.data.error));else request.resolve(event.data.items);};
        worker.onerror=()=>reset();
      }
      return new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{requests.delete(id);reject(new Error('Search timed out'));},90000);requests.set(id,{resolve,reject,timer});worker.postMessage({id,file:source,variants,chapter});});
    },
    reset
  };
})();
