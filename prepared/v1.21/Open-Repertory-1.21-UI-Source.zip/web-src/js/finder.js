(function () {
  "use strict";
  // AI Symptom Finder.
  // Turns the patient's own words into repertory searches, then runs those searches
  // against the REAL repertory data - so every rubric shown exists in the book.
  //   * With Claude available (published artifact): Claude reads the text and proposes
  //     concepts + search stems.
  //   * Without it (downloaded copy, or the viewer declined): a built-in phrase list does
  //     a simpler version of the same job.
  const OR = window.OR, S = OR.state, esc = OR.escapeHTML, $ = OR.$;

  // ---------- shared AI handle (also used by materia.js) ----------
  OR.ai = { sample: null, gemini: null, provider: "built-in", ready: false, denied: false };
  const nativeAi = window.openrepertoryNative;
  function nativeHasKey() { try { return !!(nativeAi && nativeAi.hasGeminiKey && nativeAi.hasGeminiKey()); } catch (e) { return false; } }
  function nativeSetKey(key) { try { return !!(nativeAi && nativeAi.setGeminiKey && nativeAi.setGeminiKey(key)); } catch (e) { return false; } }
  function nativeSaveError() { try { return nativeAi && nativeAi.getGeminiSaveError ? nativeAi.getGeminiSaveError() : "storage_unavailable"; } catch (e) { return "storage_unavailable"; } }
  function nativeClearKey() { try { return !!(nativeAi && nativeAi.clearGeminiKey && nativeAi.clearGeminiKey() !== false); } catch (e) { return false; } }
  function parseNative(raw) {
    let cleaned = String(raw || "{}").trim();
    if (cleaned.startsWith("```") && cleaned.endsWith("```")) cleaned = cleaned.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
    const data = JSON.parse(cleaned);
    if (data && data.error) { const e = new Error(data.detail || data.error); e.code = data.error; e.detail = data.detail || ""; throw e; }
    return data;
  }
  async function nativeTestConnection() {
    return parseNative(await ORNativeRequest("geminiAsync", ["", true]));
  }
  async function nativeGemini(prompt, options) {
    const signal = options && options.signal;
    return parseNative(await ORNativeRequest("geminiAsync", [prompt, false], signal));
  }
  function refreshNativeAi() {
    if (nativeHasKey()) { OR.ai.gemini = { interpret: nativeGemini }; OR.ai.provider = "Gemini"; }
    else if (!OR.ai.sample) { OR.ai.gemini = null; OR.ai.provider = "built-in"; }
    engineTag();
  }
  OR.hooks.start.push(() => {
    try {
      if (window.claude && window.claude.use) {
        window.claude.use("sample").then(s => { OR.ai.sample = s || null; if (!OR.ai.gemini) OR.ai.provider = OR.ai.sample ? "Claude" : "built-in"; OR.ai.ready = true; engineTag(); if (OR.onAIReady) OR.onAIReady(); },
          () => { OR.ai.ready = true; engineTag(); });
      } else { OR.ai.ready = true; }
    } catch (e) { OR.ai.ready = true; }
    // A host may inject this bridge after handling Google/Gemini OAuth itself.
    // Tokens never belong in the APK or localStorage; the bridge owns login and refresh.
    if (window.openrepertoryGemini && typeof window.openrepertoryGemini.interpret === "function") {
      OR.ai.gemini = window.openrepertoryGemini;
      OR.ai.provider = "Gemini";
    }
    refreshNativeAi();
    engineTag();
  });
  const OFFLINE_AI = "Offline phrase search";
  const aiOn = () => !!(OR.ai.gemini || OR.ai.sample) && !OR.ai.denied;
  OR.aiAvailable = aiOn;

  OR.openOnlineAi = function () {
    const connected = nativeHasKey();
    OR.modal({
      title: connected ? "Gemini is connected" : "Connect online AI",
      wide: false,
      html: `<p class="modal-msg">Use your own Google AI Studio Gemini API key. The key is encrypted by Android Keystore and is never placed in browser storage or sent to the repertory files. Patient text is sent to Gemini only when Smart Search runs.</p>
        <label class="fld"><span>Gemini API key</span><input id="geminiKeyInput" type="password" autocomplete="off" placeholder="Paste your key here"></label>
        <p class="muted small-note">Create or manage a key at <b>aistudio.google.com/apikey</b>. This connection uses Gemini for symptom interpretation; every result is then looked up in the bundled repertory.</p><p id="geminiTestStatus" class="small-note" aria-live="polite"></p>`,
      actions: [
        ...(connected ? [{ label: "Disconnect", danger: true, onClick: () => { if(!nativeClearKey()){OR.toast("The key could not be removed from storage. Please retry.");return false;} OR.ai.gemini = null; OR.ai.provider = "built-in"; engineTag(); $("menuOnlineAiSub").textContent = "Connect your Gemini API key"; OR.toast("Gemini disconnected."); } }] : []),
        { label: "Test saved connection", onClick: m => {
          const status = m.querySelector("#geminiTestStatus");
          if (status) status.textContent = "Testing Gemini…";
          setTimeout(async () => {
            try { await nativeTestConnection(); if (status) status.textContent = "Gemini connection succeeded."; }
            catch (e) { if (status) status.textContent = "Gemini test failed: " + (e.detail || e.code || "network error") + "."; }
          }, 0);
          return false;
        } },
        { label: "Cancel" },
        { label: connected ? "Replace key" : "Connect Gemini", primary: true, onClick: m => {
          const key = (m.querySelector("#geminiKeyInput") || {}).value || "";
          if (!nativeSetKey(key)) { const why = nativeSaveError(); OR.toast("Gemini key could not be saved (" + why + "). Keep the app open and check available storage."); const status = m.querySelector("#geminiTestStatus"); if (status) status.textContent = "Save failed: " + why; return false; }
          refreshNativeAi(); $("menuOnlineAiSub").textContent = "Gemini connected · key stored securely"; OR.toast("Gemini connected. Smart Search will use it online.");
        }}
      ]
    });
  };

  function engineTag() {
    const t = $("aiEngine");
    if (!t) return;
    t.textContent = aiOn() ? OR.ai.provider : OFFLINE_AI;
    t.className = "ai-engine " + (aiOn() ? "on" : "on");
    t.title = aiOn() ? `${OR.ai.provider} interprets the patient's words; rubric lookup remains local` : "Offline phrase matching searches the patient's words and searches the bundled repertory";
  }

  // ---------- helpers ----------
  const RECENT_KEY = "openrepertory_ai_recent";
  let recentTexts = [];
  const recents = () => recentTexts;
  function pushRecent(text) {
    const l = recents().filter(x => x !== text);
    l.unshift(text);
    recentTexts = l.slice(0, 6);
  }
  const stemTok = w => String(w || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const cleanVariants = v => (Array.isArray(v) ? v : [])
    .map(arr => (Array.isArray(arr) ? arr : String(arr).split(/[\s,]+/)).map(stemTok).filter(t => t.length >= 2))
    .filter(a => a.length).slice(0, 3);

  // ================= interpreters =================
  async function interpretAI(text, signal) {
    if (OR.ai.gemini) {
      text = await new Promise(resolve => {
        let done = false;
        const finish = value => { if (!done) { done = true; resolve(value); } };
        OR.modal({ title: "Review text for online search", html: `<p>Only the text below will be sent to Google Gemini. Remove names, phone numbers and other identifying details before continuing.</p><label class="fld"><span>Text to send</span><textarea id="onlinePreview" rows="7">${esc(text.slice(0, 3000))}</textarea></label>`,
          actions: [{ label: "Use offline search", onClick: () => finish(null) }, { label: "Send to Gemini", primary: true, onClick: m => finish(m.querySelector("#onlinePreview").value.trim()) }], onClose: () => finish(null) });
      });
      if (signal && signal.aborted) { const e = new Error("Stopped."); e.code = "cancelled"; throw e; }
      if (!text) return [];
    }
    const chapters = S.repertory.chapters.map(c => c.name).join(", ");
    const prompt = `You are helping a homeopath use the repertory "${S.repertory.title}". Translate the patient's own words into repertory rubric searches.

PATIENT'S WORDS:
"""
${text.slice(0, 3000)}
"""

HOW THE APP SEARCHES: plain substring matching over "CHAPTER, rubric, sub-rubric" text. Every search word must appear somewhere in that text (any order). Rubric wording is terse, old-fashioned English, e.g. "WEEPING, consolation agg.", "FEAR, death, of", "SLEEPLESSNESS, midnight, after", "ANXIETY, health, about", "PAIN, sun, from exposure to". So write each search as 1-3 SHORT lowercase word STEMS (4-7 letters) that would occur in real rubric text: "weep", "consol", "agg", "sleepl", "anxiet". Use "agg" for worse-from and "amel" for better-from when the patient makes that clear.

CHAPTERS: ${chapters}

Reply with ONLY this JSON (no prose, no code fences):
{"concepts":[{"label":"short clinical phrase","meaning":"one plain sentence: what the patient's words mean","chapter":"one chapter name or empty","importance":1,"queries":[["weep","consol","agg"],["weep","consol"],["weep"]]}]}

RULES: 1-8 concepts (up to 10 if the text is long). "queries" = up to 3 alternative searches, most specific first. importance: 1 = ordinary (the default), 2 = clearly emphasised by the patient, 3 = strongly characteristic or the main complaint. Put mental/emotional symptoms in chapter Mind, sleep in Sleep, general modalities (worse cold, better open air, thirst, cravings) in Generalities or Stomach as appropriate. Only use what the patient actually said - do not add symptoms, diagnoses or remedies.`;
    let data;
    if (OR.ai.gemini) {
      data = await OR.ai.gemini.interpret(prompt, { signal, responseFormat: "json" });
      if (typeof data === "string") data = JSON.parse(data);
    } else {
      data = await OR.ai.sample.json(prompt, { modelTier: "quick", signal });
    }
    const list = (data && data.concepts) || [];
    return list.map(c => ({
      label: String(c.label || "").slice(0, 80) || "Symptom",
      meaning: String(c.meaning || "").slice(0, 200),
      chapter: String(c.chapter || ""),
      importance: Math.min(3, Math.max(1, Math.round(+c.importance) || 1)),
      variants: cleanVariants(c.queries)
    })).filter(c => c.variants.length).slice(0, 10);
  }

  // ---- built-in phrase list (used when Claude is unavailable) ----
  const STOP = new Set("a an the and or but of to in on at for with from by is are was were be been being am i he she it they we you his her its their our my your this that these those has have had do does did not no very too also just so as if then than there here when while after before about into out up down over under more most much many some any can could should would will get gets got feel feels felt feeling always often sometimes since because really quite like likes want wants needs need say says said tell tells told patient complains complaint complaints history".split(" "));
  const NEG = /hate|dislike|can'?t (stand|bear)|cannot (stand|bear)|worse|irritat|refus|avers|doesn'?t (like|want)|don'?t (like|want)|not (like|want)|aggravat|intoler|angry when/;
  const FEAR_MAP = { dying: "death", death: "death", dark: "dark", alone: "alone", thunder: "thunder", storm: "storm", storms: "storm", crowd: "crowd", crowds: "crowd", heights: "high", high: "high", dogs: "dog", dog: "dog", ghosts: "ghost", robbers: "robber", burglars: "robber", disease: "disease", illness: "disease", cancer: "cancer", failure: "failure", poverty: "poverty", insane: "insan", insanity: "insan", madness: "insan", people: "people", water: "water", doctor: "doctor", doctors: "doctor", accident: "accident", accidents: "accident", evil: "evil", narrow: "narrow", spiders: "spider", snakes: "snake", mice: "mice", rats: "rats", fire: "fire", flying: "flying", travel: "travel", exams: "exam", exam: "exam", future: "future", misfortune: "misfort", pain: "pain", surgery: "operation", needles: "needle", strangers: "strangers" };
  const BODY = [
    [/\b(headache|migraine|head)\b/, "Head", "head"], [/\b(eyes?|eyelids?)\b/, "Eye", "eye"], [/\b(ears?|earache)\b/, "Ear", "ear"],
    [/\b(nose|nasal|sinus\w*|sneez\w+)\b/, "Nose", "nose"], [/\b(throat|tonsil\w*)\b/, "Throat", "throat"], [/\b(teeth|tooth|toothache|gums?)\b/, "Teeth", "teeth"],
    [/\b(mouth|tongue)\b/, "Mouth", "mouth"], [/\b(stomach|nausea|vomit\w*|digest\w*|acidity|heartburn)\b/, "Stomach", "stomach"],
    [/\b(abdomen|belly|bloating|flatulence|gas)\b/, "Abdomen", "abdomen"], [/\b(constipat\w+|diarrh\w+|piles|haemorrhoids|hemorrhoids)\b/, "Rectum", "rectum"],
    [/\b(urine|urinat\w+|bladder)\b/, "Bladder", "bladder"], [/\b(backache|back|spine)\b/, "Back", "back"], [/\b(cough\w*)\b/, "Cough", "cough"],
    [/\b(asthma|breath\w*|wheez\w+)\b/, "Respiration", "respiration"], [/\b(chest|heart|palpitation\w*)\b/, "Chest", "chest"],
    [/\b(joints?|knees?|legs?|arms?|hands?|feet|foot|limbs?|shoulders?|hips?)\b/, "Extremities", "extremities"],
    [/\b(skin|itch\w*|rash\w*|eczema|eruptions?|acne)\b/, "Skin", "skin"], [/\b(fever)\b/, "Fever", "fever"], [/\b(sweat\w*|perspir\w+)\b/, "Perspiration", "perspiration"],
    [/\b(dizz\w+|vertigo)\b/, "Vertigo", "vertigo"], [/\b(periods?|menses|menstru\w+|leucorrh\w+)\b/, "Genitalia female", "menses"], [/\b(face|facial)\b/, "Face", "face"]
  ];
  const SYMPTOM = [
    [/\b(pain\w*|ache|aching|hurts?|sore\w*)\b/, "pain"], [/\b(burn\w+)\b/, "burning"], [/\b(itch\w*)\b/, "itching"], [/\b(swell\w+|swollen)\b/, "swelling"],
    [/\b(stiff\w*)\b/, "stiff"], [/\b(dry\w*)\b/, "dry"], [/\b(discharge)\b/, "discharge"], [/\b(bleed\w+)\b/, "bleeding"], [/\b(numb\w*)\b/, "numb"],
    [/\b(cramp\w*)\b/, "cramp"], [/\b(throbbing)\b/, "throbbing"], [/\b(stitch\w*|stabbing)\b/, "stitching"], [/\b(pressing|pressure)\b/, "pressing"]
  ];
  const MODAL = [
    [/\bsun\b/, ["sun"]], [/\bcold (air|weather|wind)|\bcold\b/, ["cold"]], [/\b(heat|hot|warm\w*)\b/, ["warm"]], [/\bnight\b/, ["night"]], [/\bmorning\b/, ["morning"]],
    [/\bevening\b/, ["evening"]], [/\b(motion|moving|movement|walking)\b/, ["motion"]], [/\b(rest|lying|sitting)\b/, ["rest"]], [/\b(eating|meals?|after food)\b/, ["eating"]],
    [/\b(damp|wet|rain\w*)\b/, ["damp"]], [/\btouch\b/, ["touch"]], [/\bopen air\b/, ["open", "air"]], [/\bnoise\b/, ["noise"]], [/\b(thunder\w*)\b/, ["thunder"]],
    [/\b(weather change|change of weather)\b/, ["weather"]], [/\b(stooping|bending)\b/, ["stooping"]], [/\b(stuffy|closed room|warm room)\b/, ["room"]]
  ];
  const MIND = [
    [/\b(cry|cries|crying|cried|weep\w*|tearful|tears)\b/, t => ({ label: "Weeping, tearful", meaning: "Cries or weeps easily", chapter: "Mind", importance: /easily|everything|no reason|constant|at anything/.test(t) ? 2 : 1, variants: [["weep"]] })],
    [/\b(consol\w+|comfort\w*|sympath\w+)\b/, t => { const agg = NEG.test(t); return { label: agg ? "Consolation aggravates" : "Consolation ameliorates", meaning: agg ? "Worse for being consoled or comforted" : "Better for consolation or sympathy", chapter: "Mind", importance: 1, variants: [["consol", agg ? "agg" : "amel"], ["consol"]] }; }],
    [/\b(anxi\w+|worr\w+|nervous\w*|panic\w*|apprehens\w+)\b/, t => /health|illness|disease|sick/.test(t)
      ? { label: "Anxiety about health", meaning: "Worried about own health or illness", chapter: "Mind", importance: 1, variants: [["anxiety", "health"], ["anxiety"]] }
      : { label: "Anxiety", meaning: "Anxious, worried or nervous", chapter: "Mind", importance: 1, variants: [["anxiety"]] }],
    [/\b(anger|angry|irritab\w+|short.?temper\w*|rage|furious|quarrel\w+)\b/, () => ({ label: "Anger, irritability", meaning: "Easily angered or irritable", chapter: "Mind", importance: 1, variants: [["anger"], ["irritab"]] })],
    [/\b(sad|sadness|depress\w+|hopeless|low mood|despair\w*|melanchol\w+)\b/, () => ({ label: "Sadness, depression", meaning: "Low, sad or hopeless mood", chapter: "Mind", importance: 1, variants: [["sadness"], ["despair"]] })],
    [/\b(grief|bereave\w*|mourning|lost (a |her |his |my )?(mother|father|husband|wife|child|loved))\b/, () => ({ label: "Grief", meaning: "Suffering from grief or bereavement", chapter: "Mind", importance: 1, variants: [["grief"]] })],
    [/\b(lonely|loneliness|forsaken)\b/, () => ({ label: "Forsaken feeling", meaning: "Feels lonely or abandoned", chapter: "Mind", importance: 1, variants: [["forsaken"]] })],
    [/(want\w* to be alone|prefers? (to be )?alone|avoid\w* (people|company)|hates? (people|company)|avers\w+ to company)/, () => ({ label: "Aversion to company", meaning: "Wants to be alone, avoids company", chapter: "Mind", importance: 1, variants: [["company", "avers"]] })],
    [/(can'?t|cannot|afraid to|hates?) be alone|(desires?|wants?|needs?) company/, () => ({ label: "Desires company", meaning: "Cannot bear to be alone, wants company", chapter: "Mind", importance: 1, variants: [["company", "desire"], ["alone", "agg"]] })],
    [/\b(forget\w*|memory|absent.?minded)\b/, () => ({ label: "Forgetfulness", meaning: "Poor memory, forgetful", chapter: "Mind", importance: 1, variants: [["forgetful"], ["memory"]] })],
    [/\b(concentrat\w+|cannot focus|can'?t focus)\b/, () => ({ label: "Difficulty concentrating", meaning: "Cannot concentrate", chapter: "Mind", importance: 1, variants: [["concentr"]] })],
    [/\b(restless\w*|fidget\w*)\b/, () => ({ label: "Restlessness", meaning: "Restless, cannot keep still", chapter: "Mind", importance: 1, variants: [["restless"]] })],
    [/\b(impatien\w+|in a hurry|hurried|rushing)\b/, () => ({ label: "Hurry, impatience", meaning: "Impatient, always in a hurry", chapter: "Mind", importance: 1, variants: [["hurry"], ["impatien"]] })],
    [/\b(fastidious|perfection\w*|very tidy|neat|orderly|particular)\b/, () => ({ label: "Fastidious", meaning: "Fastidious, perfectionist, very orderly", chapter: "Mind", importance: 1, variants: [["fastid"]] })],
    [/\b(jealous\w*)\b/, () => ({ label: "Jealousy", meaning: "Jealous", chapter: "Mind", importance: 1, variants: [["jealous"]] })],
    [/\b(suspicious|paranoi\w+|distrust\w*)\b/, () => ({ label: "Suspicion", meaning: "Suspicious, distrustful", chapter: "Mind", importance: 1, variants: [["suspic"]] })],
    [/\b(shy|timid|bashful|lack of confidence|no confidence)\b/, () => ({ label: "Timidity, lack of confidence", meaning: "Shy, timid or lacking self-confidence", chapter: "Mind", importance: 1, variants: [["timid"], ["confidence", "want"]] })],
    [/\b(stubborn|obstinate)\b/, () => ({ label: "Obstinacy", meaning: "Stubborn, obstinate", chapter: "Mind", importance: 1, variants: [["obstin"]] })],
    [/\b(talkative|talks? (a lot|constantly)|chatty|loquacious)\b/, () => ({ label: "Talkativeness", meaning: "Talks a great deal", chapter: "Mind", importance: 1, variants: [["loquacity"]] })],
    [/\b(indifferen\w+|apath\w+|don'?t care)\b/, () => ({ label: "Indifference", meaning: "Indifferent, apathetic", chapter: "Mind", importance: 1, variants: [["indifference"]] })],
    [/\b(exam\w*|stage fright|performance|anticipat\w+)\b.*\b(anxi\w+|nervous|worr\w+|diarrh\w+|fear\w*)|\banticipat\w+/, () => ({ label: "Anticipation, anxiety before events", meaning: "Anxious or unwell in anticipation of an event", chapter: "Mind", importance: 1, variants: [["anticipation"]] })],
    [/\b(insomnia|can'?t sleep|cannot sleep|unable to sleep|sleepless\w*|trouble sleeping|difficulty sleeping|wakes? (up )?(at )?night|wakes? often)\b/, t => ({ label: "Sleeplessness", meaning: "Cannot sleep or wakes at night", chapter: "Sleep", importance: 1, variants: /midnight/.test(t) ? [["sleepl", "midnight"], ["sleepl"]] : [["sleepl"]] })],
    [/\b(nightmares?|bad dreams?|frightful dreams?)\b/, () => ({ label: "Frightful dreams", meaning: "Nightmares or frightening dreams", chapter: "Sleep", importance: 1, variants: [["dreams", "frightful"], ["nightmare"]] })],
    [/\b(sleepy|drowsy|sleepiness)\b/, () => ({ label: "Sleepiness", meaning: "Sleepy or drowsy by day", chapter: "Sleep", importance: 1, variants: [["sleepiness"]] })],
    [/no thirst|not thirsty|thirstless/, () => ({ label: "Thirstlessness", meaning: "No thirst", chapter: "Stomach", importance: 1, variants: [["thirstless"]] })],
    [/\b(very thirsty|thirst\w*|drinks a lot)\b/, () => ({ label: "Thirst", meaning: "Marked thirst", chapter: "Stomach", importance: 1, variants: [["thirst", "large"], ["thirst"]] })],
    [/\b(crav\w+|desires?|loves?)\b\s+(?:for\s+)?(sweets?|sugar|salt\w*|spicy|sour|fat\w*|eggs?|milk|chocolate|cold drinks?|bread|meat|fruit)/, t => {
      const m = t.match(/(sweets?|sugar|salt\w*|spicy|sour|fat\w*|eggs?|milk|chocolate|cold drinks?|bread|meat|fruit)/)[1];
      const stem = { sugar: "sweet", sweets: "sweet", salty: "salt", spicy: "spice", fatty: "fat", fats: "fat", "cold drinks": "cold", "cold drink": "cold" }[m] || m.replace(/s$/, "");
      return { label: "Desire for " + m, meaning: "Craves " + m, chapter: "Stomach", importance: 1, variants: [["desires", stem], ["desire", stem]] };
    }],
    [/(chilly|feels? (the )?cold|sensitive to cold|worse (in|from|for) (the )?cold|cold all the time|freezing)/, () => ({ label: "Chilly, worse from cold", meaning: "Sensitive to cold, worse in cold", chapter: "Generalities", importance: 1, variants: [["cold", "agg"], ["cold"]] })],
    [/(hot[- ]blooded|worse (in|from|for) (the )?(heat|warmth|warm)|can'?t stand (the )?heat|feels? (the )?heat)/, () => ({ label: "Worse from heat", meaning: "Sensitive to heat, worse when warm", chapter: "Generalities", importance: 1, variants: [["heat", "agg"], ["warm", "agg"]] })],
    [/(better|relief|amel\w*) (in|from|with) (the )?open air|likes? (the )?open air|wants? fresh air/, () => ({ label: "Better in open air", meaning: "Feels better outdoors, in fresh air", chapter: "Generalities", importance: 1, variants: [["open", "air", "amel"], ["air", "open"]] })],
    [/(worse|aggravated) (in|from|for) (a )?(stuffy|closed|warm) room/, () => ({ label: "Worse in a warm, closed room", meaning: "Worse in a stuffy or warm room", chapter: "Generalities", importance: 1, variants: [["room", "warm", "agg"], ["warm", "room"]] })]
  ];

  function interpretLocal(text) {
    const clauses = text.toLowerCase().replace(/[“”"]/g, "").split(/[.;\n!?]|,\s+(?=[a-z])|\s+(?:but|and also|also|plus)\s+/).map(x => x.trim()).filter(x => x.length > 2);
    const out = [], seen = new Set();
    const add = c => { const k = c.label; if (!seen.has(k)) { seen.add(k); out.push(c); } };

    clauses.forEach(clause => {
      let hit = false;
      // fears: "afraid of the dark", "fear of dying"
      const fm = clause.match(/\b(?:afraid|fear\w*|scared|terrified|frightened|phobi\w+)\b(?:\s+of)?(?:\s+(?:the|being|a|an|getting))?\s+([a-z]+)/);
      if (fm) {
        const w = FEAR_MAP[fm[1]];
        add({ label: w ? "Fear of " + fm[1] : "Fear", meaning: w ? "Afraid of " + fm[1] : "Fearfulness", chapter: "Mind", importance: 1, variants: w ? [["fear", w], ["fear"]] : [["fear"]] });
        hit = true;
      }
      MIND.forEach(([re, fn]) => { if (re.test(clause)) { add(fn(clause)); hit = true; } });

      // physical complaint = body part (+ symptom) (+ modalities)
      const body = BODY.find(b => b[0].test(clause));
      if (body) {
        const sym = (SYMPTOM.find(x => x[0].test(clause)) || [])[1] || (/headache|migraine|backache|earache|toothache/.test(clause) ? "pain" : "");
        const mods = MODAL.filter(m => m[0].test(clause)).map(m => m[1]);
        const variants = [];
        mods.forEach(m => variants.push(sym ? [sym, ...m] : m));
        if (sym) variants.push([sym]);
        if (variants.length) {
          const modTxt = mods.map(m => m.join(" ")).join(", ");
          add({ label: `${body[1]} — ${[sym, modTxt].filter(Boolean).join(", ")}`, meaning: `${sym || "Complaint"} in the ${body[2]}${modTxt ? "; modality: " + modTxt : ""}`, chapter: body[1], importance: 1, variants: variants.slice(0, 3) });
          hit = true;
        }
      } else if (!hit) {
        // general modality with no body part
        const mods = MODAL.filter(m => m[0].test(clause)).map(m => m[1]);
        if (mods.length && /worse|better|aggravat|ameliorat|relief/.test(clause)) {
          const dir = /better|relief|ameliorat/.test(clause) && !/worse/.test(clause) ? "amel" : "agg";
          add({ label: `Modality: ${dir === "agg" ? "worse" : "better"} ${mods[0].join(" ")}`, meaning: `${dir === "agg" ? "Worse" : "Better"} from ${mods.map(m => m.join(" ")).join(", ")}`, chapter: "Generalities", importance: 1, variants: [[...mods[0], dir], mods[0]] });
          hit = true;
        }
      }
    });

    if (!out.length) {
      // last resort: the meaningful words themselves
      const words = [...new Set(text.toLowerCase().match(/[a-z]{3,}/g) || [])].filter(w => !STOP.has(w)).map(w => w.slice(0, 6));
      if (words.length) {
        const variants = [words.slice(0, 3)];
        words.slice(0, 3).forEach(w => variants.push([w]));
        out.push({ label: "Keywords: " + words.slice(0, 4).join(", "), meaning: "No known phrase recognised — searching the words themselves", chapter: "", importance: 1, variants: variants.slice(0, 3) });
      }
    }
    return out.slice(0, 10);
  }

  // ================= searching the real repertory =================
  const tick = () => new Promise(r => setTimeout(r, 0));

  // prefer whole-word starts ("sun" in "sun, from exposure", not in "asunder")
  const wordStart = (txt, tok) => new RegExp("(^|[^a-z0-9])" + tok.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).test(txt);
  function refine(it, tokens) {
    const base = (it.chapter + " " + it.r.text).toLowerCase();
    const good = txt => tokens.every(t => wordStart(txt, t));
    it.subs.sort((a, b) => good(base + " " + b.text.toLowerCase()) - good(base + " " + a.text.toLowerCase()));
    const ok = it.topMatch ? good(base) : (it.subs.length > 0 && good(base + " " + it.subs[0].text.toLowerCase()));
    return ok ? 4 : 0;
  }

  async function searchConcept(c, mine) {
    const chs = S.repertory.chapters;
    const hint = chs.find(ch => ch.name.toLowerCase() === (c.chapter || "").toLowerCase());
    const found = new Map();
    const scan = async (list, vi, tokens) => {
      for (let index = 0; index < list.length; index++) {
        if (mine !== run || mine.ctl.signal.aborted) return;
        const ch = list[index];
        OR.searchInChapter(ch, tokens).forEach(it => {
          const key = ch.name + "||" + it.r.text;
          const prev = found.get(key);
          const bonus = refine(it, tokens);
          const score = (hint && ch === hint ? 3 : 0) + (it.topMatch ? 2 : 0) + (3 - vi) * 3 + bonus - Math.min(it.subs.length, 60) / 60;
          if (!prev || score > prev.score) found.set(key, Object.assign(it, { score, tokens }));
        });
        if (index % 4 === 3) await tick();
      }
    };
    for (let vi = 0; vi < c.variants.length; vi++) {
      await scan(hint ? [hint] : chs, vi, c.variants[vi]);
      if (mine !== run || mine.ctl.signal.aborted) return;
    }
    if (hint && found.size < 3) {
      await tick();
      for (let vi = 0; vi < c.variants.length; vi++) {
        await scan(chs, vi, c.variants[vi]);
        if (mine !== run || mine.ctl.signal.aborted) return;
      }
    }
    c.items = [...found.values()].sort((a, b) => b.score - a.score);
    c.shown = 5;
    c.searched = true;
  }

  // the single rubric row to offer as "best match" for a concept
  function pickOf(c) {
    const it = c.items && c.items[0];
    if (!it) return null;
    if (it.topMatch || !it.subs.length) return { chapter: it.chapter, path: it.r.text, remedies: it.r.remedies || [] };
    const s = it.subs[0];
    return { chapter: it.chapter, path: it.r.text + ", " + s.text.replace(/^\.\s*/, ""), remedies: s.remedies || [] };
  }
  const uidOfPick = p => p.chapter + "||" + p.path;

  // ================= UI =================
  const input = $("aiInput"), go = $("aiGo"), panel = $("aiPanel");
  let run = null;   // { text, engine, concepts, loading, ctl, note }
  let cid = 0;

  function autoGrow() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 110) + "px";
  }
  input.addEventListener("input", autoGrow);
  input.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); start(input.value); }
  });
  go.addEventListener("click", () => { if (run && run.loading) stop(); else start(input.value); });

  input.addEventListener("focus", () => { input.classList.remove("compact"); autoGrow(); });
  function collapseChapters() { const sb = $("sidebar"); if (sb) sb.classList.add("collapsed"); }

  function stop() {
    if (run && run.ctl) run.ctl.abort();
  }

  async function start(raw) {
    const text = String(raw || "").trim();
    if (!text) { input.focus(); return; }
    if (!S.repertory) { OR.toast("The repertory is still loading — try again in a moment."); return; }
    OR.showPage("repertory");
    collapseChapters();
    input.blur();
    input.classList.add("compact");
    input.style.height = "";
    OR.aiMode(true);
    panel.hidden = false;
    pushRecent(text);

    if (run && run.ctl) run.ctl.abort();
    const ctl = new AbortController();
    run = { text, engine: aiOn() ? OR.ai.provider : OFFLINE_AI, concepts: [], loading: true, ctl, note: "", progress: "Starting Smart Search AI…", startedAt: Date.now() };
    const mine = run;
    go.textContent = "Stop";
    render();
    mine.timer = setInterval(() => { if (mine === run && mine.loading) renderHead(); }, 700);

    let concepts = [];
    try {
      if (aiOn()) {
        try { concepts = await interpretAI(text, ctl.signal); }
        catch (e) {
          if (mine !== run) return;
          if (e && e.code === "cancelled") { mine.loading = false; go.textContent = "Find rubrics"; mine.note = "Stopped."; render(); return; }
          if (e && e.code === "not_granted") { OR.ai.denied = true; engineTag(); mine.note = "Gemini is not connected — Smart Search AI continued locally."; }
          else if (e && e.code === "invalid_key") mine.note = "Gemini rejected this API key — check the key and API access, then reconnect.";
          else if (e && e.code === "model_unavailable") mine.note = "This Gemini model is unavailable for the key or region — Smart Search AI continued locally.";
          else if (e && e.code === "rate_limited") mine.note = "Gemini is rate-limited — Smart Search AI continued locally.";
          else mine.note = "Gemini network request failed — Smart Search AI continued locally.";
          mine.engine = "built-in";
          concepts = [];
        }
      }
      if (!concepts.length) {
        if (mine.engine !== OFFLINE_AI && !mine.note) mine.note = "The live provider found no lookup terms — Smart Search AI used its local interpreter.";
        mine.engine = OFFLINE_AI;
        concepts = interpretLocal(text);
      }
      if (mine !== run) return;
      mine.concepts = concepts.map(c => Object.assign(c, { id: ++cid, items: [], shown: 5, removed: false }));
      render();
      for (let i = 0; i < mine.concepts.length; i++) {
        const c = mine.concepts[i];
        mine.progress = `Finding real rubrics ${i + 1} of ${mine.concepts.length}…`;
        renderHead();
        await searchConcept(c, mine);
        if (mine !== run || ctl.signal.aborted) return;
        renderConcept(c);
        await tick();
      }
    } finally {
      if (mine === run) {
        if (ctl.signal.aborted) mine.note = "Stopped.";
        mine.loading = false;
        if (mine.timer) clearInterval(mine.timer);
        go.textContent = "Find rubrics";
        renderHead(); renderFoot();
      }
    }
  }

  // idle state: examples + recent searches
  function showIdle() {
    OR.aiMode(true);
    panel.hidden = false;
    if (run && run.ctl) run.ctl.abort();
    run = null;
    const ex = [
      "Cries easily, hates being consoled, worse in a stuffy room, wants fresh air",
      "Afraid of the dark and of being alone, wakes at night with nightmares",
      "Headache from sun exposure, better lying in a dark room, nausea",
      "Anxious about health, checks everything, very fastidious, chilly"
    ];
    const rec = recents();
    panel.innerHTML = `
      <div class="ai-idle">
        <button class="icon-btn small ai-x" id="aiIdleClose" type="button" aria-label="Close">✕</button>
        <h3>Describe it the way the patient did</h3>
        <p class="muted">${aiOn() ? esc(OR.ai.provider) : "Local Smart Search"} interprets the patient's words, then shows real repertory rubrics grouped by symptom. Review candidates before adding them to a case.</p>
        <div class="refine-row" aria-label="Optional symptom detail prompts">${[["location","Where?"],["sensation","What does it feel like?"],["worse","Worse from?"],["better","Better from?"],["time","When?"],["associated","What else occurs?"]].map(x => `<button type="button" class="refine-chip" data-refine="${esc(x[1])}">${esc(x[0])}</button>`).join("")}</div>
        <div class="chips">${ex.map(t => `<button type="button" class="chip-btn" data-text="${esc(t)}">${esc(t)}</button>`).join("")}</div>
        ${rec.length ? `<h4 class="mh">Recent</h4><div class="chips">${rec.map(t => `<button type="button" class="chip-btn" data-text="${esc(t)}">${esc(t.length > 90 ? t.slice(0, 90) + "…" : t)}</button>`).join("")}</div>` : ""}
      </div>`;
  }
  panel.addEventListener("click", e => {
    if (e.target.closest("#aiIdleClose")) return closePanel();
    const refine = e.target.closest(".refine-chip");
    if (refine) { input.value = input.value ? input.value.trimEnd() + " " + refine.dataset.refine + " " : refine.dataset.refine + " "; autoGrow(); input.focus(); return; }
    const chip = e.target.closest(".chip-btn");
    if (chip) { input.value = chip.dataset.text; autoGrow(); start(chip.dataset.text); }
  });

  function caseLabel() { const c = OR.activeCase(); return c ? c.name : ""; }

  function renderHead() {
    const el = $("aiHeadWrap");
    if (!el || !run) return;
    const live = run.concepts.filter(c => !c.removed).length;
    el.innerHTML = `
      <div class="ai-head">
        <div class="ai-quote">“${esc(run.text.length > 220 ? run.text.slice(0, 220) + "…" : run.text)}”</div>
        <button class="icon-btn small" id="aiClose" type="button" title="Close AI results" aria-label="Close AI results">✕</button>
      </div>
      <div class="ai-meta"><span class="ai-engine ${run.engine !== "built-in" ? "on" : "off"}">${esc(run.engine)}</span>
        ${run.loading ? `<span class="muted">${run.progress || (run.concepts.length ? "Looking up rubrics…" : `${esc(run.engine)} is reading the patient's words…`)}</span>` : `<span class="muted">${live} symptom${live === 1 ? "" : "s"} found</span>`}
        ${run.note ? `<span class="ai-note">${esc(run.note)}</span>` : ""}</div>
      ${run.loading && !run.concepts.length ? `<div class="ai-skel"><i></i><i></i><i></i></div>` : ""}`;
    $("aiClose").addEventListener("click", closePanel);
  }

  function render() {
    if (!run) return;
    panel.hidden = false;
    panel.innerHTML = `<div id="aiHeadWrap"></div><div id="aiConcepts"></div><div id="aiFoot"></div>`;
    renderHead();
    run.concepts.forEach(c => {
      const sec = document.createElement("section");
      sec.className = "concept";
      sec.id = "concept-" + c.id;
      $("aiConcepts").appendChild(sec);
      renderConcept(c);
    });
    renderFoot();
  }

  function closePanel() {
    if (run && run.ctl) run.ctl.abort();
    run = null;
    panel.hidden = true;
    OR.aiMode(false);
  }

  function renderFoot() {
    const foot = $("aiFoot");
    if (!foot || !run) return;
    const ready = run.concepts.filter(c => !c.removed && c.items && c.items.length);
    if (!ready.length) { foot.innerHTML = run.loading || !run.concepts.length ? "" : `<p class="empty-state">No rubrics found. Try rewording, or edit a search below.</p>`; return; }
    foot.innerHTML = `
      <div class="ai-foot">
        <button class="primary-btn" id="aiAddAll" type="button">Add best match of each (${ready.length}) to case</button>
        <button class="ghost-btn" id="aiToAnalysis" type="button">Open Analysis</button>
        <span class="muted small-note">Adding to case: <b>${esc(caseLabel())}</b></span>
      </div>
      <p class="muted small-note">Rubrics come straight from the repertory. Check each one against what the patient actually said before relying on it — this is a study aid, not a diagnosis.</p>`;
    $("aiAddAll").addEventListener("click", addAll);
    $("aiToAnalysis").addEventListener("click", () => OR.showPage("analysis"));
  }

  function addPick(c) {
    const p = pickOf(c);
    if (!p) return false;
    const uid = uidOfPick(p);
    if (OR.hasRubric(uid)) return false;
    OR.toggleRubric(uid, p.chapter, p.path, p.remedies, c.importance, "ai");
    return true;
  }
  function addAll() {
    let n = 0;
    run.concepts.filter(c => !c.removed).forEach(c => { if (addPick(c)) n++; });
    OR.refreshAddButtons();
    OR.toast(n ? `Added ${n} rubric${n === 1 ? "" : "s"} to “${caseLabel()}”.` : "Those rubrics are already in the case.", n ? "Open Analysis" : "", () => OR.showPage("analysis"));
  }

  function renderConcept(c) {
    const sec = $("concept-" + c.id);
    if (!sec) return;
    if (c.removed) { sec.remove(); renderFoot(); return; }
    const q = c.variants[0] ? c.variants[0].join(" ") : "";
    const others = c.variants.slice(1).map(v => v.join(" "));
    sec.innerHTML = `
      <div class="c-head">
        <div class="c-title"><b>${esc(c.label)}</b>
          <button type="button" class="imp" data-act="imp" title="How strongly the patient stressed this (multiplies its grades in Analysis). Tap to change.">importance ×${c.importance}</button></div>
        ${c.meaning ? `<div class="muted c-mean">${esc(c.meaning)}</div>` : ""}
        <div class="c-q"><label>Searched for</label>
          <input class="c-query" type="text" value="${esc(q)}" aria-label="Search words for this symptom" spellcheck="false">
          ${others.length ? `<span class="muted small-note">also tried: ${others.map(esc).join(" · ")}</span>` : ""}</div>
        <div class="c-btns"><button type="button" class="mini-btn plain" data-act="best">+ Add best match</button>
          <button type="button" class="mini-btn plain" data-act="drop" title="Remove this symptom">✕ Remove</button></div>
      </div>
      <div class="c-results"></div>`;
    const box = sec.querySelector(".c-results");
    if (!c.searched) {
      box.innerHTML = `<p class="muted small-note">Searching…</p>`;
    } else if (!c.items.length) {
      box.innerHTML = `<p class="muted small-note">No rubric matched these words. Edit the search words above and press Enter.</p>`;
    } else {
      c.items.slice(0, c.shown).forEach(it => {
        const cap = 8;
        const shownSubs = it.subs.slice(0, cap);
        const wrap = document.createElement("div");
        wrap.className = "ai-item";
        wrap.appendChild(OR.renderRubric(it.r, shownSubs, { isSub: false, tokens: it.tokens, chapterName: it.chapter, parentText: "", weight: c.importance, showContext: true, matchReason: "AI smart match" }));
        wrap.querySelectorAll(".remedies").forEach(el => {
          if (el.children.length <= 36) return;
          el.classList.add("clamped");
          const t = document.createElement("button");
          t.type = "button"; t.className = "rem-toggle";
          t.textContent = `▾ all ${el.children.length} remedies`;
          t.addEventListener("click", () => { const on = el.classList.toggle("clamped"); t.textContent = on ? `▾ all ${el.children.length} remedies` : "▴ fewer"; });
          el.insertAdjacentElement("afterend", t);
        });
        if (it.subs.length > cap) {
          const more = document.createElement("button");
          more.type = "button"; more.className = "more-btn tiny";
          more.textContent = `+ ${it.subs.length - cap} more sub-rubrics — open in Repertory`;
          more.addEventListener("click", () => { $("searchBox").value = it.tokens.join(" "); OR.runSearch(it.tokens.join(" ")); });
          wrap.appendChild(more);
        }
        box.appendChild(wrap);
      });
      if (c.items.length > c.shown) {
        const b = document.createElement("button");
        b.type = "button"; b.className = "more-btn";
        b.textContent = `Show ${Math.min(5, c.items.length - c.shown)} more (${c.items.length - c.shown} left)`;
        b.addEventListener("click", () => { c.shown += 5; renderConcept(c); });
        box.appendChild(b);
      }
    }
    sec.querySelector('[data-act="imp"]').addEventListener("click", () => { c.importance = c.importance % 3 + 1; renderConcept(c); });
    sec.querySelector('[data-act="drop"]').addEventListener("click", () => { c.removed = true; renderConcept(c); });
    sec.querySelector('[data-act="best"]').addEventListener("click", () => {
      if (addPick(c)) { OR.refreshAddButtons(); OR.toast(`Added to “${caseLabel()}”.`, "Open Analysis", () => OR.showPage("analysis")); }
      else OR.toast(c.items && c.items.length ? "Already in the case." : "Nothing to add yet.");
    });
    const qi = sec.querySelector(".c-query");
    qi.addEventListener("keydown", async e => {
      if (e.key !== "Enter") return;
      const toks = qi.value.split(/[\s,]+/).map(stemTok).filter(t => t.length >= 2);
      if (!toks.length) return;
      c.variants = [toks];
      c.items = [];
      c.searched = false;
      renderConcept(c);
      await searchConcept(c);
      renderConcept(c);
      renderFoot();
    });
    if (!(run && run.loading)) renderFoot();
    else if (c.items && c.items.length) renderFoot();
  }

  // ---------- public ----------
  OR.finder = {
    focus() { input.focus(); if (!run) showIdle(); },
    open(text, opts) {
      input.value = text || "";
      autoGrow();
      OR.showPage("repertory");
      if (opts && opts.run) start(text); else input.focus();
    }
  };

  // when Analysis changes the case, refresh the footer label
  OR.hooks.casesChanged.push(() => { if (run) renderFoot(); });
})();
