/* Small runtime compatibility helpers for Android WebView 66 and later. */
(function () {
  'use strict';
  if (!Array.prototype.flatMap) Object.defineProperty(Array.prototype, 'flatMap', {
    configurable: true, writable: true, value: function (fn, context) {
      return this.reduce(function (out, item, index, array) { return out.concat(fn.call(context, item, index, array)); }, []);
    }
  });
  if (!Object.fromEntries) Object.fromEntries = function (entries) {
    var result = {};
    for (var entry of entries) Object.defineProperty(result, entry[0], { value: entry[1], enumerable: true, configurable: true, writable: true });
    return result;
  };
})();
