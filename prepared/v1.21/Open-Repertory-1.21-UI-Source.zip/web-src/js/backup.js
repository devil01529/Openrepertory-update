/* Versioned portable backup codec, shared by the normal UI and startup recovery. */
(function () {
  'use strict';
  const LIMIT=16*1024*1024;
  function b64(bytes){let s='';new Uint8Array(bytes).forEach(b=>{s+=String.fromCharCode(b);});return btoa(s);}
  function unb64(value){const s=atob(value), bytes=new Uint8Array(s.length);for(let i=0;i<s.length;i++)bytes[i]=s.charCodeAt(i);return bytes;}
  async function key(password,salt){
    const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveKey']);
    return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:210000,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
  }
  window.ORBackup={
    LIMIT,
    async encrypt(data,password){
      if(password.length<8)throw new Error('Use at least 8 characters for the backup password.');
      const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));
      const encrypted=await crypto.subtle.encrypt({name:'AES-GCM',iv},await key(password,salt),new TextEncoder().encode(JSON.stringify(data)));
      const result=`ORBK2.${b64(salt)}.${b64(iv)}.${b64(encrypted)}`;
      if(result.length>LIMIT)throw new Error('Encrypted backup exceeds the 16 MB limit.');
      return result;
    },
    async decrypt(text,password){
      if(text.length>LIMIT)throw new Error('Backup must be smaller than 16 MB.');
      const p=text.trim().split('.');
      if(p.length!==4||p[0]!=='ORBK2')throw new Error('This is not an Open Repertory encrypted backup.');
      try{
        const salt=unb64(p[1]),iv=unb64(p[2]);if(salt.length!==16||iv.length!==12)throw new Error();
        const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv},await key(password,salt),unb64(p[3]));
        return JSON.parse(new TextDecoder().decode(plain));
      }catch(error){throw new Error('Could not decrypt backup — check the password and file integrity.');}
    }
  };
})();
