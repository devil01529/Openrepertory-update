(function(){
  'use strict';
  window.ORRecovery={
    show(error){
      if(window.openrepertorySecure?.enterRecovery)openrepertorySecure.enterRecovery();
      document.getElementById('recoveryScreen')?.remove();
      const screen=document.createElement('main');screen.id='recoveryScreen';screen.className='recovery-screen';screen.setAttribute('aria-label','Record recovery');
      screen.innerHTML=`<section class="recovery-card"><h1>Recover your records</h1><p>Saved records could not be opened safely. They have not been replaced with empty records.</p><p>Restore a verified encrypted backup below. The existing encrypted storage will be preserved on this device before recovery.</p><label class="fld"><span>Backup file (.orbk)</span><input id="recoveryFile" type="file" accept=".orbk,.json,application/json,application/octet-stream"></label><label class="fld"><span>Backup text</span><textarea id="recoveryText" rows="4"></textarea></label><label class="fld"><span>Backup password</span><input id="recoveryPassword" type="password" autocomplete="current-password"></label><button id="recoveryRestore" class="primary-btn">Validate and restore backup</button><button id="recoveryRetry" class="ghost-btn">Retry opening saved records</button><p id="recoveryStatus" role="status" aria-live="polite"></p></section>`;
      document.body.appendChild(screen);
      const msg=text=>{screen.querySelector('#recoveryStatus').textContent=text;};
      screen.querySelector('#recoveryFile').addEventListener('change',event=>{
        const file=event.target.files[0];if(!file)return;
        if(file.size>ORBackup.LIMIT)return msg('Backup must be smaller than 16 MB.');
        const reader=new FileReader();reader.onload=()=>{screen.querySelector('#recoveryText').value=String(reader.result);msg('File loaded. Enter its password and validate.');};reader.onerror=()=>msg('File could not be read.');reader.readAsText(file);
      });
      screen.querySelector('#recoveryRetry').onclick=()=>location.reload();
      screen.querySelector('#recoveryRestore').onclick=async()=>{
        const button=screen.querySelector('#recoveryRestore');button.disabled=true;
        try{
          const raw=screen.querySelector('#recoveryText').value.trim();if(!raw||raw.length>ORBackup.LIMIT)throw new Error('Choose a backup smaller than 16 MB.');
          msg('Validating backup…');
          const data=raw.startsWith('ORBK2.')?await ORBackup.decrypt(raw,screen.querySelector('#recoveryPassword').value):JSON.parse(raw);
          OR.patients.validateBackup(data);
          if(!await OR.confirm('Restore backup','Replace the active records with this verified backup? The current encrypted storage will be retained for recovery.','Restore'))return;
          const values={openrepertory_patients:JSON.stringify(data.patients),openrepertory_cases:JSON.stringify(data.cases),openrepertory_mmnotes:JSON.stringify(data.mmNotes||{})};
          if(window.openrepertorySecure){
            if(openrepertorySecure.restoreRecords(JSON.stringify(values))!=='ok')throw new Error('Recovery could not commit. Existing files remain preserved.');
          }else{
            const old=localStorage.getItem('openrepertory_browser_store_v2');
            if(old!==null)localStorage.setItem('openrepertory_browser_damaged_'+Date.now(),old);
            localStorage.setItem('openrepertory_browser_store_v2',JSON.stringify(values));
          }
          msg('Recovery committed. Reopening records…');location.reload();
        }catch(error){msg(error.message);}finally{button.disabled=false;}
      };
      screen.querySelector('#recoveryFile').focus();
    }
  };
})();
