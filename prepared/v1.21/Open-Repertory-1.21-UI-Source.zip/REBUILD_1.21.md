# Source overlay for Open Repertory 1.21

Apply over the retained full clinical app source, preserving its database/text assets and existing Android keystore. This overlay contains maintained native classes/resources, web source, HTML/CSS, build/release tools and test source. Neither private signing key is included. Do not create a replacement signing key for installed users.

Use release-config.json for package/version/public channel configuration. Build with bash build.sh using pinned tools and tooling/package-lock.json dependencies. Tests for the current change are analysis_shortcut_web.py and analysis_shortcut_package.py; also run menu_web.py and the existing advanced/reliability/snapshot/release_tools suites. Select OR_TEST_RESULTS=test-results/v1.21 to isolate current evidence. Instrumentation uses only a disposable emulator. Historical update test fixtures retain their release-specific expectations and require adaptation before testing a future release.

See INTEGRATION_1.21.md, TEST_REPORT_1.21.md and UPDATE_OWNER_GUIDE.md. Private Android and metadata signing keys must be retained separately. The major UI redesign document and visual concept describe future work; only the clipboard shortcut is implemented now.
