#!/usr/bin/env bash
set -euo pipefail
project="$(cd -- "$(dirname -- "$0")/.." && pwd)"
tools="${REPERTORY_TOOLS:-/workspace/tools}"
bt="$tools/android/android-15"
rm -rf "$project/build/tests/classes"
mkdir -p "$project/build/tests/classes"
java -jar "$tools/ecj.jar" -source 8 -target 8 -proc:none -classpath "$project/build/classes" -bootclasspath "$tools/android/android-35/android.jar:$bt/core-lambda-stubs.jar" -d "$project/build/tests/classes" "$project"/tests/native/*.java
find "$project/build/tests/classes" -name '*.class' > "$project/build/tests/class-list.txt"
"$bt/d8" --min-api 23 --lib "$tools/android/android-35/android.jar" --output "$project/build/tests" "@$project/build/tests/class-list.txt"
"$bt/aapt2" link -I "$tools/android/android-35/android.jar" --manifest "$project/tests/native/AndroidManifest.xml" -o "$project/build/tests/unsigned.apk"
python - "$project" <<'PY'
import sys,pathlib,zipfile
p=pathlib.Path(sys.argv[1])/'build/tests'
with zipfile.ZipFile(p/'unsigned.apk','a') as z:z.write(p/'classes.dex','classes.dex')
PY
"$bt/zipalign" -f 4 "$project/build/tests/unsigned.apk" "$project/build/tests/aligned.apk"
"$bt/apksigner" sign --ks "$project/build/development.p12" --ks-pass pass:repertory-development --out "$project/build/tests/DevChecks.apk" "$project/build/tests/aligned.apk"
