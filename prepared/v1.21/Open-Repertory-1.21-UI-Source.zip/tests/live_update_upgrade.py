"""Exercise v1.19 → live v1.20 download + Android installation on a synthetic emulator.

Run only after the new release is publicly available. Never targets a physical phone.
"""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,time,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.20'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--serial',default='emulator-5558');p.add_argument('--reset-synthetic-app',action='store_true');a=p.parse_args()
ADB=['/workspace/tools/android/platform-tools/adb','-s',a.serial];PACKAGE='com.openrepertory.app.dev'
def run(args,timeout=180):return subprocess.run(ADB+args,check=True,capture_output=True,text=True,timeout=timeout).stdout
if run(['shell','getprop','ro.kernel.qemu']).strip()!='1':raise SystemExit('This test is restricted to an isolated Android emulator')
old=R/'releases/1.19/Open-Repertory-1.19.apk'
rollback=subprocess.run(ADB+['install','--no-streaming','-r','-d',str(old)],capture_output=True,text=True,timeout=180)
if rollback.returncode:
 if not a.reset_synthetic_app:raise SystemExit('The test requires restoring its synthetic v1.19 installation; specify --reset-synthetic-app only for this disposable emulator')
 run(['shell','am','force-stop',PACKAGE]);run(['uninstall',PACKAGE]);run(['install','--no-streaming',str(old)])
run(['install','--no-streaming','-r',str(R/'build/tests/DevChecks.apk')])
run(['shell','appops','set',PACKAGE,'REQUEST_INSTALL_PACKAGES','allow'])
stream=run(['shell','am','instrument','-w','com.openrepertory.app.dev.tests/com.openrepertory.tests.UpdateOfferChecks'],timeout=420)
(O/'android-live-update-offer.txt').write_text(stream)
if 'Live update offer checks passed: 4' not in stream or 'FAILED' in stream:raise SystemExit(stream)
print('PASS shipped v1.19 discovers, downloads and verifies live v1.20 and opens Android installer',flush=True)
# The fixture runner has detached. Confirm only this test app's genuine Android installer.
clicked=False;end=time.monotonic()+90
while time.monotonic()<end:
 try:
  run(['shell','uiautomator','dump','/sdcard/live-update-test.xml'],timeout=30)
  xml=run(['shell','cat','/sdcard/live-update-test.xml'])
  root=ET.fromstring(xml[xml.index('<?xml'):])
  for node in root.iter('node'):
   if node.get('package')=='com.android.packageinstaller' and (node.get('text') or '').strip().lower() in ('install','update'):
    bounds=[int(v) for v in re.findall(r'\d+',node.get('bounds',''))]
    if len(bounds)==4:
     run(['shell','input','tap',str((bounds[0]+bounds[2])//2),str((bounds[1]+bounds[3])//2)]);clicked=True;break
  if clicked:break
 except (subprocess.SubprocessError,ValueError,ET.ParseError):pass
 time.sleep(1)
if not clicked:raise SystemExit('Android installation confirmation was not available')
end=time.monotonic()+120;version=None
while time.monotonic()<end:
 info=run(['shell','dumpsys','package',PACKAGE]);m=re.search(r'versionCode=(\d+)',info)
 if m and int(m[1])==21:version=21;break
 time.sleep(1)
if version!=21:raise SystemExit('Android did not finish installing v1.20')
print('PASS Android installs the downloaded update over v1.19',flush=True)
run(['shell','am','force-stop','com.android.packageinstaller'])
retained=run(['shell','am','instrument','-w','-e','stage','verify','com.openrepertory.app.dev.tests/com.openrepertory.tests.UpgradeChecks'])
(O/'android-live-update-retention.txt').write_text(retained)
if 'Upgrade retention checks passed:' not in retained or 'FAILED' in retained:raise SystemExit(retained)
print('PASS live update retains encrypted clinical records and phone identity',flush=True)
path=run(['shell','pm','path',PACKAGE]).strip().removeprefix('package:');copy=O/'live-installed.apk'
run(['pull',path,str(copy)]);actual=hashlib.sha256(copy.read_bytes()).hexdigest();expected=hashlib.sha256((R/'dist/Open-Repertory-Clarke-Dev.apk').read_bytes()).hexdigest();copy.unlink()
if actual!=expected:raise SystemExit('Installed update does not match the tested APK')
result={'sourceVersion':'1.19-dev','installedVersion':'1.20-dev','discovery':'passed','nativeDownloadAndVerification':'passed','androidInstallation':'passed','encryptedRecordsAndPhoneIdentity':'passed','installedApkSha256':actual,'matchesTestedApk':True,'approvalMode':'emulator-only synthetic receipts; no real owner credentials used'}
(O/'live-update-e2e.json').write_text(json.dumps(result,indent=2)+'\n');print('Live updater installation verified',flush=True)
