"""Exercise the clinical shortcut through real rubric controls and saved cases."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]; O=R/'test-results/v1.21'; O.mkdir(parents=True,exist_ok=True); results=[]
def check(value,label):
    assert value,label
    results.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def ready(page):
    page.goto('http://127.0.0.1:8765');page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000)
def browse(page):
    page.evaluate('OR.showPage("repertory");OR.runSearch("fear")')
    page.locator('#rubricList .add-btn').first.wait_for()
def safe(page):
    return page.locator('#analysisShortcut').evaluate('''b=>{const r=b.getBoundingClientRect(),status=document.querySelector('#statusbar'),s=status&&status.getClientRects().length?status.getBoundingClientRect():null,n=document.querySelector('#bottomNav').getBoundingClientRect();return r.width>=44&&r.height>=44&&r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight-8&&(!s||r.bottom<=s.top-8)&&(!n.height||r.bottom<=n.top-8)}''')
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
        page=browser.new_page(viewport={'width':width,'height':height});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));ready(page);browse(page)
        fab=page.locator('#analysisShortcut')
        check(fab.is_hidden(),f'{width}px: no floating action for an empty case')
        page.locator('#rubricList .add-btn').first.click()
        check(fab.is_visible() and page.locator('#analysisShortcutCount').inner_text()=='1',f'{width}px: selecting a real rubric shows the clipboard button and live count')
        check(safe(page),f'{width}px: touch target fits above the status bar and bottom navigation')
        before=page.evaluate('JSON.stringify(OR.activeCase())');ranking=page.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')
        fab.click()
        check(page.evaluate('OR.state.page')=='analysis' and page.locator('#selectedList .selected-item').count()==1 and page.locator('#resultsTableWrap table').count()>0,f'{width}px: clipboard opens the existing full rubric analysis and results')
        check(fab.is_hidden() and page.evaluate('JSON.stringify(OR.activeCase())')==before and page.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')==ranking,f'{width}px: navigation preserves the case, weights and ranking')
        browse(page);page.locator('#rubricList .add-btn:not(.added)').first.click()
        check(page.locator('#analysisShortcutCount').inner_text()=='2',f'{width}px: additional rubric updates the count')
        page.locator('#menuBtn').click();check(fab.is_hidden(),f'{width}px: shortcut disappears behind the tools dialog');page.locator('#menuClose').click();check(fab.is_visible(),f'{width}px: closing tools restores the shortcut')
        page.evaluate('OR.modal({title:"Synthetic test",html:"<p>Test</p>"})');check(fab.is_hidden(),f'{width}px: shortcut is hidden during a modal');page.locator('.modal-x').click();check(fab.is_visible(),f'{width}px: closing a modal restores the shortcut')
        page.locator('#searchBox').focus();check(fab.is_hidden(),f'{width}px: shortcut stays out of text entry');page.locator('#searchBox').evaluate('e=>e.blur()');page.wait_for_timeout(30);check(fab.is_visible(),f'{width}px: shortcut returns after text entry')
        if width<700:
            page.locator('#sidebarToggle').click();check(fab.is_hidden(),f'{width}px: chapter drawer does not compete with floating analysis');page.locator('#sidebarClose').click();check(fab.is_visible(),f'{width}px: chapter close restores analysis')
        for destination in ['dashboard','patients','file','mm','diff']:
            page.evaluate('(p)=>OR.showPage(p)',destination);check(fab.is_hidden(),f'{width}px: no floating analysis over {destination}')
        browse(page);page.evaluate('window.testOldCase=OR.state.activeCaseId;OR.newCase("Synthetic empty case",null);OR.showPage("repertory")');check(fab.is_hidden(),f'{width}px: switching to an empty case clears the shortcut')
        page.evaluate('''()=>{const s=document.querySelector('#caseSelect');s.value=window.testOldCase;s.dispatchEvent(new Event('change'));}''');page.wait_for_function('()=>OR.activeCase().analysis.length===2');check(fab.is_visible() and page.locator('#analysisShortcutCount').inner_text()=='2',f'{width}px: switching back restores the correct case count')
        page.reload();page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000);browse(page);check(fab.is_visible() and page.locator('#analysisShortcutCount').inner_text()=='2',f'{width}px: saved selections survive a reload')
        # Last result remains reachable above the floating control after scrolling.
        page.evaluate('OR.runSearch("fear death")');page.locator('#rubricList .add-btn').first.wait_for()
        page.evaluate('''()=>{const c=document.querySelector('#content');c.scrollTop=c.scrollHeight;}''');page.wait_for_timeout(100)
        check(page.locator('#rubricList .add-btn').last.evaluate('e=>e.getBoundingClientRect().bottom') < fab.bounding_box()['y'],f'{width}px: scroll reserve keeps the last rubric Add button clear')
        end_scroll=page.locator('#content').evaluate('e=>e.scrollTop')
        page.locator('#menuBtn').click();page.locator('#menuClose').click()
        check(abs(page.locator('#content').evaluate('e=>e.scrollTop')-end_scroll)<1,f'{width}px: temporary menu preserves the final-row reading position')
        fab.click();page.locator('#clearAnalysis').click();page.locator('#clearAnalysis').click();browse(page);check(fab.is_hidden(),f'{width}px: clearing the final selection hides the shortcut')
        check(not errors,f'{width}px: no uncaught script errors');page.close()
    page=browser.new_page(viewport={'width':393,'height':800});ready(page);browse(page);page.locator('#rubricList .add-btn').first.click()
    page.add_style_tag(content='.analysis-shortcut{font-size:28px}')
    check(safe(page),'large-text floating action fits without clipping');page.locator('#analysisShortcut').focus();page.keyboard.press('Enter');check(page.evaluate('OR.state.page')=='analysis','keyboard activation opens analysis')
    page.evaluate('OR.store.set("openrepertory_theme",{t:"dark"})');page.reload();page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000);browse(page);check(safe(page),'dark theme preserves safe placement');page.screenshot(path=str(O/'analysis-shortcut-dark.png'))
    page.emulate_media(media='print');check(page.locator('#analysisShortcut').is_hidden(),'floating action is excluded from printed case reports');page.emulate_media(media='screen');page.close();browser.close()
(O/'analysis-shortcut-web-tests.json').write_text(json.dumps(results,indent=2));print('Shortcut browser checks passed:',len(results))
