"""Verify an installable menu-only update preserves the shipped clinical application."""
from pathlib import Path
import json,hashlib,subprocess,zipfile,os
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.21';rows=[];A=R/'dist/Open-Repertory-Clarke-Dev.apk';B=R/'releases/1.20/Open-Repertory-1.20.apk';bt='/workspace/tools/android/android-15/'
def check(v,label):
 assert v,label
 rows.append({'test':label,'status':'passed'});print('PASS',label)
with zipfile.ZipFile(A) as new,zipfile.ZipFile(B) as old:
 check(new.testzip() is None,'APK ZIP integrity')
 data=[n for n in old.namelist() if n.startswith('assets/www/data/') and 'audit' not in n]
 check(all(new.read(n)==old.read(n) for n in data),f'all {len(data)} clinical data/text assets are byte-for-byte unchanged')
 allowed={'assets/www/index.html','assets/www/css/style.css','assets/www/js/app.js'};unexpected=[]
 for n in old.namelist():
  if not n.startswith('assets/www/') or new.read(n)==old.read(n):continue
  if n in allowed:continue
  if 'audit' in n and n.endswith('.json'):
   a=json.loads(new.read(n));b=json.loads(old.read(n))
   for k in ['generated_at','generatedAt','builtAt']:a.pop(k,None);b.pop(k,None)
   if a==b:continue
  unexpected.append(n)
 check(not unexpected,'web differences are limited to clipboard markup/styling/behaviour and audit timestamps: '+str(unexpected))
 check(not any(n.endswith(('.p12','.keystore','.jks','.pdf')) or 'private' in n.lower() or 'firebase-config' in n.lower() for n in new.namelist()),'APK excludes private keys, archived Firebase configuration and source PDFs')
 dex=new.read('classes.dex');check(b'MenuChecks' not in dex and b'FixtureAuthView' not in dex and b'synthetic-apper-owner' not in dex,'test-only receipt injection and fixture classes are not shipped')
 check(all(v in dex for v in [b'devil01529/Openrepertory-update',b'preview--openrepertory-eminent.apper.so',b'AppUpdates',b'SHA256withRSA']), 'existing signed updater and Apper access endpoint are retained')
 check(b'OR.dismissMenu' in dex,'Android Back delegates to the clinical menu before its existing fallback')
 check(new.read('assets/www/css/style.css').find(b'.menu-panel[hidden]')>=0,'packaged menu explicitly respects hidden views on older WebViews')
badging=lambda p:subprocess.check_output([bt+'aapt2','dump','badging',str(p)],text=True)
a=badging(A);b=badging(B)
check("name='com.openrepertory.app.dev'" in a and "versionCode='22'" in a and "versionName='1.21-dev'" in a,'same package and increasing Android version support update from v1.20')
cert=lambda p:next(x for x in subprocess.check_output([bt+'apksigner','verify','--print-certs',str(p)],text=True).splitlines() if 'certificate SHA-256 digest:' in x)
check(cert(A)==cert(B),'existing Android signing certificate is unchanged')
perms=lambda t:{l for l in t.splitlines() if l.startswith('uses-permission:')}
check(perms(a)==perms(b),'no additional Android permissions')
# The updater implementation itself is intentionally unchanged.
public=Path('/workspace/open-repertory-public-updates/android-updater')
check(all((R/'native/com/openrepertory/app'/n).read_bytes()==(public/n).read_bytes() for n in ['AppUpdates.java','UpdateFileProvider.java']),'signed download and installation implementation matches the already shipped v1.20 updater')
(O/'analysis-shortcut-package-tests.json').write_text(json.dumps(rows,indent=2));print('Menu package checks passed:',len(rows))
