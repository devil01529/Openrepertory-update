package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.webkit.*;import java.lang.reflect.*;import java.io.*;import org.json.*;
/** Full encrypted export, Android file selection, FileReader and merge using synthetic records. */
public class DocumentChecks extends DevChecks {
 String shellOutput(String command)throws Exception{
  ByteArrayOutputStream output=new ByteArrayOutputStream();
  try(InputStream in=new ParcelFileDescriptor.AutoCloseInputStream(getUiAutomation().executeShellCommand(command))){byte[] buffer=new byte[1024];int count;while((count=in.read(buffer))!=-1)output.write(buffer,0,count);}
  return output.toString("UTF-8");
 }
 void shell(String command)throws Exception{shellOutput(command);}
 String labels(android.view.accessibility.AccessibilityNodeInfo node){if(node==null)return "<no active window>";String text="["+node.getText()+"|"+node.getContentDescription()+"]";for(int i=0;i<node.getChildCount();i++)text+=labels(node.getChild(i));return text;}
 boolean scrollFiles(android.view.accessibility.AccessibilityNodeInfo node){if(node==null)return false;if(node.isScrollable()&&node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))return true;for(int i=0;i<node.getChildCount();i++)if(scrollFiles(node.getChild(i)))return true;return false;}
 android.view.accessibility.AccessibilityNodeInfo findFile(android.view.accessibility.AccessibilityNodeInfo node,String name){if(node==null)return null;if(node.isVisibleToUser()&&node.getText()!=null&&name.equals(node.getText().toString()))return node;for(int i=0;i<node.getChildCount();i++){android.view.accessibility.AccessibilityNodeInfo found=findFile(node.getChild(i),name);if(found!=null)return found;}return null;}
 void chooseBackup(String filename)throws Exception{long end=System.currentTimeMillis()+45000;while(System.currentTimeMillis()<end){android.view.accessibility.AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow(),file=findFile(root,filename);if(file!=null){android.graphics.Rect bounds=new android.graphics.Rect();file.getBoundsInScreen(bounds);if(!bounds.isEmpty()){Bundle selected=new Bundle();selected.putString("stream","Selecting exported document "+filename+" at "+bounds+"\n");sendStatus(0,selected);shell("input tap "+bounds.centerX()+" "+bounds.centerY());Thread.sleep(1000);clickNamed(getUiAutomation().getRootInActiveWindow(),"Open");return;}}scrollFiles(root);Thread.sleep(700);}throw new Exception("Backup file not found: "+filename);}
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.MODEL.contains("sdk"))throw new Exception("Synthetic credential automation is restricted to an emulator");
  activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Class<?> base=activity.getClass().getSuperclass();Field f=base.getDeclaredField("webView");f.setAccessible(true);web=(WebView)f.get(activity);
  runOnMainSync(()->activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT));
  waitJS("!!(window.OR&&OR.state.repertory)",180);Field auth=base.getDeclaredField("authenticated");auth.setAccessible(true);
  if(!auth.getBoolean(activity)){
   shell("input tap 240 250");shell("input keyevent 67 67 67 67 67 67 67 67");shell("input text 1234");shell("input keyevent 66");
   long end=System.currentTimeMillis()+60000;while(!auth.getBoolean(activity)&&System.currentTimeMillis()<end)Thread.sleep(500);
  }
  check(auth.getBoolean(activity),"Android emulator device credential unlocks the app");
  int before=((Number)js("OR.patientList().length")).intValue();
  js("OR.patients.openBackup();document.querySelector('#bkEncPass').value='native-document-password-15';document.querySelector('#bkSaveEnc').click()");
  clickDocumentControl("Save");
  // A repeated run can legitimately offer overwrite confirmation for today's backup.
  long end=System.currentTimeMillis()+90000;
  while(System.currentTimeMillis()<end){
   if(Boolean.TRUE.equals(js("document.querySelector('#bkMsg') && document.querySelector('#bkMsg').textContent.includes('Encrypted backup saved')")))break;
   clickNamed(getUiAutomation().getRootInActiveWindow(),"Replace");Thread.sleep(500);
  }
  check(Boolean.TRUE.equals(js("document.querySelector('#bkMsg').textContent.includes('Encrypted backup saved')")),"encrypted backup saves through the actual Android document provider");
  String filename=null;for(String candidate:shellOutput("ls -t /sdcard/Download").split("\n")){candidate=candidate.trim();if(candidate.startsWith("openrepertory-backup-")&&candidate.endsWith(".orbk")){filename=candidate;break;}}
  if(filename==null)throw new Exception("Saved backup not present in emulator Downloads");
  js("document.querySelector('#bkFile').scrollIntoView({block:'center'})");Thread.sleep(1000);
  JSONArray point=(JSONArray)js("(function(){var r=document.querySelector('#bkFile').getBoundingClientRect();return [r.left+10,r.top+r.height/2,innerWidth,r.top,r.height]})()");
  int[] origin=new int[2];runOnMainSync(()->web.getLocationOnScreen(origin));double scale=web.getWidth()/point.getDouble(2);
  float x=origin[0]+(float)(point.getDouble(0)*scale),y=origin[1]+(float)(point.getDouble(1)*scale);
  check(y>origin[1] && y<origin[1]+web.getHeight() && x>origin[0] && x<origin[0]+web.getWidth(),"backup file control remains visible inside the scrolled Android dialog");
  Bundle geometry=new Bundle();geometry.putString("stream","File input geometry "+point+"; origin="+origin[0]+","+origin[1]+"; tap="+x+","+y+"; visible="+web.getVisibility()+"\n");sendStatus(0,geometry);
  long now=SystemClock.uptimeMillis();sendPointerSync(android.view.MotionEvent.obtain(now,now,0,x,y,0));sendPointerSync(android.view.MotionEvent.obtain(now,now+100,1,x,y,0));
  clickDocumentControl("Show roots");clickDocumentControl("Downloads");chooseBackup(filename);
  waitJS("document.querySelector('#bkMsg').textContent.includes('File loaded') || document.querySelector('#bkMsg').textContent.includes('could not be read')",90);
  check(Boolean.TRUE.equals(js("document.querySelector('#bkText').value.startsWith('ORBK2.')")),"Android file picker and FileReader load the encrypted backup");
  js("document.querySelector('#bkImportPass').value='native-document-password-15';document.querySelector('#bkMerge').click()");
  waitJS("document.querySelector('#bkMsg').textContent.startsWith('Imported')",120);
  check(((Number)js("OR.patientList().length")).intValue()==before,"encrypted Android export/import round trip preserves patient count");
  check("ok".equals(js("openrepertorySecure.storageHealth()")),"imported Android records pass encrypted collection checks");
  result.putString("stream","Document checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable error){result.putString("stream","Document checks failed: "+error+"; UI="+labels(getUiAutomation().getRootInActiveWindow())+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
