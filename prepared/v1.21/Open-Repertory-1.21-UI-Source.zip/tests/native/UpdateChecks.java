package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import android.content.pm.*;import android.util.Base64;import com.openrepertory.app.*;import org.json.*;import java.io.*;import java.net.*;import java.security.*;import java.util.*;
/** Real crypto, archive parser, transfer and scoped provider checks; emulator fixtures only. */
public final class UpdateChecks extends DevChecks {
 KeyPair key;String publicKey;File folder;
 String sign(JSONObject payload)throws Exception {
  byte[] bytes=payload.toString().getBytes("UTF-8");java.security.Signature s=java.security.Signature.getInstance("SHA256withRSA");s.initSign(key.getPrivate());s.update(bytes);
  return new JSONObject().put("schema",1).put("payload",Base64.encodeToString(bytes,Base64.NO_WRAP)).put("signature",Base64.encodeToString(s.sign(),Base64.NO_WRAP)).toString();
 }
 JSONObject payload(File apk,int code)throws Exception{return new JSONObject().put("schema",1).put("repository",UpdateConfig.REPOSITORY).put("packageName",getTargetContext().getPackageName()).put("versionCode",code).put("versionName","fixture").put("minSdk",23).put("apkUrl","https://github.com/"+UpdateConfig.REPOSITORY+"/releases/download/v1.20/fixture.apk").put("size",apk.length()).put("sha256",AppUpdates.hash(apk)).put("notes","Synthetic update test").put("publishedAt","2026-10-22T00:00:00Z");}
 boolean rejects(String text,String pub){try{AppUpdates.parseSigned(text,pub);return false;}catch(Exception e){return true;}}
 boolean rejectsApk(File f,AppUpdates.Release r){try{AppUpdates.validateApk(getTargetContext(),f,r);return false;}catch(Exception e){return true;}}
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
  folder=new File(getTargetContext().getExternalCacheDir(),"update-fixtures");File valid=new File(folder,"valid.apk");
  KeyPairGenerator generator=KeyPairGenerator.getInstance("RSA");generator.initialize(2048);key=generator.generateKeyPair();publicKey=Base64.encodeToString(key.getPublic().getEncoded(),Base64.NO_WRAP);
  JSONObject original=payload(valid,21);String signed=sign(original);AppUpdates.Release release=AppUpdates.parseSigned(signed,publicKey);
  check(release.code==21,"valid RSA-signed update information is accepted");
  JSONObject changed=new JSONObject(signed);byte[] bytes=Base64.decode(changed.getString("payload"),Base64.NO_WRAP);bytes[5]^=1;changed.put("payload",Base64.encodeToString(bytes,Base64.NO_WRAP));check(rejects(changed.toString(),publicKey),"modified release payload is rejected");
  check(rejects(signed,UpdateConfig.PUBLIC_KEY),"an unrelated metadata signing key is rejected by the pinned production key");
  changed=new JSONObject(signed).put("schema",2);check(rejects(changed.toString(),publicKey),"unknown envelope format is rejected");
  for(String field:new String[]{"repository","packageName","sha256","apkUrl","size","versionCode","minSdk"}){
   JSONObject bad=new JSONObject(original.toString());bad.put(field,"size".equals(field)?AppUpdates.MAX_APK+1:"versionCode".equals(field)?0:"minSdk".equals(field)?1:"invalid");check(rejects(sign(bad),publicKey),"invalid signed "+field+" is rejected");
  }
  for(String url:new String[]{"http://github.com/x","https://github.com.evil.test/x","https://user@github.com/x","https://github.com:444/x","https://evil.test/file.apk"})check(!AppUpdates.trustedUrl(new URL(url)),"untrusted destination rejected: "+url);
  check(AppUpdates.trustedUrl(new URL("https://github.com/a"))&&AppUpdates.trustedUrl(new URL("https://release-assets.githubusercontent.com/a?token=temporary")),"HTTPS GitHub asset redirects are allowed");
  AppUpdates.validateApk(getTargetContext(),valid,release);check(true,"actual higher-version APK with the installed signing identity validates");
  for(String name:new String[]{"wrong-package","wrong-signer","old"}){
   File f=new File(folder,name+".apk");AppUpdates.Release r=AppUpdates.parseSigned(sign(payload(f,"old".equals(name)?19:21)),publicKey);check(rejectsApk(f,r),"actual "+name+" APK is rejected");
  }
  File damaged=new File(folder,"damaged.apk");try(FileInputStream in=new FileInputStream(valid);FileOutputStream out=new FileOutputStream(damaged)){byte[] b=new byte[1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.write(1);}
  check(rejectsApk(damaged,release),"changed APK bytes are rejected");damaged.delete();
  JSONObject wrongVersion=new JSONObject(original.toString()).put("versionCode",22);check(rejectsApk(valid,AppUpdates.parseSigned(sign(wrongVersion),publicKey)),"manifest and APK version mismatch is rejected");
  JSONObject wrongSize=new JSONObject(original.toString()).put("size",valid.length()-1);check(rejectsApk(valid,AppUpdates.parseSigned(sign(wrongSize),publicKey)),"manifest and APK size mismatch is rejected");
  File output=new File(folder,"transfer.part");AppUpdates.TransferEvents normal=new AppUpdates.TransferEvents(){public boolean cancelled(){return false;}public void progress(int p){}};
  byte[] contents=new byte[1000];Arrays.fill(contents,(byte)7);AppUpdates.transfer(new ByteArrayInputStream(contents),output,1000,normal);check(output.length()==1000,"complete bounded download is saved");output.delete();
  boolean failed=false;try{AppUpdates.transfer(new ByteArrayInputStream(contents),output,1001,normal);}catch(Exception e){failed=true;}check(failed&&!output.exists(),"truncated download is rejected and its partial file removed");
  failed=false;try{AppUpdates.transfer(new ByteArrayInputStream(contents),output,999,normal);}catch(Exception e){failed=true;}check(failed&&!output.exists(),"oversized download is rejected and removed");
  failed=false;try{AppUpdates.transfer(new ByteArrayInputStream(contents),output,1000,new AppUpdates.TransferEvents(){public boolean cancelled(){return true;}public void progress(int p){}});}catch(InterruptedIOException e){failed=true;}check(failed&&!output.exists(),"cancelled download removes its partial file");
  failed=false;try{AppUpdates.transfer(new InputStream(){public int read()throws IOException{throw new IOException("Fixture connection lost");}},output,1000,normal);}catch(IOException e){failed=true;}check(failed&&!output.exists(),"connection failure removes its partial file");
  UpdateFileProvider provider=new UpdateFileProvider();ProviderInfo info=new ProviderInfo();info.authority=getTargetContext().getPackageName()+".updates";provider.attachInfo(getTargetContext(),info);
  Uri allowed=Uri.parse("content://"+info.authority+"/verified.apk");check("application/vnd.android.package-archive".equals(provider.getType(allowed)),"provider exposes the verified APK MIME type");
  for(String path:new String[]{"/../records-v2.db","/verified.apk?file=records-v2.db","/%76erified.apk","/manifest.json"}){
   failed=false;try{provider.openFile(Uri.parse("content://"+info.authority+path),"r");}catch(Exception e){failed=true;}check(failed,"provider rejects unrelated or ambiguous path "+path);
  }
  failed=false;try{provider.openFile(allowed,"w");}catch(Exception e){failed=true;}check(failed,"installer cannot write through the update provider");
  ProviderInfo declared=getTargetContext().getPackageManager().resolveContentProvider(info.authority,0);check(declared!=null&&!declared.exported&&declared.grantUriPermissions,"manifest restricts provider access to explicit URI grants");
  result.putString("stream","Update native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","FAILED after "+passed+" checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
