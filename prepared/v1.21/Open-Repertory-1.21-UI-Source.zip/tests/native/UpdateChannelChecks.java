package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import com.openrepertory.app.*;import java.io.*;import java.net.*;import java.lang.reflect.*;import org.json.*;
/** Anonymous live GitHub channel check; no passwords, API tokens or medical data. */
public final class UpdateChannelChecks extends DevChecks {
 static final class NetworkOnlyActivity extends Activity {NetworkOnlyActivity(Context context){attachBaseContext(context);}}
 @Override public void onStart(){Bundle result=new Bundle();AppUpdates updater=null;try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
  runOnMainSync(()->activity=new NetworkOnlyActivity(getTargetContext()));
  AppUpdates[] holder=new AppUpdates[1];runOnMainSync(()->{try{holder[0]=new AppUpdates(activity,new AppUpdates.Host(){public boolean allowed(){return false;}public void beforeInstall(Runnable r){}});}catch(Exception e){throw new RuntimeException(e);}});updater=holder[0];
  Method fetch=AppUpdates.class.getDeclaredMethod("fetchManifest");fetch.setAccessible(true);String envelope=(String)fetch.invoke(updater);
  AppUpdates.Release r=AppUpdates.parseSigned(envelope,UpdateConfig.PUBLIC_KEY);check(r.code==20&&r.name.equals("1.19-dev"),"anonymous native request reads and verifies the live latest release");
  Method open=AppUpdates.class.getDeclaredMethod("open",URL.class);open.setAccessible(true);HttpURLConnection connection=(HttpURLConnection)open.invoke(updater,new URL(r.url));
  File download=new File(getTargetContext().getExternalCacheDir(),"live-channel-download.apk");
  try(InputStream in=connection.getInputStream()){AppUpdates.transfer(in,download,r.size,new AppUpdates.TransferEvents(){public boolean cancelled(){return false;}public void progress(int p){}});}finally{connection.disconnect();}
  check(download.length()==r.size&&AppUpdates.hash(download).equals(r.sha256),"native anonymous GitHub asset download matches the signed release hash and size");
  boolean rejected=false;try{AppUpdates.validateApk(getTargetContext(),download,r);}catch(SecurityException expected){rejected=true;}
  check(rejected,"the current published APK cannot be offered as an in-place downgrade or same-version reinstall");download.delete();
  result.putString("stream","Live update channel checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){Throwable cause=e instanceof InvocationTargetException?((InvocationTargetException)e).getCause():e;result.putString("stream","FAILED after "+passed+" live channel checks: "+cause+"\n");finish(Activity.RESULT_CANCELED,result);}finally{if(updater!=null){final AppUpdates u=updater;runOnMainSync(u::dispose);}}}
}
