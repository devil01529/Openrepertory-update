package com.openrepertory.tests;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import java.lang.reflect.*;

/** Installed-window checks for the owner-requested screenshot-enabled build. */
public class CaptureChecks extends DevChecks {
 private boolean secure() {
  boolean[] value=new boolean[1];runOnMainSync(()->value[0]=(activity.getWindow().getAttributes().flags&WindowManager.LayoutParams.FLAG_SECURE)!=0);return value[0];
 }
 @Override public void onStart() {
  Bundle result=new Bundle();
  try {
   activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
   Class<?> base=activity.getClass().getSuperclass();Field f=base.getDeclaredField("webView");f.setAccessible(true);web=(WebView)f.get(activity);
   waitJS("!!(window.OR && OR.state.repertory && OR.state.page==='dashboard')",180);unlockTestActivity(base);
   check("1.11-dev".equals(getTargetContext().getPackageManager().getPackageInfo("com.openrepertory.app.dev",0).versionName),"installed screenshot-enabled version 1.11-dev");
   check(!secure(),"unlocked foreground window allows screenshots");
   js("openrepertoryNative.setSensitiveScreen(true)");getUiAutomation().waitForIdle(500,5000);
   check(!secure(),"old sensitive-screen callback cannot restore global screenshot block");
   for(String page:new String[]{"repertory","patients","analysis","dashboard"}) {
    js("OR.showPage('"+page+"')");Thread.sleep(300);check(!secure(),"screenshots remain available on "+page);
   }
   runOnMainSync(()->callActivityOnPause(activity));check(secure(),"background window remains protected");
   runOnMainSync(()->callActivityOnResume(activity));check(!secure(),"returning to unlocked app restores screenshot access");
   js("OR.showPage('repertory');OR.runSearch('acidity')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='acidity'",90);
   android.graphics.Bitmap capture=getUiAutomation().takeScreenshot();
   check(capture!=null,"Android screenshot API captures the app");
   int visible=0,total=0;
   for(int y=capture.getHeight()/4;y<capture.getHeight()*3/4;y+=12)for(int x=capture.getWidth()/4;x<capture.getWidth()*3/4;x+=12){int c=capture.getPixel(x,y);if(android.graphics.Color.red(c)+android.graphics.Color.green(c)+android.graphics.Color.blue(c)>30)visible++;total++;}
   check(visible>total*.6,"actual screenshot contains app content instead of a black protected surface");
   java.io.File file=new java.io.File(getTargetContext().getExternalCacheDir(),"screenshot-enabled-app.png");try(java.io.FileOutputStream out=new java.io.FileOutputStream(file)){capture.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}
   result.putString("stream","Capture native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
  }catch(Throwable e){result.putString("stream","FAILED after "+passed+" checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}
 }
}
