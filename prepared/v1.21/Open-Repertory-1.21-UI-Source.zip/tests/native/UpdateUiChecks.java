package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.view.*;import android.webkit.*;import android.widget.*;import com.openrepertory.app.*;import java.io.*;import java.lang.reflect.*;import org.json.*;
/** Emulator-only updater UI and real Android installer handoff. The fixture is never installed. */
public final class UpdateUiChecks extends StartupChecks {
 Object updateField(AppUpdates u,String name)throws Exception{Field f=AppUpdates.class.getDeclaredField(name);f.setAccessible(true);return f.get(u);}
 void updateInvoke(AppUpdates u,String name)throws Exception{Method m=AppUpdates.class.getDeclaredMethod(name);m.setAccessible(true);runOnMainSync(()->{try{m.invoke(u);}catch(Exception e){throw new RuntimeException(e);}});}
 void idle(AppUpdates u)throws Exception{long end=SystemClock.elapsedRealtime()+60000;while(SystemClock.elapsedRealtime()<end){if(!Boolean.TRUE.equals(updateField(u,"working")))return;Thread.sleep(100);}throw new Exception("Update operation timed out");}
 String label(AppUpdates u,String name)throws Exception{android.widget.TextView v=(android.widget.TextView)updateField(u,name);String[] value=new String[1];runOnMainSync(()->value[0]=v.getText().toString());return value[0];}
 void copy(File from,File to)throws Exception{try(InputStream in=new FileInputStream(from);FileOutputStream out=new FileOutputStream(to)){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}}
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
  activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
  ApperAccess access=(ApperAccess)field("access");getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
  ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field bf=ApperAccessScreen.class.getDeclaredField("browser");bf.setAccessible(true);WebView browser=(WebView)bf.get(screen);runOnMainSync(()->{screen.cancel();browser.stopLoading();});
  receive(receipt(access.deviceId()));ready();
  AppUpdates updates=(AppUpdates)field("updates");check(updates!=null,"native updater initializes without changing the approved workspace");
  js("window.__updatePage='retained';OR.showPage('repertory');document.getElementById('menuUpdates').click()");Thread.sleep(300);idle(updates);
  check(((AlertDialog)updateField(updates,"dialog")).isShowing(),"App updates menu opens the native update screen");
  check(label(updates,"text").contains("Installed: 1.19-dev"),"update screen shows the real installed version");
  check("retained".equals(js("window.__updatePage")),"opening updates retains the clinical document");
  File cache=new File(getTargetContext().getExternalCacheDir(),"update-fixtures"),dir=new File(getTargetContext().getFilesDir(),"updates");
  copy(new File(cache,"install-manifest.json"),new File(dir,"manifest.json"));copy(new File(cache,"valid.apk"),new File(dir,"update.apk"));
  runOnMainSync(updates::pause);runOnMainSync(updates::show);idle(updates);
  check("Install update".equals(label(updates,"downloadButton")),"a saved, independently signed verified download is reusable after reopening");
  check(label(updates,"text").contains("Download verified"),"cached download is verified before offering installation");
  updateInvoke(updates,"install");idle(updates);Thread.sleep(1000);
  // Test runner grants REQUEST_INSTALL_PACKAGES to this emulator before the test.
  boolean installerVisible=false,cancelledInstaller=false;long cancelDeadline=SystemClock.elapsedRealtime()+45000;
  while(SystemClock.elapsedRealtime()<cancelDeadline){
   android.view.accessibility.AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();
   if(root!=null&&String.valueOf(root.getPackageName()).contains("packageinstaller")){
    installerVisible=true;if(clickNamed(root,"Cancel")){cancelledInstaller=true;break;}
   }
   Thread.sleep(300);
  }
  check(installerVisible,"verified APK is handed to Android's actual package installer; status="+updateField(updates,"status"));
  check(cancelledInstaller,"the actual Android installation confirmation can be cancelled");
  boolean returned=false;long returnDeadline=SystemClock.elapsedRealtime()+45000;
  while(SystemClock.elapsedRealtime()<returnDeadline){android.view.accessibility.AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();if(root!=null&&!String.valueOf(root.getPackageName()).contains("packageinstaller")){returned=true;break;}if(root!=null)clickNamed(root,"Cancel");Thread.sleep(500);}
  check(returned,"cancelling returns from the Android installer");
  check(getTargetContext().getPackageManager().getPackageInfo(getTargetContext().getPackageName(),0).versionCode==20,"cancelling the installer retains the installed clinical APK");
  check(new File(dir,"update.apk").isFile(),"cancelling installation retains the verified download for retry");
  // Host approval remains enforced even with a retained bridge and a verified update.
  JSONObject denied=receipt(access.deviceId());denied.put("status","revoked");denied.getJSONObject("grant").put("status","revoked");receive(denied);
  boolean rejected=false;try{((ImprovedActivity)activity).new NativeBridge().openUpdates();}catch(SecurityException expected){rejected=true;}check(rejected,"a revoked account cannot invoke the update bridge");
  new File(dir,"update.apk").delete();new File(dir,"manifest.json").delete();runOnMainSync(updates::pause);
  result.putString("stream","Update UI checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","FAILED after "+passed+" checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
