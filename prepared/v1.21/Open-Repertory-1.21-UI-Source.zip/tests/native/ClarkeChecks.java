package com.openrepertory.tests;
import android.app.*;
import android.content.*;
import android.os.*;
import android.webkit.*;
import java.lang.reflect.*;

/** Real APK / WebView / encrypted database checks; all records are synthetic. */
public class ClarkeChecks extends DevChecks {
 @Override public void onStart() {
  Bundle result=new Bundle();
  try {
   activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
   Class<?> base=activity.getClass().getSuperclass();Field f=base.getDeclaredField("webView");f.setAccessible(true);web=(WebView)f.get(activity);
   waitJS("!!(window.OR && OR.state.repertory && OR.state.page==='dashboard')",180);unlockTestActivity(base);
   check(Boolean.TRUE.equals(js("ORStorage.native")),"real encrypted native storage active");
   check("1.10-dev".equals(getTargetContext().getPackageManager().getPackageInfo("com.openrepertory.app.dev",0).versionName),"installed structured development release 1.10-dev");
   android.graphics.drawable.Drawable launcher=getTargetContext().getApplicationInfo().loadIcon(getTargetContext().getPackageManager());
   check(launcher instanceof android.graphics.drawable.AdaptiveIconDrawable,"adaptive launcher icon resolves on Android");
   android.graphics.Bitmap preview=android.graphics.Bitmap.createBitmap(256,256,android.graphics.Bitmap.Config.ARGB_8888);launcher.setBounds(0,0,256,256);launcher.draw(new android.graphics.Canvas(preview));
   check(android.graphics.Color.alpha(preview.getPixel(128,128))>0,"launcher artwork renders without an empty center");
   java.io.File previewFile=new java.io.File(getTargetContext().getExternalCacheDir(),"launcher-preview.png");try(java.io.FileOutputStream output=new java.io.FileOutputStream(previewFile)){preview.compress(android.graphics.Bitmap.CompressFormat.PNG,100,output);}
   js("OR.setRepertory('clarke')");waitJS("OR.state.repertoryId==='clarke'",120);
   check(((Number)js("OR.state.repertory.chapters.length")).intValue()==3,"Clarke loads three structured repertory chapters offline");
   check(Boolean.TRUE.equals(js("OR.state.remedies['Clarke-fer'].indexOf('combined source label')>=0")),"source-specific remedy names resolve");
   js("OR.newCase('SYNTHETIC_NATIVE_CLARKE',null);OR.showPage('repertory');OR.runSearch('abdomen distended')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='abdomen distended'",180);
   check("worker".equals(js("OR.lastSearchStats.backend")),"structured search runs in Android WebView worker");
   check(((Number)js("document.querySelector('[data-rubric-uid*=clarke-043-1186]').querySelectorAll('.rem').length")).intValue()==7,"scan-checked distended abdomen rubric has seven remedies");
   check(Boolean.TRUE.equals(js("document.querySelector('[data-rubric-uid*=clarke-043-1186]').textContent.indexOf('printed p. 34')>=0")),"rubric source citation renders");
   js("OR.runSearch('abdomen large')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='abdomen large'",90);js("document.querySelector('[data-rubric-uid*=clarke-043-1235] .add-btn').click()");
   js("OR.runSearch('acidity')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='acidity'",90);check(Boolean.TRUE.equals(js("document.querySelector('[data-rubric-uid*=clarke-043-2150]').querySelectorAll('.source-italic').length===4")),"checked Acidity retains exactly four printed italic remedies");
   check(Boolean.TRUE.equals(js("getComputedStyle(document.querySelector('[data-rubric-uid*=clarke-043-2150] [data-abbr=\"Calc.\"]')).fontStyle==='italic'")),"source italics render independently of grade 1");
   js("document.querySelector('[data-rubric-uid*=clarke-043-2150] .add-btn').click()");
   check(Boolean.TRUE.equals(js("OR.activeCase().analysis.length===2 && OR.activeCase().repertoryId==='clarke'")),"ordinary rubric buttons add to a Clarke source-locked case");
   check(Boolean.TRUE.equals(js("OR.rankCase(OR.activeCase()).some(r=>r.abbr==='Calc.' && r.count===2 && r.score===2 && r.coveragePct===100)")),"native ranking agrees with independent presence-only expectation");
   check(Boolean.TRUE.equals(js("document.querySelector('#includeGrade1').disabled")),"strength-grade filtering disabled for presence-only source");
   check(Boolean.TRUE.equals(js("OR.activeCase().analysis.every(x=>x.provenance && x.provenance.sourceIds.length>0)")),"case retains rubric-level source provenance");
   js("OR.saveCaseSnapshot(OR.activeCase());window.__clarkeReload='before'");
   runOnMainSync(()->web.reload());waitJS("typeof window.__clarkeReload==='undefined' && !!(window.OR && OR.state.repertory)",180);
   check(Boolean.TRUE.equals(js("OR.state.repertoryId==='clarke' && OR.activeCase().analysis.length===2")),"Clarke selection and encrypted case survive WebView reload");
   check(Boolean.TRUE.equals(js("OR.activeCase().analysis.every(x=>x.provenance && x.provenance.sourceIds.length>0) && OR.activeCase().snapshots.slice(-1)[0].rubrics.every(r=>r.provenance)")),"reload preserves case and snapshot source citations");
   check(Boolean.TRUE.equals(js("OR.state.remedies['Clarke-rhs'].indexOf('toxicodendron')>=0")),"source dictionary extension survives cold JavaScript initialization");
   check(Boolean.TRUE.equals(js("OR.activeCase().analysis[1].remedies.find(m=>m.r==='Calc.').sourceTypography.style==='italic'")),"source typography survives encrypted reload");
   js("OR.setRepertory('kent')");waitJS("OR.state.repertoryId==='kent'",120);js("OR.toggleRubric('clarke-native-mixed-test','Mind','Synthetic foreign rubric',[{r:'Acon.',g:3}],1,'manual')");
   check(((Number)js("OR.activeCase().analysis.length")).intValue()==2,"mixed-source addition rejected on Android");
   js("OR.setRepertory('clarke')");waitJS("OR.state.repertoryId==='clarke'",120);js("OR.newCase('SYNTHETIC_NATIVE_CLARKE_QUALIFIER',null);OR.showPage('repertory');OR.runSearch('anger effects')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='anger effects'",90);
   js("document.querySelector('[data-rubric-uid*=clarke-149-819-q0] .add-btn').click()");
   check(Boolean.TRUE.equals(js("OR.activeCase().analysis.length===1 && OR.activeCase().analysis[0].remedies.length===1 && OR.activeCase().analysis[0].remedies[0].r==='Ant-t.'")),"qualified causation entry adds only the qualified remedy");
   js("OR.runSearch('autumn')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='autumn'",90);
   check(Boolean.TRUE.equals(js("document.querySelector('[data-rubric-uid*=clarke-149-1381] > .rubric-row > .add-btn').disabled")),"qualification container cannot create empty analysis");
   check(Boolean.TRUE.equals(js("!document.querySelector('iframe,embed,object') && !window.ClarkeReader")),"structured app has no PDF reader");
   check(Boolean.TRUE.equals(js("!document.querySelector('#persistentError')")),"no persistent application errors");
   js("OR.runSearch('knock-knee')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='knock-knee'",90);
   check(Boolean.TRUE.equals(js("!document.querySelector('[data-rubric-uid*=clarke-091-946] .add-btn').disabled && !!document.querySelector('[data-rubric-uid*=clarke-091-946] [data-abbr=\"Maland.\"]')")),"scan-corrected Knock-knee remedy loads on Android");
   check(Boolean.TRUE.equals(js("document.querySelector('[data-rubric-uid*=clarke-091-946] .source-abbreviation-review').textContent.indexOf('Md → Mld')>=0")),"scan review notes are included in installed APK");
   js("OR.runSearch('abdomen');OR.showPage('repertory')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='abdomen'",90);
   result.putString("stream","Clarke native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
  } catch(Throwable e) {result.putString("stream","FAILED after "+passed+" checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}
 }
}
