package com.openrepertory.tests;
import android.app.*;import android.os.*;import android.content.*;import android.database.*;import android.database.sqlite.*;import org.json.*;import javax.crypto.*;import java.io.*;import java.lang.reflect.*;import java.util.*;
/** Isolated encrypted fixtures never replace the user's legacy or active database. */
public class MigrationChecks extends DevChecks {
 @Override public void onStart(){Bundle result=new Bundle();Object store=null;Method close=null;try{
  Class<?> type=Class.forName("com.openrepertory.app.RecordStore",true,getTargetContext().getClassLoader());
  Constructor<?> constructor=type.getDeclaredConstructor(Context.class,File.class,File.class);constructor.setAccessible(true);Method key=type.getDeclaredMethod("key");key.setAccessible(true);
  File legacy=new File(getTargetContext().getFilesDir(),"migration-fixture.enc"),database=new File(getTargetContext().getFilesDir(),"migration-fixture.db");database.delete();
  JSONObject patients=new JSONObject();for(int i=0;i<200;i++)patients.put("p"+i,new JSONObject().put("id","p"+i).put("name","Synthetic migration patient "+i).put("visits",new JSONArray()));
  JSONObject legacyValues=new JSONObject().put("openrepertory_patients",new JSONObject().put("patients",patients).put("activeId","p0").toString())
    .put("openrepertory_cases",new JSONObject().put("cases",new JSONObject().put("c0",new JSONObject().put("id","c0").put("name","Synthetic case").put("patientId","p0").put("analysis",new JSONArray()))).put("activeCaseId","c0").toString())
    .put("openrepertory_mmnotes",new JSONObject().put("Nat-m.","Synthetic remedy note").toString());
  Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,(java.security.Key)key.invoke(null));byte[] encrypted=cipher.doFinal(legacyValues.toString().getBytes("UTF-8"));
  try(FileOutputStream out=new FileOutputStream(legacy)){out.write(cipher.getIV());out.write(encrypted);}
  store=constructor.newInstance(getTargetContext(),database,legacy);Method read=type.getMethod("read",String.class);close=type.getMethod("close");long started=SystemClock.elapsedRealtime();
  JSONObject migrated=new JSONObject((String)read.invoke(store,"openrepertory_patients"));
  check(migrated.getJSONObject("patients").length()==200,"all 200 synthetic legacy patient records migrate");
  check("Synthetic migration patient 199".equals(migrated.getJSONObject("patients").getJSONObject("p199").getString("name")),"legacy clinical fields retain their values");
  check("p0".equals(new JSONObject((String)read.invoke(store,"openrepertory_cases")).getJSONObject("cases").getJSONObject("c0").getString("patientId")),"migration preserves patient-case links");
  check("Synthetic remedy note".equals(new JSONObject((String)read.invoke(store,"openrepertory_mmnotes")).getString("Nat-m.")),"migration preserves punctuation in remedy note keys");
  check(legacy.exists()&&legacy.length()>28,"legacy encrypted fixture is retained after migration");
  SQLiteDatabase sql=SQLiteDatabase.openDatabase(database.getAbsolutePath(),null,SQLiteDatabase.OPEN_READWRITE);byte[] peer;
  try(Cursor rows=sql.rawQuery("SELECT cipher FROM records WHERE name='patient:p1'",null)){rows.moveToFirst();peer=rows.getBlob(0);}
  JSONObject changed=migrated.getJSONObject("patients").getJSONObject("p0");changed.put("name","Synthetic changed patient");
  long patchStarted=SystemClock.elapsedRealtime();type.getMethod("patchPatient",String.class,String.class).invoke(store,changed.toString(),"p0");long patchMs=SystemClock.elapsedRealtime()-patchStarted;
  try(Cursor rows=sql.rawQuery("SELECT cipher FROM records WHERE name='patient:p1'",null)){rows.moveToFirst();check(Arrays.equals(peer,rows.getBlob(0)),"updating one patient does not rewrite another patient's ciphertext");}
  byte[] deleted;
  try(Cursor rows=sql.rawQuery("SELECT cipher FROM records WHERE name='patient:p7'",null)){rows.moveToFirst();deleted=rows.getBlob(0);}
  sql.delete("records","name=?",new String[]{"patient:p7"});boolean detected=false;
  try{read.invoke(store,"openrepertory_patients");}catch(InvocationTargetException error){detected=error.getCause() instanceof IOException;}
  finally{ContentValues row=new ContentValues();row.put("name","patient:p7");row.put("cipher",deleted);sql.insertOrThrow("records",null,row);sql.close();}
  check(detected,"encrypted collection manifest detects a missing patient row");
  type.getMethod("health").invoke(store);check(true,"restored fixture passes collection integrity checks");
  result.putString("stream","Migration checks passed: "+passed+"; 200-patient migration/check elapsed="+(SystemClock.elapsedRealtime()-started)+"ms; single-patient patch="+patchMs+"ms (software emulator observation)\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","Migration checks failed: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}finally{try{if(store!=null&&close!=null)close.invoke(store);}catch(Exception ignored){}}}
}
