package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.webkit.*;import android.database.*;import android.database.sqlite.*;import java.io.*;import java.lang.reflect.*;import java.security.*;import org.json.*;
public class RecoveryChecks extends DevChecks {
 @Override void waitJS(String expression,int seconds) throws Exception {
  long end=System.currentTimeMillis()+seconds*1000L;while(System.currentTimeMillis()<end){if(Boolean.TRUE.equals(js(expression)))return;Thread.sleep(250);}throw new Exception("Recovery wait timed out: "+expression+"; status="+js("document.querySelector('#recoveryStatus') && document.querySelector('#recoveryStatus').textContent"));
 }
 @Override public void onStart(){Bundle result=new Bundle();try{
  activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Field f=activity.getClass().getSuperclass().getDeclaredField("webView");f.setAccessible(true);web=(WebView)f.get(activity);
  waitJS("!!(window.OR&&OR.state.repertory)",180);
  js("if(!OR.patientList().length){OR.showPage('patients');document.querySelector('#patientNew').click();document.querySelector('.modal [data-k=name]').value='Native Recovery Fixture';document.querySelector('.modal [data-k=name]').dispatchEvent(new Event('input',{bubbles:true}));document.querySelector('.modal .primary-btn').click();}");
  waitJS("OR.patientList().length>0",60);
  int patients=((Number)js("OR.patientList().length")).intValue();
  js("ORBackup.encrypt({app:'openrepertory',version:1,patients:JSON.parse(ORStorage.read('openrepertory_patients')||'{\\\"patients\\\":{},\\\"activeId\\\":null}'),cases:JSON.parse(ORStorage.read('openrepertory_cases')),mmNotes:JSON.parse(ORStorage.read('openrepertory_mmnotes')||'{}')},'native-recovery-password-15').then(v=>window.recoveryFixture=v)");
  waitJS("typeof window.recoveryFixture==='string'",120);String backup=(String)js("window.recoveryFixture");
  try(FileOutputStream fixture=new FileOutputStream(new File(getTargetContext().getFilesDir(),"native-recovery-fixture.orbk"))){fixture.write(backup.getBytes("UTF-8"));}
  Field vaultField=activity.getClass().getDeclaredField("vault");vaultField.setAccessible(true);Object vault=vaultField.get(activity);vault.getClass().getMethod("close").invoke(vault);
  File path=new File(getTargetContext().getFilesDir(),"records-v2.db");
  SQLiteDatabase sql=SQLiteDatabase.openDatabase(path.getAbsolutePath(),null,SQLiteDatabase.OPEN_READWRITE);byte[] damaged;
  try(Cursor rows=sql.rawQuery("SELECT cipher FROM records WHERE name='openrepertory_cases'",null)){rows.moveToFirst();damaged=rows.getBlob(0);}
  damaged[damaged.length-1]^=1;sql.execSQL("UPDATE records SET cipher=? WHERE name='openrepertory_cases'",new Object[]{damaged});sql.close();
  runOnMainSync(()->web.reload());waitJS("!!document.querySelector('#recoveryScreen')",90);check(true,"corrupted clinical records open the recovery screen");
  check("error".equals(js("openrepertorySecure.restoreRecords('{}')")),"incomplete recovery cannot replace existing data");
  js("document.querySelector('#recoveryText').value="+JSONObject.quote(backup)+";document.querySelector('#recoveryPassword').value='wrong';document.querySelector('#recoveryRestore').click()");
  waitJS("document.querySelector('#recoveryStatus').textContent.includes('Could not decrypt')",120);check(true,"wrong recovery password is rejected");
  js("document.querySelector('#recoveryPassword').value='native-recovery-password-15';document.querySelector('#recoveryRestore').click()");
  waitJS("!!document.querySelector('.modal .modal-foot .danger-btn')",120);js("document.querySelector('.modal .modal-foot .danger-btn').click()");
  waitJS("!document.querySelector('#recoveryScreen') && !!(window.OR&&OR.state.repertory)",180);
  check(((Number)js("OR.patientList().length")).intValue()==patients,"native encrypted recovery restores all patient records");
  File[] files=getTargetContext().getFilesDir().listFiles((dir,name)->name.startsWith("records-damaged-")&&name.endsWith(".db"));
  check(files!=null&&files.length>0&&files[0].length()>0,"original damaged encrypted database is preserved");
  check("ok".equals(js("openrepertorySecure.storageHealth()")),"restored database passes integrity checks");
  result.putString("stream","Recovery checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","Recovery checks failed: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
