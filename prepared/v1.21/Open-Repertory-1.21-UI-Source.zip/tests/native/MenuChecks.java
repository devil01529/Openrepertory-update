package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.view.View;import android.webkit.*;import com.openrepertory.app.*;import java.lang.reflect.*;import org.json.*;
/** Isolated emulator-only receipt fixtures exercise actual APK WebView and Android Back. */
public final class MenuChecks extends StartupChecks {
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
        activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
        ApperAccess access=(ApperAccess)field("access");
        getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
        JSONObject owner=receipt(access.deviceId());
        ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView original=(WebView)af.get(screen);
        WebView[] created=new WebView[1];runOnMainSync(()->created[0]=new FixtureAuthView(activity));WebView browser=created[0];
        runOnMainSync(()->{original.stopLoading();screen.removeView(original);original.destroy();browser.getSettings().setJavaScriptEnabled(true);browser.getSettings().setDomStorageEnabled(true);browser.getSettings().setUserAgentString("Mozilla/5.0 Chrome/120.0.0.0");screen.addView(browser,new android.widget.LinearLayout.LayoutParams(-1,0,1));browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){screen.check();}});});af.set(screen,browser);
        String page="<html><body><a href='/' onclick='window.managerClicks++;return false'>Device requests</a><button onclick='window.refreshes++'>Refresh requests</button><h1>Owner approvals fixture</h1><script>window.managerClicks=0;window.refreshes=0;window.calls=0;window.base="+owner.toString()+";window.ORApperNative={result:null,check:function(a){window.calls++;this.result=JSON.parse(JSON.stringify(window.base));this.result.nonce=a.nonce;}};</script></body></html>";
        runOnMainSync(()->{screen.cancel();browser.loadDataWithBaseURL(ApperAccess.ORIGIN+"/device",page,"text/html","UTF-8",null);});
        ready();

        check(Boolean.TRUE.equals(js("OR.state.page==='dashboard'")),"clinical workspace opens after the existing approval gate");
        js("OR.newCase('Synthetic clipboard test',null);OR.setRepertory('clarke').then(()=>{OR.showPage('repertory');OR.runSearch('acidity')})");
        waitJS("document.querySelector('#rubricList .add-btn')!==null",60);
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden")),"clipboard is hidden for an empty clinical case");
        js("document.querySelector('#rubricList .add-btn').click()");
        check(Boolean.TRUE.equals(js("!document.getElementById('analysisShortcut').hidden&&document.getElementById('analysisShortcutCount').textContent==='1'")),"real rubric selection shows the packaged clipboard shortcut");
        check(Boolean.TRUE.equals(js("(()=>{const b=document.getElementById('analysisShortcut').getBoundingClientRect(),n=document.getElementById('bottomNav').getBoundingClientRect();return b.height>=48&&b.left>=0&&b.right<=innerWidth&&b.bottom<=n.top-8})()")),"actual Android WebView places the clipboard above bottom navigation");
        js("window.__shortcutCase=JSON.stringify(OR.activeCase());document.getElementById('analysisShortcut').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='analysis'&&document.querySelectorAll('#selectedList .selected-item').length===1&&!!document.querySelector('#resultsTableWrap table')")),"clipboard opens the full selected-rubric analysis and results");
        check(Boolean.TRUE.equals(js("JSON.stringify(OR.activeCase())===window.__shortcutCase&&document.getElementById('analysisShortcut').hidden")),"opening analysis preserves the active case and hides the redundant shortcut");
        js("OR.showPage('repertory');document.getElementById('searchBox').focus()");
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden")),"clipboard hides during keyboard input on Android");
        js("document.getElementById('searchBox').blur()");waitJS("!document.getElementById('analysisShortcut').hidden",10);
        check(true,"clipboard returns after keyboard input");
        js("OR.modal({title:'Synthetic shortcut test',html:'<p>Test</p>'})");
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden")),"clipboard does not compete with Android WebView dialogs");
        js("document.querySelector('.modal-x').click()");waitJS("!document.getElementById('analysisShortcut').hidden",10);
        check(true,"clipboard returns after closing a dialog");
        js("OR.showPage('analysis');document.getElementById('clearAnalysis').click();document.getElementById('clearAnalysis').click();OR.showPage('repertory')");
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden&&OR.activeCase().analysis.length===0")),"clearing the last rubric hides the Android clipboard shortcut");
        js("OR.showPage('dashboard')");
        js("window.__menuRetained='keep';document.getElementById('menuBtn').click()");
        check(Boolean.TRUE.equals(js("!document.getElementById('menuPanel').hidden&&[...document.querySelectorAll('#menuHome .menu-item')].filter(e=>e.getClientRects().length).length===7")),"packaged phone menu shows seven grouped actions");
        check(Boolean.TRUE.equals(js("document.getElementById('menuPanel').getAttribute('role')==='dialog'&&document.activeElement.id==='menuFinder'")),"actual WebView menu exposes dialog semantics and initial focus");
        check(Boolean.TRUE.equals(js("getComputedStyle(document.getElementById('menuPanel')).opacity==='1'&&getComputedStyle(document.getElementById('menuPanel')).backgroundColor!=='rgba(0, 0, 0, 0)'")),"the menu is opaque instead of merging with the page underneath");
        js("document.getElementById('menuSettingsButton').click()");
        check(Boolean.TRUE.equals(js("!document.getElementById('menuSettings').hidden&&document.getElementById('menuHome').hidden")),"settings opens in a separate compact view");
        runOnMainSync(()->activity.onBackPressed());waitJS("!document.getElementById('menuHome').hidden",10);
        check(Boolean.TRUE.equals(js("!document.getElementById('menuPanel').hidden")),"Android Back returns from Settings without closing the app");
        runOnMainSync(()->activity.onBackPressed());waitJS("document.getElementById('menuPanel').hidden",10);
        check("keep".equals(js("window.__menuRetained")),"Android Back closes the main menu and preserves the clinical document");
        check(Boolean.TRUE.equals(js("document.getElementById('toolbar').getAttribute('aria-hidden')===null")),"native Back restores underlying workspace accessibility");
        js("document.getElementById('menuBtn').click();document.querySelector('#menuPanel [data-page=file]').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='file'&&document.querySelector('[data-bottom-page=patients]').getAttribute('aria-current')==='page'")),"Patient file remains reachable through the new menu");
        js("document.getElementById('menuBtn').click();document.querySelector('#menuPanel [data-page=diff]').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='diff'&&document.querySelector('[data-bottom-page=mm]').getAttribute('aria-current')==='page'")),"remedy comparison remains reachable under Library");
        js("document.getElementById('menuBtn').click();document.getElementById('menuFinder').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='repertory'&&document.activeElement.id==='aiInput'")),"Find rubrics retains the existing patient-word input action");
        js("window.__expectedTheme=['auto','light','dark'][(['auto','light','dark'].indexOf((OR.store.get('openrepertory_theme')||{}).t||'auto')+1)%3];document.activeElement.blur();document.getElementById('menuBtn').click();document.getElementById('menuSettingsButton').click();document.getElementById('menuTheme').click()");
        check(Boolean.TRUE.equals(js("(OR.store.get('openrepertory_theme')||{}).t===window.__expectedTheme&&!document.getElementById('menuSettings').hidden")),"Appearance changes the stored theme without closing Settings");
        js("OR.dismissMenu();document.getElementById('menuUpdates').click()");Thread.sleep(500);
        Field uf=activity.getClass().getDeclaredField("updates");uf.setAccessible(true);AppUpdates updates=(AppUpdates)uf.get(activity);Field df=AppUpdates.class.getDeclaredField("dialog");df.setAccessible(true);
        check(df.get(updates)!=null,"App updates still opens its existing native screen");
        runOnMainSync(updates::pause);
        check("keep".equals(js("window.__menuRetained")),"opening updates retains the active clinical document");
        runOnMainSync(()->{screen.cancel();browser.stopLoading();});
        result.putString("stream","Menu native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","FAILED after "+passed+" menu checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
