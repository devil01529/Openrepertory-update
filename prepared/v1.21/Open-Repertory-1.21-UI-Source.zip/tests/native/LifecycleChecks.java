package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.webkit.*;import java.lang.reflect.*;import org.json.*;
public class LifecycleChecks extends DevChecks {
 @Override public void onStart(){Bundle result=new Bundle();try{
  activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Field f=activity.getClass().getSuperclass().getDeclaredField("webView");f.setAccessible(true);web=(WebView)f.get(activity);
  waitJS("!!(window.OR&&OR.state.repertory&&OR.lifecycle.started)",180);
  if("prepare".equals(args.getString("stage"))){
   js("OR.store.set('openrepertory_lifecycle_probe',{count:OR.patientList().length,pid:"+android.os.Process.myPid()+"});OR.showPage('patients');document.querySelector('#patientNew').click();document.querySelector('.modal [data-k=name]').value='PROCESS_DRAFT_15';document.querySelector('.modal [data-k=name]').dispatchEvent(new Event('input',{bubbles:true}));OR.store.set('openrepertory_pending_export',{name:'interrupted-export.orbk',text:'SYNTHETIC_PENDING_EXPORT_15'})");
   check("PROCESS_DRAFT_15".equals(js("OR.drafts.list()['patient-new'].values.name")),"draft is durably saved before process termination");
   check("interrupted-export.orbk".equals(js("openrepertorySecure.pendingExport()")),"interrupted export is retained in encrypted storage");
  }else{
   check(((Number)js("OR.store.get('openrepertory_lifecycle_probe').pid")).intValue()!=android.os.Process.myPid(),"checks resumed in a new Android process");
   check("PROCESS_DRAFT_15".equals(js("OR.drafts.list()['patient-new'].values.name")),"patient draft survives process restart");
   check("interrupted-export.orbk".equals(js("openrepertorySecure.pendingExport()")),"pending export survives process restart");
   check(Boolean.TRUE.equals(js("!!document.querySelector('#resumeExport') && !!document.querySelector('#resumeDrafts')")),"restart displays resume actions");
   js("OR.patients.resumeDraft('patient-new')");check("PROCESS_DRAFT_15".equals(js("document.querySelector('.modal [data-k=name]').value")),"restarted draft restores original input");
   js("document.querySelector('.modal .modal-x').click();openrepertorySecure.discardExport()");
   check(Boolean.TRUE.equals(js("OR.patientList().length===OR.store.get('openrepertory_lifecycle_probe').count")),"resuming a draft does not create duplicate patient records");
  }
  result.putString("stream","Lifecycle checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","Lifecycle checks failed: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
