package com.openrepertory.tests;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.View;
import android.webkit.*;
import com.openrepertory.app.*;
import org.json.*;
import java.lang.reflect.*;

/** Emulator-only synthetic receipts exercise the production validator; no bypass enters the APK. */
public class ApperChecks extends DevChecks {
    static final String NONCE="test-request-nonce", USER="synthetic-apper-owner";
    JSONObject receipt(String device) throws Exception {
        return new JSONObject().put("protocol",1).put("projectId",ApperAccess.PROJECT).put("mode","live").put("nonce",NONCE).put("status","approved")
            .put("user",new JSONObject().put("id",USER).put("email","synthetic@example.test").put("profile","Owner_c"))
            .put("request",new JSONObject().put("id","request-1").put("ownerId",USER).put("device",device))
            .put("grant",new JSONObject().put("id","grant-1").put("requestId","request-1").put("device",device).put("status","approved").put("version",1));
    }
    void receive(JSONObject receipt) throws Exception {
        Method method=activity.getClass().getDeclaredMethod("receiveAccess",JSONObject.class,String.class);method.setAccessible(true);
        runOnMainSync(()->{try{method.invoke(activity,receipt,NONCE);}catch(Exception error){throw new RuntimeException(error);}});
    }
    @Override public void onStart(){
        Bundle result=new Bundle();
        try {
            String emulator=android.os.Build.FINGERPRINT;
            if(!emulator.contains("generic")&&!emulator.contains("sdk"))throw new Exception("Synthetic fixtures require the test emulator");
            activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            Field webField=MainActivity.class.getDeclaredField("webView");webField.setAccessible(true);web=(WebView)webField.get(activity);
            unlockTestActivity(MainActivity.class);
            Field accessField=activity.getClass().getDeclaredField("access");accessField.setAccessible(true);ApperAccess access=(ApperAccess)accessField.get(activity);
            String device=access.deviceId();
            check(device.matches("[a-f0-9]{64}"),"installation has a stable complete fingerprint");
            check(new ApperAccess(getTargetContext()).deviceId().equals(device),"updating the provider preserves the installation fingerprint");
            check(ApperAccess.trusted(Uri.parse(ApperAccess.ORIGIN+"/device"))&&!ApperAccess.trusted(Uri.parse(ApperAccess.ORIGIN+".evil.test/device"))
                &&!ApperAccess.trusted(Uri.parse("http://preview--openrepertory-eminent.apper.so"))&&!ApperAccess.trusted(Uri.parse("https://user@preview--openrepertory-eminent.apper.so")),"only the pinned HTTPS origin can provide a receipt");
            JSONObject valid=receipt(device);
            check(ApperAccess.approved(valid,NONCE,device),"matching live account, request and device grant validate");
            for(String key:new String[]{"protocol","projectId","nonce","mode","status"}){
                JSONObject invalid=new JSONObject(valid.toString());invalid.put(key,"invalid");check(!ApperAccess.approved(invalid,NONCE,device),"reject mismatched "+key);
            }
            JSONObject bad=new JSONObject(valid.toString());bad.getJSONObject("user").put("id","another-user");check(!ApperAccess.approved(bad,NONCE,device),"another account cannot reuse the grant");
            bad=new JSONObject(valid.toString());bad.getJSONObject("request").put("ownerId","another-user");check(!ApperAccess.approved(bad,NONCE,device),"business account text cannot override actual request ownership");
            bad=new JSONObject(valid.toString());bad.getJSONObject("grant").put("requestId","another-request");check(!ApperAccess.approved(bad,NONCE,device),"cross-request grant is rejected");
            bad=new JSONObject(valid.toString());bad.getJSONObject("grant").put("device",new String(new char[64]).replace('\0','b'));check(!ApperAccess.approved(bad,NONCE,device),"grant for another phone is rejected");
            bad=new JSONObject(valid.toString());bad.getJSONObject("grant").put("status","revoked");check(!ApperAccess.approved(bad,NONCE,device),"outer approved status cannot override revoked grant");
            bad=new JSONObject(valid.toString());bad.remove("grant");check(!ApperAccess.approved(bad,NONCE,device),"missing grant cannot unlock the app");
            bad=new JSONObject(valid.toString());bad.getJSONObject("grant").put("version",0);check(!ApperAccess.approved(bad,NONCE,device),"malformed grant version fails closed");
            // Only this emulator fixture may replace a synthetic previous provider binding.
            SharedPreferences binding=getTargetContext().getSharedPreferences("openrepertory.vault-owner",0);
            binding.edit().putString("uid","synthetic-legacy-owner").remove("provider").commit();
            check("migration".equals(access.accept(valid,NONCE))&&!access.cachedAllowed(),"legacy records require an explicit owner migration before access");
            check(access.migrateLegacyOwner()&&access.cachedAllowed(),"approved owner migration retains the local vault binding");
            check(new ApperAccess(getTargetContext()).cachedAllowed(),"approval survives restart encrypted in Android Keystore");
            String raw=getTargetContext().getSharedPreferences("openrepertory.apper-access.v1",0).getString("approval","");
            check(!raw.contains(USER)&&!raw.contains("synthetic@example.test"),"cached account and approval are encrypted");
            JSONObject cache=new JSONObject().put("project",ApperAccess.PROJECT).put("uid",USER).put("device",device).put("boot",7).put("elapsed",1000);
            check(ApperAccess.offlineValid(cache,device,7,2000)&&!ApperAccess.offlineValid(cache,device,7,86401000L),"offline access has a strict 24-hour limit");
            check(!ApperAccess.offlineValid(cache,device,8,2000)&&!ApperAccess.offlineValid(cache,device,7,999),"reboot and time rollback invalidate offline access");
            check(!ApperAccess.offlineValid(cache,"wrong-device",7,2000),"offline access cannot move to another installation");
            // Stop the auth browser during isolated receipt fixtures to avoid unrelated network callbacks.
            Field screenField=activity.getClass().getDeclaredField("accessScreen");screenField.setAccessible(true);ApperAccessScreen screen=(ApperAccessScreen)screenField.get(activity);
            Field authField=ApperAccessScreen.class.getDeclaredField("browser");authField.setAccessible(true);WebView authWeb=(WebView)authField.get(screen);
            runOnMainSync(()->{screen.cancel();authWeb.stopLoading();});
            boolean blocked=false;try{((ImprovedActivity)activity).new SecureBridge().read("openrepertory_cases");}catch(SecurityException expected){blocked=true;}
            check(blocked,"clinical native bridge stays closed before approval");
            receive(valid);waitJS("!!(window.OR&&OR.state.repertory)",180);
            check(Boolean.TRUE.equals(js("ORStorage.native")),"approved receipt opens the existing encrypted clinical workspace");
            js("OR.setRepertory('clarke').then(()=>{OR.showPage('repertory');OR.runSearch('acidity')})");waitJS("OR.lastSearchStats&&OR.lastSearchStats.query==='acidity'",120);
            check(Boolean.TRUE.equals(js("document.querySelector('[data-rubric-uid*=clarke-043-2150]').querySelectorAll('.source-italic').length===4")),"Clarke source typography and search remain intact");
            js("OR.newCase('SYNTHETIC_APPER_CASE',null);document.querySelector('[data-rubric-uid*=clarke-043-2150] .add-btn').click()");
            check(Boolean.TRUE.equals(js("OR.activeCase().analysis.length===1&&OR.activeCase().analysis[0].remedies.length===12")),"rubric selection and original case analysis still work");
            boolean[] capture=new boolean[1];runOnMainSync(()->capture[0]=(activity.getWindow().getAttributes().flags&android.view.WindowManager.LayoutParams.FLAG_SECURE)==0);
            check(capture[0],"screenshots remain available in the unlocked approved workspace");
            JSONObject revoked=new JSONObject(valid.toString());revoked.put("status","revoked");revoked.getJSONObject("grant").put("status","revoked");receive(revoked);
            check(!access.cachedAllowed(),"revocation deletes cached approval immediately");
            blocked=false;try{((ImprovedActivity)activity).new SecureBridge().read("openrepertory_cases");}catch(SecurityException expected){blocked=true;}
            check(blocked,"revocation closes clinical native bridge");
            receive(valid);waitJS("!!(window.OR&&OR.state.repertory)",180);
            check(Boolean.TRUE.equals(js("OR.activeCase().name==='SYNTHETIC_APPER_CASE'&&OR.activeCase().analysis.length===1")),"revocation and reapproval retain encrypted patient/case records");
            JSONObject other=receipt(device);other.getJSONObject("user").put("id","another-account");other.getJSONObject("request").put("ownerId","another-account");
            check("records".equals(access.accept(other,NONCE))&&!access.cachedAllowed(),"another approved account cannot inherit the local vault");
            access.clear();check(!access.cachedAllowed()&&access.uid().isEmpty(),"sign-out clears permission and retains record files");
            result.putString("stream","Apper native checks passed: "+passed+"\\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
        }catch(Throwable error){result.putString("stream","FAILED after "+passed+" checks: "+error+"\\n");finish(Activity.RESULT_CANCELED,result);}
    }
}
