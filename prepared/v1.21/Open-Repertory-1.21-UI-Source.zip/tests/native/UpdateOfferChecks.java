package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.webkit.*;import com.openrepertory.app.*;import org.json.*;import java.io.*;import java.lang.reflect.*;import java.util.concurrent.*;
/** Real public release discovery/download through the unchanged v1.19 updater. Emulator only. */
public final class UpdateOfferChecks extends StartupChecks {
 Object uf(AppUpdates u,String key)throws Exception{Field f=AppUpdates.class.getDeclaredField(key);f.setAccessible(true);return f.get(u);}
 void invoke(AppUpdates u,String name)throws Exception{Method m=AppUpdates.class.getDeclaredMethod(name);m.setAccessible(true);runOnMainSync(()->{try{m.invoke(u);}catch(Exception e){throw new RuntimeException(e);}});}
 void idle(AppUpdates u)throws Exception{long end=SystemClock.elapsedRealtime()+180000;while(SystemClock.elapsedRealtime()<end){if(!Boolean.TRUE.equals(uf(u,"working")))return;Thread.sleep(100);}throw new Exception("Updater did not finish");}
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
        activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
        ApperAccess access=(ApperAccess)field("access");
        getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
        JSONObject owner=receipt(access.deviceId());
        ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView original=(WebView)af.get(screen);
        WebView[] created=new WebView[1];runOnMainSync(()->created[0]=new FixtureAuthView(activity));WebView browser=created[0];
        runOnMainSync(()->{original.stopLoading();screen.removeView(original);original.destroy();browser.getSettings().setJavaScriptEnabled(true);browser.getSettings().setDomStorageEnabled(true);browser.getSettings().setUserAgentString("Mozilla/5.0 Chrome/120.0.0.0");screen.addView(browser,new android.widget.LinearLayout.LayoutParams(-1,0,1));browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){screen.check();}});});af.set(screen,browser);
        String page="<html><body><a href='/' onclick='window.managerClicks++;return false'>Device requests</a><button onclick='window.refreshes++'>Refresh requests</button><h1>Owner approvals fixture</h1><script>window.managerClicks=0;window.refreshes=0;window.calls=0;window.base="+owner.toString()+";window.ORApperNative={result:null,check:function(a){window.calls++;this.result=JSON.parse(JSON.stringify(window.base));this.result.nonce=a.nonce;}};</script></body></html>";
        runOnMainSync(()->{screen.cancel();browser.loadDataWithBaseURL(ApperAccess.ORIGIN+"/device",page,"text/html","UTF-8",null);});
        ready();

        check(getTargetContext().getPackageManager().getPackageInfo(getTargetContext().getPackageName(),0).versionCode==20,"the test starts from the shipped v1.19 client");
        js("OR.newCase('SYNTHETIC_LIVE_UPDATE_CASE',null);OR.store.set('openrepertory_update_fixture',{marker:'SYNTHETIC_UPGRADE_119'})");
        js("document.getElementById('menuUpdates').click()");
        AppUpdates updates=(AppUpdates)field("updates");idle(updates);
        Method check=AppUpdates.class.getDeclaredMethod("check",boolean.class);check.setAccessible(true);
        runOnMainSync(()->{try{check.invoke(updates,true);}catch(Exception e){throw new RuntimeException(e);}});idle(updates);Thread.sleep(200);
        AppUpdates.Release offered=(AppUpdates.Release)uf(updates,"release");
        check(offered!=null&&offered.code==21&&offered.name.equals("1.20-dev"),"v1.19 discovers the signed v1.20 release from Latest");
        invoke(updates,"download");idle(updates);Thread.sleep(200);
        File apk=new File(getTargetContext().getFilesDir(),"updates/update.apk");
        AppUpdates.validateApk(getTargetContext(),apk,offered);
        check(apk.isFile()&&apk.length()==offered.size,"v1.19 downloads and validates the actual v1.20 APK");
        // Snapshot raw encrypted records plus a decryptable sentinel immediately before installation.
        JSONObject snap=new JSONObject();
        try(android.database.sqlite.SQLiteDatabase db=android.database.sqlite.SQLiteDatabase.openDatabase(new File(getTargetContext().getFilesDir(),"records-v2.db").getAbsolutePath(),null,android.database.sqlite.SQLiteDatabase.OPEN_READONLY);android.database.Cursor rows=db.rawQuery("SELECT name,cipher FROM records ORDER BY name",null)){
            while(rows.moveToNext())snap.put(rows.getString(0),android.util.Base64.encodeToString(rows.getBlob(1),android.util.Base64.NO_WRAP));
        }
        String hash=android.util.Base64.encodeToString(java.security.MessageDigest.getInstance("SHA-256").digest(snap.toString().getBytes("UTF-8")),android.util.Base64.NO_WRAP);
        getTargetContext().getSharedPreferences("updater-upgrade-fixture",0).edit().putString("hash",hash).putString("device",access.deviceId()).commit();
        invoke(updates,"install");idle(updates);
        boolean visible=false;long end=SystemClock.elapsedRealtime()+60000;
        while(SystemClock.elapsedRealtime()<end){android.view.accessibility.AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();if(root!=null&&String.valueOf(root.getPackageName()).contains("packageinstaller")){visible=true;break;}Thread.sleep(300);}
        check(visible,"the verified live update opens Android's installation confirmation");
        // The host test confirms Install after this runner disconnects; no real phone is used.
        result.putString("stream","Live update offer checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","FAILED after "+passed+" live update offer checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
