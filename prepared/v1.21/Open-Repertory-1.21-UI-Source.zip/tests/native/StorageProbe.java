package com.openrepertory.tests;
import android.app.*;import android.os.*;import java.lang.reflect.*;import android.database.*;import android.database.sqlite.*;import java.io.*;
public class StorageProbe extends Instrumentation {
 Bundle arguments;
 public void onCreate(Bundle args){arguments=args;super.onCreate(args);start();}
 public void onStart(){Bundle result=new Bundle();Object store=null;Method close=null;try{
  Class<?> type=Class.forName("com.openrepertory.app.RecordStore",true,getTargetContext().getClassLoader());close=type.getMethod("close");store=type.getConstructor(android.content.Context.class).newInstance(getTargetContext());
  if(arguments!=null&&"true".equals(arguments.getString("repair-fixture"))){
   if(!android.os.Build.FINGERPRINT.contains("generic"))throw new Exception("Fixture repair is restricted to the emulator");
   close.invoke(store);File file=new File(getTargetContext().getFilesDir(),"records-v2.db");SQLiteDatabase db=SQLiteDatabase.openDatabase(file.getAbsolutePath(),null,SQLiteDatabase.OPEN_READWRITE);byte[] original;
   try(Cursor rows=db.rawQuery("SELECT cipher FROM records WHERE name='openrepertory_cases'",null)){rows.moveToFirst();original=rows.getBlob(0);}
   byte[] corrected=original.clone();corrected[corrected.length-1]^=1;db.execSQL("UPDATE records SET cipher=? WHERE name='openrepertory_cases'",new Object[]{corrected});
   boolean healthy=false;
   try{type.getMethod("health").invoke(store);healthy=true;}finally{if(!healthy)db.execSQL("UPDATE records SET cipher=? WHERE name='openrepertory_cases'",new Object[]{original});db.close();}
  }else type.getMethod("health").invoke(store);
  close.invoke(store);result.putString("stream","Storage probe healthy\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable error){Throwable cause=error instanceof InvocationTargetException?((InvocationTargetException)error).getCause():error;result.putString("stream","Storage probe: "+cause.getClass().getName()+": "+cause.getMessage()+"\n");finish(Activity.RESULT_CANCELED,result);}finally{try{if(store!=null&&close!=null)close.invoke(store);}catch(Exception ignored){}}}
}
