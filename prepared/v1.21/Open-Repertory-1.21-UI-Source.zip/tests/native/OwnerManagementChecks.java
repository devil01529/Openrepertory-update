package com.openrepertory.tests;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.View;
import android.webkit.*;
import com.openrepertory.app.*;
import java.lang.reflect.*;
import org.json.*;

/** Remote-page fixtures run only in the instrumentation APK; no real grants are modified. */
public class OwnerManagementChecks extends StartupChecks {
    @Override void receive(JSONObject receipt)throws Exception {
        // Keep the simulated server and manually supplied receipt consistent; cancel old fixture polls.
        ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");
        Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView browser=(WebView)af.get(screen);
        runOnMainSync(screen::cancel);authJS(browser,"window.base="+receipt.toString());
        super.receive(receipt);
    }
    void invoke(String method)throws Exception {Method m=activity.getClass().getDeclaredMethod(method);m.setAccessible(true);runOnMainSync(()->{try{m.invoke(activity);}catch(Exception e){throw new RuntimeException(e);}});}
    boolean managing()throws Exception{return Boolean.TRUE.equals(field("managingAccess"));}
    void waitManager(boolean expected)throws Exception{long end=SystemClock.elapsedRealtime()+15000;while(SystemClock.elapsedRealtime()<end){if(managing()==expected)return;Thread.sleep(100);}throw new Exception("Manager state not reached");}
    @Override public void onStart(){Bundle result=new Bundle();try{
        if(!android.os.Build.FINGERPRINT.contains("generic")&&!android.os.Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
        activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
        ApperAccess access=(ApperAccess)field("access");
        getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
        JSONObject owner=receipt(access.deviceId());
        ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView original=(WebView)af.get(screen);
        WebView[] created=new WebView[1];runOnMainSync(()->created[0]=new FixtureAuthView(activity));WebView browser=created[0];
        runOnMainSync(()->{original.stopLoading();screen.removeView(original);original.destroy();browser.getSettings().setJavaScriptEnabled(true);browser.getSettings().setDomStorageEnabled(true);browser.getSettings().setUserAgentString("Mozilla/5.0 Chrome/120.0.0.0");screen.addView(browser,new android.widget.LinearLayout.LayoutParams(-1,0,1));browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){screen.check();}});});af.set(screen,browser);
        String page="<html><body><a href='/' onclick='window.managerClicks++;return false'>Device requests</a><button onclick='window.refreshes++'>Refresh requests</button><h1>Owner approvals fixture</h1><script>window.managerClicks=0;window.refreshes=0;window.calls=0;window.base="+owner.toString()+";window.ORApperNative={result:null,check:function(a){window.calls++;this.result=JSON.parse(JSON.stringify(window.base));this.result.nonce=a.nonce;}};</script></body></html>";
        runOnMainSync(()->{screen.cancel();browser.loadDataWithBaseURL(ApperAccess.ORIGIN+"/device",page,"text/html","UTF-8",null);});
        ready();check(access.owner(),"approved Owner profile exposes owner management");
        js("window.__ownerSentinel='keep';OR.showPage('repertory')");
        invoke("enterOwnerManagement");waitManager(true);Thread.sleep(700);
        boolean[] state=new boolean[2];runOnMainSync(()->{state[0]=screen.getVisibility()==View.VISIBLE;state[1]=web.getVisibility()!=View.VISIBLE;});
        check(state[0]&&state[1],"owner approvals open inside the APK while the clinical page is hidden");
        check(((Number)authJS(browser,"window.managerClicks")).intValue()==1,"entry uses the existing authenticated Device requests route");
        check(((Number)authJS(browser,"window.refreshes")).intValue()>=1,"opening owner management refreshes the request list");
        check("keep".equals(js("window.__ownerSentinel")),"opening owner approvals preserves the clinical document");
        receive(owner);Thread.sleep(200);check(managing(),"successful background approval checks do not close owner management");
        lifecycle("onPause");lifecycle("onResume");Thread.sleep(500);check(managing(),"returning to the app keeps the owner management screen open");
        Field bf=ApperAccessScreen.class.getDeclaredField("backToApp");bf.setAccessible(true);android.widget.Button back=(android.widget.Button)bf.get(screen);
        runOnMainSync(()->back.performClick());waitManager(false);Thread.sleep(500);
        check("keep".equals(js("window.__ownerSentinel"))&&"repertory".equals(js("OR.state.page")),"Back to repertory restores the original page without losing state");
        invoke("enterOwnerManagement");waitManager(true);runOnMainSync(()->activity.onBackPressed());waitManager(false);Thread.sleep(300);check(!managing(),"Android Back returns from approvals to the clinical workspace");
        JSONObject member=new JSONObject(owner.toString());member.getJSONObject("user").put("profile","Member_c");receive(member);Thread.sleep(200);
        check(!access.owner(),"approved Member profiles do not expose owner management");invoke("enterOwnerManagement");Thread.sleep(200);check(!managing(),"a Member cannot invoke owner management directly");
        receive(owner);Thread.sleep(200);invoke("enterOwnerManagement");waitManager(true);receive(member);Thread.sleep(200);check(!managing()&&!access.owner(),"loss of Owner role exits the management screen");
        receive(owner);Thread.sleep(200);invoke("enterOwnerManagement");waitManager(true);
        JSONObject revoked=new JSONObject(owner.toString());revoked.put("status","revoked");revoked.getJSONObject("grant").put("status","revoked");receive(revoked);
        check(!managing()&&!access.cachedAllowed(),"revoking the current phone closes management and clinical access");
        boolean blocked=false;try{((ImprovedActivity)activity).new SecureBridge().read("openrepertory_cases");}catch(SecurityException expected){blocked=true;}check(blocked,"revoked owner cannot use a retained clinical native bridge");
        runOnMainSync(()->{screen.cancel();browser.stopLoading();});
        result.putString("stream","Owner management native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","FAILED after "+passed+" checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
