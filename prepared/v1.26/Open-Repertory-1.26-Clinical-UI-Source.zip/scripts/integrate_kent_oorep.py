"""Build a separate English Kent source from the fully cached OOREP audit.

The owner confirmed redistribution permission in this task. Legacy Publicum
source keys and clinical cases are never renamed or migrated by this importer.
"""
import json,hashlib,re,collections,datetime,csv
from pathlib import Path
R=Path(__file__).resolve().parents[1];D=R/'apk/assets/www/data';C=Path('/workspace/scratch/oorep-live-kent')
raw=json.loads((C/'rows.json').read_text());manifest=json.loads((C/'manifest.json').read_text());assert len(raw)==manifest['total']
catalogue=json.loads(Path('/workspace/scratch/oorep-live-catalogue.json').read_text());info=next(x['info'] for x in catalogue if x['info']['abbrev']=='kent');assert info['language']=='en'
legacy=json.loads((D/'kent_publicum_full.json').read_text());chapters={};parents={};aliases={};conflicts=[];links=0
def remedies(item):
    global links
    out={}
    for value in item['weightedRemedies']:
        rm=value['remedy'];grade=value['weight'];assert grade in [1,2,3];abbr=rm['nameAbbrev'];links+=1
        entry=aliases.setdefault(abbr,{'name':rm['nameLong'],'aliases':set(),'sourceRemedyIds':set()});entry['aliases'].update(rm.get('namealt') or []);entry['sourceRemedyIds'].add(str(rm['id']))
        if abbr in out:conflicts.append({'sourceRubricId':item['rubric']['id'],'remedy':abbr,'grades':[out[abbr]['g'],grade],'rule':'retain highest source grade; preserve raw records in audit cache'})
        if abbr not in out or grade>out[abbr]['g']:out[abbr]={'r':abbr,'g':grade}
    return list(out.values())
for key,item in sorted(raw.items(),key=lambda pair:(pair[1]['rubric']['chapterId'],pair[1]['rubric']['fullPath'])):
    source=item['rubric'];assert source['abbrev']=='kent';path=source['fullPath'];parts=[s.strip() for s in path.split(',')];chapterName=parts[0];chapterId=source['chapterId']
    ch=chapters.setdefault(chapterName,{'id':f'kent1897-ch-{chapterId}','name':chapterName,'rubrics':[],'sourceChapterId':chapterId,'indexRows':[]})
    record={'text':parts[1].upper() if len(parts)>1 else chapterName,'id':'kent1897-'+key,'sourceIds':[key],'sourcePath':path,'remedies':remedies(item)}
    if source.get('textt'):record['sourceText']=source['textt']
    if len(parts)==1:ch['indexRows'].append(record);continue
    parentKey=(chapterName,parts[1].casefold());parent=parents.get(parentKey)
    if parent is None:
        parent={'text':parts[1].upper(),'id':'kent1897-heading-'+hashlib.sha256((chapterName+'|'+parts[1]).encode()).hexdigest()[:16],'sourceIds':[],'syntheticHeading':True,'remedies':[],'sub':[]};parents[parentKey]=parent;ch['rubrics'].append(parent)
    if len(parts)==2:
        children=parent.pop('sub',[]);parent.clear();parent.update(record);parent['sub']=children
    else:
        record['text']='. '+', '.join(parts[2:]);parent.setdefault('sub',[]).append(record)
order=['Mind','Vertigo','Head','Eye','Vision','Ear','Hearing','Nose','Face','Mouth','Teeth','Throat','External throat','Stomach','Abdomen','Rectum','Stool','Urine','Urethra','Bladder','Kidneys','Prostate gland','Genitalia male','Genitalia female','Larynx and trachea','Respiration','Cough','Expectoration','Chest','Back','Extremities','Sleep','Chill','Fever','Perspiration','Skin','Generalities']
chapters=sorted(chapters.values(),key=lambda c:(order.index(c['name']) if c['name'] in order else 999,c['name']))
rep={'id':'kent1897','title':'Kent · English (OOREP)','author':'J. T. Kent','year':info['year'],'language':'en','edition':info.get('edition'),'source':'OOREP live English Kent dataset','source_url':'https://www.oorep.com/','source_license':'Redistribution permission confirmed by app owner on 2026-10-22; OOREP API license field unspecified. Not claimed to be the GPL Publicum dataset.','oorep_abbrev':'kent','dataRevision':'oorep-kent-en-2026-10-22','sourceSnapshot':{'rows':len(raw),'pages':manifest['pages'],'completedAt':manifest['completedAt'],'pagesManifestSha256':hashlib.sha256((C/'manifest.json').read_bytes()).hexdigest()},'chapters':chapters,'remedyAliases':{a:{'name':v['name'],'aliases':sorted(v['aliases']),'sourceRemedyIds':sorted(v['sourceRemedyIds'])} for a,v in aliases.items()}}
def walk(rep):
    for ch in rep['chapters']:
        for r in ch['rubrics']:
            yield ch,r
            for s in r.get('sub',[]):yield ch,s
nodes=list(walk(rep));byPath=collections.defaultdict(list)
for _,r in nodes:
    if r.get('sourcePath'):byPath[r['sourcePath']].append(r)
duplicatePaths=[]
for path,variants in byPath.items():
    if len(variants)<2:continue
    duplicatePaths.append({'path':path,'sourceIds':[v['sourceIds'][0] for v in variants],'policy':'Keep each source record and its grades; annotate the source row and prevent selecting both variants in one case.'})
    for variant in variants:
        variant['text']+=' [OOREP row '+variant['sourceIds'][0]+']'
        variant['sourceNote']='Duplicate source path: OOREP supplies distinct remedy lists/grades. This is row '+variant['sourceIds'][0]+'. Compare the source records and select only one variant.'
paths={r['sourcePath'].casefold():r for _,r in nodes if r.get('sourcePath')};refCount=0
def enrich(target):
    global refCount
    rows=list(walk(target));lookup={r.get('sourcePath','').casefold():r for _,r in rows if r.get('sourcePath')}
    for ch,r in rows:
        text=r.get('sourcePath',r['text']);refs=[]
        for match in re.finditer(r'\((?:see(?: also)?|compare|synonym[s]?:?)\s+([^()]+)\)',text,re.I):
            label=match.group(1).strip();prefix=r.get('sourcePath','').split(', ');targetRow=None
            for n in range(len(prefix)-1,0,-1):
                candidate=', '.join(prefix[:n]+[label]).casefold()
                if candidate in lookup:targetRow=lookup[candidate];break
            ref={'label':label,'kind':'synonym' if match.group(0).lower().startswith('(synonym') else 'see-also','sourceText':match.group(0),'sourceId':'kent' if target.get('id')=='publicum' else target.get('id'),'resolution':'source-path' if targetRow else 'search'}
            if targetRow:ref['targetId']=targetRow['id']
            refs.append(ref);refCount+=1
        if refs:r['references']=refs
enrich(rep)
# Preserve source identity and exact saved UID wording for Publicum. Enrich only
# explicit parenthetical references; do not interpret ordinary 'can see' as links.
legacyEnriched=json.loads(json.dumps(legacy))
for ch in legacyEnriched['chapters']:
    for parent in ch['rubrics']:
        parent['sourcePath']=ch['name']+', '+parent['text']
        for sub in parent.get('sub',[]):sub['sourcePath']=ch['name']+', '+parent['text']+', '+re.sub(r'^\.\s*','',sub['text'])
enrich(legacyEnriched)
# Keep legacy clinical asset byte-identical; references are a sidecar keyed by
# stable node ID, loaded by ensureRepertory for presentation only.
gplRows=json.loads(Path('/workspace/scratch/oorep-clinical-tables.json').read_text())['remedy']
gplAliases={}
for ident,abbr,name,alternate in gplRows:
    names=next(csv.reader([alternate[1:-1]],escapechar='\\')) if alternate not in ['\\N','{}'] else []
    gplAliases[abbr]={'name':name,'aliases':names,'sourceRemedyIds':[ident]}
sidecar={'source':'OOREP GPL Publicum explicit source text / remedy alternate names','references':{r['id']:r['references'] for _,r in walk(legacyEnriched) if r.get('references')},'remedyAliases':gplAliases}
(D/'oorep_relationships.json').write_text(json.dumps(sidecar,ensure_ascii=False,separators=(',',':')))
(D/'kent_english_oorep.json').write_text(json.dumps(rep,ensure_ascii=False,separators=(',',':')))

def norm(s):return re.sub(r'\s+',' ',s).strip().casefold()
legacyPaths={norm(ch['name']+', '+r['text']):r for ch in legacy['chapters'] for r in ch['rubrics']}
for ch in legacy['chapters']:
    for r in ch['rubrics']:
        for sub in r.get('sub',[]):legacyPaths[norm(ch['name']+', '+r['text']+', '+re.sub(r'^\.\s*','',sub['text']))]=sub
missing=[];shared=0;different=0
for key,item in raw.items():
    r=legacyPaths.get(norm(item['rubric']['fullPath']))
    if r is None:missing.append({'id':key,'path':item['rubric']['fullPath']})
    else:
        shared+=1;wanted={x['remedy']['nameAbbrev']:x['weight'] for x in item['weightedRemedies']};got={x['r']:x['g'] for x in r.get('remedies',[])};different+=wanted!=got
coverage=collections.Counter(str(i) for _,r in nodes for i in r['sourceIds'])
for ch in chapters:
    for r in ch['indexRows']:coverage.update(r['sourceIds'])
assert set(coverage)==set(raw) and all(n==1 for n in coverage.values())
report={'scope':'Exhaustive cached public OOREP English Kent API snapshot, not a printed-book scan audit','sourceUrl':'https://www.oorep.com/','sourceAbbrev':'kent','language':'en','sourceRows':len(raw),'apiPages':manifest['pages'],'apiDeclaredTotal':manifest['total'],'uniqueImportedSourceIds':len(coverage),'missingImportedSourceIds':[],'extraImportedSourceIds':[],'chapterIndexRows':sum(len(ch['indexRows']) for ch in chapters),'displayedSourceRows':sum(bool(r['sourceIds']) for _,r in nodes),'syntheticHeadings':sum(not r['sourceIds'] for _,r in nodes),'chapters':len(chapters),'sourceRemedyRecords':links,'duplicateAbbreviationRecords':conflicts,'sourceAliases':sum(len(v['aliases']) for v in rep['remedyAliases'].values()),'explicitKentCrossReferences':sum(len(r.get('references',[])) for _,r in nodes),'explicitLegacyCrossReferences':len(sidecar['references']),'legacyComparison':{'identity':'Existing app key kent is Publicum, author Vladimir Polony, 2008; not OOREP Kent English','sourcePathsShared':shared,'kentPathsNotInLegacyPublicum':len(missing),'sharedPathsWithDifferentRemedyLinksOrGrades':different,'missingPaths':missing},'completedAt':manifest['completedAt'],'sourcePageHashes':manifest['pageSha256'],'permission':'Owner confirmed redistribution permission in this task; API license is unspecified'}
report['duplicateSourcePaths']=duplicatePaths
report['legacyAlternateNames']=sum(len(v['aliases']) for v in gplAliases.values())
(D/'kent_oorep_audit.json').write_text(json.dumps(report,ensure_ascii=False,separators=(',',':')))
registry=json.loads((D/'source_registry.json').read_text());old=next(x for x in registry['bundled_sources'] if x['id']=='kent');old.update(title='Repertorium Publicum · English (legacy source key kent)',author='Vladimir Polony',verification='Preserved for existing Publicum cases; distinct from English Kent')
registry['bundled_sources']=[x for x in registry['bundled_sources'] if x['id']!='kent1897'];registry['bundled_sources'].insert(0,dict(id='kent1897',file='kent_english_oorep.json',title=rep['title'],author=rep['author'],edition=rep['edition'],status='BUNDLED_API_AUDITED',license=rep['source_license'],sourceUrl=rep['source_url'],ocrQuality='Structured live API snapshot',verification='All source IDs and remedy grades compared exhaustively; printed-book scan verification not performed'))
(D/'source_registry.json').write_text(json.dumps(registry,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in report.items() if k not in ['sourcePageHashes','legacyComparison']},indent=2));print('Legacy path differences:',len(missing),'shared:',shared,'shared grades/links differ:',different)
