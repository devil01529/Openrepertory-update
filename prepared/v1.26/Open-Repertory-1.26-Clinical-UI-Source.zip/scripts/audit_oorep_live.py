"""Read-only, resumable audit of public OOREP API pages. Never publishes source responses.

Stores raw clinical responses outside the app. One sequential request at a time,
at least one second apart; honours Retry-After and stops on access rejection.
"""
import argparse,json,time,hashlib,datetime
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError,URLError
p=argparse.ArgumentParser();p.add_argument('--source',default='kent');p.add_argument('--cache',type=Path,required=True);a=p.parse_args();a.cache.mkdir(parents=True,exist_ok=True)
def get(page):
    file=a.cache/f'{page:05}.json'
    if file.exists():return json.loads(file.read_text())
    url='https://www.oorep.com/api/lookup_rep?'+urlencode(dict(repertory=a.source,symptom='***',page=page,remedyString='',minWeight=0,getRemedies=0))
    for attempt in range(5):
        try:
            started=time.monotonic()
            with urlopen(Request(url,headers={'User-Agent':'OpenRepertory-SourceAudit/1.0 (read-only; sequential; cached)'}),timeout=90) as r:raw=r.read()
            result=json.loads(raw);assert result[0]['currPage']==page
            tmp=file.with_suffix('.tmp');tmp.write_bytes(raw);tmp.replace(file)
            time.sleep(max(0,1-(time.monotonic()-started)));return result
        except HTTPError as error:
            if error.code in [401,403,404]:raise
            if attempt==4:raise
            time.sleep(max(float(error.headers.get('Retry-After','0')),5*2**attempt))
        except (URLError,TimeoutError,json.JSONDecodeError):
            if attempt==4:raise
            time.sleep(5*2**attempt)
first=get(0)[0];total=first['totalNumberOfRepertoryRubrics'];pages=first['totalNumberOfPages'];assert first['totalNumberOfResults']==total,'Wildcard must include every source row before a full audit can be claimed'
print('Source',a.source,'rows',total,'pages',pages,flush=True)
seen={};page_hashes={}
for page in range(pages):
    response=get(page)[0]
    assert response['totalNumberOfRepertoryRubrics']==total and response['totalNumberOfResults']==total
    for row in response['results']:
        for item in row['subRubrics']:
            rubric=item['rubric'];key=str(rubric['id']);assert key not in seen,'Duplicate source ID across pages'
            seen[key]=item
    page_hashes[str(page)]=hashlib.sha256((a.cache/f'{page:05}.json').read_bytes()).hexdigest()
    if page%20==0 or page==pages-1:print('Cached page',page+1,'/',pages,'unique rows',len(seen),flush=True)
assert len(seen)==total
(a.cache/'rows.json').write_text(json.dumps(seen,ensure_ascii=False,separators=(',',':')))
(a.cache/'manifest.json').write_text(json.dumps(dict(source=a.source,total=total,pages=pages,completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),pageSha256=page_hashes),indent=2))
print('COMPLETE',len(seen),'unique source rows; raw responses remain outside the APK',flush=True)
