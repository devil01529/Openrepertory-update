(function () {
  "use strict";

  const CHUNK_ROWS = 260;  // rows drawn per batch while scrolling a long list
  const SUB_PAGE = 60;     // sub-rubrics drawn per batch inside one big rubric
  const GRID_MAX = 120;    // remedies shown in the Analysis grid
  const KENT_CHAPTER_ORDER = [
    "Mind", "Vertigo", "Head", "Eye", "Vision", "Ear", "Hearing", "Nose",
    "Face", "Mouth", "Teeth", "Throat", "External throat", "Stomach", "Abdomen",
    "Rectum", "Stool", "Urine", "Urethra", "Bladder", "Kidneys", "Prostate gland",
    "Genitalia male", "Genitalia female", "Larynx and trachea", "Respiration", "Cough",
    "Expectoration", "Chest", "Back", "Extremities", "Sleep", "Chill", "Fever",
    "Perspiration", "Skin", "Generalities"
  ];
  const OOREP_EXTRA_ORDER = ["Appetite", "Heart & Circulation", "Blood", "Clinical"];
  const KENT_CHAPTER_RANK = new Map([...KENT_CHAPTER_ORDER, ...OOREP_EXTRA_ORDER].map((name, index) => [name.toLowerCase(), index]));

  const state = {
    remedies: {},
    repertory: null,
    activeChapter: null,
    query: "",
    cases: {},       // { caseId: { id, name, analysis: [{uid, chapter, text, remedies:[{r,g}]}] } }
    activeCaseId: null,
    includeGrade1: true,
    sourceAbbreviations: true,
    scoreMethod: "grade",
    page: "dashboard",
    onlineSources: [],
    sourceRegistry: null,
    searchIndexes: Object.create(null),
    searchScope: "all"
  };
  // shared namespace used by patients.js / materia.js
  const OR = window.OR = { state, pages: {}, hooks: { start: [], casesChanged: [], repertoryChanged: [] } };
  function activeCase() { return state.cases[state.activeCaseId]; }
  function activeAnalysis() { const c = activeCase(); return c ? c.analysis : []; }

  const $ = id => document.getElementById(id);
  const els = {
    content: $("content"),
    chapterTree: $("chapterTree"),
    chapterHero: $("chapterHero"),
    rubricList: $("rubricList"),
    emptyState: $("emptyState"),
    breadcrumb: $("breadcrumb"),
    searchWrap: $("searchWrap"),
    searchBox: $("searchBox"), searchScope: $("searchScope"),
    clearSearch: $("clearSearch"),
    chapterSearchWrap: $("chapterSearchWrap"),
    chapterSearchBox: $("chapterSearchBox"),
    chapterClearSearch: $("chapterClearSearch"),
    infoPanel: $("infoPanel"),
    infoBody: $("infoBody"),
    remedyToast: $("remedyToast"),
    statusText: $("statusText"),
    analysisCount: $("analysisCount"),
    pageTitle: $("pageTitle"),
    activeContext: $("activeContext"), dashboardRoot: $("dashboardRoot"),
    menuBtn: $("menuBtn"), menuDot: $("menuDot"), menuPanel: $("menuPanel"), menuBackdrop: $("menuBackdrop"), bottomNav: $("bottomNav"),
    casePatient: $("casePatient"), caseToFile: $("caseToFile"), caseOpenFile: $("caseOpenFile"),
    selectedCount: $("selectedCount"),
    selectedList: $("selectedList"),
    resultsTableWrap: $("resultsTableWrap"),
    clearAnalysis: $("clearAnalysis"),
    caseSelect: $("caseSelect"),
    caseNew: $("caseNew"),
    caseRename: $("caseRename"),
    caseDelete: $("caseDelete"),
    includeGrade1: $("includeGrade1"),
    scoreMethod: $("scoreMethod"),
    copySummary: $("copySummary"),
    saveSnapshot: $("saveSnapshot"), snapshotHistory: $("snapshotHistory"), compareRemedies: $("compareRemedies"), exportCase: $("exportCase"), printCase: $("printCase"),
    pages: document.querySelectorAll(".page"),
    sidebar: $("sidebar"),
    repSelect: $("repSelect"), repLibrary: $("repLibrary"), repCompare: $("repCompare"), sourceLockBadge: $("sourceLockBadge"),
    repNote: $("repNote"),
    sidebarToggle: $("sidebarToggle"),
    sidebarClose: $("sidebarClose")
  };

  function collapseSidebar() { els.sidebar.classList.add("collapsed"); updateAnalysisShortcut(); }
  function toggleSidebar() { els.sidebar.classList.toggle("collapsed"); updateAnalysisShortcut(); }
  els.sidebarToggle.addEventListener("click", toggleSidebar);
  els.sidebarClose.addEventListener("click", collapseSidebar);

  // ---------- small helpers ----------
  function escapeHTML(s) {
    return String(s).replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }
  function escapeRegExp(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  // "fear death" / "Fear, death" -> ["fear","death"]
  function tokenize(q) {
    return (q || "").toLowerCase().split(/[\s,]+/).filter(Boolean);
  }

  function highlightText(text, tokens) {
    if (!tokens || !tokens.length) return escapeHTML(text);
    const re = new RegExp(
      "(" + tokens.slice().sort((a, b) => b.length - a.length).map(escapeRegExp).join("|") + ")", "gi"
    );
    let out = "", last = 0, m;
    while ((m = re.exec(text))) {
      if (!m[0].length) { re.lastIndex++; continue; }
      out += escapeHTML(text.slice(last, m.index)) + "<mark>" + escapeHTML(m[0]) + "</mark>";
      last = m.index + m[0].length;
    }
    return out + escapeHTML(text.slice(last));
  }

  // All application records use encrypted native storage in the APK.
  const store = OR.store = {
    ok: true,
    get(key) { const raw = ORStorage.read(key); return raw === null ? null : JSON.parse(raw); },
    batch(values) {
      try { ORStorage.batch(values); store.ok = true; return true; }
      catch (error) { store.ok = false; ORReportError(error.message); return false; }
    },
    set(key, value) { return store.batch({ [key]: value }); }
  };
  // Historical source text and provenance are always visible; ignore any legacy saved-off preference.

  OR.escapeHTML = escapeHTML;
  OR.tokenize = tokenize;
  OR.uid = uidGen;
  OR.$ = $;

  // small message at the bottom; optional action button
  let appToastTimer;
  OR.toast = function (msg, actionLabel, action) {
    const t = $("appToast");
    t.innerHTML = `<span>${escapeHTML(msg)}</span>` + (actionLabel ? `<button type="button" class="find-btn">${escapeHTML(actionLabel)}</button>` : "");
    if (actionLabel) t.querySelector("button").addEventListener("click", () => { t.classList.remove("show"); action(); });
    t.classList.add("show");
    clearTimeout(appToastTimer);
    appToastTimer = setTimeout(() => t.classList.remove("show"), actionLabel ? 5000 : 2600);
  };

  // ---------- dialogs (own modal; native prompt/confirm are blocked in hosted pages) ----------
  const modalStack = [];
  const modalBackground=new Map();
  function syncModalAccessibility(){
    const active=modalStack[modalStack.length-1];
    if(active && !modalBackground.size){
      active.firstElementChild.focus();
      [...document.body.children].filter(el=>!['modalRoot','appToast','persistentError'].includes(el.id)&&!['SCRIPT','STYLE'].includes(el.tagName)).forEach(el=>{
        modalBackground.set(el,{hidden:el.getAttribute('aria-hidden'),inert:el.inert});el.setAttribute('aria-hidden','true');if('inert' in el)el.inert=true;
      });
    }
    updateAnalysisShortcut();
    for(const wrap of modalStack){if(wrap===active){wrap.removeAttribute('aria-hidden');if('inert' in wrap)wrap.inert=false;}else{wrap.setAttribute('aria-hidden','true');if('inert' in wrap)wrap.inert=true;}}
    if(!active){for(const [el,old]of modalBackground){if(old.hidden===null)el.removeAttribute('aria-hidden');else el.setAttribute('aria-hidden',old.hidden);if('inert' in el)el.inert=!!old.inert;}modalBackground.clear();}
  }
  OR.modal = function (opts) {
    const root = $("modalRoot");
    const wrap = document.createElement("div");
    wrap.className = "modal-back";
    const titleId = "dialog-title-" + Math.random().toString(36).slice(2);
    wrap.innerHTML = `<div class="modal ${opts.wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-labelledby="${titleId}" tabindex="-1">
      <div class="modal-head"><b id="${titleId}">${escapeHTML(opts.title || "")}</b><button type="button" class="icon-btn small modal-x" aria-label="Close">✕</button></div>
      <div class="modal-body">${opts.html || ""}</div>
      <div class="modal-foot"></div></div>`;
    root.appendChild(wrap);
    const modal = wrap.firstElementChild;
    const foot = modal.querySelector(".modal-foot");
    const previousFocus = document.activeElement;
    modalStack.push(wrap);
    syncModalAccessibility();
    let draft=null;
    function close() {
      if(!wrap.isConnected)return;
      if(draft)draft.discard();
      document.removeEventListener("keydown", onKey);
      const index = modalStack.indexOf(wrap);
      if (index >= 0) modalStack.splice(index, 1);
      wrap.remove();
      syncModalAccessibility();
      if (previousFocus && previousFocus.isConnected && previousFocus.focus) previousFocus.focus();
      if (opts.onClose) opts.onClose();
    }
    function onKey(e) {
      if (modalStack[modalStack.length - 1] !== wrap) return;
      if (e.key === "Escape") { e.preventDefault(); close(); return; }
      if (e.key !== "Tab") return;
      const focusable = [...modal.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')]
        .filter(el => !el.hidden && el.getAttribute("aria-hidden") !== "true");
      if (!focusable.length) { e.preventDefault(); modal.focus(); return; }
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (e.shiftKey && (document.activeElement === first || !modal.contains(document.activeElement))) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
    document.addEventListener("keydown", onKey);
    (opts.actions || []).forEach(a => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = a.primary ? "primary-btn" : (a.danger ? "danger-btn" : "ghost-btn");
      b.textContent = a.label;
      b.addEventListener("click", async () => {
        b.disabled=true;
        try {
          const keep=a.onClick?await a.onClick(modal,close):undefined;
          if(keep!==false&&!a.stay)close();
        }catch(error){
          ORReportError(error.message);
          let status=modal.querySelector('.modal-save-error');
          if(!status){status=document.createElement('p');status.className='modal-save-error';status.setAttribute('role','alert');modal.querySelector('.modal-body').appendChild(status);}
          status.textContent=error.message;
        }finally{b.disabled=false;}
      });
      foot.appendChild(b);
    });
    modal.querySelector(".modal-x").addEventListener("click", close);
    wrap.addEventListener("mousedown", e => { if (e.target === wrap) close(); });
    if (opts.onMount) opts.onMount(modal, close);
    if(opts.draftKey && OR.drafts)draft=OR.drafts.attach(modal,opts);
    const first = modal.querySelector("input, textarea, select") || modal.querySelector("button:not([disabled])") || modal;
    if (wrap.isConnected) { if(opts.noFocus)modal.focus();else first.focus(); }
    return { el: modal, close };
  };
  OR.ask = function (title, value, label) {
    return new Promise(resolve => {
      let done = false;
      const finish = v => { if (!done) { done = true; resolve(v); } };
      OR.modal({
        title,
        html: `<label class="fld"><span>${escapeHTML(label || "")}</span><input type="text" class="ask-in" value="${escapeHTML(value || "")}"></label>`,
        actions: [
          { label: "Cancel", onClick: () => finish(null) },
          { label: "OK", primary: true, onClick: m => finish(m.querySelector(".ask-in").value.trim()) }
        ],
        onMount: m => m.querySelector(".ask-in").addEventListener("keydown", e => {
          if (e.key === "Enter") { e.preventDefault(); m.querySelector(".primary-btn").click(); }
        }),
        onClose: () => finish(null)
      });
    });
  };
  OR.confirm = function (title, message, okLabel) {
    return new Promise(resolve => {
      let done = false;
      const finish = v => { if (!done) { done = true; resolve(v); } };
      OR.modal({
        title, html: `<p class="modal-msg">${escapeHTML(message)}</p>`, noFocus: true,
        actions: [
          { label: "Cancel", onClick: () => finish(false) },
          { label: okLabel || "Delete", danger: true, onClick: () => finish(true) }
        ],
        onClose: () => finish(false)
      });
    });
  };

  // ---------- cases (per-viewer convenience only, via localStorage) ----------
  function uidGen() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  let committedCases = null;
  OR.rememberCases = () => { committedCases = ORClone({cases:state.cases,activeCaseId:state.activeCaseId}); };
  function saveCases() {
    if (!store.set("openrepertory_cases", { cases: state.cases, activeCaseId: state.activeCaseId })) {
      if(committedCases){ORRestoreObject(state.cases,committedCases.cases);state.activeCaseId=committedCases.activeCaseId;}
      throw new Error("Cases were not saved. The previous records have been retained.");
    }
    OR.rememberCases();
    OR.hooks.casesChanged.forEach(fn => fn());
  }
  OR.saveCases = saveCases;

  function normalizeProvenance(value) {
    if (!value || typeof value !== "object") return null;
    return {rubricId: typeof value.rubricId === "string" ? value.rubricId.slice(0,100) : "",
      dataRevision: typeof value.dataRevision === "string" ? value.dataRevision.slice(0,100) : "",
      sourceNote: typeof value.sourceNote === "string" ? value.sourceNote.slice(0,2000) : "",
      sourceIds: Array.isArray(value.sourceIds) ? value.sourceIds.filter(x=>typeof x === "string").slice(0,20) : []};
  }
  function normalizeAnalysisItem(it) {
    if (!it || typeof it !== "object" || typeof it.uid !== "string" || typeof it.chapter !== "string" || typeof it.text !== "string" || !Array.isArray(it.remedies)) return null;
    const remedies = it.remedies.filter(rm => rm && typeof rm === "object" && typeof rm.r === "string" && Number.isFinite(Number(rm.g)) && Number(rm.g) >= 1 && Number(rm.g) <= 3).map(rm => {
      const result={r:rm.r,g:Number(rm.g)};
      if(typeof rm.sourceAbbreviation==='string')result.sourceAbbreviation=rm.sourceAbbreviation.slice(0,50);
      if(rm.sourceTypography && ['roman','italic','unresolved'].includes(rm.sourceTypography.style))result.sourceTypography={style:rm.sourceTypography.style,review:['scan-checked','machine-detected','pending'].includes(rm.sourceTypography.review)?rm.sourceTypography.review:'pending',evidenceId:typeof rm.sourceTypography.evidenceId==='string'?rm.sourceTypography.evidenceId.slice(0,180):''};
      return result;
    });
    return { provenance: normalizeProvenance(it.provenance), uid: it.uid, chapter: it.chapter, text: it.text, origin: it.origin === "ai" ? "ai" : "manual", sourceId: typeof it.sourceId === "string" ? it.sourceId : null, w: Number.isFinite(Number(it.w)) ? Math.max(1, Math.min(5, Number(it.w))) : (Number.isFinite(Number(it.weight)) ? Math.max(1, Math.min(5, Number(it.weight))) : 1), remedies };
  }
  function normalizeSnapshot(s) {
    if (!s || typeof s !== "object" || !Array.isArray(s.rubrics)) return null;
    const rubrics = s.rubrics.map(normalizeAnalysisItem).filter(Boolean).map(({w,...rubric})=>({...rubric,weight:w}));
    const ranking = Array.isArray(s.ranking) ? s.ranking.filter(x => x && typeof x.abbr === "string").map(x => ({ abbr: x.abbr, count: Number(x.count) || 0, score: Number(x.score) || 0, averageGrade: Number(x.averageGrade) || 0 })) : [];
    return Object.assign({}, s, { rubrics, ranking, savedAt: typeof s.savedAt === "string" ? s.savedAt : new Date().toISOString() });
  }
  function loadCases() {
    try {
      const raw = ORStorage.read("openrepertory_cases");
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.cases && Object.keys(parsed.cases).length) {
          state.cases = parsed.cases;
          // tolerate damaged or hand-edited saves: every case needs an id, a name and an analysis array
          Object.entries(state.cases).forEach(([cid, cs]) => {
            if (!/^[A-Za-z0-9_-]{1,120}$/.test(cid)) { delete state.cases[cid]; return; }
            if (!cs || typeof cs !== "object") { delete state.cases[cid]; return; }
            cs.id = /^[A-Za-z0-9_-]{1,120}$/.test(String(cs.id || "")) ? String(cs.id) : cid;
            cs.name = typeof cs.name === "string" && cs.name ? cs.name : "Case";
            cs.analysis = Array.isArray(cs.analysis) ? cs.analysis.map(normalizeAnalysisItem).filter(Boolean) : [];
            cs.snapshots = Array.isArray(cs.snapshots) ? cs.snapshots.map(normalizeSnapshot).filter(Boolean) : [];
          });
          if (!Object.keys(state.cases).length) throw new Error("no usable cases");
          state.activeCaseId = parsed.activeCaseId in state.cases
            ? parsed.activeCaseId : Object.keys(state.cases)[0];
          OR.rememberCases();
          return;
        }
      }
      // migrate the old single-case format if present
      const old = ORStorage.read("openrepertory_analysis");
      const analysis = old ? JSON.parse(old) : [];
      const id = uidGen();
      state.cases = { [id]: { id, name: "Case 1", analysis } };
      state.activeCaseId = id;
      saveCases();
    } catch (e) {
      throw new Error("Saved cases could not be opened safely. Existing data has been retained. " + e.message);
    }
  }

  function renderCaseSelect() {
    els.caseSelect.innerHTML = Object.values(state.cases)
      .map(c => {
        const pt = c.patientId && OR.patientName ? OR.patientName(c.patientId) : "";
        return `<option value="${c.id}" ${c.id === state.activeCaseId ? "selected" : ""}>${escapeHTML(c.name)}${pt ? " · " + escapeHTML(pt) : ""} (${c.analysis.length})</option>`;
      })
      .join("");
    renderCasePatientBar();
  }
  OR.renderCaseSelect = renderCaseSelect;

  // patient link controls on the Analysis page
  function renderCasePatientBar() {
    const c = activeCase();
    const list = OR.patientList ? OR.patientList() : [];
    els.casePatient.innerHTML = `<option value="">— not linked —</option>` +
      list.map(p => `<option value="${p.id}" ${c && c.patientId === p.id ? "selected" : ""}>${escapeHTML(p.name || "Unnamed")}</option>`).join("");
    const linked = !!(c && c.patientId);
    els.caseToFile.style.display = linked ? "" : "none";
    els.caseOpenFile.style.display = linked ? "" : "none";
  }
  OR.renderCasePatientBar = renderCasePatientBar;

  els.casePatient.addEventListener("change", () => {
    const c = activeCase();
    if (!c) return;
    c.patientId = els.casePatient.value || null;
    saveCases();
    renderCaseSelect();
  });
  els.caseToFile.addEventListener("click", () => {
    const c = activeCase();
    if (!c || !c.patientId || !OR.patients) return;
    if (!c.analysis.length) { OR.toast("Add rubrics to the case first."); return; }
    OR.patients.addVisitFromCase(c.patientId, c.name, compactCaseNote(c));
    OR.toast("Saved to patient file.", "Open file", () => { OR.patients.open(c.patientId); });
  });
  els.caseOpenFile.addEventListener("click", () => {
    const c = activeCase();
    if (c && c.patientId && OR.patients) OR.patients.open(c.patientId);
  });

  // make a case (optionally for a patient) and open it in Analysis
  OR.newCase = function (name, patientId) {
    const id = uidGen();
    state.cases[id] = { id, name: name || `Case ${Object.keys(state.cases).length + 1}`, patientId: patientId || null, analysis: [] };
    state.activeCaseId = id;
    saveCases();
    renderCaseSelect();
    renderAnalysis();
    refreshAddButtons();
    return id;
  };
  OR.openCase = async function (caseId) {
    if (!state.cases[caseId]) return;
    if (state.cases[caseId].repertoryId) await applyRepertory(state.cases[caseId].repertoryId);
    state.activeCaseId = caseId;
    saveCases();
    renderCaseSelect();
    renderAnalysis();
    refreshAddButtons();
    showPage("analysis");
  };

  els.caseSelect.addEventListener("change", async () => {
    const id = els.caseSelect.value;
    if (state.cases[id].repertoryId) await applyRepertory(state.cases[id].repertoryId);
    state.activeCaseId = id;
    saveCases();
    renderAnalysis();
    refreshAddButtons();
  });

  els.caseNew.addEventListener("click", async () => {
    const name = await OR.ask("New case", "", "Name this case (e.g. patient initials)");
    if (name === null) return;
    OR.newCase(name, null);
  });

  els.caseRename.addEventListener("click", async () => {
    const c = activeCase();
    if (!c) return;
    const name = await OR.ask("Rename case", c.name, "Case name");
    if (!name) return;
    c.name = name;
    saveCases();
    renderCaseSelect();
  });

  els.caseDelete.addEventListener("click", async () => {
    const c = activeCase();
    if (!c) return;
    if (!await OR.confirm("Delete case", `Delete case "${c.name}"? This can't be undone.`)) return;
    delete state.cases[c.id];
    if (!Object.keys(state.cases).length) {
      const id = uidGen();
      state.cases[id] = { id, name: "Case 1", analysis: [] };
      state.activeCaseId = id;
    } else {
      state.activeCaseId = Object.keys(state.cases)[0];
    }
    saveCases();
    renderCaseSelect();
    renderAnalysis();
    refreshAddButtons();
  });

  // ---------- data loading ----------
  // Data can arrive three ways: gzip+base64 embedded in the page (published
  // preview), plain embedded JSON, or a normal fetch() of data/*.json.
  async function loadJSON(path) {
    const gz = window.__EMBEDDED_GZ__ && window.__EMBEDDED_GZ__[path];
    if (gz) {
      if (typeof DecompressionStream === "undefined") {
        throw new Error("This browser is too old to unpack the data (needs DecompressionStream) - please update it.");
      }
      const bin = atob(gz);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
      return JSON.parse(await new Response(stream).text());
    }
    if (window.__EMBEDDED_DATA__ && window.__EMBEDDED_DATA__[path]) return window.__EMBEDDED_DATA__[path];
    const res = await fetch(path);
    if (!res.ok) throw new Error("Failed to load " + path);
    return res.json();
  }

  async function init() {
    loadCases();
    try {
      const savedMethod = localStorage.getItem("or.scoreMethod");
      if (["coverage", "grade", "weighted", "classical"].includes(savedMethod)) state.scoreMethod = savedMethod;
      els.scoreMethod.value = state.scoreMethod;
    } catch (e) { /* storage unavailable */ }
    OR.hooks.start.forEach(fn => fn());
    renderCaseSelect();
    updateMenuBadges();
    els.statusText.textContent = "Loading repertory…";
    try {
      let startId = activeCase()?.repertoryId || "kent1897";
      try { const saved = localStorage.getItem("or.repertory"); if (REP_FILES[saved]) startId = saved; } catch (_) {}
      state.repertories = {};
      const [remedies, audit, kentIntegrity, onlineSources, sourceRegistry, clarkeNames] = await Promise.all([
        loadJSON("data/remedies_full.json"), loadJSON("data/audit_report.json"),
        loadJSON("data/kent_integrity_audit_v2.json"), loadJSON("data/online_repertory_sources.json"),
        loadJSON("data/source_registry.json"), loadJSON("data/clarke_remedy_names.json"), ensureRepertory(startId)
      ]);
      state.remedies = Object.assign({}, remedies, clarkeNames); state.audit = audit; state.kentIntegrity = kentIntegrity;
      state.onlineSources = onlineSources.sources || []; state.sourceRegistry = sourceRegistry;
      await applyRepertory(startId);
      renderAnalysis();
      renderDashboard();
      showPage("dashboard");
      if (OR.pages[state.page] && OR.pages[state.page].onData) OR.pages[state.page].onData();
    } catch (err) {
      els.statusText.textContent = "Error loading repertory data: " + err.message;
      ORReportError("Startup failed: " + err.message + ". Reopen the app to retry.");
      console.error(err);
      throw err;
    }
  }

  const REP_FILES = { kent1897: "kent_english_oorep.json", clarke: "clarke.json", kent: "kent_publicum_full.json", bbcr: "bbcr1905.json", knerr1897: "knerr1897.json", tpb1846: "tpb1846.json", boger1915: "boger1915.json" };
  const repLoads = new Map();
  async function ensureRepertory(id) {
    if (!REP_FILES[id]) throw new Error("Unknown repertory");
    if (state.repertories[id]) return state.repertories[id];
    if (!repLoads.has(id)) repLoads.set(id, loadJSON("data/" + REP_FILES[id]).then(async rep => {
      if (id === "kent") rep.chapters.sort((a,b) => (KENT_CHAPTER_RANK.get(a.name.toLowerCase()) ?? 99) - (KENT_CHAPTER_RANK.get(b.name.toLowerCase()) ?? 99));
      if (id === "kent") {
        if (!state.oorepRelationships) state.oorepRelationships = await loadJSON("data/oorep_relationships.json");
        const refs=state.oorepRelationships.references || {};
        rep.chapters.forEach(ch=>ch.rubrics.forEach(r=>{if(refs[r.id])r.references=refs[r.id];(r.sub||[]).forEach(sub=>{if(refs[sub.id])sub.references=refs[sub.id];});}));
        rep.remedyAliases=state.oorepRelationships.remedyAliases || {};
      }
      if(rep.remedyNames) Object.assign(state.remedies, rep.remedyNames);
      if(rep.remedyAliases) Object.entries(rep.remedyAliases).forEach(([abbr,v])=>{if(!state.remedies[abbr])state.remedies[abbr]=v.name;});
      state.repertories[id] = rep; return rep;
    }).catch(error => { repLoads.delete(id); throw error; }));
    return repLoads.get(id);
  }
  OR.ensureRepertory = ensureRepertory;
  async function loadAllRepertories() { await Promise.all(Object.keys(REP_FILES).map(ensureRepertory)); }
  let repSelection = 0;
  // switch between the loaded repertories (Kent / BBCR 1905 / Knerr 1897 / TPB 1846 / Boger 1915)
  async function applyRepertory(id) {
    searchGeneration++;
    const selection = ++repSelection;
    els.statusText.textContent = "Loading selected repertory…";
    let rep;
    try { rep = await ensureRepertory(id); }
    catch (error) { els.repSelect.value = state.repertoryId || "kent"; OR.toast("Book could not be loaded. Please retry."); throw error; }
    if (selection !== repSelection) return;

    OR.aiMode(false);
    els.rubricList.setAttribute("aria-busy","false");
    state.repertoryId = id;
    rep.sha256 = state.audit?.datasets?.[id]?.sha256 || rep.sha256;
    state.repertory = rep;
    Object.entries(rep.remedyAliases || {}).forEach(([abbr,v])=>{if(!state.remedies[abbr])state.remedies[abbr]=v.name;});
    const styleBar=$("sourceStyleBar"); if(styleBar)styleBar.hidden=id!=="clarke";
    state.activeChapter = null;
    state.query = "";
    els.searchBox.value = "";
    els.repSelect.value = id;
    els.statusText.title = `${rep.source || "OOREP"} · ${rep.source_license || "Source license metadata unavailable"}` + (rep.note ? "\n" + rep.note : "");
    buildChapterTree();
    collapseChapter();
    els.statusText.textContent =
      `${rep.title} — ${rep.chapters.length} chapters, ${countRubrics(rep).toLocaleString()} rubrics, ` +
      `${Object.keys(state.remedies).length.toLocaleString()} remedies`;
    const quality = id === "kent1897" ? "English Kent · source records audited against OOREP; printed-book verification remains separate" : id === "clarke" ? "Clarke 1904 · equal-weight remedy links · transcription requires review" : id === "kent" ? "Structured OOREP data · source scan verification recommended" : id === "knerr1897" ? "⚠ Conservative grading · scan verification recommended" : id === "tpb1846" ? "⚠ Source-neutral grades · original typography is in the scan" : id === "boger1915" ? "⚠ Source inverted · original grading requires scan verification" : "⚠ OCR-derived source · grading should be verified against the printed book";
    els.repNote.hidden = false;
    els.repNote.textContent = `${quality}. ${rep.shortNote || rep.note || "Source metadata unavailable."}`;
    OR.hooks.repertoryChanged.forEach(fn => { try { fn(id); } catch (e) { console.error(e); } });
  }
  OR.setRepertory = applyRepertory;
  try { state.sourceAbbreviations=localStorage.getItem('or.clarkeSourceAbbreviations')!=='false'; } catch(e) {}
  $("sourceAbbreviations").checked=state.sourceAbbreviations;
  $("sourceAbbreviations").addEventListener('change',()=>{
    state.sourceAbbreviations=$("sourceAbbreviations").checked;
    try{localStorage.setItem('or.clarkeSourceAbbreviations',String(state.sourceAbbreviations));}catch(e){}
    document.querySelectorAll('#rubricList .rem').forEach(button=>{button.textContent=state.sourceAbbreviations && button.dataset.sourceAbbreviation ? button.dataset.sourceAbbreviation : button.dataset.abbr;});
  });
  $("sourceStyleHelp").addEventListener('click',()=>OR.modal({title:'Clarke’s printed styles',html:'<p><b>Roman and italic type are preserved separately from analysis scores.</b></p><p>Clarke explains on printed pages 31–32 (PDF 40–41) that italics in Part I identify remedies discussed under the same heading in his <i>Prescriber</i>. He explicitly says this does not mean the medicine is more indicated.</p><p><i>Italic</i> = printed italic style. Roman = printed upright style. Dotted abbreviations have unresolved typography. Open a rubric’s Source transcription to read its style review details. Remedy buttons open the full name in Materia Medica.</p><p>Source styles were detected from the scan, with separately checked examples. Complete visual verification remains pending. No three-level strength grades have been invented; Clarke analysis counts presence. Elsewhere in the book, typography is retained without assigning a strength meaning.</p>',actions:[{label:'Close',primary:true}]}));
  els.repSelect.addEventListener("change", async () => {
    await applyRepertory(els.repSelect.value);
    try { localStorage.setItem("or.repertory", els.repSelect.value); } catch (e) { /* ignore */ }
  });
  const REP_QUALITY = { clarke: ["Clarke 1904 · OCR-derived rubrics · presence-only weights", "REVIEW"], kent: ["Structured OOREP data · scan verification recommended", "PASS"], bbcr: ["OCR-derived source · verify against scan", "REVIEW"], knerr1897: ["Scan-backed historical source · conservative grading", "REVIEW"], tpb1846: ["Source-neutral grades · verify printed typography", "REVIEW"], boger1915: ["Source inverted · verify original grading", "REVIEW"] };
  const REPERTORY_NAMES={kent1897:"Kent",kent:"Repertorium Publicum",clarke:"Clarke",bbcr:"Boenninghausen — BBCR",knerr1897:"Knerr",tpb1846:"Therapeutic Pocket Book",boger1915:"Boger"};
  OR.repertoryName=id=>REPERTORY_NAMES[id]||state.repertories?.[id]?.title||id||"Repertory";
  async function openRepertoryLibrary() {
    const cards=Object.keys(REP_FILES).map(id=>`<button type="button" class="book-choice ${id===state.repertoryId?'current':''}" data-library-rep="${id}" aria-pressed="${id===state.repertoryId}"><span>${escapeHTML(OR.repertoryName(id))}</span><span aria-hidden="true">${id===state.repertoryId?'✓':'›'}</span></button>`).join('');
    OR.modal({title:"Choose repertory",html:`<div class="book-choices">${cards}</div>`,actions:[{label:"Close"}],onMount:(modal,close)=>modal.querySelectorAll('[data-library-rep]').forEach(button=>button.onclick=async()=>{
      button.disabled=true;button.setAttribute('aria-busy','true');
      try{await applyRepertory(button.dataset.libraryRep);try{localStorage.setItem('or.repertory',button.dataset.libraryRep);}catch(e){}close();showPage('repertory');}
      catch(e){button.disabled=false;button.removeAttribute('aria-busy');}
    })});
  }
  els.repLibrary.addEventListener("click", openRepertoryLibrary);

  function acrossSourceMatches(rep, query) {
    if (!rep || !query) return [];
    let items = [];
    searchVariants(query).forEach(variant => rep.chapters.forEach(ch => { items = items.concat(searchInChapter(ch, tokenize(variant))); }));
    return [...new Map(items.map(item => [item.r.id + "|" + item.chapter, item])).values()].slice(0, 8);
  }
  async function openCrossRepertoryComparison(query) {
    const q = String(query || "").trim();
    if (!q) {
      OR.modal({ title: "Compare the same symptom across sources", html: `<label class="fld full"><span>Symptom or rubric phrase</span><input id="crossRepQuery" type="search" placeholder="e.g. anxiety before sleep" autofocus></label><p class="muted small-note">The comparison searches every bundled offline repertory and shows source-specific wording and remedy links.</p>`, actions: [{ label: "Cancel" }, { label: "Compare", primary: true, onClick: m => { const value = m.querySelector("#crossRepQuery").value.trim(); if (!value) return false; openCrossRepertoryComparison(value); } }] });
      return;
    }
    await loadAllRepertories();
    const sections = Object.entries(state.repertories || {}).filter(([, rep]) => rep).map(([id, rep]) => {
      const matches = acrossSourceMatches(rep, q);
      const meta = (state.sourceRegistry && state.sourceRegistry.bundled_sources || []).find(x => x.id === id || (id === "kent" && x.id === "kent"));
      const body = matches.length ? matches.map(item => {
        const remedies = [...(item.r.remedies || []), ...item.subs.flatMap(s => s.remedies || [])].slice(0, 8).map(x => `${escapeHTML(x.r)}${x.g ? `<sup>${escapeHTML(String(x.g))}</sup>` : ""}`).join(", ");
        return `<li><b>${escapeHTML(item.chapter)}</b> · ${escapeHTML(item.r.text)}${item.subs.length ? `<small>${item.subs.slice(0, 3).map(s => ` · ${escapeHTML(s.text)}`).join("")}</small>` : ""}<span class="cross-remedies">${remedies || "No remedy links"}</span></li>`;
      }).join("") : `<li class="muted">No matching rubric found in this source.</li>`;
      return `<section class="cross-rep-source"><header><h3>${escapeHTML(rep.title || id)}</h3><span>${escapeHTML(meta ? meta.status : "BUNDLED")}</span></header><p class="muted small-note">${escapeHTML(meta ? `${meta.author} · ${meta.edition} · ${meta.ocrQuality}` : "Source metadata unavailable")}</p><ol>${body}</ol></section>`;
    }).join("");
    OR.modal({ title: `Cross-repertory comparison · “${q}”`, wide: true, html: `<p class="rep-library-intro"><b>Same query, separate source results.</b><span>This is a read-only comparison. It does not merge rubrics, grades, remedy links, or analysis scores. To add a rubric, open its repertory and select it for the active case.</span></p><div class="cross-rep-grid">${sections}</div>`, actions: [{ label: "Close", primary: true }] });
  }
  els.repCompare.addEventListener("click", () => openCrossRepertoryComparison(els.searchBox.value));

  function countRubrics(rep) {
    let n = 0;
    rep.chapters.forEach(ch => {
      n += ch.rubrics.length;
      ch.rubrics.forEach(r => { if (r.sub) n += r.sub.length; });
    });
    return n;
  }

  // ---------- chapter tree ----------
  function chapterSlug(name) {
    return String(name).toLowerCase().replace(/^bb:\s*/, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  }
  function chapterRubricCount(chapter) {
    return chapter.rubrics.reduce((n, r) => n + 1 + (r.sub ? r.sub.length : 0), 0);
  }
  function renderChapterHero(chapter) {
    if (!els.chapterHero) return;
    if (!chapter) { els.chapterHero.hidden = true; els.chapterHero.innerHTML = ""; return; }
    const name = chapter.name.replace(/^BB:\s*/, "");
    els.chapterHero.hidden = false;
    els.chapterHero.innerHTML = `<img src="art/chapter/${chapterSlug(name)}.png" alt=""><div class="chapter-summary"><h2>${escapeHTML(name)}</h2><p>${chapterRubricCount(chapter).toLocaleString()} rubric nodes</p></div>`;
  }
  function filterChapters() {
    const q = $("chapterFilter").value.trim().toLocaleLowerCase();
    let visible = 0, total = 0;
    els.chapterTree.querySelectorAll("[data-chapter-id]").forEach(li => {
      const match = li.dataset.chapterName.toLocaleLowerCase().includes(q);
      li.hidden = !match; total++; if (match) visible++;
    });
    els.chapterTree.querySelectorAll(".chapter-separator").forEach(li => li.hidden = !!q);
    $("chapterFilterStatus").textContent = q ? (visible ? visible + " of " + total + " chapters" : "No chapters match. Clear the filter to see all chapters.") : total + " chapters";
    $("chapterFilterClear").hidden = !q;
  }
  $("chapterFilter").addEventListener("input", filterChapters);
  $("chapterFilterClear").onclick = () => { $("chapterFilter").value = ""; filterChapters(); $("chapterFilter").focus(); };
  function buildChapterTree() {
    $("chapterFilter").value = "";
    els.chapterTree.innerHTML = "";
    let additionsLabelAdded = false;
    const additions = new Set(["appetite", "heart & circulation", "blood", "clinical"]);
    state.repertory.chapters.forEach(ch => {
      if (!additionsLabelAdded && additions.has(ch.name.toLowerCase())) {
        const label = document.createElement("li");
        label.className = "chapter-separator";
        label.setAttribute("aria-hidden", "true");
        label.textContent = "OOREP additions";
        els.chapterTree.appendChild(label);
        additionsLabelAdded = true;
      }
      const li = document.createElement("li");
      li.dataset.chapterId = ch.id;
      const cleanName = ch.name.replace(/^BB:\s*/, "");
      li.className = "chapter-row";
      li.dataset.chapterName = cleanName;
      li.innerHTML = `<button type="button" class="chapter-choice"><span class="chapter-row-art"><img src="art/chapter/${chapterSlug(cleanName)}.png" alt="" loading="lazy"></span><span class="chapter-row-copy"><b>${escapeHTML(cleanName)}</b><small>${chapterRubricCount(ch).toLocaleString()} rubric nodes</small></span><span class="chapter-current" aria-hidden="true">✓</span></button>`;
      li.addEventListener("click", () => {
        state.query = "";
        els.searchBox.value = "";
        selectChapter(ch.id);
      });
      els.chapterTree.appendChild(li);
    });
    filterChapters();
  }

  function clearActiveChapterMarks() {
    [...els.chapterTree.children].forEach(li => { li.classList.remove("active"); li.querySelector("button")?.removeAttribute("aria-current"); });
  }

  function resetList() {
    stopObserver();
    listState = null;
    els.rubricList.innerHTML = "";
  }

  // AI results replace the normal list; any normal navigation switches them off again
  OR.aiMode = on => els.content.classList.toggle("ai-mode", !!on);
  function collapseChapter() {
    OR.aiMode(false);
    state.activeChapter = null;
    clearActiveChapterMarks();
    els.breadcrumb.textContent = "";
    resetList();
    renderChapterHero(null);
    els.emptyState.style.display = "block";
    els.chapterSearchWrap.style.display = "none";
  }

  function selectChapter(chapterId) {
    searchGeneration++;
    els.rubricList.setAttribute("aria-busy","false");
    OR.aiMode(false);
    state.activeChapter = chapterId;
    [...els.chapterTree.children].forEach(li => {
      const active = li.dataset.chapterId === chapterId;
      li.classList.toggle("active", active);
      const button = li.querySelector("button");
      if (button) { if (active) button.setAttribute("aria-current", "true"); else button.removeAttribute("aria-current"); }
    });
    const chapter = state.repertory.chapters.find(c => c.id === chapterId);
    if (!chapter) return;
    renderChapterHero(chapter);
    els.emptyState.style.display = "none";
    els.chapterSearchWrap.style.display = "flex";
    els.chapterSearchBox.value = "";
    renderChapterView(chapter, "");
    collapseSidebar();
  }

  // ---------- building the list of things to show ----------
  function chapterItems(chapter) {
    const items = [];
    chapter.rubrics.forEach(r => {
      const subs = (r.sub || []).filter(s => s.remedies && s.remedies.length);
      if ((r.remedies && r.remedies.length) || subs.length) {
        items.push({ r, chapter: chapter.name, subs, topMatch: true });
      }
    });
    return items;
  }

  const abbrCache = new Map();
  function normAbbr(a) {
    let v = abbrCache.get(a);
    if (v === undefined) {
      v = a.toLowerCase().replace(/\.$/, "");
      abbrCache.set(a, v);
    }
    return v;
  }
  function remedyHas(remedies, tok) {
    for (let i = 0; i < remedies.length; i++) if (normAbbr(remedies[i].r) === tok) return true;
    return false;
  }
  const SEARCH_SYNONYMS = {
    sadness: ["grief", "sorrow", "sad"], grief: ["sadness", "sorrow"],
    anxiety: ["fear", "apprehension"], fear: ["anxiety", "fright"],
    angry: ["anger", "irritability", "irritable"], headache: ["head pain"],
    nausea: ["sickness", "sick stomach"], vomiting: ["vomiting", "retching"],
    sleepless: ["wakeful", "insomnia"], consolation: ["comfort"],
    worse: ["aggravation", "agg"], better: ["amelioration", "amel"]
  };
  function levenshtein(a, b) {
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      for (let j = 1; j <= b.length; j++) cur[j] = Math.min(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[b.length];
  }
  function normalizeSearchQuery(query) {
    return String(query || "").replace(/[“”‘’]/g, "").replace(/[!;:()[\]{}]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function searchVariants(query) {
    const base = normalizeSearchQuery(query);
    const variants = [base];
    // These are source-recorded alternate remedy names, kept separate from
    // the app's heuristic patient-word suggestions below.
    const aliasKey=base.toLowerCase().replace(/[.]/g, "").replace(/\s+/g, " ").trim();
    Object.entries(state.repertory?.remedyAliases || {}).forEach(([abbr,record])=>{
      if ([record.name].concat(record.aliases || []).some(name=>name && name.toLowerCase().replace(/[.]/g, "").replace(/\s+/g, " ").trim()===aliasKey)) variants.push(abbr.replace(/\.$/, ""));
    });
    OR.tokenize(base).forEach(token => (SEARCH_SYNONYMS[token] || []).forEach(syn => variants.push(base.replace(new RegExp(`\\b${escapeRegExp(token)}\\b`, "i"), syn))));
    return [...new Set(variants)].filter(Boolean);
  }

  // Every word must appear in the path text (including a close typo match) OR
  // be a remedy abbreviation of this rubric.
  function matchesAll(tokens, pathLower, remedies) {
    const words = pathLower.split(/[^a-z0-9]+/).filter(Boolean);
    for (let i = 0; i < tokens.length; i++) {
      const t = tokens[i];
      const fuzzy = t.length >= 5 && words.some(word => levenshtein(word, t) <= (t.length >= 8 ? 2 : 1));
      if (pathLower.indexOf(t) === -1 && !fuzzy && !remedyHas(remedies, t)) return false;
    }
    return true;
  }

  function buildSearchIndex(rep) {
    const entries = [], termMap = new Map();
    const add = entry => {
      const index = entries.length; entries.push(entry);
      const terms = new Set((entry.pathLower + " " + entry.remedyKeys.join(" ")).split(/[^a-z0-9-]+/).filter(Boolean));
      terms.forEach(term => { if (!termMap.has(term)) termMap.set(term, new Set()); termMap.get(term).add(index); });
    };
    rep.chapters.forEach(chapter => chapter.rubrics.forEach(r => {
      const parentKey = `${chapter.name}||${r.id}`;
      const parentPath = `${chapter.name} ${r.text}`.toLowerCase();
      add({ kind: "parent", parentKey, chapter: chapter.name, r, pathLower: parentPath, remedyKeys: (r.remedies || []).reduce((out,x)=>out.concat([normAbbr(x.r)].concat(x.sourceAbbreviation?[normAbbr(x.sourceAbbreviation.replace(/\s+/g,''))]:[])),[]) });
      (r.sub || []).forEach(s => add({ kind: "sub", parentKey, chapter: chapter.name, r, sub: s, pathLower: `${parentPath} ${s.text}`.toLowerCase(), remedyKeys: (s.remedies || []).reduce((out,x)=>out.concat([normAbbr(x.r)].concat(x.sourceAbbreviation?[normAbbr(x.sourceAbbreviation.replace(/\s+/g,''))]:[])),[]) }));
    }));
    return { entries, termMap };
  }
  function searchIndexFor(rep) {
    const key = rep && (rep.id || rep.title);
    if (!key) return { entries: [], termMap: new Map() };
    if (!state.searchIndexes[key]) state.searchIndexes[key] = buildSearchIndex(rep);
    return state.searchIndexes[key];
  }
  function candidateEntries(index, tokens) {
    const sets = tokens.map(token => index.termMap.get(token));
    if (sets.every(Boolean)) {
      const ordered = sets.slice().sort((a, b) => a.size - b.size);
      return [...ordered[0]].filter(i => ordered.every(set => set.has(i))).map(i => index.entries[i]);
    }
    return index.entries;
  }
  // Indexed search keeps each repertory independent while avoiding repeated JSON traversal.
  function searchInChapter(chapter, tokens) {
    const index = searchIndexFor(state.repertory);
    const entries = candidateEntries(index, tokens).filter(entry => entry.chapter === chapter.name);
    const groups = new Map();
    entries.forEach(entry => {
      const matched = matchesAll(tokens, entry.pathLower, entry.remedyKeys.map(r => ({ r })));
      if (!matched) return;
      if (!groups.has(entry.parentKey)) groups.set(entry.parentKey, { r: entry.r, chapter: entry.chapter, subs: [], topMatch: false, matchReason: "" });
      const group = groups.get(entry.parentKey);
      if (entry.kind === "parent") { group.topMatch = true; group.matchReason = entry.pathLower.includes(tokens.join(" ")) ? "Exact heading/path match" : "Heading or remedy match"; }
      else { group.subs.push(entry.sub); if (!group.topMatch) group.matchReason = "Sub-rubric match"; }
    });
    return [...groups.values()].sort((a, b) => Number(b.topMatch) - Number(a.topMatch) || a.chapter.localeCompare(b.chapter));
  }

  function summarize(items) {
    const subs = items.reduce((n, it) => n + it.subs.length, 0);
    return `${items.length.toLocaleString()} rubric(s), ${subs.toLocaleString()} sub-rubric(s)`;
  }

  function renderChapterView(chapter, query) {
    const tokens = tokenize(query);
    if (!tokens.length) {
      els.breadcrumb.textContent = `${state.repertory.title} › ${chapter.name}`;
      renderList(chapterItems(chapter), [], false);
      return;
    }
    let items = [];
    searchVariants(query).forEach(variant => { items = items.concat(searchInChapter(chapter, tokenize(variant))); });
    items = [...new Map(items.map(item => [item.r.id, item])).values()];
    items = items.filter(i => i.topMatch).concat(items.filter(i => !i.topMatch));
    els.breadcrumb.textContent = `${chapter.name} › "${query.trim()}" — ${summarize(items)} in this chapter`;
    renderList(items, tokens, true);
  }

  // ---------- rendering (chunked so huge chapters stay fast) ----------
  let listState = null;
  let observer = null;
  function stopObserver() { if (observer) { observer.disconnect(); observer = null; } }

  function renderList(items, tokens, smartSearch) {
    resetList();
    els.emptyState.style.display = "none";
    els.content.scrollTop = 0;
    if (!items.length) {
      els.rubricList.innerHTML = `<p class="empty-state">No rubrics match.</p>`;
      return;
    }
    listState = { items, idx: 0, tokens, smartSearch: !!smartSearch };
    appendChunk();
  }

  function appendChunk() {
    const st = listState;
    if (!st) return;
    stopObserver();
    const old = els.rubricList.querySelector(".more-wrap");
    if (old) old.remove();

    const frag = document.createDocumentFragment();
    let rows = 0;
    while (st.idx < st.items.length && rows < CHUNK_ROWS) {
      const it = st.items[st.idx++];
      frag.appendChild(renderRubric(it.r, it.subs, {
        isSub: false, tokens: st.tokens, chapterName: it.chapter, parentText: "", matchReason: it.matchReason,
        showContext: st.smartSearch
      }));
      rows += 1 + Math.min(it.subs.length, SUB_PAGE);
    }
    els.rubricList.appendChild(frag);

    if (st.idx < st.items.length) {
      const wrap = document.createElement("div");
      wrap.className = "more-wrap";
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "more-btn";
      btn.textContent = `Show more rubrics (${(st.items.length - st.idx).toLocaleString()} remaining)`;
      btn.addEventListener("click", appendChunk);
      wrap.appendChild(btn);
      els.rubricList.appendChild(wrap);
      if ("IntersectionObserver" in window) {
        observer = new IntersectionObserver(entries => {
          if (entries[0].isIntersecting) appendChunk();
        }, { root: els.content, rootMargin: "900px" });
        observer.observe(wrap);
      }
    }
  }

  function renderRemedies(remedies) {
    return (remedies || [])
      .slice()
      .sort((a, b) => b.g - a.g)
      .map(rm => {
        const full = state.remedies[rm.r] || rm.r;
        const source=state.repertoryId==='clarke',style=source && rm.sourceTypography;
        const label=source && state.sourceAbbreviations && rm.sourceAbbreviation ? rm.sourceAbbreviation.replace(/[.]?$/,'.') : rm.r;
        const note=source ? ` · Printed style: ${style?style.style:'unresolved'}; ${style?style.review:'pending'} · Presence only; no strength grade` : '';
        return `<button type="button" class="rem g${rm.g}${source?' source-'+(style?style.style:'unresolved'):''}" data-abbr="${escapeHTML(rm.r)}" data-source-abbreviation="${escapeHTML(source && rm.sourceAbbreviation || '')}" title="Open ${escapeHTML(full)} in Materia Medica${escapeHTML(note)}" aria-label="Open ${escapeHTML(full)} in Materia Medica${escapeHTML(note)}">${escapeHTML(label)}</button>`;
      })
      .join("");
  }

  let branchesCollapsed = false;
  OR.setBranchesCollapsed = collapsed => {
    branchesCollapsed = !!collapsed;
    els.rubricList.querySelectorAll(".rubric-toggle:not(.none)").forEach(button => {
      if ((button.getAttribute("aria-expanded") === "true") === branchesCollapsed) button.click();
    });
  };
  function renderRubric(r, subs, ctx) {
    const { isSub, tokens, chapterName, parentText, matchReason, showContext } = ctx;
    const div = document.createElement("div");
    div.className = "rubric" + (isSub ? " sub" : "");

    const shown = isSub ? r.text.replace(/^\.\s*/, "") : r.text;
    const fullPath = isSub ? parentText + ", " + shown : r.text;
    const uid = chapterName + "||" + (state.repertoryId === "clarke" ? r.id + "||" : "") + fullPath;
    const isAdded = OR.hasRubric(uid);
    const hasSub = subs.length > 0;
    const subId = "rubric-subs-" + Math.random().toString(36).slice(2);
    const contextLabel = isSub
      ? `Chapter: ${chapterName} · Rubric: ${parentText} · Sub-rubric`
      : `Chapter: ${chapterName} · Rubric`;
    div.dataset.rubricUid = uid;
    div.dataset.chapter = chapterName;
    div.dataset.depth = isSub ? 1 : 0;

    const row = document.createElement("div");
    row.className = "rubric-row";
    row.innerHTML = `
      <button class="rubric-toggle ${hasSub ? (branchesCollapsed ? "" : "open") : "none"}" type="button" aria-expanded="${hasSub && !branchesCollapsed}" aria-controls="${subId}" aria-label="${hasSub && !branchesCollapsed ? "Collapse" : "Expand"} sub-rubrics for ${escapeHTML(shown)}" ${hasSub ? `title="${subs.length} sub-rubrics"` : "disabled"}>${hasSub && !branchesCollapsed ? "▾" : "▸"}${hasSub ? `<small>${subs.length}</small>` : ""}</button>
      <span class="rubric-text">${highlightText(shown, tokens)}${showContext ? `<small class="rubric-citation"><b>${escapeHTML(contextLabel)}</b>${matchReason ? ` · <em>Match: ${escapeHTML(matchReason)}</em>` : ""}</small>` : ""}</span>
      <span class="remedy-count" title="Number of remedies">${(r.remedies || []).length}</span>
      <span class="remedies">${renderRemedies(r.remedies)}</span>
      <button class="add-btn ${isAdded ? "added" : ""}" type="button">${isAdded ? "✓ Added" : "+ Add"}</button>`;
    div.appendChild(row);
    if (OR.clinic) OR.clinic.decorateRubric(div, row, r, {chapterName, fullPath, uid});
    if (r.crossReference) {
      const refs=document.createElement("div"); refs.className="rubric-citation";
      r.crossReference.split(/;|\band\b/i).map(x=>x.replace(/^also\s+/i,"").trim().replace(/[.]$/,"")).filter(Boolean).forEach(target=>{
        const button=document.createElement("button"); button.type="button"; button.textContent="See "+target;
        button.addEventListener("click",()=>OR.runSearch(target)); refs.appendChild(button);
      });
      div.appendChild(refs);
    }
    if (r.sourceNote) {
      const citation=document.createElement("small"); citation.className="rubric-citation"; citation.textContent=r.sourceNote; div.appendChild(citation);
      if (r.sourceText) {
        const details=document.createElement("details"), summary=document.createElement("summary"), text=document.createElement("p");
        details.className="source-transcription"; summary.textContent="Source transcription";
        text.textContent=(r.checkedTranscription ? r.text+" — "+r.checkedTranscription : r.sourceText)+" · "+r.transcriptionReview;
        details.appendChild(summary); details.appendChild(text); div.appendChild(details);
        if(state.repertoryId==='clarke') {
          const styles=document.createElement('p');styles.className='source-style-review';
          styles.textContent='Printed-style review: '+(r.remedies || []).map(m=>`${m.sourceAbbreviation || m.r}: ${m.sourceTypography ? m.sourceTypography.style+' ('+m.sourceTypography.review+')' : 'unresolved (pending)'}`).join('; ');
          details.appendChild(styles);
          if (r.abbreviationReviews && r.abbreviationReviews.length) {
            const notes=document.createElement('ul'); notes.className='source-abbreviation-review';
            r.abbreviationReviews.forEach(review=>{
              const item=document.createElement('li');
              item.textContent=(review.ocrToken===review.printedToken ? review.printedToken : review.ocrToken+' → '+review.printedToken)+': '+review.note+' (PDF p. '+review.pdfPage+')';
              notes.appendChild(item);
            });
            details.appendChild(notes);
          }
        }
      }
    }

    const addBtn = row.querySelector(".add-btn");
    addBtn.dataset.uid = uid;
    if (r.unscored || !(r.remedies || []).length) {
      addBtn.disabled = true;
      addBtn.textContent = r.crossReference ? "Reference" : r.unscored ? "Review needed" : "Choose sub-rubric";
      addBtn.title = "This heading has no resolved remedy links.";
    }
    addBtn.addEventListener("click", () => {
      if (document.activeElement?.matches("input,textarea")) document.activeElement.blur();
      toggleAnalysisItem(uid, chapterName, fullPath, r.remedies || [], ctx.weight, "manual", r.sourceNote ? {rubricId:r.id, sourceIds:r.sourceIds || [], sourceNote:r.sourceNote, dataRevision:state.repertory.dataRevision || ""} : null);
    });
    if (hasSub) {
      const subWrap = document.createElement("div");
      subWrap.className = "sub-list" + (branchesCollapsed ? "" : " open");
      subWrap.id = subId;
      subWrap.setAttribute("role", "group");
      div.appendChild(subWrap);
      let loaded = !branchesCollapsed;
      if (loaded) appendSubs(subWrap, r, subs, 0, SUB_PAGE, ctx);
      const toggleBtn = row.querySelector(".rubric-toggle");
      toggleBtn.addEventListener("click", () => {
        const open = subWrap.classList.toggle("open");
        if (open && !loaded) { loaded = true; appendSubs(subWrap, r, subs, 0, SUB_PAGE, ctx); }
        toggleBtn.firstChild.nodeValue = open ? "▾" : "▸";
        toggleBtn.classList.toggle("open", open);
        toggleBtn.setAttribute("aria-expanded", String(open));
        toggleBtn.setAttribute("aria-label", `${open ? "Collapse" : "Expand"} sub-rubrics for ${shown}`);
      });
    }
    return div;
  }

  // draws sub-rubrics [start, start+count) and a "show more" row if any remain
  function appendSubs(subWrap, parent, subs, start, count, ctx) {
    const old = subWrap.querySelector(":scope > .sub-more");
    if (old) old.remove();
    const end = Math.min(subs.length, start + count);
    const frag = document.createDocumentFragment();
    for (let i = start; i < end; i++) {
      frag.appendChild(renderRubric(subs[i], [], {
        isSub: true, tokens: ctx.tokens, chapterName: ctx.chapterName, parentText: parent.text, weight: ctx.weight, showContext: ctx.showContext
      }));
    }
    subWrap.appendChild(frag);
    if (end < subs.length) {
      const remaining = subs.length - end;
      const more = document.createElement("div");
      more.className = "sub-more";
      const b1 = document.createElement("button");
      b1.type = "button"; b1.className = "more-btn";
      b1.textContent = `Show ${Math.min(remaining, 100)} more of ${remaining.toLocaleString()}`;
      b1.addEventListener("click", () => appendSubs(subWrap, parent, subs, end, 100, ctx));
      more.appendChild(b1);
      if (remaining > 100) {
        const b2 = document.createElement("button");
        b2.type = "button"; b2.className = "more-btn";
        b2.textContent = `Show all ${remaining.toLocaleString()}`;
        b2.addEventListener("click", () => appendSubs(subWrap, parent, subs, end, remaining, ctx));
        more.appendChild(b2);
      }
      subWrap.appendChild(more);
    }
  }

  // remedy taps: one delegated listener for the whole list
  els.rubricList.addEventListener("click", e => {
    const rem = e.target.closest(".rem");
    if (rem) {
      e.preventDefault();
      const abbr = rem.dataset.abbr;
      if (OR.openMateriaRemedy) OR.openMateriaRemedy(abbr);
    }
  });

  let toastTimer;
  OR.findRemedy = abbr => findRemedyEverywhere(abbr);
  function findRemedyEverywhere(abbr) {
    if (!state.repertory) return;
    showPage("repertory");
    const clean = abbr.replace(/\.$/, "");
    els.searchBox.value = clean;
    runSearch(clean);
    els.remedyToast.classList.remove("show");
  }

  function showRemedyInfo(abbr) {
    const full = state.remedies[abbr] || "Unknown remedy";
    els.infoBody.innerHTML = `
      <div class="full-name">${escapeHTML(full)}</div>
      <div class="abbr">abbreviation: ${escapeHTML(abbr)}</div>
      <button class="find-btn" type="button">Find every rubric with this remedy →</button>`;
    els.infoBody.querySelector(".find-btn").addEventListener("click", () => findRemedyEverywhere(abbr));
    // the side panel is hidden on phones - show the name in a small toast instead
    if (getComputedStyle(els.infoPanel).display === "none") {
      els.remedyToast.innerHTML = `<strong>${escapeHTML(full)}</strong><span>${escapeHTML(abbr)}</span><button class="find-btn" type="button">Find every rubric →</button>`;
      els.remedyToast.querySelector(".find-btn").addEventListener("click", () => findRemedyEverywhere(abbr));
      els.remedyToast.classList.add("show");
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => els.remedyToast.classList.remove("show"), 5000);
    }
  }

  // ---------- universal search ----------
  let searchGeneration=0;
  const searchLookups=new WeakMap();
  async function runSearch(query) {
    collapseSidebar();
    const generation=++searchGeneration;
    OR.lastSearchStats=null;
    OR.aiMode(false);
    query = normalizeSearchQuery(query);
    state.query = query;
    els.chapterSearchWrap.style.display = "none";
    const tokens = tokenize(query);
    if (!tokens.length) {
      els.rubricList.setAttribute("aria-busy","false");
      els.statusText.textContent="Ready to search";
      els.breadcrumb.textContent = "";
      resetList();
      els.emptyState.style.display = "block";
      clearActiveChapterMarks();
      state.activeChapter = null;
      return;
    }
    let items = [];
    const scopeChapter = state.searchScope === "chapter" && currentChapter();
    const chapters = scopeChapter ? [scopeChapter] : state.repertory.chapters;
    const rep=state.repertory,repId=state.repertoryId,started=performance.now();
    els.rubricList.setAttribute('aria-busy','true');els.statusText.textContent='Searching…';
    let backend='worker';
    try {
      const matches=await ORSearch.query(REP_FILES[repId],searchVariants(query),scopeChapter?scopeChapter.name:null);
      if(generation!==searchGeneration||rep!==state.repertory)return;
      if(!searchLookups.has(rep)){const map=new Map();rep.chapters.forEach(ch=>ch.rubrics.forEach(r=>map.set(ch.name+'||'+r.id,r)));searchLookups.set(rep,map);}
      const lookup=searchLookups.get(rep);
      items=matches.map(m=>{const r=lookup.get(m.chapter+'||'+m.id);return r?{r,chapter:m.chapter,subs:m.subs.map(i=>r.sub[i]),topMatch:m.topMatch,matchReason:m.matchReason}:null;}).filter(Boolean);
    } catch(error) {
      if(generation!==searchGeneration||rep!==state.repertory)return;
      backend='fallback';
      searchVariants(query).forEach(variant => chapters.forEach(ch => { items = items.concat(searchInChapter(ch, tokenize(variant))); }));
    }
    if(generation!==searchGeneration||rep!==state.repertory)return;
    els.rubricList.setAttribute('aria-busy','false');
    OR.lastSearchStats={query,backend,milliseconds:Math.round(performance.now()-started),results:items.length};
    els.statusText.textContent='Search complete';
    items = [...new Map(items.map(item => [`${item.chapter}||${item.r.id}`, item])).values()];
    // rubrics whose own heading matches come first, then ones matched only via a sub-rubric
    items = items.filter(i => i.topMatch).concat(items.filter(i => !i.topMatch));
    clearActiveChapterMarks();
    state.activeChapter = null;
    els.breadcrumb.textContent = `${state.repertory.title} · ${scopeChapter ? `Chapter: ${scopeChapter.name}` : "All chapters"} · Search "${query.trim()}" — ${summarize(items)}`;
    renderList(items, tokens, true);
  }

  let debounceTimer;
  els.searchBox.addEventListener("input", e => {
    clearTimeout(debounceTimer);
    const val = e.target.value;
    debounceTimer = setTimeout(() => runSearch(val), 200);
  });
  els.clearSearch.addEventListener("click", () => {
    els.searchBox.value = "";
    runSearch("");
  });

  // ---------- search inside one chapter ----------
  function currentChapter() {
    return state.repertory && state.repertory.chapters.find(c => c.id === state.activeChapter);
  }
  els.searchScope.addEventListener("change", e => {
    state.searchScope = e.target.value;
    if (els.searchBox.value.trim()) runSearch(els.searchBox.value);
    else if (state.searchScope === "chapter" && currentChapter()) renderChapterView(currentChapter(), "");
  });
  let chapterDebounceTimer;
  els.chapterSearchBox.addEventListener("input", e => {
    clearTimeout(chapterDebounceTimer);
    const val = e.target.value;
    chapterDebounceTimer = setTimeout(() => {
      const chapter = currentChapter();
      if (chapter) renderChapterView(chapter, val);
    }, 200);
  });
  els.chapterClearSearch.addEventListener("click", () => {
    els.chapterSearchBox.value = "";
    const chapter = currentChapter();
    if (chapter) renderChapterView(chapter, "");
  });

  // ---------- analysis / repertorisation ----------
  function refreshAddButtons() {
    const added = new Set(activeAnalysis().filter(a=>itemSource(a)===state.repertoryId).map(a=>a.uid));
    document.querySelectorAll(".add-btn").forEach(b => {
      if (b.disabled) return;
      const on = added.has(b.dataset.uid);
      b.classList.toggle("added", on);
      b.textContent = on ? "✓ Added" : "+ Add";
    });
  }

  OR.openSourceReference = async function (reference) {
    OR.clinic?.captureReference();
    if (reference.sourceId && reference.sourceId !== state.repertoryId) await applyRepertory(reference.sourceId);
    showPage("repertory");
    if (reference.targetId) {
      for (const chapter of state.repertory.chapters) {
        for (const parent of chapter.rubrics) {
          const target=[parent].concat(parent.sub||[]).find(r=>r.id===reference.targetId);
          if (!target) continue;
          selectChapter(chapter.id);
          const path=target===parent?parent.text:parent.text+", "+target.text.replace(/^\.\s*/,"");
          await OR.openRubricLocation({sourceId:state.repertoryId,uid:chapter.name+"||"+path,text:path});return;
        }
      }
    }
    OR.toast("Source reference: showing matching entries; choose the intended rubric.");
    els.searchBox.value=reference.label;await runSearch(reference.label);
  };

  OR.openRubricLocation = async function (item) {
    if (!item || !item.uid) return;
    const sourceId = item.sourceId || (activeCase() && activeCase().repertoryId) || state.repertoryId;
    if (sourceId && sourceId !== state.repertoryId) await applyRepertory(sourceId);
    const parts = String(item.uid).split("||");
    const chapterName = parts.shift();
    const chapter = state.repertory && state.repertory.chapters.find(ch => ch.name === chapterName);
    if (!chapter) { OR.toast(`Chapter not found in ${state.repertory ? state.repertory.title : "the active repertory"}.`); return; }
    showPage("repertory");
    els.searchBox.value = "";
    renderChapterView(chapter, item.text || parts.join("||"));
    requestAnimationFrame(() => {
      const target = [...els.rubricList.querySelectorAll(".rubric")].find(node => node.dataset.rubricUid === item.uid);
      if (target) { target.scrollIntoView({ block: "center", behavior: "smooth" }); target.classList.add("location-highlight"); setTimeout(() => target.classList.remove("location-highlight"), 2200); }
      else OR.toast("Rubric located in the chapter; expand or load more results to view its exact row.");
    });
  };

  OR.toggleRubric = (uid, chapterName, text, remedies, w, origin) => toggleAnalysisItem(uid, chapterName, text, remedies, w, origin);
  function itemSource(item,c=activeCase()){return item.sourceId||c?.repertoryId||state.repertoryId;}
  OR.hasRubric=uid=>activeAnalysis().some(a=>a.uid===uid&&itemSource(a)===state.repertoryId);
  OR.activeCase = () => activeCase();
  OR.rankCase = c => rankCase(c);
  function toggleAnalysisItem(uid, chapterName, text, remedies, w, origin, provenance) {
    const c = activeCase();
    const list = activeAnalysis();
    // Source plus the retained legacy UID identifies a selection. Books can
    // share chapter/path strings without toggling each other's selected rows.
    const idx=list.findIndex(a=>a.uid===uid&&itemSource(a,c)===state.repertoryId);
    if(idx>=0)list.splice(idx,1);
    else {
      if (c && !c.repertoryId) c.repertoryId = state.repertoryId;
      list.push({ uid, chapter: chapterName, text, remedies, provenance: provenance || null, sourceId: state.repertoryId, origin: origin === "ai" ? "ai" : "manual", w: w >= 1 && w <= 3 ? w : 1 });
    }
    saveCases();
    renderCaseSelect();
    renderAnalysis();
    refreshAddButtons();
  }

  function removeAnalysisItem(uid,sourceId) {
    const c = activeCase();
    c.analysis = c.analysis.filter(a => !(a.uid === uid && (!sourceId || itemSource(a,c)===sourceId)));
    saveCases();
    renderCaseSelect();
    renderAnalysis();
    refreshAddButtons();
  }

  let clearArmed = false, clearTimer;
  els.clearAnalysis.addEventListener("click", () => {
    if (!activeAnalysis().length) return;
    if (!clearArmed) {
      clearArmed = true;
      els.clearAnalysis.textContent = "Tap again to clear";
      clearTimer = setTimeout(resetClearBtn, 3000);
      return;
    }
    activeCase().analysis = [];
    saveCases();
    renderCaseSelect();
    renderAnalysis();
    refreshAddButtons();
    resetClearBtn();
  });
  function resetClearBtn() {
    clearArmed = false;
    clearTimeout(clearTimer);
    els.clearAnalysis.textContent = "Clear all";
  }

  // One shortcut to the existing analysis; never creates or modifies a case.
  function updateAnalysisShortcut() {
    const button = $("analysisShortcut"), n = activeAnalysis().length;
    const focused = document.activeElement;
    const editing = focused && (focused.matches("input:not([type=button]):not([type=checkbox]):not([type=radio]),textarea,select") || focused.isContentEditable);
    const chaptersOpen = window.matchMedia("(max-width: 699px)").matches && !els.sidebar.classList.contains("collapsed");
    button.hidden = state.page !== "repertory" || !n || editing || chaptersOpen || !els.menuPanel.hidden || modalStack.length > 0;
    $("analysisShortcutCount").textContent = n;
    button.setAttribute("aria-label", "Open analysis, " + n + " selected " + (n === 1 ? "rubric" : "rubrics"));
    const statusBar = $("statusbar");
    const status = statusBar && statusBar.getClientRects().length ? statusBar.getBoundingClientRect() : null;
    const nav = els.bottomNav.getBoundingClientRect();
    const bottom = Math.max(12, status ? window.innerHeight - status.top + 12 : 0, window.matchMedia("(max-width: 699px)").matches && nav.height ? window.innerHeight - nav.top + 12 : 0);
    // In short landscape windows a floating control would cover the entire
    // reading row. Reserve an icon slot in the reading tools instead.
    const docked = window.innerHeight < 480 && state.page === "repertory" && n > 0;
    document.body.classList.toggle("docked-analysis-shortcut", docked);
    const tools = $("repCommand") && document.querySelector(".rep-reading-tools");
    const slot = docked && tools ? tools.getBoundingClientRect() : null;
    button.style.bottom = slot ? "auto" : bottom + "px";
    button.style.top = slot ? slot.top + Math.max(4,(slot.height - 52)/2) + "px" : "auto";
    // Keep the scroll reserve during temporary overlays so a menu/dialog cannot
    // clamp the reading position at the end of the rubric list.
    document.body.classList.toggle("has-analysis-shortcut", state.page === "repertory" && n > 0);
  }
  $("analysisShortcut").addEventListener("click", () => {
    showPage("analysis");
    const heading = $("page-analysis").querySelector("h1,h2,h3");
    if (heading) { heading.setAttribute("tabindex", "-1"); heading.focus(); }
  });
  document.addEventListener("focusin", updateAnalysisShortcut);
  document.addEventListener("focusout", () => setTimeout(updateAnalysisShortcut, 0));
  window.addEventListener("resize", updateAnalysisShortcut);
  if (window.visualViewport) window.visualViewport.addEventListener("resize", updateAnalysisShortcut);

  function renderAnalysis() {
    const list = activeAnalysis();
    const presenceOnly=!!list.length&&list.every(item=>itemSource(item)==="clarke");
    els.includeGrade1.disabled=presenceOnly;
    els.includeGrade1.checked=presenceOnly||state.includeGrade1;
    const gradeLabel=els.includeGrade1.parentElement;
    if(gradeLabel.lastChild&&gradeLabel.lastChild.nodeType===3)gradeLabel.lastChild.textContent=presenceOnly?" all source entries":" include grade 1";
    els.includeGrade1.title=presenceOnly?"Clarke records presence, not strength grades.":"";
    els.scoreMethod.querySelector('[value="grade"]').textContent=presenceOnly?"Presence count":"Grade weighted";
    const n = list.length;
    els.analysisCount.textContent = n;
    const bottomCaseBadge = $("bottomCaseBadge");
    if (bottomCaseBadge) bottomCaseBadge.textContent = n;
    updateMenuBadges();
    updateAnalysisShortcut();
    if (OR.clinic) OR.clinic.analysisChanged();
    els.selectedCount.textContent = n;
    els.clearAnalysis.style.display = n ? "" : "none";
    els.copySummary.style.display = n ? "" : "none";
    els.saveSnapshot.style.display = n ? "" : "none";
    els.snapshotHistory.style.display = activeCase() && activeCase().snapshots && activeCase().snapshots.length ? "" : "none";
    els.compareRemedies.style.display = n ? "" : "none";
    els.exportCase.style.display = n ? "" : "none";
    els.printCase.style.display = n ? "" : "none";

    if (!n) {
      els.selectedList.innerHTML = `<p class="empty-state">No rubrics added yet. Go to <b>Repertory</b>, browse or search, and click <b>+ Add</b> on any rubric.</p>`;
      els.resultsTableWrap.innerHTML = `<p class="empty-state">Results will appear here once you add rubrics to the case.</p>`;
      return;
    }

    els.selectedList.innerHTML = "";
    if (state.repertoryId === "clarke" && list.some(item=>itemSource(item)==="clarke"&&(!item.provenance || item.provenance.dataRevision !== state.repertory.dataRevision))) {
      const notice=document.createElement("p"); notice.className="small-note source-revision-notice";
      notice.textContent="This saved case contains rubrics from an earlier Clarke database. Review them against the corrected entries before using the analysis. Saved remedy selections have been retained.";
      els.selectedList.appendChild(notice);
    }
    const frag = document.createDocumentFragment();
    list.forEach((item, i) => {
      const w = item.w || 1;
      const div = document.createElement("div");
      div.className = "selected-item";
      div.innerHTML = `
        <button class="si-text rubric-location-link" type="button" title="Open this rubric in its chapter"><span class="si-chapter">${i + 1}. Chapter: ${escapeHTML(item.chapter)}</span>${escapeHTML(item.text)}<small class="si-source">Source: ${escapeHTML(OR.repertoryName(itemSource(item)))} · Open rubric →</small></button>
        <div class="si-side">
          <div class="wt" role="group" aria-label="Rubric importance" title="Importance: multiplies this rubric's grades in the ranking">
            ${[1, 2, 3].map(k => `<button type="button" class="${k === w ? "on" : ""}" data-w="${k}">×${k}</button>`).join("")}
          </div>
          <button class="remove-btn" type="button" title="Remove from analysis">✕</button>
        </div>`;
      div.querySelector(".remove-btn").addEventListener("click", () => removeAnalysisItem(item.uid,itemSource(item)));
      div.querySelector(".rubric-location-link").addEventListener("click", () => OR.openRubricLocation(item));
      div.querySelectorAll(".wt button").forEach(btn => btn.addEventListener("click", () => {
        item.w = +btn.dataset.w;
        saveCases();
        renderAnalysis();
      }));
      frag.appendChild(div);
    });
    els.selectedList.appendChild(frag);

    const ranked = rankCase(activeCase());

    if (!ranked.length) {
      els.resultsTableWrap.innerHTML = `<p class="empty-state">No remedies meet the current grade filter.</p>`;
      return;
    }
    const shown = ranked.slice(0, GRID_MAX);

    const summary = shown.map((r, i) => `<div class="analysis-remedy-card"><span class="remedy-rank">${i + 1}</span><span class="analysis-remedy-main"><b>${escapeHTML(state.remedies[r.abbr] || r.abbr)}</b><small>${r.coveragePct}% coverage${presenceOnly ? "" : ` · average grade ${r.averageGrade.toFixed(2)}`} · ${r.score} points</small></span><button class="evidence-btn" type="button" data-evidence-remedy="${escapeHTML(r.abbr)}">Why scored</button><button class="card-arrow" type="button" aria-label="Open Materia Medica" data-analysis-remedy="${escapeHTML(r.abbr)}">›</button></div>`).join("");
    const head=shown.map(r=>`<th class="matrix-remedy" title="${escapeHTML(state.remedies[r.abbr]||r.abbr)}"><button type="button" data-analysis-remedy="${escapeHTML(r.abbr)}">${escapeHTML(r.abbr)}</button><small>${r.count}/${n} · ${r.score} pts</small></th>`).join('');
    const rows=list.map((item,i)=>`<tr><th class="remcol matrix-rubric" title="${escapeHTML(item.chapter+': '+item.text)}"><span>${i+1}. ${escapeHTML(item.chapter)} · ${escapeHTML(item.text)}</span><small>${escapeHTML(OR.repertoryName(itemSource(item)))}${(item.w||1)>1?' · ×'+item.w:''}</small></th>${shown.map(r=>`<td class="cell ${r.grades[i]?'g'+r.grades[i]:''}" title="${itemSource(item)==='clarke'?'Presence link':'Recorded grade'}">${r.grades[i]||'—'}</td>`).join('')}</tr>`).join('');
    els.resultsTableWrap.innerHTML = `
      <div class="analysis-summary" aria-label="Ranked remedies">${summary}</div>
      <div class="grid-scroll">
        <table class="results-table grid">
          <thead><tr><th class="remcol">Rubric / remedy<small>Coverage · points</small></th>${head}</tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <p class="analysis-disclaimer" style="margin-top:10px;">
        ${ranked.length > GRID_MAX ? `Showing the top ${GRID_MAX} of ${ranked.length.toLocaleString()} remedies. ` : ""}
        Ranked with the selected method. Coverage is rubrics covered / total; ${presenceOnly ? "" : "Avg is average recorded grade; "}Pts is the method score. Rows are selected rubrics; columns are ranked remedies, and ${presenceOnly ? 'each cell records a remedy link (1 = present; no strength grade is inferred).' : 'each cell is that remedy’s recorded grade (3 = strongest).'} Rows highlighted in green cover every rubric.
        This is a reproducible analysis aid, not a diagnosis.
      </p>`;
    els.resultsTableWrap.querySelectorAll("[data-analysis-remedy]").forEach(btn => btn.addEventListener("click", () => OR.openMateriaRemedy && OR.openMateriaRemedy(btn.dataset.analysisRemedy)));
    els.resultsTableWrap.querySelectorAll("[data-evidence-remedy]").forEach(btn => btn.addEventListener("click", () => showRemedyEvidence(btn.dataset.evidenceRemedy)));
  }

  function showRemedyEvidence(abbr) {
    const c = activeCase();
    const matches = (c ? c.analysis : []).map(item => {
      const hit = (item.remedies || []).find(rm => rm.r === abbr);
      return hit && (itemSource(item,c)==="clarke"||state.includeGrade1||hit.g>=2) ? { item, grade: hit.g, sourceTypography: hit.sourceTypography } : null;
    }).filter(Boolean);
    const name = state.remedies[abbr] || abbr;
    OR.modal({
      title: `Why ${name} scored`, wide: true,
      html: `<div class="evidence-dialog"><div class="evidence-summary"><b>${escapeHTML(name)}</b><span>${matches.length}/${c ? c.analysis.length : 0} selected rubrics matched</span></div>${matches.length ? `<div class="evidence-list">${matches.map(x => `<div class="evidence-row"><div><b>${escapeHTML(x.item.chapter)}</b><span>${escapeHTML(x.item.text)}</span></div><strong class="g${x.grade}">${itemSource(x.item,c)==='clarke' ? "Present" : "Grade "+x.grade}</strong><button type="button" class="mini-btn plain" data-evidence-source="${escapeHTML(x.item.text)}">Source</button></div>`).join("")}</div>` : `<p class="empty-state compact">This remedy did not meet the current grade filter in the selected rubrics.</p>`}<p class="muted small-note">The evidence list is deterministic: it shows the exact selected rubric records and recorded ${c && c.analysis.length && c.analysis.every(it=>itemSource(it,c)==='clarke') ? "presence links" : "grades"} used by the current analysis method. It is not a diagnosis or a substitute for source review.</p></div>`,
      actions: [{ label: "Open Materia Medica", primary: true, onClick: (_modal, close) => { close(); if (OR.openMateriaRemedy) OR.openMateriaRemedy(abbr); return false; } }, { label: "Close" }],
      onMount: modal => modal.querySelectorAll("[data-evidence-source]").forEach(button => button.addEventListener("click", () => { const q = button.dataset.evidenceSource; OR.modal({ title: "Rubric source", html: `<p class="provenance-path">${escapeHTML(q)}</p><p class="muted small-note">Open the Repertory page to review this rubric with its bundled source ID and provenance metadata.</p>`, actions: [{ label: "Open Repertory", primary: true, onClick: (_modal, close) => { close(); OR.showPage("repertory"); OR.runSearch(q); } }, { label: "Close" }] }); }))
    });
  }

  els.includeGrade1.addEventListener("change", () => {
    state.includeGrade1 = els.includeGrade1.checked;
    renderAnalysis();
  });

  els.scoreMethod.addEventListener("change", () => {
    state.scoreMethod = els.scoreMethod.value;
    try { localStorage.setItem("or.scoreMethod", state.scoreMethod); } catch (e) { /* ignore */ }
    renderAnalysis();
  });

  // ranked remedies of a case: [{abbr,count,score,grades[]}]
  function rankCase(c) {
    const list = c ? c.analysis : [];
    const minGrade = state.includeGrade1 ? 1 : 2;
    const tally = new Map();
    list.forEach((item, idx) => {
      (item.remedies || []).forEach(rm => {
        if (rm.g < (itemSource(item,c)==="clarke"?1:minGrade)) return;
        let t = tally.get(rm.r);
        if (!t) { t = { abbr: rm.r, count: 0, score: 0, gradeSum: 0, grades: new Array(list.length).fill(0) }; tally.set(rm.r, t); }
        if (!t.grades[idx]) t.count += 1;
        const delta = rm.g - t.grades[idx];
        const importance = item.w || 1;
        const specificity = 1 + 1 / Math.log2((item.remedies || []).length + 1);
        if (state.scoreMethod === "coverage") t.score += delta > 0 ? 1 : 0;
        else if (state.scoreMethod === "weighted") t.score += delta * importance * specificity;
        else if (state.scoreMethod === "classical") t.score += delta * importance * (delta >= 3 ? 2 : delta === 2 ? 1.35 : 0.8);
        else t.score += delta * importance;
        t.grades[idx] = rm.g;
        t.gradeSum += delta;
      });
    });
    tally.forEach(t => { t.averageGrade = t.count ? +(t.gradeSum / t.count).toFixed(2) : 0; t.coveragePct = list.length ? Math.round(100 * t.count / list.length) : 0; });
    return [...tally.values()].sort((a, b) => b.count - a.count || b.score - a.score || a.abbr.localeCompare(b.abbr));
  }

  function compactCaseNote(c) {
    const lines = ["Rubrics:"];
    c.analysis.forEach((it, i) => lines.push(`${i + 1}. ${it.chapter} — ${it.text}${(it.w || 1) > 1 ? ` [×${it.w}]` : ""}`));
    const top = rankCase(c).slice(0, 8);
    lines.push("", "Top remedies (rubrics covered / points):");
    top.forEach(r => lines.push(`${r.abbr} (${state.remedies[r.abbr] || r.abbr}) — ${r.count}/${c.analysis.length}, ${r.score} pts`));
    return lines.join("\n");
  }

  function caseSummaryText() {
    const c = activeCase();
    const list = c.analysis;
    const lines = [`Case: ${c.name}`, `Rubrics (${list.length}):`];
    list.forEach((item, i) => lines.push(`  ${i + 1}. ${item.chapter} — ${item.text}${(item.w || 1) > 1 ? `  [importance ×${item.w}]` : ""}`));
    const ranked = rankCase(c);
    lines.push("", `Remedy ranking (${c.analysis.length&&c.analysis.every(item=>itemSource(item,c)==="clarke") ? "presence only; printed italics do not change scores" : state.includeGrade1 ? "grades 1-3" : "grades 2-3 only"}):`);
    ranked.forEach((r, i) => {
      lines.push(`  ${i + 1}. ${r.abbr} (${state.remedies[r.abbr] || r.abbr}) — ${r.count}/${list.length} rubrics, ${r.score} pts`);
    });
    lines.push("", "Generated with Open Repertory — for reference only, not a diagnosis.");
    return lines.join("\n");
  }
  function caseExportPayload(c) {
    const source = (c.repertoryId && state.repertories && state.repertories[c.repertoryId]) || state.repertory;
    return { format: "openrepertory-case-v1", exportedAt: new Date().toISOString(), privacy: "Patient names, contact fields, case labels, and patient linkage are excluded by default.", case: { id: c.id, label: "Exported repertory case", repertoryId: c.repertoryId || state.repertoryId, analysis: c.analysis.map(x => ({ uid: x.uid, chapter: x.chapter, text: x.text, weight: x.w || 1, remedies: x.remedies, sourceId: x.sourceId || c.repertoryId || state.repertoryId, provenance: x.provenance || null })), snapshots: c.snapshots || [] }, analysis: { sourceIds:[...new Set(c.analysis.map(x=>itemSource(x,c)))], repertoryId: c.repertoryId || state.repertoryId, repertoryTitle: new Set(c.analysis.map(x=>itemSource(x,c))).size>1?"Multiple repertories":source && source.title, repertoryYear: source && source.year, method: state.scoreMethod, includeGrade1: state.includeGrade1, formulaVersion: "or-score-v1", ranking: rankCase(c).map(x => ({ abbr: x.abbr, name: state.remedies[x.abbr] || x.abbr, count: x.count, coveragePct: x.coveragePct, averageGrade: x.averageGrade, score: x.score })) } };
  }
  function openRemedyComparison() {
    const c = activeCase(); if (!c || !c.analysis.length) return;
    const ranked = rankCase(c).slice(0, 4);
    const presence=c.analysis.length&&c.analysis.every(item=>itemSource(item,c)==="clarke");
    const head = ranked.map(r => `<th>${escapeHTML(r.abbr)}<small>${escapeHTML(state.remedies[r.abbr] || r.abbr)}</small></th>`).join("");
    const rows = c.analysis.map((item, i) => `<tr><th>${i + 1}. ${escapeHTML(item.text)}${(item.w || 1) > 1 ? ` <small>×${item.w}</small>` : ""}</th>${ranked.map(r => `<td class="cell g${r.grades[i] || 0}">${r.grades[i] || "—"}</td>`).join("")}</tr>`).join("");
    OR.modal({ title: "Remedy comparison", wide: true, html: `<div class="comparison-explainer"><b>Top remedies side by side</b><span>${presence ? "Presence, coverage and scores are from the selected rubric links; printed italics do not increase scores." : "Grades, coverage, average grade, and score are from the current deterministic analysis."} This comparison does not prescribe a remedy.</span></div><div class="comparison-metrics">${ranked.map((r, i) => `<div><b>${i + 1}. ${escapeHTML(r.abbr)}</b><span>${r.coveragePct}% coverage${presence ? "" : ` · avg ${r.averageGrade.toFixed(2)}`} · ${r.score} pts</span></div>`).join("")}</div><div class="comparison-scroll"><table class="comparison-table"><thead><tr><th>Selected rubric</th>${head}</tr></thead><tbody>${rows}</tbody></table></div><p class="muted small-note">Method: ${escapeHTML(state.scoreMethod)} · ${presence ? "All source entries included" : `Grade filter: ${state.includeGrade1 ? "1–3" : "2–3"}`} · weights are shown beside weighted rubrics.</p>`, actions: [{ label: "Close", primary: true }] });
  }

  els.copySummary.addEventListener("click", async () => {
    const text = caseSummaryText();
    try {
      await navigator.clipboard.writeText(text);
    } catch (e) {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); } catch (e2) { /* ignore */ }
      document.body.removeChild(ta);
    }
    const old = els.copySummary.textContent;
    els.copySummary.textContent = "Copied!";
    setTimeout(() => { els.copySummary.textContent = old; }, 1500);
  });
  els.compareRemedies.addEventListener("click", openRemedyComparison);
  els.exportCase.addEventListener("click", () => { const c = activeCase(); if (c) downloadJSON(`openrepertory-case-${c.id}.json`, caseExportPayload(c)); });
  els.printCase.addEventListener("click", () => { try { window.ORPrint(caseSummaryText(), activeCase()?.name || "Case report"); } catch (e) { OR.toast("Printing is unavailable in this WebView."); } });

  OR.saveCaseSnapshot = function (c) {
    if (!c || !c.analysis.length) return false;
    if (!c.repertoryId) c.repertoryId = state.repertoryId;
    c.snapshots = c.snapshots || [];
    c.snapshots.push({
      id: uidGen(), savedAt: new Date().toISOString(), repertoryId: c.repertoryId || state.repertoryId, sourceIds:[...new Set(c.analysis.map(x=>itemSource(x,c)))],
      repertoryTitle: new Set(c.analysis.map(x=>itemSource(x,c))).size>1?"Multiple repertories":(state.repertories[c.repertoryId]?.title||state.repertory?.title), repertoryYear: state.repertory && state.repertory.year,
      repertorySource: state.repertory && state.repertory.source, datasetFile: state.repertory && state.repertory.file,
      datasetHash: state.repertory && (state.repertory.sha256 || state.repertory.datasetHash || null), formulaVersion: "or-score-v1",
      method: state.scoreMethod, includeGrade1: state.includeGrade1,
      rubrics: c.analysis.map(x => ({ uid: x.uid, chapter: x.chapter, text: x.text, sourceId: x.sourceId || c.repertoryId || state.repertoryId, weight: x.w || 1, remedies: x.remedies, provenance: x.provenance || null })),
      ranking: rankCase(c).slice(0, 20).map(x => ({ abbr: x.abbr, count: x.count, score: x.score, averageGrade: x.averageGrade }))
    });
    saveCases();
    OR.toast(`Snapshot saved (${c.snapshots.length}).`);
    return true;
  };
  els.saveSnapshot.addEventListener("click", () => OR.saveCaseSnapshot(activeCase()));
  async function downloadJSON(filename, value) {
    if (window.openrepertorySecure) return ORNativeRequest("saveDocument", [filename, JSON.stringify(value, null, 2)], null, 600000);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }));
    a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  function snapshotDifference(a, b) {
    const key=(x,s)=>(x.sourceId||s.repertoryId||"")+"::"+x.uid;
    const ar = new Map((a.rubrics || []).map(x => [key(x,a), x]));
    const br = new Map((b.rubrics || []).map(x => [key(x,b), x]));
    const added = [...br.values()].filter(x => !ar.has(key(x,b)));
    const removed = [...ar.values()].filter(x => !br.has(key(x,a)));
    const changed = [...br.values()].filter(x => ar.has(key(x,b)) && (x.text !== ar.get(key(x,b)).text || x.weight !== ar.get(key(x,b)).weight));
    const oldRank = new Map((a.ranking || []).map((x, i) => [x.abbr, i + 1]));
    const newRank = new Map((b.ranking || []).map((x, i) => [x.abbr, i + 1]));
    const remedyChanges = [...new Set([...oldRank.keys(), ...newRank.keys()])].map(abbr => ({ abbr, from: oldRank.get(abbr) || "—", to: newRank.get(abbr) || "—" })).filter(x => x.from !== x.to).slice(0, 10);
    return { added, removed, changed, remedyChanges };
  }
  function openSnapshotHistory() {
    const c = activeCase(); const snapshots = c && c.snapshots || [];
    if (!c || !snapshots.length) { OR.toast("Save a snapshot first."); return; }
    const options = snapshots.map((s, i) => `<option value="${i}">${i + 1}. ${escapeHTML(new Date(s.savedAt).toLocaleString())} · ${escapeHTML(s.method || "grade")}</option>`).join("");
    OR.modal({ title: `Snapshot history · ${c.name}`, wide: true, html: `<div class="snapshot-history"><div class="snapshot-toolbar"><label>Compare <select id="snapA" class="sel">${options}</select></label><span>with</span><label><select id="snapB" class="sel">${options}</select></label><button class="mini-btn plain" id="snapCompare" type="button">Compare</button></div><div id="snapComparison" class="snapshot-comparison"><p class="muted small-note">Select two snapshots and compare their rubrics and ranking.</p></div><div class="snapshot-list">${snapshots.slice().reverse().map((s, reverseIndex) => { const i = snapshots.length - 1 - reverseIndex; return `<div class="snapshot-history-row"><span><b>${escapeHTML(new Date(s.savedAt).toLocaleString())}</b><small>${escapeHTML(s.repertoryTitle || "Repertory")} · ${escapeHTML(s.method || "grade")} · ${(s.rubrics || []).length} rubrics · ${(s.ranking || []).length} remedies</small></span><div><button class="mini-btn plain" data-snap-export="${i}" type="button">Export</button><button class="mini-btn plain" data-snap-restore="${i}" type="button">Restore copy</button></div></div>`; }).join("")}</div></div>`, actions: [{ label: "Close", primary: true }], onMount: modal => {
      const result = modal.querySelector("#snapComparison");
      modal.querySelector("#snapCompare").addEventListener("click", () => { const a = snapshots[+modal.querySelector("#snapA").value], b = snapshots[+modal.querySelector("#snapB").value], d = snapshotDifference(a, b); result.innerHTML = `<div class="snapshot-diff-grid"><div><b>Rubrics added</b><strong>${d.added.length}</strong></div><div><b>Rubrics removed</b><strong>${d.removed.length}</strong></div><div><b>Rubrics changed</b><strong>${d.changed.length}</strong></div><div><b>Ranking changes</b><strong>${d.remedyChanges.length}</strong></div></div><div class="snapshot-diff-list">${d.remedyChanges.length ? d.remedyChanges.map(x => `<div><span>${escapeHTML(x.abbr)}</span><small>rank ${x.from} → ${x.to}</small></div>`).join("") : `<p class="muted small-note">No ranking-position changes between these snapshots.</p>`}</div>`; });
      modal.querySelectorAll("[data-snap-export]").forEach(btn => btn.addEventListener("click", () => downloadJSON(`openrepertory-snapshot-${snapshots[+btn.dataset.snapExport].id}.json`, snapshots[+btn.dataset.snapExport])));
      modal.querySelectorAll("[data-snap-restore]").forEach(btn => btn.addEventListener("click", async () => { const s = snapshots[+btn.dataset.snapRestore], id = uidGen(); state.cases[id] = { id, name: `${c.name} · restored ${new Date(s.savedAt).toLocaleDateString()}`, patientId: c.patientId || null, repertoryId: s.repertoryId || null, analysis: (s.rubrics || []).map(x => ({ uid: x.uid, chapter: x.chapter, text: x.text, w: x.weight || 1, remedies: x.remedies || [], sourceId: x.sourceId || s.repertoryId || null, provenance: normalizeProvenance(x.provenance) })) }; state.activeCaseId = id; if (s.repertoryId) await applyRepertory(s.repertoryId); if (s.method) { state.scoreMethod = s.method; els.scoreMethod.value = s.method; } if (typeof s.includeGrade1 === "boolean") { state.includeGrade1 = s.includeGrade1; els.includeGrade1.checked = s.includeGrade1; } saveCases(); renderCaseSelect(); renderAnalysis(); OR.toast(`Snapshot restored as a new case with ${s.repertoryTitle || s.repertoryId || "saved"} analysis context.`); }));
    } });
  }
  els.snapshotHistory.addEventListener("click", openSnapshotHistory);

  // ---------- dashboard and pages ----------
  function updateActiveContext() {
    const c = activeCase();
    const patient = c && c.patientId && OR.patientName ? OR.patientName(c.patientId) : "Unlinked case";
    const rep = state.repertory ? state.repertory.title : "Loading repertory";
    if (els.activeContext) els.activeContext.innerHTML = `<span class="context-patient">${escapeHTML(patient)}</span><span class="context-case">${escapeHTML(c ? c.name : "No active case")}</span><span class="context-rep">${escapeHTML(rep)}</span>`;
    if (OR.clinic) OR.clinic.updateContext();
    if (els.sourceLockBadge) {
      const lockedId = c && c.repertoryId;
      const locked = lockedId && state.repertories && state.repertories[lockedId];
      els.sourceLockBadge.textContent = locked ? `SOURCE LOCK · ${lockedId}` : `SOURCE · ${state.repertoryId || "loading"}`;
      els.sourceLockBadge.classList.toggle("locked", !!locked);
      els.sourceLockBadge.title = locked ? `This case accepts rubrics only from ${locked.title}. Comparison is read-only.` : "A case becomes source-locked when its first rubric is added.";
    }
  }

  function renderDashboard() {
    if (!els.dashboardRoot) return;
    updateActiveContext();
    if (OR.clinic) { OR.clinic.renderToday(); return; }
    const c = activeCase();
    const patients = OR.patientList ? OR.patientList() : [];
    const patient = c && c.patientId && OR.patientName ? OR.patientName(c.patientId) : "No patient linked";
    const ranking = c && c.analysis.length ? rankCase(c).slice(0, 3) : [];
    const now = new Date();
    const followups = patients.flatMap(p => (p.visits || []).filter(v => v.followup && !(p.visits || []).some(other => other.date > v.date)).map(v => {
      const days = Math.round((new Date(v.followup + "T00:00:00") - new Date(now.toISOString().slice(0, 10) + "T00:00:00")) / 86400000);
      return { patient: p, visit: v, days };
    })).filter(x => !isNaN(x.days) && x.days <= 14).sort((a, b) => a.days - b.days).slice(0, 4);
    const recentPatients = patients.slice().sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).slice(0, 4);
    const snapshot = c && c.snapshots && c.snapshots.length ? c.snapshots[c.snapshots.length - 1] : null;
    const followupLabel = x => x.days < 0 ? `${-x.days}d overdue` : x.days === 0 ? "today" : `in ${x.days}d`;
    els.dashboardRoot.innerHTML = `
      <div class="dashboard-head"><div><div class="eyebrow">CLINICAL WORKSPACE</div><h1>Open Repertory</h1><p>Build a traceable case from symptoms to rubrics, analysis, and reference sources.</p></div><button class="primary-btn" data-dashboard="patients">Open patients</button></div>
      ${!patients.length ? `<section class="onboarding-card" aria-label="Getting started"><div><span class="eyebrow">GET STARTED</span><h2>Start with the patient’s words</h2><p>Keep your records on this device, describe the complaint naturally, then verify the repertory rubrics before analysis.</p></div><div class="onboarding-actions"><button class="primary-btn" data-dashboard="patients">Create patient</button><button class="ghost-btn" data-dashboard="repertory" data-finder="true">Describe symptoms</button></div></section>` : ""}
      <section class="context-card"><div><span class="context-label">ACTIVE CASE</span><h2>${escapeHTML(c ? c.name : "No active case")}</h2><p>${escapeHTML(patient)} · ${c ? c.analysis.length : 0} selected rubric${c && c.analysis.length === 1 ? "" : "s"}</p></div><div class="context-card-actions"><button class="ghost-btn" data-dashboard="analysis">Open analysis</button><button class="ghost-btn" data-dashboard="repertory">Add rubric</button></div></section>
      <div class="dashboard-grid">
        <section class="dashboard-card"><div class="dashboard-card-head"><h3>Quick actions</h3><span class="card-kicker">START HERE</span></div><div class="quick-actions"><button class="quick-action" data-dashboard="patients"><b>+ New patient</b><small>Create a patient record</small></button><button class="quick-action" data-dashboard="repertory" data-finder="true"><b>Describe symptoms</b><small>Patient words → candidate rubrics</small></button><button class="quick-action" data-dashboard="repertory"><b>Browse repertory</b><small>Search and add rubrics</small></button><button class="quick-action" data-dashboard="analysis"><b>Run analysis</b><small>Rank remedies transparently</small></button><button class="quick-action" data-dashboard="mm"><b>Open Materia Medica</b><small>Review source passages</small></button></div></section>
        <section class="dashboard-card"><div class="dashboard-card-head"><h3>Workspace status</h3><span class="status-pill good">OFFLINE READY</span></div><div class="status-list"><div><span>Smart Search</span><b>Local ready</b></div><div><span>Patients</span><b>${patients.length}</b></div><div><span>Cases</span><b>${Object.keys(state.cases).length}</b></div><div><span>Repertory</span><b>${escapeHTML(state.repertory ? state.repertory.year || "loaded" : "loading")}</b></div><div><span>Rubrics in case</span><b>${c ? c.analysis.length : 0}</b></div></div></section>
      </div>
      <div class="dashboard-grid dashboard-grid-secondary">
        <section class="dashboard-card"><div class="dashboard-card-head"><h3>Follow-ups</h3><span class="card-kicker">NEXT 14 DAYS</span></div>${followups.length ? `<div class="dashboard-list">${followups.map(x => `<button class="dashboard-list-row" data-patient="${escapeHTML(x.patient.id)}"><span><b>${escapeHTML(x.patient.name || "Unnamed patient")}</b><small>${escapeHTML(x.visit.rx || "Follow-up visit")} · ${escapeHTML(x.visit.followup)}</small></span><strong class="followup-${x.days < 0 ? "over" : x.days === 0 ? "today" : "soon"}">${followupLabel(x)}</strong></button>`).join("")}</div>` : `<p class="empty-state compact">No follow-ups due in the next 14 days.</p>`}</section>
        <section class="dashboard-card"><div class="dashboard-card-head"><h3>Continue working</h3><span class="card-kicker">CASE HISTORY</span></div>${snapshot ? `<button class="snapshot-card" data-dashboard="analysis"><span class="snapshot-icon">↺</span><span><b>${escapeHTML(c.name)}</b><small>Last snapshot · ${escapeHTML(new Date(snapshot.savedAt).toLocaleDateString())}</small><small>${(snapshot.ranking || []).length} remedies preserved</small></span></button>` : `<p class="empty-state compact">Save a case snapshot after analysis to preserve a reproducible checkpoint.</p>`}</section>
      </div>
      <section class="dashboard-card"><div class="dashboard-card-head"><h3>Recent patients</h3><button class="mini-btn plain" data-dashboard="patients">View all</button></div>${recentPatients.length ? `<div class="dashboard-list recent-patients">${recentPatients.map(p => `<button class="dashboard-list-row" data-patient="${escapeHTML(p.id)}"><span><b>${escapeHTML(p.name || "Unnamed patient")}</b><small>${(Object.values(state.cases).filter(x => x.patientId === p.id).length)} case${Object.values(state.cases).filter(x => x.patientId === p.id).length === 1 ? "" : "s"} · ${p.updatedAt ? "updated " + escapeHTML(new Date(p.updatedAt).toLocaleDateString()) : "no recent update"}</small></span><span class="card-arrow">›</span></button>`).join("")}</div>` : `<p class="empty-state compact">No patient records yet.</p>`}</section>
      <section class="dashboard-card trust-card"><div><div class="dashboard-card-head"><h3>Data trust</h3><span class="status-pill good">TRACEABLE</span></div><p>Repertory source and integrity metadata are bundled offline. Patient records stay on this device; use encrypted backup before changing devices.</p></div><a class="mini-btn plain" href="data/audit_report.json" target="_blank" rel="noopener">View audit</a></section>
      <section class="dashboard-card dashboard-ranking"><div class="dashboard-card-head"><h3>Top remedies in active case</h3><button class="mini-btn plain" data-dashboard="analysis">View full analysis</button></div>${ranking.length ? `<div class="remedy-cards">${ranking.map((r, i) => `<button class="remedy-card" data-remedy="${escapeHTML(r.abbr)}"><span class="remedy-rank">${i + 1}</span><span><b>${escapeHTML(state.remedies[r.abbr] || r.abbr)}</b><small>${escapeHTML(r.abbr)} · ${r.coveragePct}% coverage${c && c.analysis.length && c.analysis.every(it=>itemSource(it,c)==='clarke') ? "" : ` · avg grade ${r.averageGrade.toFixed(2)}`}</small></span></button>`).join("")}</div>` : `<p class="empty-state compact">Add rubrics to the active case to see a transparent remedy ranking here.</p>`}</section>`;
    els.dashboardRoot.querySelectorAll("[data-dashboard]").forEach(btn => btn.addEventListener("click", () => {
      showPage(btn.dataset.dashboard);
      if (btn.dataset.finder === "true" && OR.finder) OR.finder.focus();
    }));
    els.dashboardRoot.querySelectorAll("[data-remedy]").forEach(btn => btn.addEventListener("click", () => OR.openMateriaRemedy && OR.openMateriaRemedy(btn.dataset.remedy)));
    els.dashboardRoot.querySelectorAll("[data-patient]").forEach(btn => btn.addEventListener("click", () => OR.patients && OR.patients.open(btn.dataset.patient)));
  }
  OR.pages.dashboard = { onShow: renderDashboard, onData: renderDashboard };
  OR.hooks.casesChanged.push(renderDashboard);

  // ---------- pages & three-dot menu ----------
  const PAGE_TITLES = {
    dashboard: "Today", repertory: "Repertory", analysis: "Analysis", patients: "Patients",
    file: "Patient file", mm: "Library", diff: "Compare remedies"
  };

  // ---------- theme: auto / light / dark ----------
  const THEMES = ["auto", "light", "dark"];
  function applyTheme(t) {
    [document.documentElement, document.body].forEach(el => {
      if (t === "auto") el.removeAttribute("data-theme"); else el.setAttribute("data-theme", t);
    });
    const lbl = $("menuThemeSub");
    if (lbl) lbl.textContent = "Theme: " + t + " (tap to change)";
  }
  OR.hooks.start.push(() => {
    const t = (store.get("openrepertory_theme") || {}).t;
    applyTheme(THEMES.indexOf(t) >= 0 ? t : "auto");
  });

  function updateMenuBadges() {
    const c = activeCase();
    $("miAnalysisSub").textContent = c ? `Case: ${c.name}` : "Repertorisation of the active case";
    if (OR.patients) OR.patients.refreshMenu();
    updateActiveContext();
  }
  OR.updateMenuBadges = updateMenuBadges;

  // Screenshots are allowed for source/search/analysis study views, but not for
  // patient records or any page that can expose a patient-linked case context.
  OR.updateScreenshotPolicy = function () {
    const c = activeCase();
    const patientLinked = !!(c && c.patientId);
    const sensitive = state.page === "dashboard" || state.page === "patients" || state.page === "file" || patientLinked;
    if (window.openrepertoryNative && typeof window.openrepertoryNative.setSensitiveScreen === "function") {
      try { window.openrepertoryNative.setSensitiveScreen(sensitive); } catch (_) { /* browser build */ }
    }
  };

  function showPage(page) {
    if (OR.clinic) OR.clinic.beforePage();
    if (!PAGE_TITLES[page]) page = "repertory";
    state.page = page;
    document.getElementById("toolbar").dataset.page=page;
    els.pages.forEach(p => p.classList.toggle("active", p.id === "page-" + page));
    const primaryPage = page === "diff" ? "mm" : page === "file" ? "patients" : page;
    document.querySelectorAll("[data-bottom-page]").forEach(b=>{if(b.dataset.bottomPage===primaryPage)b.setAttribute("aria-current","page");else b.removeAttribute("aria-current");});
    els.menuPanel.querySelectorAll("[data-page]").forEach(b => {
      const active = b.dataset.page === (b.closest('.menu-destinations') ? primaryPage : page);
      b.classList.toggle("active", active);
      if (active) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    els.pageTitle.textContent = PAGE_TITLES[page];
    if (els.bottomNav) els.bottomNav.querySelectorAll("[data-bottom-page]").forEach(b => b.classList.toggle("active", b.dataset.bottomPage === primaryPage));
    const isRep = page === "repertory";
    els.searchWrap.style.display = isRep ? "flex" : "none";
    els.sidebarToggle.style.display = isRep ? "" : "none";
    $("aiBar").style.display = isRep ? "" : "none";
    if (isRep) els.sidebar.classList.remove("collapsed");
    OR.updateScreenshotPolicy();
    closeMenu();
    const pg = OR.pages[page];
    if (pg && pg.onShow) pg.onShow();
    window.scrollTo(0, 0);
    if (OR.clinic) OR.clinic.onPage(page);
    updateAnalysisShortcut();
  }
  OR.showPage = showPage;

  let menuSettingsOpen = false;
  const menuBackground = new Map();
  function menuFocusables() {
    return [...els.menuPanel.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled])')].filter(el => el.getClientRects().length);
  }
  function positionMenu() {
    if (els.menuPanel.hidden) return;
    const viewport = window.visualViewport;
    const offset = viewport ? viewport.offsetTop : 0;
    const bottom = offset + (viewport ? viewport.height : window.innerHeight);
    const navHeight = window.matchMedia("(max-width: 699px)").matches && els.bottomNav && els.bottomNav.getClientRects().length ? els.bottomNav.getBoundingClientRect().height : 0;
    const top = Math.max(offset + 8, Math.min(els.menuBtn.getBoundingClientRect().bottom + 8, bottom - navHeight - 192));
    els.menuPanel.style.top = top + "px";
    els.menuPanel.style.maxHeight = Math.max(100, bottom - top - navHeight - 12) + "px";
    if (!menuFocusables().includes(document.activeElement)) $("menuClose").focus();
  }
  function menuView(settings, focus = true) {
    const previous = menuSettingsOpen;
    menuSettingsOpen = settings;
    $("menuHome").hidden = !!settings;
    $("menuSettings").hidden = settings !== true;
    if ($("menuReadingPanel")) $("menuReadingPanel").hidden = settings !== "reading";
    $("menuBack").hidden = !settings;
    $("menuTitle").textContent = settings === "reading" ? "Repertory & reading" : settings ? "Settings" : "Tools & settings";
    $("menuSettingsButton").setAttribute("aria-expanded", String(settings === true));
    if ($("menuReadingButton")) $("menuReadingButton").setAttribute("aria-expanded", String(settings === "reading"));
    els.menuPanel.querySelector('.menu-content').scrollTop = 0;
    if (focus) (settings === "reading" ? $("textSizeSmaller") : settings ? $("menuTheme") : previous === "reading" ? $("menuReadingButton") : $("menuSettingsButton")).focus();
  }
  function openMenu() {
    menuView(false, false);
    els.menuPanel.hidden = false;
    els.menuBackdrop.hidden = false;
    els.menuBtn.setAttribute("aria-expanded", "true");
    updateMenuBadges();
    positionMenu();
    $("menuFinder").focus();
    [...document.body.children].filter(el => !['menuPanel','menuBackdrop','appToast','persistentError'].includes(el.id) && !['SCRIPT','STYLE'].includes(el.tagName)).forEach(el => {
      menuBackground.set(el, { hidden: el.getAttribute('aria-hidden'), inert: el.inert });
      el.setAttribute('aria-hidden', 'true');
      if ('inert' in el) el.inert = true;
    });
  }
  function closeMenu() {
    const wasOpen = !els.menuPanel.hidden;
    els.menuPanel.hidden = true;
    els.menuBackdrop.hidden = true;
    els.menuBtn.setAttribute("aria-expanded", "false");
    for (const [el, old] of menuBackground) {
      if (old.hidden === null) el.removeAttribute('aria-hidden'); else el.setAttribute('aria-hidden', old.hidden);
      if ('inert' in el) el.inert = !!old.inert;
    }
    menuBackground.clear();
    if (wasOpen) els.menuBtn.focus();
    updateAnalysisShortcut();
  }
  OR.dismissMenu = () => {
    if (els.menuPanel.hidden) return false;
    if (menuSettingsOpen) menuView(false); else closeMenu();
    return true;
  };
  OR.openReadingMenu = () => { if (els.menuPanel.hidden) openMenu(); menuView("reading"); };
  els.menuBtn.addEventListener("click", () => { els.menuPanel.hidden ? openMenu() : closeMenu(); });
  $("menuClose").addEventListener("click", closeMenu);
  $("menuBack").addEventListener("click", () => menuView(false));
  $("menuSettingsButton").addEventListener("click", () => menuView(true));
  els.menuBackdrop.addEventListener("click", closeMenu);
  document.addEventListener("keydown", e => {
    if (els.menuPanel.hidden) return;
    if (e.key === "Escape") { e.preventDefault(); OR.dismissMenu(); return; }
    if (e.key !== "Tab") return;
    const buttons = menuFocusables(), first = buttons[0], last = buttons[buttons.length - 1];
    if (e.shiftKey && (document.activeElement === first || !els.menuPanel.contains(document.activeElement))) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && (document.activeElement === last || !els.menuPanel.contains(document.activeElement))) { e.preventDefault(); first.focus(); }
  });
  window.addEventListener('resize', positionMenu);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', positionMenu);
  els.menuPanel.querySelectorAll("[data-page]").forEach(b =>
    b.addEventListener("click", () => showPage(b.dataset.page)));
  if (els.bottomNav) els.bottomNav.querySelectorAll("[data-bottom-page]").forEach(b =>
    b.addEventListener("click", () => showPage(b.dataset.bottomPage)));
  $("menuAccount").addEventListener("click",()=>{closeMenu();if(window.openrepertoryNative && openrepertoryNative.openAccount)openrepertoryNative.openAccount();else OR.toast("Account access is managed in the Android app.");});
  $("menuUpdates").addEventListener("click",()=>{closeMenu();if(window.openrepertoryNative && openrepertoryNative.openUpdates)openrepertoryNative.openUpdates();else OR.toast("App updates are available in the Android app.");});
  $("menuTheme").addEventListener("click", () => {
    const cur = (store.get("openrepertory_theme") || {}).t || "auto";
    const next = THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length];
    store.set("openrepertory_theme", { t: next });
    applyTheme(next);
  });
  $("menuOnlineAi").addEventListener("click", () => { closeMenu(); if (OR.openOnlineAi) OR.openOnlineAi(); });
  $("menuFinder").addEventListener("click", () => {
    showPage("repertory");
    if (OR.finder) OR.finder.focus();
  });
  $("menuBackup").addEventListener("click", () => { closeMenu(); if (OR.patients) OR.patients.openBackup(); });

  OR.renderAnalysis = renderAnalysis;
  OR.setActiveCase = id => {
    if (!state.cases[id]) return;
    state.activeCaseId = id;
    saveCases(); renderCaseSelect(); renderAnalysis(); refreshAddButtons();
  };
  OR.renderRubric = renderRubric;
  OR.searchInChapter = searchInChapter;
  OR.runSearch = runSearch;
  OR.selectChapter = selectChapter;
  OR.refreshAddButtons = refreshAddButtons;
  OR.highlight = highlightText;
  OR.start = init;
})();
