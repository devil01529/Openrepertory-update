import os
"""Clinical consultation workflows and adaptive layouts in the real web app."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/os.environ.get('OR_TEST_RESULTS','test-results/v1.22');O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,label):
    assert v,label
    checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def ready(page,url='http://127.0.0.1:8765'):
    page.goto(url);page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000)
def search(page,query):
    page.evaluate('(q)=>{OR.showPage("repertory");document.querySelector("#searchBox").value=q;OR.runSearch(q)}',query)
    page.wait_for_function('()=>document.querySelector("#rubricList").getAttribute("aria-busy")==="false"&&OR.lastSearchStats',timeout=60000)
def bounds(page,selector):return page.locator(selector).bounding_box()
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
        page=browser.new_page(viewport={'width':width,'height':height});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));ready(page)
        check(page.evaluate('OR.state.repertoryId')=='kent1897',f'{width}px: new installations start with the actual English Kent source')
        context=bounds(page,'#activeContext');header=bounds(page,'#toolbar');main=bounds(page,'#main')
        check(context['y']>=header['y']+header['height']-1 and abs(context['y']+context['height']-main['y'])<2 and context['width']>=width-(88 if width>=700 else 0)-1,f'{width}px: full-width patient/case context directly precedes the clinical workspace')
        check(page.locator('#bottomNav').evaluate('e=>getComputedStyle(e).position')=='fixed',f'{width}px: phone navigation and tablet rail reserve no extra block in the reading flow')
        check(page.locator('.resume-consultation').is_visible() and not page.locator('.dashboard-head').count(),f'{width}px: Today prioritises the active consultation over the old introductory hero')
        search(page,'fear death');page.locator('#searchBox').focus();page.locator('#rubricList .add-btn:not([disabled])').first.dispatch_event('click');fab=page.locator('#analysisShortcut')
        check(fab.is_visible() and fab.locator('svg').count()==1 and fab.locator('span:visible,b:visible').count()==0,f'{width}px: floating shortcut renders only the clipboard icon')
        f=bounds(page,'#analysisShortcut');nav=bounds(page,'#bottomNav')
        check(f['height']>=48 and 0<=f['x'] and f['x']+f['width']<=width and f['y']>=0 and f['y']+f['height']<=height and (width>=700 or f['y']+f['height']<=nav['y']-8),f'{width}px: icon fits its touch target above phone navigation or beside the tablet rail')
        if width==393:check(bounds(page,'#content')['height']>=height*.60,'phone reading workspace occupies at least 60% of the screen with finder collapsed')
        check(page.locator('#aiBar').is_hidden(),f'{width}px: patient-word finder is collapsed by default')
        before=page.evaluate('JSON.stringify(OR.activeCase())');ranking=page.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))');fab.click()
        check(page.evaluate('OR.state.page')=='analysis' and page.locator('.analysis-remedy-card').count()>0,f'{width}px: clipboard opens the full current-case ranking')
        page.locator('#analysisTabs [data-view=matrix]').click();check(page.locator('.grid-scroll').is_visible(),f'{width}px: matrix is a separate readable analysis view')
        if width<700:page.locator('#analysisTabs [data-view=rubrics]').click()
        check(page.locator('#selectedList .selected-item').first.is_visible(),f'{width}px: selected rubrics and importance controls remain reachable')
        check(page.evaluate('JSON.stringify(OR.activeCase())')==before and page.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')==ranking,f'{width}px: changing views does not change selected data or scoring')
        page.evaluate('OR.clinic.back()');check(page.evaluate('OR.state.page')=='repertory',f'{width}px: workspace Back returns from analysis to repertory')
        page.locator('#rubricList .rubric-source-button').first.click();check('Kent' in page.locator('.modal').inner_text() and 'Source IDs:' in page.locator('.modal').inner_text(),f'{width}px: rubric source details retain source identity and IDs');page.locator('.modal-x').click()
        page.locator('#readingPreferences').click();page.locator('#readingDensity').select_option('compact');page.locator('#readingRemedies').select_option('all');page.get_by_role('button',name='Apply',exact=True).click();check(page.locator('body').get_attribute('data-density')=='compact' and page.locator('body').evaluate('e=>e.classList.contains("show-all-remedies")'),f'{width}px: reading preferences control density and complete remedy lines')
        page.locator('#menuBtn').click();check(page.locator('#menuPanel').is_visible() and fab.is_hidden(),f'{width}px: grouped tools menu remains usable above the new workspace');page.locator('#menuClose').click()
        check(not errors,f'{width}px: no uncaught errors in the clinical navigation flow');page.screenshot(path=str(O/f'clinical-repertory-{width}.png'));page.close()
    page=browser.new_page(viewport={'width':393,'height':800});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));ready(page)
    search(page,'memory weakness labor');reference=page.locator('.rubric-reference-links button').filter(has_text='stupefaction').first;reference.click()
    check(page.locator('.location-highlight').count()>0,'cross-reference opens the exact source target rather than merging rubrics into analysis')
    page.locator('#referenceReturn').click();page.wait_for_function('()=>OR.state.query==="memory weakness labor"&&document.querySelector("#rubricList").getAttribute("aria-busy")==="false"');check(page.locator('.rubric-reference-links').count()>0,'Previous rubric restores the originating search')
    search(page,'Aluminium Oxydatum');check(page.locator('#rubricList .rem[data-abbr="Alum."]').count()>0,'source-recorded alternate remedy name finds canonical remedy rubrics')
    page.evaluate('OR.openMateriaRemedy("Alum.")');page.wait_for_function('()=>document.querySelector("#mmDetail").textContent.includes("Aluminium Oxydatum")');check(page.locator('.mm-source-aliases').is_visible(),'Materia Medica identifies source-recorded alternate remedy names separately')
    page.locator('.mm-personal-notes summary').click();page.locator('#mmPersonalNotes').fill('Synthetic private remedy note');check(page.evaluate('OR.mmNotes["Alum."]')=='Synthetic private remedy note','private remedy notes save through the existing encrypted-backup-compatible store')
    page.locator('#mmBack').click();check(not page.locator('#mmWrap').evaluate('e=>e.classList.contains("detail-open")'),'focused library reader returns to the remedy list')
    # Different duplicate-source paths must keep their grades and not double-count.
    search(page,'clenching fingers');variants=page.locator('.rubric-text').filter(has_text='OOREP row').locator('xpath=../..')
    check(variants.count()==2,'both conflicting source versions of the fingers rubric remain visible')
    variants.nth(0).locator('.add-btn').click();variants.nth(1).locator('.add-btn').click();check(page.evaluate('OR.activeCase().analysis.length')==1,'one case cannot double-count the two conflicting versions of one source path')
    # A real patient/visit workflow, using the existing encryption/storage path.
    page.evaluate('OR.showPage("patients")');page.locator('#patientNew').click();page.locator('[data-k=name]').fill('Synthetic UI patient');page.get_by_role('button',name='Create patient',exact=True).click();page.locator('#patientTabs').wait_for()
    check(page.locator('#fileOverview').is_visible() and page.locator('#fileNotes').is_hidden(),'patient file opens with a focused Overview section')
    page.locator('#patientTabs [data-view=notes]').click();page.locator('[data-f=chief]').fill('Synthetic chief complaint for UI test');page.locator('[data-f=mind]').fill('Synthetic mental notes')
    check(page.evaluate('OR.patients.current().chief')=='Synthetic chief complaint for UI test','Notes tab saves existing patient fields without changing their storage schema')
    page.locator('#patientTabs [data-view=visits]').click();page.locator('[data-act=addvisit]').click();page.locator('[data-k=complaint]').fill('Synthetic follow-up');page.get_by_role('button',name='Save visit',exact=True).click();check(page.evaluate('OR.patients.current().visits.length')==1,'Visits tab retains the existing visit creation and draft workflow')
    page.locator('#patientTabs [data-view=cases]').click();check(page.locator('#fileCases').is_visible(),'Cases tab exposes existing linked and unlinked case workflows')
    page.reload();page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)');page.evaluate('OR.patients.open(OR.patientList()[0].id);OR.clinic.patientView("notes")');check(page.locator('[data-f=chief]').input_value()=='Synthetic chief complaint for UI test','patient fields survive reload and the new file navigation')
    page.set_viewport_size({'width':1280,'height':900});check(page.locator('#patientRail').is_visible() and page.locator('#fileCases').is_visible(),'tablet patient workspace shows a patient list and cases alongside Notes')
    page.screenshot(path=str(O/'clinical-patient-tablet.png'));page.set_viewport_size({'width':393,'height':800});page.evaluate('OR.showPage("analysis");OR.clinic.setAnalysisView("ranking")')
    check('Synthetic UI patient' not in page.locator('#activeContext').inner_text(),'leaving an unrelated patient file restores the actual active-case identity')
    page.screenshot(path=str(O/'clinical-analysis-phone.png'))
    page.evaluate('OR.showPage("repertory")');page.locator('#readingPreferences').click();page.locator('#presentationMode').check();page.get_by_role('button',name='Apply',exact=True).click()
    check('Synthetic UI patient' not in page.locator('#activeContext').inner_text(),'presentation mode removes patient and case identity from the shared context')
    page.evaluate('OR.showPage("patients")');check(page.locator('#presentationShield').is_visible() and page.locator('#patientList').is_hidden(),'presentation mode hides the patient workspace rather than exposing record cards')
    page.locator('#exitPresentation').click();check(page.locator('#patientList').is_visible() and page.evaluate('OR.patientList()[0].chief')=='Synthetic chief complaint for UI test','leaving presentation mode restores existing records without altering them')
    # Compare all four analysis methods to the actual published 1.21 app.
    old=browser.new_page();ready(old,'http://127.0.0.1:8766')
    fixture="""()=>{const c=OR.activeCase();c.repertoryId='kent';c.analysis=[{uid:'fixture-a',chapter:'Mind',text:'Synthetic A',w:2,remedies:[{r:'Acon.',g:3},{r:'Bell.',g:1}]},{uid:'fixture-b',chapter:'Head',text:'Synthetic B',w:1,remedies:[{r:'Acon.',g:1},{r:'Bell.',g:2},{r:'Puls.',g:2}]}];} """
    for current in [old,page]:current.evaluate(fixture)
    for method in ['coverage','grade','weighted','classical']:
        for include in [True,False]:
            values=[]
            for current in [old,page]:values.append(current.evaluate('(x)=>{OR.state.scoreMethod=x[0];OR.state.includeGrade1=x[1];return OR.rankCase(OR.activeCase())}',[method,include]))
            check(values[0]==values[1],f'{method}, grade 1={include}: analysis matches the published 1.21 scoring engine')
    old.close()
    page.evaluate('OR.showPage("repertory")');page.add_style_tag(content='html{font-size:32px!important}')
    check(page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'200% text does not create whole-screen horizontal overflow')
    page.locator('#menuBtn').click();check(page.locator('#menuClose').is_visible(),'200% text keeps the tools menu close control reachable');page.locator('#menuClose').click();page.screenshot(path=str(O/'clinical-large-text.png'))
    check(not errors,'source links, alternate names, visits and analysis flows have no uncaught errors');page.close();browser.close()
(O/'clinical-ui-web-tests.json').write_text(json.dumps(checks,indent=2));print('Clinical UI checks passed:',len(checks))
