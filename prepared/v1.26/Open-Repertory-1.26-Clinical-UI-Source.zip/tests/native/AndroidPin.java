package com.openrepertory.tests;
import android.app.*;import android.os.*;import android.view.accessibility.*;import android.accessibilityservice.*;import java.io.*;
/** Isolated emulator UI utility; never part of the production APK. */
final class AndroidPin {
 static AccessibilityNodeInfo node(Instrumentation test,String id){
  android.app.UiAutomation ui=test.getUiAutomation();AccessibilityNodeInfo root=ui.getRootInActiveWindow();
  if(root!=null){java.util.List<AccessibilityNodeInfo> nodes=root.findAccessibilityNodeInfosByViewId("com.android.systemui:id/"+id);if(!nodes.isEmpty())return nodes.get(0);}
  for(AccessibilityWindowInfo window:ui.getWindows()){root=window.getRoot();if(root!=null){java.util.List<AccessibilityNodeInfo> nodes=root.findAccessibilityNodeInfosByViewId("com.android.systemui:id/"+id);if(!nodes.isEmpty())return nodes.get(0);}}return null;
 }
 static void shell(Instrumentation test,String command)throws Exception{try(InputStream in=new ParcelFileDescriptor.AutoCloseInputStream(test.getUiAutomation().executeShellCommand(command))){while(in.read()!=-1){}}}
 static void unlock(Instrumentation test,KeyguardManager keyguard)throws Exception{
  AccessibilityServiceInfo info=test.getUiAutomation().getServiceInfo();info.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS|AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;test.getUiAutomation().setServiceInfo(info);
  shell(test,"input keyevent 224");long end=SystemClock.elapsedRealtime()+60000,lastSwipe=0;AccessibilityNodeInfo pin=null;
  while(SystemClock.elapsedRealtime()<end){
   pin=node(test,"pinEntry");if(pin!=null&&pin.isVisibleToUser()&&node(test,"key1")!=null)break;
   if(SystemClock.elapsedRealtime()-lastSwipe>2000){lastSwipe=SystemClock.elapsedRealtime();shell(test,"input touchscreen swipe 240 740 240 200 500");}
   Thread.sleep(250);
  }
  if(pin==null||!pin.isVisibleToUser())throw new Exception("Android PIN controls did not become visible");
  shell(test,"input keyevent 67 67 67 67 67 67 67 67");
  for(String key:new String[]{"key1","key2","key3","key4","key_enter"}){
   AccessibilityNodeInfo button=node(test,key);if(button==null)throw new Exception("Missing Android PIN key: "+key);
   if(!button.performAction(AccessibilityNodeInfo.ACTION_CLICK)){android.graphics.Rect bounds=new android.graphics.Rect();button.getBoundsInScreen(bounds);shell(test,"input tap "+bounds.centerX()+" "+bounds.centerY());}Thread.sleep(200);
  }
  end=SystemClock.elapsedRealtime()+30000;while(keyguard.isDeviceLocked()&&SystemClock.elapsedRealtime()<end)Thread.sleep(200);
  if(keyguard.isDeviceLocked())throw new Exception("Android PIN entry did not unlock the test device");
 }
}
