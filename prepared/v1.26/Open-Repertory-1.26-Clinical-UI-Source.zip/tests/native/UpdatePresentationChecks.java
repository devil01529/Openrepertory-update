package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.view.*;import android.webkit.*;import android.widget.*;import android.view.accessibility.AccessibilityNodeInfo;import com.openrepertory.app.*;import org.json.*;import java.lang.reflect.*;import java.io.*;
/** Emulator-only long release-note fixture tests layout; no update is downloaded. */
public final class UpdatePresentationChecks extends StartupChecks {
 Object uf(AppUpdates u,String name)throws Exception{Field f=AppUpdates.class.getDeclaredField(name);f.setAccessible(true);return f.get(u);}
 void set(AppUpdates u,String name,Object value)throws Exception{Field f=AppUpdates.class.getDeclaredField(name);f.setAccessible(true);f.set(u,value);}
 boolean contains(AccessibilityNodeInfo node,String text){if(node==null)return false;if(node.getText()!=null&&node.getText().toString().contains(text))return true;for(int i=0;i<node.getChildCount();i++)if(contains(node.getChild(i),text))return true;return false;}
 TextView findText(View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().contains(text))return (TextView)view;if(view instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)view;for(int i=0;i<g.getChildCount();i++){TextView found=findText(g.getChildAt(i),text);if(found!=null)return found;}}return null;}
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
  activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
  ApperAccess access=(ApperAccess)field("access");getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
  ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field bf=ApperAccessScreen.class.getDeclaredField("browser");bf.setAccessible(true);WebView browser=(WebView)bf.get(screen);runOnMainSync(()->{screen.cancel();browser.stopLoading();});receive(receipt(access.deviceId()));ready();
  AppUpdates u=(AppUpdates)field("updates");StringBuilder notes=new StringBuilder();for(int i=0;i<80;i++)notes.append("LONG_RELEASE_NOTES_MARKER — Detailed release notes belong in the separate notes reader.\n");
  JSONObject data=new JSONObject().put("versionCode",999).put("versionName","1.25-test").put("minSdk",23).put("size",26831340).put("apkUrl","https://github.com/devil01529/Openrepertory-update/releases/download/v1.25/test.apk").put("sha256",new String(new char[64]).replace('\0','a')).put("notes",notes.toString());
  Constructor<AppUpdates.Release> ctor=AppUpdates.Release.class.getDeclaredConstructor(JSONObject.class,String.class);ctor.setAccessible(true);set(u,"release",ctor.newInstance(data,""));set(u,"working",false);
  js("window.__updateLayoutSentinel='retained'");runOnMainSync(u::show);Thread.sleep(500);
  TextView text=(TextView)uf(u,"text");Button download=(Button)uf(u,"downloadButton"),notesButton=(Button)uf(u,"notesButton");
  check(!text.getText().toString().contains("LONG_RELEASE_NOTES_MARKER"),"long release notes cannot expand the main update card");
  check(text.getText().toString().contains("Installed: 1.24-dev")&&text.getText().toString().contains("Available: 1.25-test"),"update summary shows installed and available versions clearly");
  android.graphics.Rect rect=new android.graphics.Rect();boolean[] visible=new boolean[1];runOnMainSync(()->visible[0]=download.getGlobalVisibleRect(rect)&&rect.height()>=download.getHeight()-2&&download.getHeight()>0);
  check(visible[0],"download action remains visible with a long release-note payload");
  check(notesButton.getVisibility()==View.VISIBLE,"release notes have a separate optional action");
  File output=new File(getTargetContext().getExternalCacheDir(),"update-summary-124.png");try(FileOutputStream stream=new FileOutputStream(output)){getUiAutomation().takeScreenshot().compress(android.graphics.Bitmap.CompressFormat.PNG,100,stream);}
  runOnMainSync(notesButton::performClick);Thread.sleep(800);
  AlertDialog noteReader=(AlertDialog)uf(u,"notesDialog");boolean[] rendered=new boolean[1];runOnMainSync(()->{TextView body=findText(noteReader.getWindow().getDecorView(),"LONG_RELEASE_NOTES_MARKER");rendered[0]=noteReader.isShowing()&&body!=null&&body.isShown();});
  check(rendered[0],"full release notes remain readable in the separate scrollable reader");
  runOnMainSync(()->noteReader.getButton(AlertDialog.BUTTON_POSITIVE).performClick());waitForIdleSync();
  check(!noteReader.isShowing()&&((AlertDialog)uf(u,"dialog")).isShowing(),"release notes close back to the download controls");
  check("retained".equals(js("window.__updateLayoutSentinel")),"opening notes retains the clinical document");
  runOnMainSync(notesButton::performClick);AlertDialog reopened=(AlertDialog)uf(u,"notesDialog");runOnMainSync(u::pause);
  check(!reopened.isShowing(),"backgrounding closes the optional notes reader with the main updater");
  check(Boolean.TRUE.equals(js("!!OR.state.repertory")),"closing updates retains the loaded clinical workspace");
  result.putString("stream","Update presentation native checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","FAILED after "+passed+" update presentation checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
