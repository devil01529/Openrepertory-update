package com.openrepertory.tests;
import android.app.*;import android.os.*;import android.content.*;
public final class PinUiProbe extends Instrumentation {
 public void onCreate(Bundle args){super.onCreate(args);start();}
 public void onStart(){Bundle result=new Bundle();try{if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");AndroidPin.unlock(this,(KeyguardManager)getTargetContext().getSystemService(Context.KEYGUARD_SERVICE));result.putString("stream","Normal Android PIN UI utility succeeded\n");finish(Activity.RESULT_OK,result);}catch(Throwable e){result.putString("stream","PIN UI utility failed: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
