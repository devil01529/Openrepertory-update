package com.openrepertory.tests;
import android.app.*;import android.os.*;import android.content.*;import android.database.*;import android.database.sqlite.*;import com.openrepertory.app.*;import org.json.*;import java.io.*;import java.security.*;import java.util.*;
/** Emulator-only real APK replacement preserves encrypted data and installation identity. */
public final class UpgradeChecks extends Instrumentation {
 Bundle args;public void onCreate(Bundle a){args=a;super.onCreate(a);start();}
 public void onStart(){Bundle result=new Bundle();RecordStore store=null;try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
  Context c=getTargetContext();store=new RecordStore(c);String stage=args.getString("stage");SharedPreferences p=c.getSharedPreferences("updater-upgrade-fixture",0);
  if("prepare".equals(stage)){
   JSONObject patient=new JSONObject().put("id","upgrade_patient").put("name","SYNTHETIC_UPGRADE_PATIENT").put("chief","Synthetic retained clinical notes").put("visits",new JSONArray());
   JSONArray remedies=new JSONArray().put(new JSONObject().put("r","Nat-m.").put("g",1)).put(new JSONObject().put("r","Tarent.").put("g",2));
   JSONObject rubric=new JSONObject().put("uid","Mind||ABRUPT").put("chapter","Mind").put("text","ABRUPT").put("remedies",remedies).put("w",1).put("sourceId","kent");
   JSONObject clinicalCase=new JSONObject().put("id","upgrade_case").put("name","SYNTHETIC_LEGACY_PUBLICUM").put("patientId","upgrade_patient").put("repertoryId","kent").put("analysis",new JSONArray().put(rubric));
   store.write(new JSONObject().put("openrepertory_update_fixture",new JSONObject().put("marker","SYNTHETIC_UPGRADE_119").put("note","Encrypted records must survive").toString())
    .put("openrepertory_cases",new JSONObject().put("cases",new JSONObject().put("upgrade_case",clinicalCase)).put("activeCaseId","upgrade_case").toString())
    .put("openrepertory_patients",new JSONObject().put("patients",new JSONObject().put("upgrade_patient",patient)).put("activeId","upgrade_patient").toString()));
  }
  JSONObject snapshot=new JSONObject();List<String> names=new ArrayList<>();try(SQLiteDatabase db=SQLiteDatabase.openDatabase(new File(c.getFilesDir(),"records-v2.db").getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);Cursor rows=db.rawQuery("SELECT name,cipher FROM records ORDER BY name",null)){while(rows.moveToNext()){names.add(rows.getString(0));snapshot.put(rows.getString(0),Base64String(rows.getBlob(1)));}}
  if(!store.read("openrepertory_update_fixture").contains("SYNTHETIC_UPGRADE_119"))throw new Exception("Sentinel could not be decrypted");
  if(!store.read("openrepertory_cases").contains("SYNTHETIC_LEGACY_PUBLICUM")||!store.read("openrepertory_patients").contains("Synthetic retained clinical notes"))throw new Exception("Clinical upgrade fixture could not be decrypted");
  String hash=Base64String(MessageDigest.getInstance("SHA-256").digest(snapshot.toString().getBytes("UTF-8"))),device=new ApperAccess(c).deviceId();
  if("prepare".equals(stage)){p.edit().putString("hash",hash).putString("device",device).commit();result.putString("stream","Upgrade fixture prepared: "+names.size()+" encrypted records\n");}
  else{if(!hash.equals(p.getString("hash",""))||!device.equals(p.getString("device","")))throw new Exception("Upgrade changed data or installation fingerprint");result.putString("stream","Upgrade retention checks passed: "+names.size()+" encrypted records and device identity unchanged\n");}
  finish(Activity.RESULT_OK,result);
 }catch(Throwable e){result.putString("stream","FAILED upgrade fixture: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}finally{if(store!=null)store.close();}}
 String Base64String(byte[] b){return android.util.Base64.encodeToString(b,android.util.Base64.NO_WRAP);}
}
