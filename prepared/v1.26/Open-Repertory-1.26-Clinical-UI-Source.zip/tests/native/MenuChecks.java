package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.view.View;import android.webkit.*;import com.openrepertory.app.*;import java.lang.reflect.*;import org.json.*;
/** Isolated emulator-only receipt fixtures exercise actual APK WebView and Android Back. */
public final class MenuChecks extends StartupChecks {
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
        activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
        ApperAccess access=(ApperAccess)field("access");
        getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
        JSONObject owner=receipt(access.deviceId());
        ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView original=(WebView)af.get(screen);
        WebView[] created=new WebView[1];runOnMainSync(()->created[0]=new FixtureAuthView(activity));WebView browser=created[0];
        runOnMainSync(()->{original.stopLoading();screen.removeView(original);original.destroy();browser.getSettings().setJavaScriptEnabled(true);browser.getSettings().setDomStorageEnabled(true);browser.getSettings().setUserAgentString("Mozilla/5.0 Chrome/120.0.0.0");screen.addView(browser,new android.widget.LinearLayout.LayoutParams(-1,0,1));browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){screen.check();}});});af.set(screen,browser);
        String page="<html><body><a href='/' onclick='window.managerClicks++;return false'>Device requests</a><button onclick='window.refreshes++'>Refresh requests</button><h1>Owner approvals fixture</h1><script>window.managerClicks=0;window.refreshes=0;window.calls=0;window.base="+owner.toString()+";window.ORApperNative={result:null,check:function(a){window.calls++;this.result=JSON.parse(JSON.stringify(window.base));this.result.nonce=a.nonce;}};</script></body></html>";
        runOnMainSync(()->{screen.cancel();browser.loadDataWithBaseURL(ApperAccess.ORIGIN+"/device",page,"text/html","UTF-8",null);});
        ready();
        js("window.__menuFixtureReady=false;(OR.state.cases.upgrade_case?OR.openCase('upgrade_case'):OR.setRepertory('kent')).then(()=>{OR.showPage('dashboard');window.__menuFixtureReady=true});true");
        waitJS("window.__menuFixtureReady&&OR.state.repertoryId==='kent'&&OR.state.page==='dashboard'",180);

        check(Boolean.TRUE.equals(js("OR.state.page==='dashboard'")),"clinical workspace opens after the existing approval gate");
        check(Boolean.TRUE.equals(js("(()=>{const e=document.getElementById('dashboardRoot');return e.clientHeight<e.scrollHeight&&e.getBoundingClientRect().bottom<=innerHeight})()")),"Today has a bounded scroller on WebView 66");
        org.json.JSONObject bounds=(org.json.JSONObject)js("(()=>{const r=document.getElementById('dashboardRoot').getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height*.85,end:r.top+r.height*.15,width:innerWidth}})()");
        float scale=web.getWidth()/(float)bounds.getDouble("width");int[] location=new int[2];runOnMainSync(()->web.getLocationOnScreen(location));
        float x=location[0]+(float)bounds.getDouble("x")*scale,y=location[1]+(float)bounds.getDouble("y")*scale,target=location[1]+(float)bounds.getDouble("end")*scale;
        long down=SystemClock.uptimeMillis();android.view.MotionEvent event=android.view.MotionEvent.obtain(down,down,android.view.MotionEvent.ACTION_DOWN,x,y,0);sendPointerSync(event);event.recycle();
        for(int i=1;i<=12;i++){Thread.sleep(25);event=android.view.MotionEvent.obtain(down,SystemClock.uptimeMillis(),android.view.MotionEvent.ACTION_MOVE,x,y+(target-y)*i/12,0);sendPointerSync(event);event.recycle();}
        event=android.view.MotionEvent.obtain(down,SystemClock.uptimeMillis(),android.view.MotionEvent.ACTION_UP,x,target,0);sendPointerSync(event);event.recycle();Thread.sleep(600);
        check(Boolean.TRUE.equals(js("document.getElementById('dashboardRoot').scrollTop>0")),"a real Android swipe scrolls Today");
        js("document.getElementById('dashboardRoot').scrollTop=100000");
        check(Boolean.TRUE.equals(js("(()=>{const e=document.querySelector('[data-today=sources]').getBoundingClientRect(),r=document.getElementById('dashboardRoot').getBoundingClientRect();return e.bottom<=r.bottom+1&&e.top>=r.top})()")),"the last Today action is reachable above Android navigation");
        js("OR.showPage('repertory');document.getElementById('repLibrary').click()");
        check(Boolean.TRUE.equals(js("document.querySelectorAll('.book-choice').length===7&&getComputedStyle(document.getElementById('repSelect')).display==='none'")),"chapter book switch uses the app picker instead of the Android select");
        js("document.querySelector('.modal-x').click();document.getElementById('chapterFilter').value='mind';document.getElementById('chapterFilter').dispatchEvent(new Event('input'))");
        check(Boolean.TRUE.equals(js("document.querySelectorAll('#chapterTree li[data-chapter-id]:not([hidden])').length===1&&!!document.querySelector('#chapterTree img')")),"illustrated chapter filter works in the packaged WebView");
        js("document.getElementById('chapterFilterClear').click();document.querySelector('#chapterTree .chapter-choice').click();window.__chapter=OR.state.activeChapter;document.getElementById('sidebarToggle').click();document.querySelector('#chapterTree .chapter-choice').click()");
        check(Boolean.TRUE.equals(js("OR.state.activeChapter===window.__chapter&&document.getElementById('sidebar').classList.contains('collapsed')")),"current chapter reselection keeps the chapter and closes the panel on Android");
        js("document.getElementById('toggleBranches').click();OR.selectChapter(OR.state.activeChapter)");
        check(Boolean.TRUE.equals(js("!document.querySelector('#rubricList .sub-list .rubric')")),"collapsed branches defer child DOM on Android");
        js("document.getElementById('toggleBranches').click()");
        check(Boolean.TRUE.equals(js("!!document.querySelector('#rubricList .sub-list .rubric')")),"expanding branches restores source sub-rubrics on Android");
        js("OR.showPage('dashboard')");

        if(Boolean.TRUE.equals(js("!!OR.state.cases.upgrade_case")))check(Boolean.TRUE.equals(js("OR.state.cases.upgrade_case.repertoryId==='kent'&&OR.state.cases.upgrade_case.analysis[0].sourceId==='kent'")),"the existing Publicum case retains its source key after adding English Kent");
        if(Boolean.TRUE.equals(js("OR.activeCase().id==='upgrade_case'"))){
          js("window.__sourceBefore=JSON.stringify(OR.activeCase());OR.setRepertory('kent1897');true");waitJS("OR.state.repertoryId==='kent1897'",180);
          check(Boolean.TRUE.equals(js("!OR.hasRubric('Mind||ABRUPT')")),"Android selection state is scoped to the current source even for an identical path");
          js("OR.toggleRubric('Mind||ABRUPT','Mind','ABRUPT',[],1,'manual')");
          check(Boolean.TRUE.equals(js("OR.activeCase().analysis.length===2&&OR.activeCase().analysis[0].sourceId==='kent'")),"Android can add another repertory while retaining the original source rubric");
          js("OR.toggleRubric('Mind||ABRUPT','Mind','ABRUPT',[],1,'manual')");
          js("OR.setRepertory('kent');true");waitJS("OR.state.repertoryId==='kent'",180);
          check(Boolean.TRUE.equals(js("OR.hasRubric('Mind||ABRUPT')")),"returning to the owning source restores the selected state");
          check(Boolean.TRUE.equals(js("JSON.stringify(OR.activeCase())===window.__sourceBefore")),"source navigation retains the exact original case data on Android");
        }
        js("OR.newCase('Synthetic clipboard test',null);OR.setRepertory('clarke').then(()=>{OR.showPage('repertory');OR.runSearch('acidity')})");
        waitJS("document.querySelector('#rubricList .add-btn')!==null",60);
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden")),"clipboard is hidden for an empty clinical case");
        js("document.querySelector('#rubricList .add-btn').click()");
        check(Boolean.TRUE.equals(js("!document.getElementById('analysisShortcut').hidden&&document.getElementById('analysisShortcutCount').textContent==='1'")),"real rubric selection shows the packaged clipboard shortcut");
        check(Boolean.TRUE.equals(js("!document.querySelector('#analysisShortcut span')&&getComputedStyle(document.getElementById('analysisShortcutCount')).display==='none'")),"the packaged floating control displays only a clipboard icon");
        check(Boolean.TRUE.equals(js("(()=>{const b=document.getElementById('analysisShortcut').getBoundingClientRect(),n=document.getElementById('bottomNav').getBoundingClientRect();return b.height>=48&&b.left>=0&&b.right<=innerWidth&&b.bottom<=n.top-8})()")),"actual Android WebView places the clipboard above bottom navigation");
        js("window.__shortcutCase=JSON.stringify(OR.activeCase());document.getElementById('analysisShortcut').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='analysis'&&document.querySelectorAll('#selectedList .selected-item').length===1&&!!document.querySelector('#resultsTableWrap table')")),"clipboard opens the full selected-rubric analysis and results");
        check(Boolean.TRUE.equals(js("JSON.stringify(OR.activeCase())===window.__shortcutCase&&document.getElementById('analysisShortcut').hidden")),"opening analysis preserves the active case and hides the redundant shortcut");
        js("OR.clinic.setAnalysisView('matrix')");
        check(Boolean.TRUE.equals(js("getComputedStyle(document.querySelector('.grid-scroll')).display!=='none'")),"the Android analysis matrix is reachable through its dedicated view");
        runOnMainSync(()->activity.onBackPressed());waitJS("OR.state.page==='repertory'",10);
        check(true,"Android Back returns from analysis to the repertory workspace");
        js("OR.showPage('repertory');OR.selectChapter(OR.state.repertory.chapters[0].id);document.getElementById('searchBox').focus()");
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden")),"clipboard hides during keyboard input on Android");
        js("document.getElementById('searchBox').blur()");waitJS("!document.getElementById('analysisShortcut').hidden",10);
        check(true,"clipboard returns after keyboard input");
        js("OR.modal({title:'Synthetic shortcut test',html:'<p>Test</p>'})");
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden")),"clipboard does not compete with Android WebView dialogs");
        js("document.querySelector('.modal-x').click()");waitJS("!document.getElementById('analysisShortcut').hidden",10);
        check(true,"clipboard returns after closing a dialog");
        js("OR.showPage('analysis');document.getElementById('clearAnalysis').click();document.getElementById('clearAnalysis').click();OR.showPage('repertory')");
        check(Boolean.TRUE.equals(js("document.getElementById('analysisShortcut').hidden&&OR.activeCase().analysis.length===0")),"clearing the last rubric hides the Android clipboard shortcut");
        js("OR.showPage('dashboard')");
        js("window.__menuRetained='keep';document.getElementById('menuBtn').click()");
        check(Boolean.TRUE.equals(js("!document.getElementById('menuPanel').hidden&&[...document.querySelectorAll('#menuHome .menu-item')].filter(e=>e.getClientRects().length).length===8")),"packaged phone menu shows eight grouped actions");
        check(Boolean.TRUE.equals(js("document.getElementById('menuPanel').getAttribute('role')==='dialog'&&document.activeElement.id==='menuFinder'")),"actual WebView menu exposes dialog semantics and initial focus");
        check(Boolean.TRUE.equals(js("getComputedStyle(document.getElementById('menuPanel')).opacity==='1'&&getComputedStyle(document.getElementById('menuPanel')).backgroundColor!=='rgba(0, 0, 0, 0)'")),"the menu is opaque instead of merging with the page underneath");
        js("document.getElementById('menuSettingsButton').click()");
        check(Boolean.TRUE.equals(js("!document.getElementById('menuSettings').hidden&&document.getElementById('menuHome').hidden")),"settings opens in a separate compact view");
        runOnMainSync(()->activity.onBackPressed());waitJS("!document.getElementById('menuHome').hidden",10);
        check(Boolean.TRUE.equals(js("!document.getElementById('menuPanel').hidden")),"Android Back returns from Settings without closing the app");
        runOnMainSync(()->activity.onBackPressed());waitJS("document.getElementById('menuPanel').hidden",10);
        check("keep".equals(js("window.__menuRetained")),"Android Back closes the main menu and preserves the clinical document");
        check(Boolean.TRUE.equals(js("document.getElementById('toolbar').getAttribute('aria-hidden')===null")),"native Back restores underlying workspace accessibility");
        js("document.getElementById('menuBtn').click();document.querySelector('#menuPanel [data-page=file]').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='file'&&document.querySelector('[data-bottom-page=patients]').getAttribute('aria-current')==='page'")),"Patient file remains reachable through the new menu");
        js("document.getElementById('menuBtn').click();document.querySelector('#menuPanel [data-page=diff]').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='diff'&&document.querySelector('[data-bottom-page=mm]').getAttribute('aria-current')==='page'")),"remedy comparison remains reachable under Library");
        js("document.getElementById('menuBtn').click();document.getElementById('menuFinder').click()");
        check(Boolean.TRUE.equals(js("OR.state.page==='repertory'&&document.activeElement.id==='aiInput'")),"Find rubrics retains the existing patient-word input action");
        js("window.__expectedTheme=['auto','light','dark'][(['auto','light','dark'].indexOf((OR.store.get('openrepertory_theme')||{}).t||'auto')+1)%3];document.activeElement.blur();document.getElementById('menuBtn').click();document.getElementById('menuSettingsButton').click();document.getElementById('menuTheme').click()");
        check(Boolean.TRUE.equals(js("(OR.store.get('openrepertory_theme')||{}).t===window.__expectedTheme&&!document.getElementById('menuSettings').hidden")),"Appearance changes the stored theme without closing Settings");
        js("OR.dismissMenu();document.getElementById('menuUpdates').click()");Thread.sleep(500);
        Field uf=activity.getClass().getDeclaredField("updates");uf.setAccessible(true);AppUpdates updates=(AppUpdates)uf.get(activity);Field df=AppUpdates.class.getDeclaredField("dialog");df.setAccessible(true);
        check(df.get(updates)!=null,"App updates still opens its existing native screen");
        runOnMainSync(updates::pause);
        check("keep".equals(js("window.__menuRetained")),"opening updates retains the active clinical document");
        if(Boolean.TRUE.equals(js("OR.patientList().length>0"))){
          js("OR.patients.open(OR.patientList()[0].id);OR.clinic.patientView('notes')");
          check(Boolean.TRUE.equals(js("!!document.getElementById('patientTabs')&&getComputedStyle(document.getElementById('fileNotes')).display!=='none'")),"the Android patient file exposes the Notes workspace without changing records");
          runOnMainSync(()->activity.onBackPressed());waitJS("document.getElementById('fileRoot').dataset.patientView==='overview'",10);
          check(true,"Android Back returns from Notes to patient Overview");
        }
        runOnMainSync(()->{screen.cancel();browser.stopLoading();});
        result.putString("stream","Menu native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","FAILED after "+passed+" menu checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
