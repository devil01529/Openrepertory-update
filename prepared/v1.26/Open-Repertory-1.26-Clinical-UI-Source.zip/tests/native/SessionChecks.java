package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.view.View;import android.webkit.*;import com.openrepertory.app.*;import java.lang.reflect.*;import org.json.*;
public final class SessionChecks extends StartupChecks {
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
        activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
        ApperAccess access=(ApperAccess)field("access");
        getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
        JSONObject owner=receipt(access.deviceId());
        ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView original=(WebView)af.get(screen);
        WebView[] created=new WebView[1];runOnMainSync(()->created[0]=new FixtureAuthView(activity));WebView browser=created[0];
        runOnMainSync(()->{original.stopLoading();screen.removeView(original);original.destroy();browser.getSettings().setJavaScriptEnabled(true);browser.getSettings().setDomStorageEnabled(true);browser.getSettings().setUserAgentString("Mozilla/5.0 Chrome/120.0.0.0");screen.addView(browser,new android.widget.LinearLayout.LayoutParams(-1,0,1));browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){screen.check();}});});af.set(screen,browser);
        String page="<html><body><a href='/' onclick='window.managerClicks++;return false'>Device requests</a><button onclick='window.refreshes++'>Refresh requests</button><h1>Owner approvals fixture</h1><script>window.managerClicks=0;window.refreshes=0;window.calls=0;window.base="+owner.toString()+";window.ORApperNative={result:null,check:function(a){window.calls++;this.result=JSON.parse(JSON.stringify(window.base));this.result.nonce=a.nonce;}};</script></body></html>";
        runOnMainSync(()->{screen.cancel();browser.loadDataWithBaseURL(ApperAccess.ORIGIN+"/device",page,"text/html","UTF-8",null);});
        ready();


        js("OR.openReadingMenu();document.getElementById('textSizeReset').click();OR.dismissMenu();OR.dismissMenu()");
        js("OR.showPage('repertory');OR.selectChapter(OR.state.repertory.chapters[0].id);document.getElementById('content').scrollTop=160;window.__sessionSentinel='keep-session';window.__sessionPage=OR.state.page;window.__sessionScroll=document.getElementById('content').scrollTop;window.__sessionCase=JSON.stringify(OR.activeCase())");
        lifecycle("onPause");Field bg=MainActivity.class.getDeclaredField("backgroundAt");bg.setAccessible(true);bg.setLong(activity,SystemClock.elapsedRealtime()-120000);
        check((activity.getWindow().getAttributes().flags&android.view.WindowManager.LayoutParams.FLAG_SECURE)!=0,"background window stays protected in Android recents");
        lifecycle("onResume");
        Field a=MainActivity.class.getDeclaredField("authenticated");a.setAccessible(true);
        check(a.getBoolean(activity),"a warm return after more than a minute does not request device authentication");
        check(((LaunchScreen)field("launchScreen")).getVisibility()==View.GONE,"warm return keeps the clinical surface visible without a login cover");
        check(Boolean.TRUE.equals(js("window.__sessionSentinel==='keep-session'&&OR.state.page===window.__sessionPage&&document.getElementById('content').scrollTop===window.__sessionScroll&&JSON.stringify(OR.activeCase())===window.__sessionCase")),"page, reading position, document and case survive a background return");
        js("OR.openReadingMenu();document.getElementById('textSizeLarger').click()");Thread.sleep(300);
        check(textZoom()==110,"text sizing updates actual Android WebView text zoom");
        check(Boolean.TRUE.equals(js("OR.store.get('openrepertory_ui').textSize===110")),"text size is saved in the encrypted preference store");
        js("openrepertoryNative.setTextScale(999)");Thread.sleep(300);check(textZoom()==140,"native text zoom is bounded to the supported maximum");
        js("document.getElementById('textSizeReset').click();OR.dismissMenu();OR.dismissMenu()");Thread.sleep(300);check(textZoom()==100,"Reset restores native text zoom");
        shell("input keyevent 223");android.app.KeyguardManager keyguard=(android.app.KeyguardManager)activity.getSystemService(android.content.Context.KEYGUARD_SERVICE);
        long end=SystemClock.elapsedRealtime()+20000;while(!keyguard.isDeviceLocked()&&SystemClock.elapsedRealtime()<end)Thread.sleep(200);
        check(keyguard.isDeviceLocked(),"Android secure keyguard locks during the real screen-off test");
        end=SystemClock.elapsedRealtime()+10000;while(a.getBoolean(activity)&&SystemClock.elapsedRealtime()<end)Thread.sleep(100);
        check(!a.getBoolean(activity),"device locking invalidates in-memory app authentication");
        boolean blocked=false;try{((ImprovedActivity)activity).new SecureBridge().read("openrepertory_cases");}catch(SecurityException expected){blocked=true;}check(blocked,"the clinical bridge rejects reads while the device is locked");
        AndroidPin.unlock(this,keyguard);
        check(!keyguard.isDeviceLocked(),"the test device is unlocked through its normal Android PIN UI");
        end=SystemClock.elapsedRealtime()+20000;while(!a.getBoolean(activity)&&SystemClock.elapsedRealtime()<end)Thread.sleep(100);
        check(a.getBoolean(activity),"verified Android device unlock resumes the existing session without a second app PIN");
        end=SystemClock.elapsedRealtime()+30000;while((!Boolean.TRUE.equals(field("approvalForeground"))||!Boolean.TRUE.equals(field("accessGranted")))&&SystemClock.elapsedRealtime()<end)Thread.sleep(100);
        check(Boolean.TRUE.equals(field("accessGranted")),"device-unlock recovery revalidates owner approval before restoring access");
        waitJS("window.__sessionSentinel==='keep-session'",30);
        check(Boolean.TRUE.equals(js("window.__sessionSentinel==='keep-session'&&OR.state.page===window.__sessionPage&&JSON.stringify(OR.activeCase())===window.__sessionCase")),"device lock and unlock retain the original clinical document and case");
        org.json.JSONObject revoked=receipt(access.deviceId());revoked.put("status","revoked");revoked.getJSONObject("grant").put("status","revoked");receive(revoked);
        blocked=false;try{((ImprovedActivity)activity).new SecureBridge().read("openrepertory_cases");}catch(SecurityException expected){blocked=true;}check(blocked&&!access.cachedAllowed(),"session preservation never overrides owner revocation");
        result.putString("stream","Session native checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
    }catch(Throwable error){Bundle failure=new Bundle();failure.putString("stream","FAILED session after "+passed+" checks: "+error+"\n");finish(Activity.RESULT_CANCELED,failure);}}
    android.view.accessibility.AccessibilityNodeInfo systemNode(String id){android.view.accessibility.AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();if(root==null)return null;java.util.List<android.view.accessibility.AccessibilityNodeInfo> nodes=root.findAccessibilityNodeInfosByViewId("com.android.systemui:id/"+id);return nodes.isEmpty()?null:nodes.get(0);}
    int textZoom(){final int[] value=new int[1];runOnMainSync(()->value[0]=web.getSettings().getTextZoom());return value[0];}
    void shell(String command)throws Exception{try(java.io.InputStream in=new android.os.ParcelFileDescriptor.AutoCloseInputStream(getUiAutomation().executeShellCommand(command))){while(in.read()!=-1){}}}
}
