"""Mixed-book selections must remain distinct by source plus legacy chapter/path."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.26';checks=[]
def check(v,label):
 assert v,label
 checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def source(p,key):p.evaluate('(key)=>OR.setRepertory(key)',key)
def search(p):
 p.evaluate('OR.showPage("repertory");OR.runSearch("abrupt")');p.wait_for_function('()=>OR.lastSearchStats&&document.querySelector("#rubricList").getAttribute("aria-busy")==="false"',timeout=90000)
def click(p):p.locator('.rubric[data-rubric-uid="Mind||ABRUPT"] .add-btn').first.click()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for origin,foreign in [('kent','kent1897'),('kent1897','kent')]:
  p=b.new_page(viewport={'width':393,'height':800});p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>OR.state.repertory',timeout=90000);source(p,origin);search(p);click(p);original=p.evaluate('OR.activeCase().analysis[0]')
  check(p.evaluate('OR.hasRubric("Mind||ABRUPT")'),origin+': original entry is selected')
  source(p,foreign);search(p);check(not p.evaluate('OR.hasRubric("Mind||ABRUPT")'),origin+': shared path in another book starts unselected');click(p)
  check(p.evaluate('OR.activeCase().analysis.length')==2,origin+': second book can be added to the same case')
  check(p.evaluate('OR.activeCase().analysis[0]')==original,origin+': adding another book preserves original grades and provenance')
  check(p.evaluate('OR.activeCase().analysis[1].sourceId')==foreign,origin+': added entry keeps the selected book identity')
  p.evaluate('OR.showPage("analysis");OR.clinic.setAnalysisView("rubrics")');p.locator('.selected-item').nth(1).locator('[data-w="3"]').click()
  check(p.evaluate('OR.activeCase().analysis[1].w')==3 and p.evaluate('OR.activeCase().analysis[0].w')==1,origin+': importance changes affect only one source entry')
  check(p.evaluate('OR.saveCaseSnapshot(OR.activeCase())'),origin+': snapshot accepts multiple books')
  before=p.evaluate('OR.activeCase().analysis');rank=p.evaluate('OR.rankCase(OR.activeCase())');p.reload();p.wait_for_function('()=>OR.state.repertory',timeout=90000)
  check(p.evaluate('OR.activeCase().analysis')==before,origin+': both entries persist independently after reload')
  check(p.evaluate('OR.rankCase(OR.activeCase())')==rank,origin+': ranking persists across reload')
  p.evaluate('OR.showPage("analysis");OR.clinic.setAnalysisView("rubrics")');p.locator('.selected-item').nth(1).locator('.remove-btn').click()
  check(p.evaluate('OR.activeCase().analysis')==[original],origin+': removing foreign entry cannot delete the original entry')
  source(p,origin);search(p);check(p.evaluate('OR.hasRubric("Mind||ABRUPT")'),origin+': returning to original book still shows its selection');click(p)
  check(p.evaluate('OR.activeCase().analysis.length')==0,origin+': toggling original book removes only its own final entry');p.close()
 b.close()
(O/'source-switch-guard-tests.json').write_text(json.dumps(checks,indent=2));print('Mixed-book source identity checks passed:',len(checks))
