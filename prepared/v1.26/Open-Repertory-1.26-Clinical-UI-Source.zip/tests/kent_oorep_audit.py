import os
"""Independent, exhaustive check of the app database against cached live API rows."""
from pathlib import Path
import json,collections,re,hashlib
R=Path(__file__).resolve().parents[1];D=R/'apk/assets/www/data';O=R/os.environ.get('OR_TEST_RESULTS','test-results/v1.22');O.mkdir(parents=True,exist_ok=True);checks=[]
raw=json.loads(Path('/workspace/scratch/oorep-live-kent/rows.json').read_text());rep=json.loads((D/'kent_english_oorep.json').read_text());audit=json.loads((D/'kent_oorep_audit.json').read_text())
def check(value,label):
    assert value,label
    checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
check(rep['id']=='kent1897' and rep['oorep_abbrev']=='kent' and rep['language']=='en','English Kent has a separate source identity from legacy Publicum')
check(len(raw)==68742==audit['apiDeclaredTotal'],'all 68,742 unique rows were collected from all 688 declared API pages')
nodes=[];indexes=[]
for ch in rep['chapters']:
    indexes.extend(ch.get('indexRows',[]))
    for parent in ch['rubrics']:nodes.extend([parent]+parent.get('sub',[]))
represented={};headings=0
for node in nodes+indexes:
    if not node['sourceIds']:headings+=1;continue
    for key in node['sourceIds']:
        assert key not in represented,('duplicate ID',key)
        represented[key]=node
check(set(represented)==set(raw),'every source ID is represented exactly once, including chapter index rows')
check(len(indexes)==37 and headings==1039,'37 chapter index rows and 1,039 synthetic navigation headings are labelled separately')
check(all(represented[k]['sourcePath']==v['rubric']['fullPath'] for k,v in raw.items()),'all 68,742 original source paths are preserved verbatim')
wanted={k:collections.Counter((x['remedy']['nameAbbrev'],x['weight']) for x in v['weightedRemedies']) for k,v in raw.items()}
check(all(collections.Counter((x['r'],x['g']) for x in represented[k]['remedies'])==v for k,v in wanted.items()),'every remedy abbreviation and grade matches its original API source row')
check(sum(sum(v.values()) for v in wanted.values())==624010,'all 624,010 original remedy records are retained without merging grade conflicts')
expected=collections.defaultdict(set)
for item in raw.values():
    for value in item['weightedRemedies']:expected[value['remedy']['nameAbbrev']].update(value['remedy'].get('namealt') or [])
check(all(set(rep['remedyAliases'][a]['aliases'])==names for a,names in expected.items()),'all 103 recorded alternate remedy names match the source exactly')
check(sum(len(names) for names in expected.values())==103,'source synonym count is 103; heuristic patient-word suggestions are not counted')
refs=[(r,ref) for r in nodes for ref in r.get('references',[])]
check(len(refs)==5,'all five explicit parenthetical Kent cross-reference occurrences are integrated')
ids={r['id'] for r in nodes}
check(all(ref.get('targetId') in ids and ref['sourceId']=='kent1897' for _,ref in refs),'all Kent cross-reference targets resolve to an existing node in the same source')
check(all(ref['sourceText'] in r['sourcePath'] and re.match(r'\(compare ',ref['sourceText'],re.I) for r,ref in refs),'references have exact source evidence; ordinary uses of the word see are not treated as links')
a,b=represented['15359'],represented['65440']
check(a['text']!=b['text'] and a['sourcePath']==b['sourcePath'],'duplicate fingers paths remain distinguishable source records')
check(next(x['g'] for x in a['remedies'] if x['r']=='Lach.')==1 and next(x['g'] for x in b['remedies'] if x['r']=='Lach.')==2,'the documented Lachesis grade conflict is preserved rather than silently resolved')
legacy=D/'kent_publicum_full.json';baseline=Path('/workspace/scratch/baseline-1.21/kent_publicum_full.json')
check(hashlib.sha256(legacy.read_bytes()).digest()==hashlib.sha256(baseline.read_bytes()).digest(),'legacy Publicum clinical data remains byte-identical for existing cases')
side=json.loads((D/'oorep_relationships.json').read_text())
check(len(side['references'])==3 and all(ref['sourceId']=='kent' for refs in side['references'].values() for ref in refs),'three legacy Publicum reference rows are integrated without renaming saved source keys')
check(audit['legacyComparison']['kentPathsNotInLegacyPublicum']==4684 and audit['legacyComparison']['sharedPathsWithDifferentRemedyLinksOrGrades']==9746,'legacy-vs-Kent differences are recorded as different compilations, not silently mixed')
check(len({r['id'] for r in nodes+indexes})==len(nodes)+len(indexes),'source and navigation IDs are unique throughout the imported book')
(O/'kent-oorep-audit-tests.json').write_text(json.dumps(checks,indent=2));print('Exhaustive Kent source audit checks passed:',len(checks))
