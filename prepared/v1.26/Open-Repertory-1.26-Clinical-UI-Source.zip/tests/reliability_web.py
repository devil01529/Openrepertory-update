import os
import json,pathlib,time,subprocess
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1];out=root/os.environ.get('OR_TEST_RESULTS','test-results/v1.12');out.mkdir(exist_ok=True);results=[]
def wait(page,expr,seconds=60):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  if page.evaluate(expr):return
  page.wait_for_timeout(100)
 raise AssertionError('Timeout: '+expr+'; '+page.locator('body').inner_text()[-1200:])
def record(name):results.append({'test':name,'status':'passed'});print('PASS',name,flush=True)
def fail_storage(page):page.evaluate('''() => {const old=Storage.prototype.setItem;window.restoreStore=()=>Storage.prototype.setItem=old;Storage.prototype.setItem=function(key,value){if(key==='openrepertory_browser_store_v2')throw new Error('Synthetic disk full');return old.call(this,key,value);};}''')
def restore(page):page.evaluate('() => {restoreStore();return true;}')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);context=browser.new_context(viewport={'width':412,'height':915},accept_downloads=True)
 page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765');wait(page,'!!(window.OR&&OR.state.repertory)')
 page.evaluate('OR.showPage("patients")');page.locator('#patientNew').click();page.locator('.modal [data-k="name"]').fill('Recoverable Draft');page.locator('.modal [data-k="chief"]').fill('Synthetic draft complaint')
 assert page.evaluate('OR.drafts.list()["patient-new"].values.name')=='Recoverable Draft';assert page.evaluate('OR.patientList().length')==0
 page.reload();wait(page,'!!(window.OR&&OR.state.repertory)');assert page.locator('#resumeDrafts').is_visible()
 page.locator('#resumeDrafts').click();page.locator('[data-resume-draft="patient-new"]').click()
 assert page.locator('.modal [data-k="name"]').input_value()=='Recoverable Draft'
 record('patient draft survives reload without creating a partial patient')
 fail_storage(page);page.get_by_role('button',name='Create patient',exact=True).click();wait(page,'!!document.querySelector(".modal-save-error")')
 assert page.evaluate('OR.patientList().length')==0;assert page.locator('.modal [data-k="name"]').input_value()=='Recoverable Draft'
 record('failed patient creation rolls back records and keeps the form open')
 restore(page);page.get_by_role('button',name='Create patient',exact=True).click();wait(page,'OR.patientList().length===1')
 assert page.evaluate('OR.patientList()[0].name')=='Recoverable Draft';assert page.evaluate('Object.keys(OR.drafts.list()).length')==0
 record('retry commits exactly one patient and clears its draft')
 page.evaluate('if(OR.clinic)OR.clinic.patientView("visits")');page.locator('[data-act="addvisit"]').click();page.locator('.modal [data-k="notes"]').fill('Synthetic interrupted visit')
 fail_storage(page);page.get_by_role('button',name='Save visit',exact=True).click();wait(page,'!!document.querySelector(".modal-save-error")');assert page.evaluate('OR.patientList()[0].visits.length')==0
 restore(page);page.get_by_role('button',name='Save visit',exact=True).click();wait(page,'OR.patientList()[0].visits.length===1')
 assert page.evaluate('OR.patientList()[0].visits[0].notes')=='Synthetic interrupted visit'
 record('failed visit save rolls back and retry does not duplicate the visit')
 page.evaluate('if(OR.clinic)OR.clinic.patientView("notes")');chief=page.locator('#fileRoot [data-f="chief"]');old=page.evaluate('OR.patientList()[0].chief')
 fail_storage(page);chief.fill('Retry-safe field content');assert page.evaluate('OR.patientList()[0].chief')==old
 restore(page);page.evaluate('OR.flushPatientEdits()');assert page.evaluate('OR.patientList()[0].chief')=='Retry-safe field content'
 record('patient field edits update live state only after a successful write')
 # Add a patient-linked case, then verify deletion is an all-or-nothing operation.
 page.evaluate('OR.activeCase().patientId=OR.patientList()[0].id;OR.saveCases();')
 case_before=page.evaluate('JSON.stringify(OR.state.cases)');patient_before=page.evaluate('JSON.stringify(OR.patientList())')
 fail_storage(page);page.locator('[data-act="delete"]').click();page.get_by_role('button',name='Delete',exact=True).last.click();page.wait_for_timeout(100)
 assert page.evaluate('JSON.stringify(OR.state.cases)')==case_before;assert page.evaluate('JSON.stringify(OR.patientList())')==patient_before
 restore(page);record('patient deletion and case unlinking remain atomic on a write failure')
 # Case edits must also roll back, preserving the committed state.
 fail_storage(page);page.evaluate('''() => {try{OR.toggleRubric('rollback','Mind','Synthetic rubric',[{r:'Acon.',g:2}],1,'manual');}catch(error){window.expectedRollback=true;}}''')
 assert page.evaluate('JSON.stringify(OR.state.cases)')==case_before;restore(page);record('case rubric write failure restores the committed case')
 # Build a real encrypted portable backup before simulating unreadable storage.
 backup=page.evaluate('''async () => ORBackup.encrypt({app:'openrepertory',version:1,patients:JSON.parse(ORStorage.read('openrepertory_patients')),cases:JSON.parse(ORStorage.read('openrepertory_cases')),mmNotes:{}},'recovery-password-123')''')
 page.evaluate("localStorage.setItem('openrepertory_browser_store_v2','{')");page.reload();page.wait_for_selector('#recoveryScreen')
 page.locator('#recoveryText').fill(backup);page.locator('#recoveryPassword').fill('incorrect');page.locator('#recoveryRestore').click();wait(page,'document.querySelector("#recoveryStatus").textContent.includes("Could not decrypt")')
 assert page.evaluate("localStorage.getItem('openrepertory_browser_store_v2')")=='{';record('recovery rejects a wrong password without changing damaged storage')
 page.locator('#recoveryPassword').fill('recovery-password-123');page.locator('#recoveryRestore').click();page.get_by_role('button',name='Restore',exact=True).click();wait(page,'!!(window.OR&&OR.state.repertory) && !document.querySelector("#recoveryScreen")')
 assert page.evaluate('OR.patientList().length')==1
 assert page.evaluate("Object.keys(localStorage).some(k=>k.startsWith('openrepertory_browser_damaged_'))")
 record('startup recovery validates and restores a backup while retaining damaged data')
 # Preserve exact supported search behavior while moving the work off the UI thread.
 for book,query in [('kent','consol'),('bbcr','acon'),('knerr1897','sleep midnight'),('tpb1846','acon'),('boger1915','sleep')]:
  page.evaluate('(id)=>OR.setRepertory(id)',book);wait(page,'OR.state.repertoryId==='+json.dumps(book))
  expected=page.evaluate('''q=>OR.state.repertory.chapters.flatMap(c=>OR.searchInChapter(c,q.toLowerCase().split(/\\s+/))).map(x=>x.chapter+'|'+x.r.id+'|'+x.subs.map(s=>s.id).sort().join(',')).sort()''',query)
  actual=page.evaluate('''async ({query,file})=>(await ORSearch.query(file,[query],null)).map(x=>{const ch=OR.state.repertory.chapters.find(c=>c.name===x.chapter),r=ch.rubrics.find(r=>r.id===x.id);return x.chapter+'|'+r.id+'|'+x.subs.map(i=>r.sub[i].id).sort().join(',');}).sort()''',{'query':query,'file':{'kent':'kent_publicum_full.json','bbcr':'bbcr1905.json','knerr1897':'knerr1897.json','tpb1846':'tpb1846.json','boger1915':'boger1915.json'}[book]})
  assert actual==expected,(book,len(actual),len(expected))
 record('worker search matches the existing search semantics across all five books')
 page.evaluate('OR.showPage("repertory");OR.runSearch("consol");OR.runSearch("acon")');wait(page,'OR.lastSearchStats && OR.lastSearchStats.query==="acon"')
 assert page.evaluate('OR.lastSearchStats.backend')=='worker';record('background search publishes only the latest requested results')
 # Print a long complete static report, not clipped form controls.
 page.evaluate('OR.patients.open(OR.patientList()[0].id)');page.evaluate('if(OR.clinic)OR.clinic.patientView("notes")');notes=page.locator('#fileRoot [data-f="notes"]');notes.fill(('SYNTHETIC LONG CLINICAL REPORT\n'*350)+'FINAL_REPORT_MARKER_15')
 page.locator('[data-act="print"]').click();page.emulate_media(media='print');pdf=out/'synthetic-patient-report.pdf';page.pdf(path=str(pdf),format='A4')
 text=subprocess.run(['pdftotext',str(pdf),'-'],capture_output=True,text=True,check=True).stdout
 assert 'FINAL_REPORT_MARKER_15' in text and 'Recoverable Draft' in text
 assert text.count('\f')>1
 record('multi-page PDF contains the complete clinical report and final text')
 page.emulate_media(media='screen');page.set_viewport_size({'width':320,'height':720});page.evaluate('document.documentElement.style.fontSize="150%"');page.screenshot(path=str(out/'large-font-mobile.png'),full_page=True)
 assert page.get_by_role('button',name='Open tools and settings').is_visible();record('small-screen large-font rendering and labelled navigation remain usable')
 assert not errors,errors;record('no uncaught browser errors during reliability and recovery workflows')
 browser.close()
(out/'browser-reliability.json').write_text(json.dumps(results,indent=2))
