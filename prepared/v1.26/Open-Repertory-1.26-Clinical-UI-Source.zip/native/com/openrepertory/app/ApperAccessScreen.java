package com.openrepertory.app;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.util.UUID;

/** Separate hosted-auth surface: no clinical JavascriptInterface, file access or local data. */
public final class ApperAccessScreen extends LinearLayout {
    public interface Actions {void check();void signOut();void details();void receipt(JSONObject result,String nonce);void unavailable(boolean network);void interactionRequired();void loading();void closeManager();}
    private final Actions actions;
    private final TextView status,title;
    private final Button backToApp,phoneDetails;
    private boolean managerMode;
    private final WebView browser;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final String device;
    private String nonce;
    private long deadline;
    private boolean polling,disposed,failed,requested;
    private long loginVisibleAt;
    private final Runnable poll=this::pollResult;
    public ApperAccessScreen(Context context,String device,Actions actions) {
        super(context);this.actions=actions;this.device=device;
        setOrientation(VERTICAL);setBackgroundColor(0xfff4f6f9);
        int pad=dp(12);setPadding(pad,pad,pad,pad);
        title=new TextView(context);title.setText("Open Repertory · Account access");title.setTextSize(20);title.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);title.setPadding(0,dp(8),0,dp(8));title.setTextColor(0xff193252);addView(title);
        status=new TextView(context);status.setTextSize(13);status.setTextColor(0xff374151);status.setPadding(0,dp(5),0,dp(5));addView(status);
        LinearLayout controls=new LinearLayout(context);
        backToApp=button(controls,"Back to repertory",actions::closeManager);backToApp.setVisibility(GONE);
        button(controls,"Check / reload",this::load);
        phoneDetails=button(controls,"Phone details",actions::details);
        button(controls,"Sign out",actions::signOut);
        addView(controls,new LayoutParams(-1,-2));
        browser=new WebView(context);addView(browser,new LayoutParams(-1,0,1));
        WebSettings settings=browser.getSettings();
        settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);settings.setSupportMultipleWindows(false);
        if(Build.VERSION.SDK_INT>=26)settings.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser,false);
        WebView.setWebContentsDebuggingEnabled(false);
        browser.setWebChromeClient(new WebChromeClient());
        browser.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                return !ApperAccess.trusted(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return !ApperAccess.trusted(Uri.parse(url));}
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon){cancel();failed=false;}
            @Override public void onPageFinished(WebView view,String url){
                if(!ApperAccess.trusted(Uri.parse(url)))return;
                browser.evaluateJavascript("sessionStorage.setItem('or-native-device',"+JSONObject.quote(device)+")",null);
                if(!failed)actions.check();
            }
            @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){
                if(request.isForMainFrame()){failed=true;cancel();actions.unavailable(true);}
            }
            @Override public void onReceivedHttpError(WebView view,WebResourceRequest request,WebResourceResponse response){
                if(request.isForMainFrame()){failed=true;cancel();actions.unavailable(false);}
            }
        });
        if(Build.VERSION.SDK_INT>=30)setOnApplyWindowInsetsListener((v,insets)->{
            android.graphics.Insets visible=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.ime());
            setPadding(pad+visible.left,pad+visible.top,pad+visible.right,pad+visible.bottom);return insets;
        });
        show("Unlock your phone to sign in. Patient records stay on this device.");
    }
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private Button button(LinearLayout row,String text,Runnable action){
        Button button=new Button(getContext());button.setText(text);button.setTextSize(11);button.setAllCaps(false);button.setPadding(dp(5),0,dp(5),0);button.setTextColor(0xff1b2a4a);android.graphics.drawable.GradientDrawable shape=new android.graphics.drawable.GradientDrawable();shape.setColor(0xffffffff);shape.setCornerRadius(dp(8));shape.setStroke(dp(1),0xffd7dbe3);button.setBackground(shape);
        LayoutParams size=new LayoutParams(0,dp(48),1);size.setMargins(dp(2),dp(4),dp(2),dp(8));row.addView(button,size);button.setOnClickListener(v->action.run());return button;
    }
    public void show(String message){status.setText(message);}
    private boolean supportedEngine(){
        java.util.regex.Matcher version=java.util.regex.Pattern.compile("Chrome/([0-9]+)").matcher(browser.getSettings().getUserAgentString());
        try{return version.find()&&Integer.parseInt(version.group(1))>=100;}catch(Exception error){return false;}
    }
    public void ensureLoaded(){if(!requested||failed||!supportedEngine())load();}
    public void load(){if(disposed)return;requested=true;actions.loading();if(!supportedEngine()){actions.interactionRequired();show("Update Android System WebView or Chrome using Google Play, then reopen this app. Apper sign-in needs a current browser engine; your records are unchanged.");return;}failed=false;loginVisibleAt=0;browser.loadUrl(ApperAccess.ORIGIN+(managerMode?"/":"/device?device="+device));show(managerMode?"Loading owner approvals…":"Loading secure Apper sign-in…");}
    public void setManager(boolean enabled){
        managerMode=enabled;
        title.setText(enabled?"Owner · Access approvals":"Open Repertory · Apper access");
        backToApp.setVisibility(enabled?VISIBLE:GONE);phoneDetails.setVisibility(enabled?GONE:VISIBLE);
    }
    public void openManager(){
        cancel();setManager(true);
        show("Review phones and save approval decisions in Apper.");
        if(!ApperAccess.trusted(Uri.parse(browser.getUrl()==null?"":browser.getUrl()))){load();return;}
        // Use the portal's existing router and authenticated SDK session.
        browser.evaluateJavascript("(function(){var link=document.querySelector('a[href=\"/\"]');if(!link)return false;link.click();var refresh=Array.from(document.querySelectorAll('button')).find(function(b){return b.textContent.trim()==='Refresh requests';});if(refresh)refresh.click();return true;})()",value->{if(!disposed&&managerMode&&!"true".equals(value))load();});
    }
    public void check(){
        if(disposed||polling)return;
        if(failed||!ApperAccess.trusted(Uri.parse(browser.getUrl()==null?"":browser.getUrl()))) {ensureLoaded();return;}
        nonce=UUID.randomUUID().toString();loginVisibleAt=0;deadline=SystemClock.elapsedRealtime()+25000;polling=true;pollResult();
    }
    private void pollResult(){
        if(!polling||disposed)return;
        if(!ApperAccess.trusted(Uri.parse(browser.getUrl()==null?"":browser.getUrl()))) {cancel();actions.unavailable(false);return;}
        final String expected=nonce;
        String args="{device:"+JSONObject.quote(device)+",nonce:"+JSONObject.quote(expected)+",projectId:"+JSONObject.quote(ApperAccess.PROJECT)+"}";
        String script="(function(){var b=window.ORApperNative;if(!b){var a=document.querySelector('#authentication');var r=a&&(a.shadowRoot||a);return r&&r.querySelector('input')?JSON.stringify({interaction:true}):null;} if(b.__nativeNonce!=="+JSONObject.quote(expected)+"){b.__nativeNonce="+JSONObject.quote(expected)+";b.check("+args+");}return b.result&&b.result.nonce==="+JSONObject.quote(expected)+"?JSON.stringify(b.result):null;})()";
        browser.evaluateJavascript(script,value->{
            if(disposed||!polling||!expected.equals(nonce))return;
            if(!ApperAccess.trusted(Uri.parse(browser.getUrl()==null?"":browser.getUrl()))){cancel();actions.unavailable(false);return;}
            if(value!=null&&!"null".equals(value))try {
                Object decoded=new JSONTokener(value).nextValue();JSONObject receipt=new JSONObject(String.valueOf(decoded));
                if(receipt.optBoolean("interaction")) {
                    // Allow the SDK to finish restoring a saved session before revealing a form.
                    if(loginVisibleAt==0)loginVisibleAt=SystemClock.elapsedRealtime();
                    if(SystemClock.elapsedRealtime()-loginVisibleAt>=800){actions.interactionRequired();}
                } else {loginVisibleAt=0;cancel();actions.receipt(receipt,expected);return;}
            }catch(Exception ignored){}
            if(SystemClock.elapsedRealtime()>=deadline){cancel();actions.unavailable(false);return;}
            handler.postDelayed(poll,100);
        });
    }
    public void cancel(){polling=false;nonce=null;handler.removeCallbacks(poll);}
    public void logout(){
        cancel();failed=false;
        // Destroy this session even if its React shell is not currently mounted.
        browser.evaluateJavascript("(async function(){if(window.ORApperNative)try{await window.ORApperNative.logout();}catch(e){}localStorage.clear();sessionStorage.clear();location.assign('/member/login');})()",ignored->{
            CookieManager.getInstance().removeSessionCookies(null);CookieManager.getInstance().flush();
        });
    }
    public void resume(){browser.onResume();}
    public void pause(){cancel();browser.onPause();}
    public void dispose(){disposed=true;cancel();browser.stopLoading();browser.destroy();}
}
