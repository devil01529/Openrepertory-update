"""Deterministic, loss-checked importer for owner-authorized OOREP editions.
Does not modify Kent or overwrite earlier editions used by saved cases.
"""
from pathlib import Path
import json,hashlib,collections,re,argparse
R=Path(__file__).resolve().parents[1];D=R/'apk/assets/www/data';A=R/'source-material/repertory-comparison-20261024'
p=argparse.ArgumentParser();p.add_argument('--cache',type=Path,default=Path('/workspace/scratch/oorep-audit-20261024'));p.add_argument('--source',choices=['boericke','bogboen','boen'],action='append');args=p.parse_args()
SPECS={'boericke':('boericke1906','Boericke',1906),'bogboen':('bbcr1905_oorep','Boenninghausen — BBCR',1905),'boen':('tpb1891','Therapeutic Pocket Book — Allen 1891',1891)}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
protected=json.loads((A/'kent-protected.json').read_text());assert all(digest(D/f)==h for f,h in protected.items())
reports=json.loads((A/'import-audit.json').read_text()) if (A/'import-audit.json').exists() else {}
for source,(key,title,year) in SPECS.items():
 if args.source and source not in args.source:continue
 cache=args.cache/source;manifest=json.loads((cache/'manifest.json').read_text());raw=json.loads((cache/'rows.json').read_text());assert len(raw)==manifest['total']
 assert {int(p) for p in manifest['pageSha256']}==set(range(manifest['pages']))
 pageRows={}
 for page,h in manifest['pageSha256'].items():
  f=cache/f'{int(page):05}.json';assert digest(f)==h
  response=json.loads(f.read_text())[0];assert response['currPage']==int(page)
  for group in response['results']:
   for item in group['subRubrics']:
    sid=str(item['rubric']['id']);assert sid not in pageRows;pageRows[sid]=item
 assert pageRows==raw,'Cached row index differs from hashed source pages'
 chapters={};parents={};aliases={};records=[];duplicates=[];grades=collections.Counter();allLinks=0
 for sourceid,item in sorted(raw.items(),key=lambda x:int(x[0])):
  src=item['rubric'];path=src['fullPath'];parts=[s.strip() for s in path.split(',')];assert parts and all(parts)
  chapter=chapters.setdefault(parts[0],{'id':key+'-ch-'+hashlib.sha256(parts[0].encode()).hexdigest()[:16],'name':parts[0],'rubrics':[]})
  values={};ungraded=[];sourceLinks=[];grouped=collections.defaultdict(list);conflicts=[]
  for value in item['weightedRemedies']:
   rm=value['remedy'];g=value['weight'];assert isinstance(g,int)
   abbr=rm['nameAbbrev'];allLinks+=1;grades[str(g)]+=1
   entry=aliases.setdefault(abbr,{'name':rm['nameLong'],'aliases':set(),'sourceRemedyIds':set()});entry['aliases'].update(rm.get('namealt') or []);entry['sourceRemedyIds'].add(str(rm['id']))
   sourceLinks.append({'r':abbr,'g':g,'sourceRemedyId':rm['id']});grouped[abbr].append(g)
  for abbr,weights in grouped.items():
   distinct=sorted(set(weights))
   if len(distinct)>1:conflicts.append({'r':abbr,'sourceWeights':weights});continue
   g=distinct[0]
   if not 1<=g<=5:ungraded.append({'r':abbr,'sourceWeight':g});continue
   values[abbr]={'r':abbr,'g':g}
  rec={'id':key+'-'+sourceid,'text':parts[1] if len(parts)>1 else parts[0],'sourceIds':[sourceid],'sourcePath':path,'sourceHierarchy':parts,'sourceMotherId':src.get('mother'),'sourceChapterId':src['chapterId'],'sourceIsMother':src.get('isMother'),'sourceLabel':src.get('path'),'sourceNote':'OOREP '+source+' record '+sourceid+'. Raw database grades retained; only unambiguous grades 1–5 are scored. Not independently scan-verified.','remedies':list(values.values())}
  rec['sourceRemedyRecords']=sourceLinks
  if conflicts:rec['conflictingRemedies']=conflicts;rec['sourceNote']+=' Conflicting source grades are retained separately and excluded from scoring pending source review.'
  if src.get('textt'):rec['sourceText']=src['textt']
  if ungraded:rec['ungradedRemedies']=ungraded;rec['sourceNote']+=' Unsupported source weights are retained for review but not assigned a grade or scored.'
  records.append(rec)
  if len(parts)==1:chapter['rubrics'].append(rec);continue
  groupkey=(parts[0],parts[1]);parent=parents.get(groupkey)
  if parent is None:
   parent={'id':key+'-heading-'+hashlib.sha256('|'.join(groupkey).encode()).hexdigest()[:16],'text':parts[1],'syntheticHeading':True,'sourceIds':[],'remedies':[],'sub':[]};parents[groupkey]=parent;chapter['rubrics'].append(parent)
  if len(parts)==2 and parent.get('syntheticHeading'):
   children=parent['sub'];parent.clear();parent.update(rec);parent['sub']=children;records[-1]=parent
  else:
   rec['text']='. '+(', '.join(parts[2:]) if len(parts)>2 else parts[1]);parent['sub'].append(rec)
 # Every duplicate displayed path gets an explicit immutable source-row suffix.
 identities=collections.defaultdict(list)
 for ch in chapters.values():
  for par in ch['rubrics']:
   if not par.get('syntheticHeading'):identities[(ch['name'],par['text'])].append(par)
   for child in par.get('sub',[]):identities[(ch['name'],par['text']+', '+child['text'].removeprefix('. '))].append(child)
 for identity,variants in identities.items():
  if len(variants)>1:
   duplicates.append({'displayPath':identity,'sourceIds':[x['sourceIds'][0] for x in variants]})
   for v in variants:v['text']+=' [source row '+v['sourceIds'][0]+']'
 bypath=collections.defaultdict(list)
 for rec in records:bypath[rec['sourcePath'].casefold()].append(rec)
 refs=resolved=0
 for rec in records:
  links=[]
  for match in re.finditer(r'\((?:see(?: also)?|compare)\s+([^()]+)\)',(rec['sourceLabel'] or rec['sourceHierarchy'][-1]),re.I):
   label=match.group(1).strip();parts=rec['sourceHierarchy'];targets=[]
   for n in range(len(parts)-1,-1,-1):
    found=bypath.get(', '.join(parts[:n]+[label]).casefold(),[])
    if len(found)==1:targets=found;break
   link={'label':label,'kind':'see-also','sourceText':match.group(0),'sourceId':key,'resolution':'source-path' if targets else 'search'}
   if targets:link['targetId']=targets[0]['id'];resolved+=1
   links.append(link);refs+=1
  if links:rec['references']=links
 aliases={a:{'name':v['name'],'aliases':sorted(v['aliases']),'sourceRemedyIds':sorted(v['sourceRemedyIds'])} for a,v in aliases.items()}
 rep={'id':key,'title':title,'author':'Oscar E. Boericke' if source=='boericke' else 'C. M. Boger' if source=='bogboen' else 'C. von Bönninghausen; T. F. Allen edition','year':year,'language':'en','source':'OOREP structured '+source+' dataset','source_url':'https://www.oorep.com/faq','source_license':'Redistribution permission for this OOREP dataset confirmed by app owner on 2026-10-24. API license field unspecified; not claimed GPL.','dataRevision':'oorep-'+source+'-20261024','oorep_abbrev':source,'gradeRange':[1,max(int(g) for g in grades if 1<=int(g)<=5)],'shortNote':'Complete API snapshot; source grades preserved. '+('Provider marks this edition under development. ' if source=='boen' else '')+'Not independently scan-verified.','note':'All source paths and original parent IDs are retained. Navigation groups by chapter and first heading; deeper path components remain in full sub-rubric labels. Unsupported weights and conflicting grade entries are retained for review and excluded from scoring; exact duplicate links count once. Different books use different grade scales.','sourceSnapshot':manifest,'remedyAliases':aliases,'remedyCount':len(aliases),'chapters':list(chapters.values())}
 packaged=[r for ch in rep['chapters'] for par in ch['rubrics'] for r in [par]+par.get('sub',[]) if not r.get('syntheticHeading')];assert len(packaged)==len(raw);assert len({r['id'] for r in packaged})==len(raw)
 for r in packaged:
  original=raw[r['sourceIds'][0]];assert r['sourcePath']==original['rubric']['fullPath']
  actual=sorted((x['r'],x['g']) for x in r['sourceRemedyRecords'])
  expected=sorted((x['remedy']['nameAbbrev'],x['weight']) for x in original['weightedRemedies']);assert actual==expected,(source,r['id'])
 missingParents=[];cyclicParents=[];parentDepth=0
 for sourceid,item in raw.items():
  current=sourceid;seen=set();depth=0
  while current in raw:
   if current in seen:cyclicParents.append(sourceid);break
   seen.add(current);mother=raw[current]['rubric'].get('mother')
   if mother is None or mother<0:break
   current=str(mother);depth+=1
   if current not in raw:missingParents.append({'sourceId':sourceid,'missingParent':current});break
  parentDepth=max(parentDepth,depth)
 file=D/(key+'.json');file.write_text(json.dumps(rep,ensure_ascii=False,separators=(',',':')))
 reports[key]={'source':source,'file':file.name,'sourceRows':len(raw),'chapters':len(rep['chapters']),'remedyBearingRubrics':sum(bool(r['remedies']) for r in packaged),'distinctRemedies':len(aliases),'remedyLinksIncludingZero':allLinks,'grades':dict(grades),'unscoredLinks':sum(v for g,v in grades.items() if not 1<=int(g)<=5),'conflictingRemedies':sum(len(r.get('conflictingRemedies',[])) for r in packaged),'repeatedSourceLinks':sum(len(r['sourceRemedyRecords'])-len({x['r'] for x in r['sourceRemedyRecords']}) for r in packaged),'explicitReferences':refs,'resolvedReferences':resolved,'maxCommaPathDepth':max(len(r['sourceHierarchy']) for r in packaged),'maxExplicitParentDepth':parentDepth,'missingParentReferences':missingParents,'cyclicParentReferences':cyclicParents,'rowsWithExplicitParent':sum(r['sourceMotherId'] is not None and r['sourceMotherId']>=0 for r in packaged),'syntheticHeadings':sum(bool(p.get('syntheticHeading')) for ch in rep['chapters'] for p in ch['rubrics']),'duplicateDisplayPaths':duplicates,'remedyAliases':sum(len(v['aliases']) for v in aliases.values()),'sha256':digest(file),'verification':'Every source ID, path, remedy abbreviation and weight compared exhaustively to cached API responses; no printed-book scan certification.'}
assert all(digest(D/f)==h for f,h in protected.items())
(A/'import-audit.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2))
