from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];A=R/'source-material/repertory-comparison-20261024';audit=json.loads((A/'import-audit.json').read_text());verified=json.loads((R/'test-results/v1.31/classical-data-audit.json').read_text());lines=[]
for k,old in [('boericke1906','Not previously bundled'),('bbcr1905_oorep','10,769 OCR nodes / 140 remedies / 115,582 links'),('tpb1891','1,641 OCR nodes / 120 remedies / 48,090 links')]:
 a=audit[k];v=verified['sources'][k];lines.append(f"| {k} | {old} | {a['sourceRows']:,} | {a['distinctRemedies']:,} | {v['scoredLinks']:,} | {a['explicitReferences']:,} ({a['resolvedReferences']:,} resolved) |")
metrics=[]
for key,a in audit.items():
 grades=', '.join(g for g in sorted(a['grades'],key=int) if 1<=int(g)<=5)
 metrics.append(f"| {key} | {grades} | {a['chapters']} | {a['rowsWithExplicitParent']:,} / depth {a['maxExplicitParentDepth']} | {a['remedyAliases']} | {a['unscoredLinks']} / {a['conflictingRemedies']} |")
text='''# Repertory comparison and integration — 1.31

Kent's English and Publicum databases and relationship sidecar are byte-identical to the protected baseline. No Kent data replacement or new Kent import was performed.

## Measured comparison

Counts are measured from the actual files, not publishers' marketing totals. Source rows include headings/reference entries; they are not all remedy-bearing clinical rubrics. Old counts are navigation nodes from OCR imports, so this is coverage evidence, not a one-for-one equivalence claim. Distinct remedies count source abbreviations actually used. Scored links count each unambiguous positive remedy association once; raw links include duplicates and unsupported values.

| Imported source | Earlier bundled source | Source rows | Distinct remedies | Scored links | Explicit references (directly resolved) |
|---|---|---:|---:|---:|---:|
'''+ '\n'.join(lines)+'''

## Grading, hierarchy and source anomalies

| Source | Positive grade scale | Navigation chapter groups | Recorded parent links / depth | Alternate remedy names | Unsupported weights / conflicting remedy grades |
|---|---|---:|---:|---:|---:|
'''+ '\n'.join(metrics)+'''

Boericke has an explicit parent hierarchy with no missing parents or detected cycles. BBCR and TPB provide full paths but no explicit parent links in this API snapshot; zero in that column means the field is absent, not that the printed work has no hierarchy. Navigation groups use the first source-path component. Some BBCR sections share the source chapter ID −1; unique application navigation IDs prevent those sections from opening the wrong chapter. Original source IDs remain intact.

## Decisions

- **Boericke:** added as a new searchable repertory. Recorded alternate remedy names participate in search. Explicit cross-references open a uniquely resolved rubric, otherwise a clearly labelled search. No rubric synonyms were invented.
- **BBCR:** the structured source is the preferred picker entry because the earlier OCR dataset explicitly contained only the first printed remedy-list line and provisional case-derived grades. The earlier edition remains under “Earlier editions” and keeps its original identifier so saved cases are not silently rewritten.
- **TPB:** Allen's 1891 edition is added separately. It has recorded grades 1–4 instead of the earlier 1846 OCR import's presence-only grade 1. These are different editions, and OOREP marks Allen's edition under development; it is not represented as a certified complete replacement. The 1846 source remains accessible for saved cases.
- **Phatak:** bibliographic sources found, but no verified redistributable structured export. Not bundled.
- **Synthetic Repertory (Barthel/Klunker):** identified separately from Schroyens' Synthesis. No authorized structured export available. Not bundled.
- **Complete Repertory:** licensed editions identified through Complete Dynamics; no authorized structured export available. Not bundled.

User-confirmed OOREP redistribution permission covers Boericke, BBCR and TPB (2026-10-24). It is not generalized to unrelated proprietary repertories, and these datasets are not labelled GPL merely because OOREP software is GPL.

## Integrity and grading

Every imported source ID, full path, parent identifier, remedy abbreviation, original remedy ID and raw weight was compared with the complete cached API pages. Page hashes and source counts are retained. All raw associations remain in the packaged source records; the scoring list is deliberately stricter:

- Exact duplicate remedy links count once.
- Conflicting grades for the same remedy/rubric remain visible for review and are excluded from scoring. No automatic highest-grade selection.
- Unsupported values, including BBCR weight zero and Boericke weight 30, remain visible and unscored. An independent Boericke transcription shows parenthetical “(30)” beside those five entries, supporting their exclusion as strength grades; this does not certify the original edition's typography.
- Grades 4 and 5 survive case saving, snapshots and encrypted backup validation. Grade 4/5 display has distinct numeric markers and matrix styles. Different books' grade scales are not claimed equivalent. Existing scoring formulas are unchanged.

Navigation groups by chapter and first heading. Full deeper comma paths remain visible in sub-rubric labels, and original source hierarchy/parent IDs are preserved. This is not an arbitrary-depth visual tree rebuild. TPB/BBCR may lack explicit parent IDs even where their full paths encode hierarchy. Only explicitly recorded references and alternate remedy names are added; zero references means none extracted from the provided records, not proof the printed book has none.

Complete source-response comparison is **not** complete printed-book scan verification. Remaining source anomalies are disclosed rather than silently repaired. Exact counts, grade distributions, duplicate paths, excluded values and hierarchy measurements are in the bundled import audit and validation JSON.

## Source research

- OOREP catalogue/edition status and licensing notes: https://www.oorep.com/faq
- Boericke independent transcription: https://www.homeoint.org/books4/boerirep/index.htm
- Weight-30 sample review: https://www.homeoint.org/books4/boerirep/general.htm
- Phatak bibliographic record: https://openlibrary.org/books/OL19437481M
- Synthetic bibliographic record: https://www.ncbi.nlm.nih.gov/nlmcatalog/8908003
- Synthetic publisher listing: https://ibpsbook.com/product/synthetic-repertory-3-vols/
- Complete source catalogue: https://www.completedynamics.com/pages/repertories.php?lang=en&prices=n
- Complete licensing: https://www.completedynamics.com/pages/pricing_licenses.php?lang=en

For the three unavailable modern sources, the next step is a rights-holder-authorized structured export with edition metadata and redistribution rights. It can then undergo the same ID, hierarchy, grade, reference and duplicate audits; download availability alone is not a license or a quality guarantee.
'''
(R/'REPERTORY_COMPARISON_1.31.md').write_text(text)
(R/'CLINICAL_UI_GUIDE_1.31.md').write_text('''# Using the new repertories — 1.31

1. Open Repertory and tap the book name. Choose Boericke, BBCR or Therapeutic Pocket Book — Allen 1891.
2. Select a chapter or search a rubric/remedy. Alternate remedy names supplied by the source also work.
3. Tap a reference link to jump to its resolved entry. When the destination is ambiguous, search opens so you can choose it.
4. Use the source information button to inspect the source and notes. Unscored/conflicting entries are explicitly labelled and excluded from analysis.
5. Add rubrics to your case as before. Grades 4 and 5 retain their numeric values in analysis, saved snapshots and encrypted backups. Grade scales differ between books.
6. For an older saved case, “Earlier editions” contains the previous BBCR OCR and 1846 TPB sources. Existing case entries retain their original source and grades; the app does not silently migrate them.

Kent is unchanged. TPB's provider marks the 1891 edition under development. See REPERTORY_COMPARISON_1.31.md for measured coverage and source limitations. Phatak, Synthetic and Complete are not bundled because no authorized structured export was available.

Install through Menu → App updates, or download the signed APK from the GitHub release. Android asks you to confirm installation. Keep an encrypted backup before any update; retain the existing installed app rather than uninstalling it.
''')
(R/'UPDATE_RELEASE_NOTES_1.31.md').write_text('''Open Repertory 1.31 — audited classical repertory expansion

Adds owner-authorized structured Boericke, BBCR and Allen 1891 Therapeutic Pocket Book datasets with recorded grades, aliases and explicit cross-references. Previous OCR editions remain available for saved cases. Kent databases are unchanged.

Preserves higher grades through analysis, snapshots and encrypted backups. Duplicate remedy links count once; conflicting grades and unsupported weights are retained for review and excluded from scoring. TPB is marked under development by its source. Complete API-record audit, not printed-book scan certification.

Phatak, Synthetic and Complete remain external catalogue entries pending authorized structured exports.

Guide: https://github.com/devil01529/Openrepertory-update/blob/main/CLINICAL_UI_GUIDE_1.31.md
Comparison: https://github.com/devil01529/Openrepertory-update/blob/main/REPERTORY_COMPARISON_1.31.md
''')
