(function(){
  'use strict';
  const OR=window.OR,KEY='openrepertory_drafts',flushers=new Set();
  OR.drafts={
    list:()=>OR.store.get(KEY)||{},
    remove(key){const drafts=this.list();delete drafts[key];if(!OR.store.set(KEY,drafts))return false;OR.lifecycle?.refresh();return true;},
    attach(modal,opts){
      const drafts=this.list(),saved=drafts[opts.draftKey];
      if(saved)modal.querySelectorAll('[data-k]').forEach(el=>{if(saved.values[el.dataset.k]!==undefined)el.value=saved.values[el.dataset.k];});
      const persist=()=>{
        const values={};modal.querySelectorAll('[data-k]').forEach(el=>{values[el.dataset.k]=el.value;});
        const current=OR.drafts.list();current[opts.draftKey]={context:opts.draftContext,values,updatedAt:Date.now()};
        OR.store.set(KEY,current);
      };
      modal.addEventListener('input',persist);modal.addEventListener('change',persist);flushers.add(persist);
      return{discard(){flushers.delete(persist);modal.removeEventListener('input',persist);modal.removeEventListener('change',persist);OR.drafts.remove(opts.draftKey);}};
    }
  };
  OR.flushDrafts=()=>{for(const flush of flushers)flush();if(OR.flushPatientEdits)OR.flushPatientEdits();};
  document.addEventListener('visibilitychange',()=>{if(document.hidden)OR.flushDrafts();});
  window.addEventListener('pagehide',OR.flushDrafts);
  OR.openDrafts=()=>{
    const drafts=OR.drafts.list();
    OR.modal({title:'Saved drafts',html:Object.entries(drafts).map(([key,d])=>`<div class="draft-row"><span>${OR.escapeHTML(d.context.type==='patient'?'New patient':'Visit draft')}</span><button class="primary-btn" data-resume-draft="${OR.escapeHTML(key)}">Resume</button><button class="ghost-btn" data-discard-draft="${OR.escapeHTML(key)}">Discard</button></div>`).join('')||'<p>No drafts remain.</p>',actions:[{label:'Close'}],onMount:(m,close)=>{
      m.querySelectorAll('[data-resume-draft]').forEach(b=>b.onclick=()=>{close();OR.patients.resumeDraft(b.dataset.resumeDraft);});
      m.querySelectorAll('[data-discard-draft]').forEach(b=>b.onclick=async()=>{if(await OR.confirm('Discard draft','Discard this saved draft?','Discard')){OR.drafts.remove(b.dataset.discardDraft);close();OR.openDrafts();}});
    }});
  };
  OR.lifecycle={
    started:false,
    start(){this.started=true;this.refresh();},
    refresh(){
      if(!this.started)return;
      document.getElementById('workRecovery')?.remove();
      const native=window.openrepertorySecure,drafts=Object.keys(OR.drafts.list()).length,pending=native?.pendingExport?native.pendingExport():null;
      const fileMessage=OR.store.get('openrepertory_pending_picker');
      if(!drafts&&!pending&&!fileMessage)return;
      const panel=document.createElement('div');panel.id='workRecovery';panel.className='work-recovery';panel.setAttribute('role','region');panel.setAttribute('aria-label','Saved work and backups');
      if(drafts)panel.innerHTML+=`<span>${drafts} saved draft(s)</span><button id="resumeDrafts" class="ghost-btn">Review drafts</button>`;
      if(pending)panel.innerHTML+='<span>An export was interrupted.</span><button id="resumeExport" class="ghost-btn">Resume export</button><button id="discardExport" class="ghost-btn">Discard export</button>';
      if(fileMessage)panel.innerHTML+='<span>Choose the backup file again to continue an interrupted import.</span><button id="resumePicker" class="ghost-btn">Open backup</button>';
      document.getElementById('toolbar').after(panel);
      if(drafts)panel.querySelector('#resumeDrafts').onclick=OR.openDrafts;
      if(pending){
        panel.querySelector('#resumeExport').onclick=async()=>{try{const result=await ORNativeRequest('resumeExport',[],null,600000);OR.toast(result==='saved'?'Export saved.':'Export cancelled.');this.refresh();}catch(e){ORReportError(e.message);}};
        panel.querySelector('#discardExport').onclick=async()=>{if(await OR.confirm('Discard interrupted export','Remove the retained export? Your saved records remain unchanged.','Discard')){native.discardExport();this.refresh();}};
      }
      if(fileMessage)panel.querySelector('#resumePicker').onclick=()=>{OR.store.set('openrepertory_pending_picker',null);OR.patients.openBackup();this.refresh();};
    }
  };
})();
