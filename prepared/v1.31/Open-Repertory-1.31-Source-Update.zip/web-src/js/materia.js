(function () {
  "use strict";
  // Materia Medica + Differentials.
  // Remedy profiles combine repertory-derived counts, bundled historical passages,
  // source provenance, and the user's own notes.
  const OR = window.OR, S = OR.state, esc = OR.escapeHTML, $ = OR.$;
  const NOTES_KEY = "openrepertory_mmnotes";

  // ---- ask Claude (published artifact only): streams into `box`, returns the final text ----
  function aiErr(e) {
    switch (e && e.code) {
      case "not_granted": OR.ai.denied = true; return "AI wasn't allowed for this session.";
      case "rate_limited": return "AI is busy — try again in a moment.";
      case "cancelled": return "Stopped.";
      default: return "AI couldn't answer this time.";
    }
  }
  function aiButton(btn, box, label, makePrompt, onDone) {
    let ctl = null;
    btn.addEventListener("click", async () => {
      if (ctl) { ctl.abort(); return; }
      if (!OR.aiAvailable()) { box.hidden = false; box.textContent = "AI isn't available in this view."; return; }
      ctl = new AbortController();
      btn.textContent = "Stop";
      box.hidden = false; box.classList.remove("done"); box.textContent = "Thinking…";
      let text = "";
      try {
        const r = await OR.ai.sample(makePrompt(), { modelTier: "default", signal: ctl.signal, onText: ({ text: t }) => { text = t; box.textContent = t; } });
        text = r.text || text; box.textContent = text;
        box.classList.add("done");
      } catch (e) {
        if (e && e.text) { text = e.text; box.textContent = e.text; }
        else { box.textContent = aiErr(e); text = ""; }
      }
      ctl = null;
      btn.textContent = label;
      if (text && onDone) onDone(text);
    });
  }

  OR.mmNotes = {};
  let committedNotes={};
  OR.rememberMMNotes=()=>{committedNotes=ORClone(OR.mmNotes);};
  OR.saveMMNotes = () => {
    if(!OR.store.set(NOTES_KEY,OR.mmNotes)){ORRestoreObject(OR.mmNotes,committedNotes);throw new Error('Remedy notes were not saved.');}
    committedNotes=ORClone(OR.mmNotes);return true;
  };
  OR.hooks.start.push(() => { OR.mmNotes = OR.store.get(NOTES_KEY) || {}; committedNotes=ORClone(OR.mmNotes); });

  // ---------- repertory index: per remedy counts (built once, on first use) ----------
  let idx = null;
  function buildIndex() {
    if (idx) return idx;
    const chs = S.repertory.chapters;
    const map = new Map();
    chs.forEach((ch, ci) => {
      const add = rems => {
        for (let i = 0; i < rems.length; i++) {
          const rm = rems[i];
          let e = map.get(rm.r);
          if (!e) { e = { n: 0, g: [0, 0, 0, 0, 0, 0], ch: new Uint32Array(chs.length) }; map.set(rm.r, e); }
          e.n++; e.g[rm.g]++; e.ch[ci]++;
        }
      };
      ch.rubrics.forEach(r => {
        add(r.remedies || []);
        (r.sub || []).forEach(s => add(s.remedies || []));
      });
    });
    idx = map;
    return map;
  }
  const EMPTY = () => ({ n: 0, g: [0, 0, 0, 0, 0, 0], ch: new Uint32Array(S.repertory.chapters.length) });
  const stat = abbr => (idx && idx.get(abbr)) || EMPTY();

  function allRemedies() {
    const seen = new Set(Object.keys(S.remedies));
    if (idx) idx.forEach((_, k) => seen.add(k));
    return [...seen].map(a => ({ abbr: a, name: S.remedies[a] || a }));
  }

  const subPath = (parent, s) => parent + ", " + s.text.replace(/^\.\s*/, "");
  const uidOf = (chapter, path) => chapter + "||" + path;

  // visit every rubric and sub-rubric: cb(chapterName, path, remediesArray)
  function eachRubric(cb) {
    S.repertory.chapters.forEach(ch => {
      ch.rubrics.forEach(r => {
        if (r.remedies && r.remedies.length) cb(ch.name, r.text, r.remedies);
        (r.sub || []).forEach(s => {
          if (s.remedies && s.remedies.length) cb(ch.name, subPath(r.text, s), s.remedies);
        });
      });
    });
  }

  function whenReady(container, fn) {
    if (!S.repertory) {
      container.innerHTML = `<p class="empty-state">Loading repertory data…</p>`;
      return false;
    }
    if (!idx) {
      container.innerHTML = `<p class="empty-state">Indexing the repertory (first time only)…</p>`;
      setTimeout(() => { buildIndex(); fn(); }, 30);
      return false;
    }
    return true;
  }

  // ================= MATERIA MEDICA =================
  const mmWrap = $("mmWrap"), mmList = $("mmList"), mmDetail = $("mmDetail");
  const MM_PAGE = 150;
  let mmItems = [], mmShown = 0, mmCurrent = null;
  let mmSelectedSource = null;
  let mmSourceOnly = false;
  let mmSource = null;
  let mmSourceError = false;
  let supplementalSource = null;
  let supplementalSourceError = false;
  let heringSource = null;
  let heringSourceError = false;
  let classicalSource = null;
  let classicalSourceError = false;
  OR.hooks.materiaChanged = OR.hooks.materiaChanged || [];
  function notifyMateriaChanged() { OR.hooks.materiaChanged.forEach(fn => { try { fn(); } catch (_) {} }); }
  OR.hooks.casesChanged.push(() => { if (mmCurrent) showRemedy(mmCurrent); });
  const mmSourceFilter = $("mmSourceFilter");
  function sourceRemedyAbbreviations() {
    const abbreviations = new Set((Array.isArray(mmSource?.entries) ? mmSource.entries : []).map(item => item && typeof item.abbreviation === "string" ? item.abbreviation.toLocaleLowerCase() : "").filter(Boolean));
    Object.keys(supplementalSource?.entries || {}).forEach(abbreviation => abbreviations.add(abbreviation.toLocaleLowerCase()));
    Object.keys(heringSource?.entries || {}).forEach(abbreviation => abbreviations.add(abbreviation.toLocaleLowerCase()));
    Object.keys(classicalSource?.entries || {}).forEach(abbreviation => abbreviations.add(abbreviation.toLocaleLowerCase()));
    return abbreviations;
  }
  function updateSourceFilterButton() {
    if (!mmSource && !supplementalSource && !heringSource && !classicalSource) {
      const failed = mmSourceError && supplementalSourceError && heringSourceError && classicalSourceError;
      mmSourceFilter.disabled = !failed;
      mmSourceFilter.textContent = failed ? "Retry" : "Loading…";
      mmSourceFilter.setAttribute("aria-label", failed ? "Retry loading materia medica sources" : "Loading materia medica sources");
      return;
    }
    mmSourceFilter.disabled = false;
    const count = sourceRemedyAbbreviations().size;
    mmSourceFilter.textContent = mmSourceOnly ? "Show all" : `Text only (${count})`;
    mmSourceFilter.setAttribute("aria-pressed", String(mmSourceOnly));
    mmSourceFilter.setAttribute("aria-label", mmSourceOnly ? "Show all remedies" : `Show only the ${count} remedies with source text`);
  }
  mmSourceFilter.addEventListener("click", () => {
    if (!mmSource && !supplementalSource && !heringSource && !classicalSource) {
      mmSourceError = false;
      supplementalSourceError = false;
      heringSourceError = false;
      classicalSourceError = false;
      updateSourceFilterButton();
      loadMateriaSource();
      loadSupplementalMateria();
      loadHeringMateria();
      loadClassicalMateria();
      return;
    }
    mmSourceOnly = !mmSourceOnly;
    updateSourceFilterButton();
    mmRefreshList();
  });
  function loadMateriaSource() {
    mmSourceError = false;
    updateSourceFilterButton();
    return fetch("data/materia_medica.json")
    .then(response => {
      if (!response.ok) throw new Error("Materia medica source is unavailable.");
      return response.json();
    })
    .then(data => { mmSource = data; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); })
    .catch(() => { mmSourceError = true; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); });
  }
  function loadSupplementalMateria() {
    supplementalSourceError = false;
    return fetch("data/materia_medica_supplemental.json")
      .then(response => { if (!response.ok) throw new Error("Supplemental materia medica is unavailable."); return response.json(); })
      .then(data => { supplementalSource = data; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); })
      .catch(() => { supplementalSourceError = true; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); });
  }
  function loadHeringMateria() {
    heringSourceError = false;
    return fetch("data/materia_medica_hering.json")
      .then(response => { if (!response.ok) throw new Error("Hering materia medica is unavailable."); return response.json(); })
      .then(data => { heringSource = data; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); })
      .catch(() => { heringSourceError = true; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); });
  }
  function loadClassicalMateria() {
    classicalSourceError = false;
    return fetch("data/materia_medica_classics.json")
      .then(response => { if (!response.ok) throw new Error("Classical materia medica sources are unavailable."); return response.json(); })
      .then(data => { classicalSource = data; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); })
      .catch(() => { classicalSourceError = true; updateSourceFilterButton(); if (mmCurrent) showRemedy(mmCurrent); if (S.page === "mm") mmRefreshList(); notifyMateriaChanged(); });
  }
  let materiaStarted = false;
  function ensureMateria() {
    if (materiaStarted) return;
    materiaStarted = true;
    loadMateriaSource(); loadSupplementalMateria(); loadHeringMateria(); loadClassicalMateria();
  }


  const classicalRequests = new Map(), classicalCache = [];
  function ensureClassicalEntry(abbr) {
    if (!classicalSource?.shards) return;
    const key = Object.keys(classicalSource.shards).find(k => k.toLowerCase() === String(abbr).toLowerCase());
    if (!key || classicalRequests.has(key)) return;
    const request = fetch(classicalSource.shards[key]).then(r => { if (!r.ok) throw new Error("Source text unavailable"); return r.json(); })
      .then(entries => {
        classicalSource.entries[key] = entries;
        classicalCache.push(key);
        while (classicalCache.length > 12) { const old = classicalCache.shift(); classicalSource.entries[old] = []; classicalRequests.delete(old); }
        if (mmCurrent && mmCurrent.toLowerCase() === key.toLowerCase()) showRemedy(mmCurrent);
        notifyMateriaChanged();
      }).catch(() => { classicalRequests.delete(key); OR.toast("A historical text could not load. Reopen the remedy to retry."); });
    classicalRequests.set(key, request);
  }
  function mergeMateriaSources(entries) {
    const grouped = new Map();
    const idCounts = new Map();
    entries.forEach(entry => {
      const baseId = String(entry.id || "source");
      const identity = [baseId, entry.title, entry.author, entry.year, entry.url].map(value => String(value || "")).join("\u0000");
      const existing = grouped.get(identity);
      if (existing) {
        existing.sections.push(...(Array.isArray(entry.sections) ? entry.sections : []));
        return;
      }
      const count = (idCounts.get(baseId) || 0) + 1;
      idCounts.set(baseId, count);
      const uniqueId = count === 1 ? baseId : `${baseId}:${count}`;
      grouped.set(identity, {
        ...entry,
        id: uniqueId,
        label: count > 1 ? `${entry.label || entry.title} · ${entry.year || count}` : entry.label,
        sections: Array.isArray(entry.sections) ? [...entry.sections] : [],
      });
    });
    return Array.from(grouped.values());
  }

  function materiaTextsFor(abbr) {
    ensureClassicalEntry(abbr);
    const entries = [];
    const oorepEntries = (Array.isArray(mmSource?.entries) ? mmSource.entries : []).filter(item => item && typeof item.abbreviation === "string" && item.abbreviation.toLocaleLowerCase() === abbr.toLocaleLowerCase());
    const boerickeBooks = new Map();
    oorepEntries.forEach(item => {
      const bookId = String(item.bookId || "boericke");
      if (!boerickeBooks.has(bookId)) boerickeBooks.set(bookId, []);
      boerickeBooks.get(bookId).push(item);
    });
    boerickeBooks.forEach((records, bookId) => {
      const book = (Array.isArray(mmSource?.books) ? mmSource.books : []).find(item => String(item.id) === bookId);
      const id = entries.some(item => item.id === "boericke") ? `boericke:${bookId}` : "boericke";
      entries.push({
        id, label: book ? `${book.author || "Boericke"} · ${book.year || 1906}` : "Boericke · 1906", title: book ? book.displayTitle || book.title : "Pocket Manual",
        author: book ? [book.author, book.year].filter(Boolean).join(" · ") : "William Boericke · 1906",
        url: "https://github.com/nondeterministic/oorep", rights: "OOREP marks this source Public; a separate book license is not specified in the database.",
        access: book ? book.access : "Public", sections: records.flatMap(item => Array.isArray(item.sections) ? item.sections : []),
      });
    });
    const entriesFor = source => {
      const records = source?.entries || {};
      const exact = records[abbr];
      if (exact) return exact;
      const key = Object.keys(records).find(candidate => candidate.toLocaleLowerCase() === abbr.toLocaleLowerCase());
      return key ? records[key] : [];
    };
    entriesFor(supplementalSource).forEach(entry => entries.push({
      id: entry.sourceId,
      label: entry.sourceId === "mure" ? "Mure · 1853" : "Anshutz · 1900",
      title: entry.title, author: entry.author, year: entry.year, url: entry.url,
      rights: entry.rights, sections: [{ heading: entry.heading, content: entry.text, children: [] }],
    }));
    entriesFor(heringSource).forEach(entry => entries.push({
      id: entry.sourceId,
      label: entry.label || "Hering · 1872",
      title: entry.title, author: entry.author, year: entry.year, url: entry.url,
      rights: entry.rights, sections: [{ heading: entry.heading, content: entry.text, children: [] }],
    }));
    entriesFor(classicalSource).forEach(entry => entries.push({
      id: entry.sourceId,
      label: entry.label || entry.title,
      title: entry.title, author: entry.author, year: entry.year, url: entry.url,
      rights: entry.rights, sections: [{ heading: entry.heading, content: entry.text, children: [] }],
    }));
    return mergeMateriaSources(entries);
  }

  // Return short source-backed excerpts that best match the same symptom/rubric
  // being compared in Differential. This keeps the mobile matrix readable.
  OR.materiaEvidenceFor = (abbr, symptom) => {
    const tokens = OR.tokenize(symptom).filter(t => t.length >= 4).slice(0, 8);
    return materiaTextsFor(abbr).slice(0, 3).map(entry => {
      const text = (entry.sections || []).map(section => `${section.heading || ""}. ${section.content || ""}`).join(" ")
        .replace(/\s+/g, " ").trim();
      const sentences = text.split(/(?<=[.!?])\s+/).filter(Boolean);
      const best = sentences.map(sentence => ({ sentence, score: tokens.reduce((n, token) => n + (sentence.toLocaleLowerCase().includes(token) ? 1 : 0), 0) }))
        .sort((a, b) => b.score - a.score || a.sentence.length - b.sentence.length)[0];
      const excerpt = best && best.score ? best.sentence : text.slice(0, 210);
      return { label: entry.label, text: excerpt ? `${excerpt.slice(0, 210)}${excerpt.length > 210 ? "…" : ""}` : "Source text available." };
    });
  };

  // Historical OCR is stored from several sources with different conventions.
  // Normalize it at the shared presentation boundary so every source is readable
  // without rewriting the underlying public-domain records or touching Kent data.
  function normalizeMateriaText(value) {
    let text = String(value == null ? "" : value)
      .replace(/\r\n?/g, "\n")
      .replace(/[\u00a0\u2007\u202f]/g, " ")
      .replace(/[\u00ad\u034f]/g, "")
      // Some OCR exports contain literal escape markers and HTML entities.
      .replace(/\\/g, "")
      .replace(/\^/g, "")
      .replace(/\|/g, " ");
    const decoder = document.createElement("textarea");
    decoder.innerHTML = text;
    text = decoder.value;
    // Rejoin words split at a scanned line boundary, then remove standalone
    // page numbers and normalize whitespace while retaining paragraph breaks.
    text = text.replace(/([A-Za-zÀ-ÖØ-öø-ÿ])-\s*\n\s*([A-Za-zÀ-ÖØ-öø-ÿ])/g, "$1$2");
    text = text.split(/\n\s*\n+/).map(paragraph => {
      const lines = paragraph.split("\n").map(line => line.trim()).filter(line => line && !/^\d{1,4}$/.test(line));
      return lines.join(" ").replace(/[ \t]{2,}/g, " ").trim();
    }).filter(Boolean).join("\n\n");
    return text;
  }

  function renderMateriaContent(value) {
    return normalizeMateriaText(value).split(/\n\n+/).map(paragraph => `<p>${esc(paragraph)}</p>`).join("");
  }

  function renderMateriaText(entry) {
    const renderSections = sections => (Array.isArray(sections) ? sections : []).filter(section => section && typeof section === "object").map(section => `
      <section class="oorep-mm-section">
        ${section.heading ? `<h5>${esc(normalizeMateriaText(section.heading))}</h5>` : ""}
        ${section.content ? `<div class="oorep-mm-content">${renderMateriaContent(section.content)}</div>` : ""}
        ${section.children && section.children.length ? renderSections(section.children) : ""}
      </section>`).join("");
    const sourceLabel = entry.id.startsWith("boericke") ? "BOERICKE SOURCE TEXT" : /hering/i.test(String(entry.author || "")) ? "HERING SOURCE TEXT" : "HISTORICAL SOURCE TEXT";
    return `<div class="oorep-mm-source">
      <div class="oorep-mm-source-head"><span>${sourceLabel}</span><b>${esc(entry.title)}</b>
      <small>${esc(entry.author)}${entry.access ? ` · ${esc(entry.access)}` : ""}</small></div>
      ${renderSections(entry.sections)}
      <p class="oorep-mm-credit">${esc(entry.rights)} Source: ${/^https?:\/\//i.test(String(entry.url || "")) ? `<a href="${esc(entry.url)}" target="_blank" rel="noopener noreferrer">${entry.id.startsWith("boericke") ? "OOREP database" : "source record"}</a>` : "source record unavailable"}. Historical reference, not medical advice.</p>
    </div>`;
  }

  function sourceMateria(entries) {
    if (!entries.length) {
      const loading = (!mmSource && !mmSourceError) || (!supplementalSource && !supplementalSourceError) || (!heringSource && !heringSourceError) || (!classicalSource && !classicalSourceError);
      const failed = mmSourceError || supplementalSourceError || heringSourceError || classicalSourceError;
      const message = loading ? "Loading remedy source texts…" : failed
        ? `A materia medica source could not be loaded. <button id="oorepMateriaRetry" type="button">Retry</button>`
        : `<b>No bundled source text yet</b><p>This remedy is still searchable in the repertory. No materia medica passage is fabricated when a source text is unavailable.</p>`;
      return `<div class="oorep-mm-source mm-source-unavailable" role="status">${message}</div>`;
    }
    const selected = entries.find(entry => entry.id === mmSelectedSource) || entries.find(entry => entry.id === "boericke") || entries[0];
    return `<div class="mm-source-view">
      ${entries.length > 1 ? `<div class="mm-source-tabs" role="group" aria-label="Materia medica sources">${entries.map((entry, index) => `<button type="button" class="mm-source-tab ${entry.id === selected.id ? "active" : ""}" aria-pressed="${entry.id === selected.id}" aria-controls="mmSourceContent" data-source-index="${index}">${esc(entry.label)}</button>`).join("")}</div>` : ""}
      <div id="mmSourceContent" role="tabpanel">${renderMateriaText(selected)}</div>
    </div>`;
  }

  function mmRefreshList() {
    if (!whenReady(mmList, mmRefreshList)) return;
    if (mmSourceOnly && !mmSource && !supplementalSource && !heringSource && !classicalSource) {
      const failed = mmSourceError && supplementalSourceError && heringSourceError && classicalSourceError;
      $("mmCount").textContent = failed ? "Materia sources unavailable" : "Loading remedy texts…";
      mmList.innerHTML = `<p class="empty-state">${failed ? "Materia medica sources couldn't be loaded. Use Retry above." : "Loading remedy source texts…"}</p>`;
      return;
    }
    const tokens = OR.tokenize($("mmSearch").value);
    const sort = $("mmSort").value;
    const sourceRemedies = sourceRemedyAbbreviations();
    let items = allRemedies().map(r => Object.assign(r, {
      n: stat(r.abbr).n,
      hasMateria: sourceRemedies.has(r.abbr.toLocaleLowerCase()),
    }));
    if (mmSourceOnly) {
      items = items.filter(item => item.hasMateria);
    }
    if (tokens.length) {
      items = items.filter(r => {
        const hay = (r.abbr + " " + r.name + " " + (S.repertory?.remedyAliases?.[r.abbr]?.aliases || []).join(" ")).toLowerCase();
        return tokens.every(t => hay.indexOf(t) !== -1);
      });
    }
    if (sort === "notes") items = items.filter(r => OR.mmNotes[r.abbr]);
    if (sort === "rubrics") items.sort((a, b) => b.n - a.n || a.name.localeCompare(b.name));
    else items.sort((a, b) => a.name.localeCompare(b.name));
    mmItems = items;
    mmShown = 0;
    mmList.innerHTML = "";
    const withText = items.filter(item => item.hasMateria).length;
    $("mmCount").textContent = `${items.length.toLocaleString()} remed${items.length === 1 ? "y" : "ies"} · ${withText.toLocaleString()} with source text`;
    if (!items.length) {
      mmList.innerHTML = `<p class="empty-state">${mmSourceOnly ? "No source-backed remedy entries match this search." : sort === "notes" ? "You haven't written any remedy notes yet." : "No remedies match."}</p>`;
      return;
    }
    mmMore();
  }

  function mmMore() {
    const old = mmList.querySelector(".more-wrap");
    if (old) old.remove();
    const end = Math.min(mmItems.length, mmShown + MM_PAGE);
    let html = "";
    for (let i = mmShown; i < end; i++) {
      const r = mmItems[i];
      html += `<button type="button" class="mm-row ${mmCurrent === r.abbr ? "active" : ""}" data-abbr="${esc(r.abbr)}">
        <span class="mm-row-label"><span class="mm-name">${esc(r.name)}</span><span class="mm-abbr">${esc(r.abbr)}</span></span>
        <span class="mm-source-availability ${r.hasMateria ? "available" : "unavailable"}" title="${r.hasMateria ? "Bundled source text is available" : "No bundled source text yet"}">${r.hasMateria ? "Text" : "No text"}</span>
        ${OR.mmNotes[r.abbr] ? `<span class="mm-note" title="You have private notes">Notes</span>` : ""}
        <span class="remedy-count" title="Rubrics containing this remedy">${r.n.toLocaleString()}</span></button>`;
    }
    mmList.insertAdjacentHTML("beforeend", html);
    mmShown = end;
    if (mmShown < mmItems.length) {
      const w = document.createElement("div");
      w.className = "more-wrap";
      w.innerHTML = `<button type="button" class="more-btn">Show more (${(mmItems.length - mmShown).toLocaleString()} remaining)</button>`;
      w.firstElementChild.addEventListener("click", mmMore);
      mmList.appendChild(w);
    }
  }

  // Keep browsing tools together without repeating introductory cards.
  const clearSearch=document.createElement('button');clearSearch.id='mmClearSearch';clearSearch.type='button';clearSearch.className='icon-btn small';clearSearch.textContent='×';clearSearch.setAttribute('aria-label','Clear remedy search');clearSearch.hidden=true;
  $('mmSearch').parentElement.appendChild(clearSearch);
  clearSearch.onclick=()=>{$('mmSearch').value='';clearSearch.hidden=true;mmRefreshList();$('mmSearch').focus();};
  $('mmSearch').addEventListener('input',()=>{clearSearch.hidden=!$('mmSearch').value;});
  $('mmListPane').querySelector('.mm-tools').appendChild(mmSourceFilter);
  $('mmListPane').querySelector('.mm-source-filter-entry').remove();
  $('mmCount').setAttribute('role','status');
  let mmReaderView='read';
  let mmDeb;
  $("mmSearch").addEventListener("input", () => { clearTimeout(mmDeb); mmDeb = setTimeout(mmRefreshList, 150); });
  $("mmSort").addEventListener("change", mmRefreshList);
  mmList.addEventListener("click", e => {
    const row = e.target.closest(".mm-row");
    if (!row) return;
    mmList.querySelectorAll(".mm-row.active").forEach(x => x.classList.remove("active"));
    row.classList.add("active");
    showRemedy(row.dataset.abbr);
  });

  function showRemedy(abbr) {
    const sameRemedy = mmCurrent === abbr;
    const previousScroll = sameRemedy ? mmDetail.scrollTop : 0;
    const noteFocus = sameRemedy && document.activeElement?.id === "mmPersonalNotes" ? {start:document.activeElement.selectionStart,end:document.activeElement.selectionEnd} : null;
    if(!sameRemedy)mmReaderView="read";
    mmCurrent = abbr;
    mmWrap.classList.add("detail-open");
    const name = S.remedies[abbr] || abbr;
    const materiaEntries = materiaTextsFor(abbr);
    const caseMatches = (OR.activeCase() && OR.activeCase().analysis || []).map(item => {
      const hit = (item.remedies || []).find(rm => rm.r === abbr);
      return hit ? { item, grade: hit.g } : null;
    }).filter(Boolean);
    mmDetail.innerHTML = `
      <div class="mm-inner">
        <button class="ghost-btn mm-back" id="mmBack" type="button">← All remedies</button>
        <div class="mm-profile-hero"><div><span class="eyebrow">REMEDY PROFILE</span><h2 class="mm-title">${esc(name)}</h2><div class="muted">abbreviation: <b>${esc(abbr)}</b></div></div><button class="ghost-btn" id="mmOpenAnalysis" type="button">Open analysis</button></div>
        <div class="stat-chips mm-profile-stats"><div><b>${stat(abbr).n.toLocaleString()}</b><span>rubric links</span></div><div><b>${materiaEntries.length}</b><span>source${materiaEntries.length === 1 ? "" : "s"}</span></div><div><b>${stat(abbr).g[S.repertory?.gradeRange?.[1] || 3] || 0}</b><span>grade ${S.repertory?.gradeRange?.[1] || 3}</span></div><div><b>${S.repertory ? esc(String(S.repertory.year || "—")) : "—"}</b><span>repertory edition</span></div></div>
        ${caseMatches.length ? `<section class="mm-case-evidence"><div class="dashboard-card-head"><h3>Why this remedy scored</h3><span class="status-pill good">${caseMatches.length} MATCH${caseMatches.length === 1 ? "" : "ES"}</span></div><p class="muted small-note">Selected-case evidence from ${esc(S.repertories?.[OR.activeCase()?.repertoryId]?.title || OR.activeCase()?.repertoryId || "saved source")}.</p><div class="mm-match-list">${caseMatches.map(x => `<div class="mm-match-row"><span><b>${esc(x.item.chapter)}</b><small>${esc(x.item.text)}</small></span><strong class="g${x.grade}">${OR.activeCase()?.repertoryId === "clarke" ? "Present" : "Grade " + x.grade}</strong><button class="mini-btn plain" type="button" data-mm-rubric="${esc(x.item.text)}">View rubric</button></div>`).join("")}</div></section>` : `<section class="mm-case-evidence muted"><b>No active-case match selected.</b><p class="small-note">Open Analysis to see how this remedy relates to the current case.</p></section>`}
        ${(S.repertory?.remedyAliases?.[abbr]?.aliases || []).length ? `<section class="mm-source-aliases"><b>Source-recorded alternate names</b><p>${(S.repertory.remedyAliases[abbr].aliases).map(esc).join(" · ")}</p><small>From OOREP remedy records; these are remedy synonyms, not equivalent rubrics.</small></section>` : ""}
        ${sourceMateria(materiaEntries)}
        <details class="mm-personal-notes"><summary>Your private notes</summary><label class="fld"><span>Notes about ${esc(name)}</span><textarea id="mmPersonalNotes" rows="5">${esc(OR.mmNotes[abbr]||"")}</textarea></label><p id="mmPersonalNoteStatus" role="status" class="small-note">Notes stay on this phone and are included in encrypted backups.</p></details>
        <div class="mm-related-action"><p>Related repertory rubrics stay hidden until you request them.</p><button class="primary-btn" id="mmFind" type="button">Show all related rubrics</button></div>
      </div>`;
    const inner=mmDetail.querySelector('.mm-inner');
    const readerNav=document.createElement('div');readerNav.className='mm-reader-tabs';readerNav.setAttribute('role','tablist');readerNav.setAttribute('aria-label','Remedy profile views');
    const views=[['read','Read'],['case','Case links'],['notes','My notes']];
    views.forEach(([key,label])=>{const button=document.createElement('button');button.type='button';button.id='mm-tab-'+key;button.textContent=label;button.setAttribute('role','tab');button.dataset.view=key;button.setAttribute('aria-controls','mm-view-'+key);readerNav.appendChild(button);const panel=document.createElement('section');panel.id='mm-view-'+key;panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',button.id);inner.appendChild(panel);});
    inner.querySelector('.mm-profile-hero').after(readerNav);
    ['.mm-source-aliases','.mm-source-view','.mm-source-unavailable'].forEach(sel=>{const el=inner.querySelector(sel);if(el)$('mm-view-read').appendChild(el);});
    ['#mmOpenAnalysis','.mm-profile-stats','.mm-case-evidence','.mm-related-action'].forEach(sel=>{const el=inner.querySelector(sel);if(el)$('mm-view-case').appendChild(el);});
    const notes=inner.querySelector('.mm-personal-notes');notes.open=true;$('mm-view-notes').appendChild(notes);
    function setView(key,focus){mmReaderView=key;views.forEach(([v])=>{const active=v===key;$('mm-view-'+v).hidden=!active;const tab=$('mm-tab-'+v);tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;});if(focus)$('mm-tab-'+key).focus();}
    readerNav.addEventListener('click',event=>{const button=event.target.closest('[data-view]');if(button)setView(button.dataset.view,false);});
    readerNav.addEventListener('keydown',event=>{const index=views.findIndex(v=>v[0]===mmReaderView);let next=index;if(event.key==='ArrowRight')next=(index+1)%3;else if(event.key==='ArrowLeft')next=(index+2)%3;else if(event.key==='Home')next=0;else if(event.key==='End')next=2;else return;event.preventDefault();setView(views[next][0],true);});
    function sectionPicker(){
      const existing=$('mmSectionPicker');if(existing)existing.remove();
      const content=$('mmSourceContent');if(!content)return;
      const headings=[...content.querySelectorAll('h5')];if(!headings.length)return;
      const label=document.createElement('div');label.id='mmSectionPicker';label.className='mm-section-picker';
      const trigger=document.createElement('button');trigger.type='button';trigger.className='ghost-btn mm-section-trigger';trigger.textContent='Jump to section';trigger.setAttribute('aria-haspopup','dialog');trigger.setAttribute('aria-expanded','false');label.appendChild(trigger);content.before(label);
      let selected=-1;
      trigger.onclick=()=>{
        trigger.setAttribute('aria-expanded','true');
        OR.modal({title:'Jump to section',html:'<label class="mm-section-search"><span>Find a section</span><input type="search" placeholder="Search section headings…" autocomplete="off"></label><div class="mm-section-options"></div><p class="mm-section-empty" role="status" hidden>No matching sections.</p>',noFocus:true,
          onMount:(modal,close)=>{
            modal.classList.add('mm-section-dialog');
            const list=modal.querySelector('.mm-section-options');
            headings.forEach((heading,index)=>{const row=document.createElement('button');row.type='button';row.className='mm-section-option';row.setAttribute('aria-current',String(index===selected));const text=document.createElement('span');text.textContent=heading.textContent;row.appendChild(text);const mark=document.createElement('span');mark.className='mm-section-mark';mark.setAttribute('aria-hidden','true');mark.textContent=index===selected?'✓':'›';row.appendChild(mark);list.appendChild(row);
              row.onclick=()=>{close();if(!heading.isConnected)return;selected=index;trigger.textContent='Section: '+heading.textContent;heading.setAttribute('tabindex','-1');heading.focus({preventScroll:true});mmDetail.scrollTop+=heading.getBoundingClientRect().top-mmDetail.getBoundingClientRect().top-12;};
            });
            modal.querySelector('input').addEventListener('input',event=>{const query=event.target.value.trim().toLocaleLowerCase();let visible=0;[...list.children].forEach((row,index)=>{row.hidden=!headings[index].textContent.toLocaleLowerCase().includes(query);if(!row.hidden)visible++;});modal.querySelector('.mm-section-empty').hidden=visible!==0;});
          },onClose:()=>trigger.setAttribute('aria-expanded','false')});
      };

    }
    setView(mmReaderView,false);sectionPicker();
    mmDetail.scrollTop = previousScroll;

    const materiaRetry = $("oorepMateriaRetry");
    if (materiaRetry) materiaRetry.addEventListener("click", () => {
      materiaRetry.disabled = true;
      materiaRetry.textContent = "Loading…";
      loadMateriaSource();
      loadSupplementalMateria();
      loadHeringMateria();
      loadClassicalMateria();
    });

    const sourceTabs = mmDetail.querySelector(".mm-source-tabs");
    if (sourceTabs) sourceTabs.addEventListener("click", event => {
      const button = event.target.closest("[data-source-index]");
      if (!button) return;
      const selected = materiaEntries[Number(button.dataset.sourceIndex)];
      if (!selected) return;
      mmSelectedSource = selected.id;
      sourceTabs.querySelectorAll(".mm-source-tab").forEach(tab => {
        const active = tab === button;
        tab.classList.toggle("active", active);
        tab.setAttribute("aria-pressed", String(active));
      });
      const content = mmDetail.querySelector("#mmSourceContent");
      if (content) content.innerHTML = renderMateriaText(selected);
      sectionPicker();
    });

    if(noteFocus){$("mmPersonalNotes").focus();$("mmPersonalNotes").setSelectionRange(noteFocus.start,noteFocus.end);mmDetail.scrollTop=previousScroll;}
    $("mmPersonalNotes").addEventListener("input",()=>{
      OR.mmNotes[abbr]=$("mmPersonalNotes").value;
      try{OR.saveMMNotes();$("mmPersonalNoteStatus").textContent="Saved on this phone";}
      catch(error){$("mmPersonalNoteStatus").textContent="Not saved — keep this note open and edit again to retry";ORReportError(error.message);}
    });
    $("mmBack").addEventListener("click", () => mmWrap.classList.remove("detail-open"));
    $("mmOpenAnalysis").addEventListener("click", () => OR.showPage("analysis"));
    $("mmFind").addEventListener("click", () => OR.findRemedy(abbr));
    mmDetail.querySelectorAll("[data-mm-rubric]").forEach(button => button.addEventListener("click", () => { OR.showPage("repertory"); OR.runSearch(button.dataset.mmRubric); }));
  }

  // Rubric remedy buttons open the remedy profile directly. Reverse rubric
  // lookup remains available only through the explicit button in that profile.
  OR.openMateriaRemedy = abbr => {
    if (!abbr) return;
    OR.showPage("mm");
    showRemedy(abbr);
  };
  OR.refreshMateria = () => {
    if (mmCurrent) showRemedy(mmCurrent);
    if (S.page === "mm") mmRefreshList();
  };

  // a rubric line with an "+ Add" button that adds it to the active case
  function rubricRow(it, i, tag) {
    const on = OR.hasRubric(uidOf(it.chapter, it.path));
    return `<div class="rr">
      <div class="rr-main"><span class="rr-ch">${esc(it.chapter)}</span><span class="rr-path">${esc(it.path)}</span>
        <span class="rr-meta">${it.total} remed${it.total === 1 ? "y" : "ies"}${it.extra || ""}</span></div>
      <button type="button" class="add-btn ${on ? "added" : ""}" data-add="${tag}:${i}">${on ? "✓ Added" : "+ Add"}</button></div>`;
  }
  function handleAdd(e, resolve) {
    const b = e.target.closest("[data-add]");
    if (!b) return;
    const cut = b.dataset.add.lastIndexOf(":");
    const tag = b.dataset.add.slice(0, cut), i = b.dataset.add.slice(cut + 1);
    const it = resolve(tag, +i);
    if (!it) return;
    OR.toggleRubric(uidOf(it.chapter, it.path), it.chapter, it.path, it.rems);
    const on = OR.hasRubric(uidOf(it.chapter, it.path));
    b.classList.toggle("added", on);
    b.textContent = on ? "✓ Added" : "+ Add";
    const c = OR.activeCase();
    if (on) OR.toast(`Added to case “${c ? c.name : ""}”.`, "Open Analysis", () => OR.showPage("analysis"));
  }
  OR.pages.mm = {
    onShow() { ensureMateria(); mmRefreshList(); },
    onData() { mmRefreshList(); }
  };

  // ================= DIFFERENTIALS =================
  const diffRoot = $("diffRoot");
  let diffSel = [];
  let diffReg = { d: {}, s: [] };
  const MAX_DIFF = 4;

  function addToDiff(abbr) {
    if (diffSel.indexOf(abbr) === -1 && diffSel.length < MAX_DIFF) diffSel.push(abbr);
  }

  function renderDiffShell() {
    const c = OR.activeCase();
    const canCase = !!(c && c.analysis.length);
    diffRoot.innerHTML = `
      <div class="diff-wrap">
        <p class="muted intro">Pick 2–${MAX_DIFF} remedies to see how they differ in the repertory: what they share, what only one of them has, and how each one covers the rubrics of the active case.</p>
        <div class="diff-pick">
          <div class="search-wrap light" style="flex:1 1 220px;position:relative">
            <input id="diffSearch" type="text" placeholder="Add a remedy (name or abbreviation)…" autocomplete="off">
          </div>
          <button class="ghost-btn" id="diffFromCase" type="button" ${canCase ? "" : "disabled"}>Top ${MAX_DIFF} from case</button>
          <button class="ghost-btn" id="diffClear" type="button" ${diffSel.length ? "" : "disabled"}>Clear</button>
        </div>
        <div id="diffSuggest" class="suggest" style="display:none"></div>
        <div id="diffChips" class="chips"></div>
        <div id="diffResults"></div>
      </div>`;
    renderChips();

    const inp = $("diffSearch");
    inp.addEventListener("input", () => {
      const tokens = OR.tokenize(inp.value);
      const box = $("diffSuggest");
      if (!tokens.length) { box.style.display = "none"; return; }
      const found = allRemedies().filter(r => {
        const hay = (r.abbr + " " + r.name + " " + (S.repertory?.remedyAliases?.[r.abbr]?.aliases || []).join(" ")).toLowerCase();
        return diffSel.indexOf(r.abbr) === -1 && tokens.every(t => hay.indexOf(t) !== -1);
      }).slice(0, 8);
      box.innerHTML = found.length
        ? found.map(r => `<button type="button" data-abbr="${esc(r.abbr)}"><b>${esc(r.name)}</b> <span class="muted">${esc(r.abbr)}</span></button>`).join("")
        : `<div class="muted small-note" style="padding:8px 12px">No matching remedy.</div>`;
      box.style.display = "";
    });
    $("diffSuggest").addEventListener("click", e => {
      const b = e.target.closest("button[data-abbr]");
      if (!b) return;
      if (diffSel.length >= MAX_DIFF) { OR.toast(`You can compare up to ${MAX_DIFF} remedies.`); return; }
      addToDiff(b.dataset.abbr);
      inp.value = "";
      $("diffSuggest").style.display = "none";
      renderChips(); computeDiff();
    });
    $("diffFromCase").addEventListener("click", () => {
      const cc = OR.activeCase();
      diffSel = OR.rankCase(cc).slice(0, MAX_DIFF).map(r => r.abbr);
      renderChips(); computeDiff();
    });
    $("diffClear").addEventListener("click", () => { diffSel = []; renderChips(); computeDiff(); });
  }

  function renderChips() {
    const box = $("diffChips");
    if (!box) return;
    box.innerHTML = diffSel.map(a => `<span class="chip">${esc(S.remedies[a] || a)} <span class="muted">${esc(a)}</span>
      <button type="button" data-rm="${esc(a)}" aria-label="Remove ${esc(a)}">✕</button></span>`).join("") ||
      `<span class="muted small-note">No remedies selected yet.</span>`;
    box.querySelectorAll("[data-rm]").forEach(b => b.addEventListener("click", () => {
      diffSel = diffSel.filter(x => x !== b.dataset.rm);
      renderChips(); computeDiff();
    }));
    const clr = $("diffClear");
    if (clr) clr.disabled = !diffSel.length;
  }

  const gradeChip = (abbr, g) => `<span class="rem g${g}">${esc(abbr)}</span>`;

  function materiaDiffRows(selected, shared, dist) {
    const c = OR.activeCase();
    if (c && c.analysis.length) return c.analysis.slice(0, 40).map((it, i) => ({ label: `${i + 1}. ${it.text}`, rems: it.remedies || [] }));
    const rows = [];
    shared.slice(0, 12).forEach(it => rows.push({ label: it.path, rems: it.rems || [] }));
    selected.forEach(a => (dist[a] || []).slice(0, 5).forEach(it => rows.push({ label: it.path, rems: it.rems || [] })));
    return rows.slice(0, 32);
  }

  function renderMateriaDiff(selected, shared, dist) {
    const rows = materiaDiffRows(selected, shared, dist);
    if (!rows.length) return `<div class="mm-diff-card"><h4 class="mh">Materia Medica alongside symptoms</h4><p class="empty-state">Add rubrics to the active case to align symptom rows with Materia Medica evidence.</p></div>`;
    const headers = selected.map(abbr => `<th>${esc(S.remedies[abbr] || abbr)}<br><span class="muted">${esc(abbr)}</span></th>`).join("");
    const body = rows.map(row => {
      const cells = selected.map(abbr => {
        const rm = row.rems.find(item => item.r === abbr);
        const evidence = OR.materiaEvidenceFor ? OR.materiaEvidenceFor(abbr, row.label) : [];
        const evidenceHTML = evidence.length
          ? evidence.map(item => `<div class="mm-diff-evidence"><b>${esc(item.label)}</b><span>${esc(item.text)}</span></div>`).join("")
          : `<span class="muted small-note">No loaded source excerpt</span>`;
        return `<td class="mm-diff-cell">${rm ? `<div class="mm-diff-grade">${gradeChip(abbr, rm.g)} <span class="muted">grade ${rm.g}</span></div>` : `<div class="mm-diff-grade muted">Not in rubric</div>`}${evidenceHTML}</td>`;
      }).join("");
      return `<tr><th class="mm-diff-symptom">${esc(row.label)}</th>${cells}</tr>`;
    }).join("");
    return `<section class="mm-diff-card"><h4 class="mh">Materia Medica alongside the same symptoms</h4>
      <p class="muted small-note">Each column is one selected remedy. Rows use the active case rubrics; the excerpt is matched to the symptom when source text is available.</p>
      <div class="mm-diff-scroll"><table class="mm-diff-table"><thead><tr><th class="mm-diff-symptom">Symptom / rubric</th>${headers}</tr></thead><tbody>${body}</tbody></table></div>
    </section>`;
  }

  function computeDiff() {
    const out = $("diffResults");
    if (!out) return;
    if (diffSel.length < 2) {
      out.innerHTML = `<p class="empty-state">${diffSel.length ? "Add at least one more remedy to compare." : "Select remedies above to compare them."}</p>`;
      return;
    }
    if (!whenReady(out, computeDiff)) return;

    const sel = diffSel.slice(), set = new Set(sel), k = sel.length;
    const shared = [], dist = {};
    sel.forEach(a => { dist[a] = []; });
    eachRubric((chapter, path, rems) => {
      let count = 0, minG = 9, only = null, onlyG = 0;
      const gm = {};
      for (let i = 0; i < rems.length; i++) {
        const rm = rems[i];
        if (set.has(rm.r)) { count++; gm[rm.r] = rm.g; if (rm.g < minG) minG = rm.g; only = rm.r; onlyG = rm.g; }
      }
      if (!count) return;
      if (count === k) {
        if (minG >= 2) shared.push({ chapter, path, total: rems.length, rems, gm });
      } else if (count === 1 && onlyG >= 2) {
        dist[only].push({ chapter, path, total: rems.length, rems, g: onlyG });
      }
    });
    shared.sort((a, b) => a.total - b.total);
    diffReg = { d: {}, s: shared.slice(0, 15) };

    // --- comparison table
    const chs = S.repertory.chapters;
    const cols = sel.map(a => {
      const e = stat(a);
      const chTop = [...e.ch].map((c, i) => ({ c, name: chs[i].name })).filter(x => x.c).sort((x, y) => y.c - x.c).slice(0, 3);
      return { a, e, chTop };
    });
    const th = cols.map(c => `<th>${esc(S.remedies[c.a] || c.a)}<br><span class="muted">${esc(c.a)}</span></th>`).join("");
    const cmp = `<div class="grid-scroll"><table class="results-table cmp">
      <thead><tr><th></th>${th}</tr></thead><tbody>
      <tr><td class="lbl">Rubrics</td>${cols.map(c => `<td>${c.e.n.toLocaleString()}</td>`).join("")}</tr>
      ${[5,4].filter(g=>cols.some(c=>c.e.g[g])).map(g=>`<tr><td class="lbl">Grade ${g}</td>${cols.map(c=>`<td>${c.e.g[g].toLocaleString()}</td>`).join("")}</tr>`).join("")}
      <tr><td class="lbl">Grade 3</td>${cols.map(c => `<td>${c.e.g[3].toLocaleString()}</td>`).join("")}</tr>
      <tr><td class="lbl">Grade 2</td>${cols.map(c => `<td>${c.e.g[2].toLocaleString()}</td>`).join("")}</tr>
      <tr><td class="lbl">Strongest chapters</td>${cols.map(c => `<td class="small-cell">${c.chTop.map(x => `${esc(x.name)} <span class="muted">${x.c.toLocaleString()}</span>`).join("<br>") || "—"}</td>`).join("")}</tr>
      <tr><td class="lbl">Only this one</td>${cols.map(c => `<td>${dist[c.a].length.toLocaleString()} <span class="muted small-note">rubrics (grade ≥ 2)</span></td>`).join("")}</tr>
      </tbody></table></div>`;

    // --- case coverage
    let caseHTML = "";
    const cs = OR.activeCase();
    if (cs && cs.analysis.length) {
      const rows = cs.analysis.map((it, i) => {
        const cells = sel.map(a => {
          const rm = (it.remedies || []).find(r => r.r === a);
          return `<td class="cell ${rm ? "g" + rm.g : ""}">${rm ? rm.g : ""}</td>`;
        }).join("");
        return `<tr><td class="lbl small-cell"><span class="muted">${i + 1}.</span> ${esc(it.text)}${(it.w || 1) > 1 ? ` <span class="v-fu">×${it.w}</span>` : ""}</td>${cells}</tr>`;
      }).join("");
      const tot = sel.map(a => {
        let n = 0, p = 0;
        cs.analysis.forEach(it => { const rm = (it.remedies || []).find(r => r.r === a); if (rm) { n++; p += rm.g * (it.w || 1); } });
        return `<td class="score"><b>${n}/${cs.analysis.length}</b><br><span class="muted small-note">${p} pts</span></td>`;
      }).join("");
      caseHTML = `<details class="dsec" open><summary>Coverage of case “${esc(cs.name)}”</summary>
        <div class="grid-scroll"><table class="results-table cmp"><thead><tr><th>Rubric</th>${th}</tr></thead>
        <tbody>${rows}<tr class="tot"><td class="lbl">Coverage</td>${tot}</tr></tbody></table></div></details>`;
    }

    // --- shared
    const sharedHTML = `<details class="dsec" open><summary>Rubrics they all share <span class="tab-badge">${shared.length.toLocaleString()}</span></summary>
      <p class="muted small-note">All ${k} remedies at recorded grade ≥ 2. Smallest rubrics first — a small shared rubric points to real common ground.</p>
      ${diffReg.s.length ? diffReg.s.map((it, i) => rubricRow(Object.assign({}, it, {
        extra: " · " + sel.map(a => gradeChip(a, it.gm[a])).join(" ")
      }), i, "s")).join("") : `<p class="muted small-note">No rubric contains all of them at grade 2 or higher.</p>`}</details>`;

    // --- distinguishing
    let distHTML = "";
    sel.forEach(a => {
      const arr = dist[a].sort((x, y) => y.g - x.g || x.total - y.total).slice(0, 12);
      diffReg.d[a] = arr;
      distHTML += `<details class="dsec" open><summary>Only ${esc(S.remedies[a] || a)} <span class="tab-badge">${dist[a].length.toLocaleString()}</span></summary>
        <p class="muted small-note">Rubrics where ${esc(a)} appears (recorded grade ≥ 2) and none of the others do. Higher recorded grades first, then smallest rubrics.</p>
        ${arr.length ? arr.map((it, i) => rubricRow(Object.assign({}, it, { extra: " · " + gradeChip(a, it.g) }), i, "d~" + a)).join("")
          : `<p class="muted small-note">Nothing distinctive found.</p>`}</details>`;
    });

    const aiBlock = OR.ai.sample ? `<div class="btn-row"><button class="ghost-btn" id="diffAI" type="button">✨ Explain the differences</button></div>
      <div id="diffAIBox" class="ai-out" hidden></div>` : "";
    const materiaDiffHTML = renderMateriaDiff(sel, shared, dist);
    out.innerHTML = `${aiBlock}<h4 class="mh">Comparison</h4>${cmp}${caseHTML}${materiaDiffHTML}${sharedHTML}<h4 class="mh">What separates them</h4>${distHTML}
      <p class="muted small-note" style="margin-top:14px">Tables are derived from repertory data only — a study aid for comparing remedies, not a prescribing recommendation.</p>`;
    wireDiffAI(sel, cols, dist, shared.length);
  }

  OR.hooks.materiaChanged.push(() => { if (S.page === "diff" && diffSel.length >= 2) computeDiff(); });

  function wireDiffAI(sel, cols, dist, sharedCount) {
    const btn = $("diffAI");
    if (!btn) return;
    aiButton(btn, $("diffAIBox"), "✨ Explain the differences", () => {
      const facts = cols.map(c => `${S.remedies[c.a] || c.a} (${c.a}): ${c.e.n} rubrics, strongest chapters ${c.chTop.map(x => x.name).join(", ") || "n/a"}; rubrics only it has: ${(dist[c.a] || []).slice(0, 5).map(r => r.path).join(" | ") || "none"}`).join("\n");
      return `A homeopath is comparing these remedies: ${sel.map(a => S.remedies[a] || a).join(", ")}.\n\nRepertory facts from the app (${S.repertory.title}):\n${facts}\nRubrics shared by all of them: ${sharedCount}.\n\nGive: (1) one line of keynotes per remedy, (2) 4-6 concrete points or questions to ask the patient that would separate them. Plain text, no markdown symbols, maximum 230 words. If a remedy is little known and you are unsure, say so instead of guessing. No dosing advice.`;
    });
  }

  // one delegated listener for both the "shared" and "only X" lists
  diffRoot.addEventListener("click", e => handleAdd(e, (tag, i) =>
    tag === "s" ? diffReg.s[i] : (diffReg.d[tag.slice(2)] || [])[i]));

  OR.hooks.repertoryChanged.push(() => { idx = null; if (S.page === "diff") { renderDiffShell(); computeDiff(); } });

  OR.pages.diff = {
    onShow() {
      ensureMateria();
      renderDiffShell();
      if (S.repertory) computeDiff();
      else $("diffResults").innerHTML = `<p class="empty-state">Loading repertory data…</p>`;
    },
    onData() { if (S.page === "diff") computeDiff(); }
  };
})();
