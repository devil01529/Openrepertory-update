from pathlib import Path
import json,hashlib,collections,datetime
root=Path(__file__).parent/'apk/assets/www/data'
classic=root/'materia_medica_classics.json'
d=json.loads(classic.read_text())
if 'shards' not in d:
 entries=d['entries'];folder=root/'classics';folder.mkdir(exist_ok=True)
 d['original_sha256']=hashlib.sha256(classic.read_bytes()).hexdigest();d['shards']={};d['entries']={}
 for key,value in entries.items():
  filename=hashlib.sha256(key.encode()).hexdigest()[:20]+'.json'
  (folder/filename).write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')))
  d['shards'][key]='data/classics/'+filename;d['entries'][key]=[]
 classic.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')))
files={'kent1897':'kent_english_oorep.json','clarke':'clarke.json','kent':'kent_publicum_full.json','bbcr':'bbcr1905.json','knerr1897':'knerr1897.json','tpb1846':'tpb1846.json','boger1915':'boger1915.json','boericke1906':'boericke1906.json','bbcr1905_oorep':'bbcr1905_oorep.json','tpb1891':'tpb1891.json'}
report=json.loads((root/'audit_report.json').read_text())
if 'historical_repair' not in report:
 report['historical_repair']=report.pop('kent_integrity_v2',None)
report['generated_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['report_version']=3
report['audit_tool']='prepare_data.py v1; structural checks only, not scan verification'
for key,filename in files.items():
 raw=(root/filename).read_bytes();data=json.loads(raw);nodes=[]
 def visit(r):
  nodes.append(r)
  for sub in r.get('sub',[]):visit(sub)
 for chapter in data['chapters']:
  for r in chapter['rubrics']:visit(r)
 ids=[r.get('id') for r in nodes];links=[x for r in nodes for x in r.get('remedies',[])]
 duplicates=sum(len(r.get('remedies',[]))-len({x['r'] for x in r.get('remedies',[])}) for r in nodes)
 invalid=sum(x.get('g') not in [1,2,3,4,5] for x in links)
 grades=dict(collections.Counter(str(x['g']) for x in links))
 audit=report['datasets'].setdefault(key,{'title':data['title'],'author':data.get('author'),'source':data.get('source'),'source_license':data.get('source_license')})
 audit.update(sha256=hashlib.sha256(raw).hexdigest(),chapters=len(data['chapters']),rubric_nodes=len(nodes),remedy_links=len(links),unique_rubric_ids=len(set(ids)),empty_nodes=sum(not r.get('remedies') for r in nodes),grade_counts=grades,invalid_grades=invalid,duplicate_rubric_ids_or_links=len(ids)-len(set(ids))+duplicates)
 audit['status']='PASS' if not invalid and not audit['duplicate_rubric_ids_or_links'] else 'REVIEW'
 audit['verification_scope']='Structural validation only; OCR wording and printed grades require scan review'
 if len(grades)==1:audit['warnings']={'conservative_grading':'All packaged links share one grade; weighted comparisons cannot recover original typography.'}
 if key in ['boericke1906','bbcr1905_oorep','tpb1891']:
  audit['verification_scope']='Exhaustive authorized OOREP source-record/weight comparison; not a printed-book scan audit.'
  audit['source_rows']=data['sourceSnapshot']['total']
  audit['unscored_source_links']=sum(len(r.get('ungradedRemedies',[])) for r in nodes)
  audit['conflicting_remedies_excluded']=sum(len(r.get('conflictingRemedies',[])) for r in nodes)
  audit['raw_source_links']=sum(len(r.get('sourceRemedyRecords',[])) for r in nodes)
  audit['source_anomalies']='Unsupported source weights and conflicting grades are retained for review, excluded from scoring. Identical repeated links count once.'
  if key=='tpb1891':audit['warnings']={'provider_status':'OOREP labels this edition under development; not a certified complete printed-book transcription.'}
 if key=='kent1897':
  audit['verification_scope']='Exhaustive OOREP English Kent API source-ID and grade audit; no printed-book scan verification.'
  audit['source_rows']=data['sourceSnapshot']['rows']
  audit['chapter_index_rows']=sum(len(ch.get('indexRows',[])) for ch in data['chapters'])
 if key=='clarke':
  audit['status']='PASS' if not invalid and not audit['duplicate_rubric_ids_or_links'] else 'REVIEW'
  audit['verification_scope']='Structural validation; sampled source checks only. Complete transcription review pending.'
  audit['warnings']={'presence_only':'All links use g=1 for presence. Source italics indicate Prescriber references, not grades.','transcription':'OCR-derived text; unresolved abbreviations remain unscored and visible.'}
  audit.update(title=data['title'],source=data['source'],author=data['author'],year=data['year'],source_license=data['source_license'])

 print(key,audit['rubric_nodes'],audit['remedy_links'],audit['status'])
(root/'audit_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
p=root/'kent_integrity_audit_v2.json';d=json.loads(p.read_text())
d['scope']='Current packaged data structural validation; historical repairs are recorded separately in audit_report.json historical_repair.'
d['packaged_sha256']=report['datasets']['kent']['sha256']
d['repaired_sha256']=d['packaged_sha256']
d['scan_verified']=False
p.write_text(json.dumps(d,indent=2))
