package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.webkit.*;import com.openrepertory.app.*;import java.lang.reflect.*;
/** Emulator-only targeted check of short-viewport context and enlarged text. */
public final class ShortContextChecks extends StartupChecks {
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
  activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
  getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
  ApperAccess access=(ApperAccess)field("access");ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView browser=(WebView)af.get(screen);
  runOnMainSync(()->{screen.cancel();browser.stopLoading();});receive(receipt(access.deviceId()));ready();
  check(Boolean.TRUE.equals(js("matchMedia('(max-height:480px)').matches")),"actual Android WebView exercises the short-height context media rule");
  js("OR.showPage('dashboard');window.__shortCase=JSON.stringify(OR.activeCase());window.__shortLabels=[document.querySelector('.context-patient').textContent,document.querySelector('.context-case').textContent];OR.openReadingMenu();document.getElementById('textSizeReset').click();for(let i=0;i<4;i++)document.getElementById('textSizeLarger').click();OR.dismissMenu();OR.dismissMenu()");Thread.sleep(700);
  final int[] zoom=new int[1];runOnMainSync(()->zoom[0]=web.getSettings().getTextZoom());
  check(zoom[0]==140&&Boolean.TRUE.equals(js("document.getElementById('activeContext').getBoundingClientRect().height<=56&&getComputedStyle(document.getElementById('activeContext')).flexWrap==='nowrap'")),"140 percent text keeps short-screen patient context compact");
  check(Boolean.TRUE.equals(js("['context-patient','context-case'].every(c=>{const s=getComputedStyle(document.querySelector('.'+c));return s.whiteSpace==='nowrap'&&s.textOverflow==='ellipsis'&&s.overflowX==='hidden'})")),"short-screen patient and case labels use readable single-line ellipsis");
  check(Boolean.TRUE.equals(js("JSON.stringify(window.__shortLabels)===JSON.stringify([document.querySelector('.context-patient').textContent,document.querySelector('.context-case').textContent])&&document.querySelector('.resume-consultation h2').textContent===OR.patientList().find(p=>p.id===OR.activeCase().patientId).name")),"full patient and case strings remain in DOM and Today after compacting context");
  check(Boolean.TRUE.equals(js("(()=>{const e=document.getElementById('dashboardRoot');return e.clientHeight>=80&&e.scrollHeight>e.clientHeight&&document.documentElement.scrollWidth<=innerWidth})()")),"enlarged short-screen Today retains a bounded scroll area without horizontal overflow");
  js("document.getElementById('dashboardRoot').scrollTop=100000");
  check(Boolean.TRUE.equals(js("(()=>{const a=document.querySelector('[data-today=sources]').getBoundingClientRect(),r=document.getElementById('dashboardRoot').getBoundingClientRect(),n=document.getElementById('bottomNav').getBoundingClientRect();return a.top>=r.top&&a.bottom<=r.bottom+1&&a.bottom<=n.top+1})()")),"last Today action remains reachable above navigation at140 percent text");
  js("OR.showPage('repertory')");
  check(Boolean.TRUE.equals(js("document.querySelector('.rep-reading').clientHeight>=80")),"compact context leaves usable repertory reading space at140 percent text");
  check(Boolean.TRUE.equals(js("JSON.stringify(OR.activeCase())===window.__shortCase")),"short-screen layout and enlarged text preserve the exact selected clinical case");
  js("OR.openReadingMenu();document.getElementById('textSizeReset').click();OR.dismissMenu();OR.dismissMenu();OR.showPage('dashboard')");runOnMainSync(()->{screen.cancel();browser.stopLoading();});
  result.putString("stream","Short context native checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable error){Bundle failure=new Bundle();failure.putString("stream","FAILED short context after "+passed+" checks: "+error+"\n");finish(Activity.RESULT_CANCELED,failure);}}
}
