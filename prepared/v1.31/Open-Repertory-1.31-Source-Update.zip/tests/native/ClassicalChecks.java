package com.openrepertory.tests;
import android.app.*;import android.content.*;import android.os.*;import android.webkit.*;import android.view.*;import com.openrepertory.app.*;import java.lang.reflect.*;import org.json.*;
/** Emulator-only checks of progressive glass styling on the shipped WebView. */
public final class ClassicalChecks extends StartupChecks {
 @Override public void onStart(){Bundle result=new Bundle();try{
  if(!Build.FINGERPRINT.contains("generic")&&!Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
  activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  Field wf=MainActivity.class.getDeclaredField("webView");wf.setAccessible(true);web=(WebView)wf.get(activity);unlockTestActivity(MainActivity.class);
  getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
  ApperAccess access=(ApperAccess)field("access");ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field af=ApperAccessScreen.class.getDeclaredField("browser");af.setAccessible(true);WebView browser=(WebView)af.get(screen);
  runOnMainSync(()->{screen.cancel();browser.stopLoading();});receive(receipt(access.deviceId()));ready();
  js("window.__originalClassicalCase=JSON.stringify(OR.activeCase().analysis)");
  for(String book:new String[]{"boericke1906","tpb1891","bbcr1905_oorep"}){
   js("window.__classicalReady=false;OR.setRepertory('"+book+"').then(()=>{OR.showPage('repertory');OR.selectChapter(OR.state.repertory.chapters[0].id);window.__classicalReady=true});true");
   waitJS("window.__classicalReady",180);
   check(Boolean.TRUE.equals(js("OR.state.repertoryId==='"+book+"'&&document.querySelectorAll('#rubricList .rubric').length>0")),book+" loads and renders on Android WebView");
   js("document.querySelector('#rubricList .add-btn:not([disabled])').click();OR.showPage('analysis');OR.clinic.setAnalysisView('matrix')");
   check(Boolean.TRUE.equals(js("OR.activeCase().analysis.some(x=>x.sourceId==='"+book+"')&&!!document.querySelector('.cell')")),book+" selects and analyses on Android");
  }
  js("OR.toggleRubric('native-grade-fixture','Test','Higher grades',[{r:'Acon.',g:4},{r:'Bell.',g:5}],1,'manual');OR.saveCaseSnapshot(OR.activeCase());OR.showPage('analysis');OR.clinic.setAnalysisView('matrix')");
  check(Boolean.TRUE.equals(js("!!document.querySelector('.cell.g4')&&!!document.querySelector('.cell.g5')")),"Higher grade cells render on WebView66");
  js("window.__classicalExpected=JSON.stringify(OR.activeCase().analysis);window.__classicalBackup=false;(async()=>{const data={app:'openrepertory',version:1,patients:{patients:{},activeId:null},cases:{cases:OR.state.cases,activeCaseId:OR.state.activeCaseId},mmNotes:{}};const encoded=await ORBackup.encrypt(data,'emulator-only-password');const restored=OR.patients.validateBackup(await ORBackup.decrypt(encoded,'emulator-only-password'));window.__classicalBackup=JSON.stringify(restored.inC[restored.activeCaseId].analysis)===window.__classicalExpected;})().catch(e=>window.__classicalError=String(e));true");
  waitJS("window.__classicalBackup||window.__classicalError",90);
  check(Boolean.TRUE.equals(js("window.__classicalBackup")),"Encrypted Android backup retains imported source identities and grades");
  runOnMainSync(()->{screen.cancel();browser.stopLoading();});
  result.putString("stream","Classical native checks passed: "+passed+"\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable error){Bundle failure=new Bundle();failure.putString("stream","FAILED classical after "+passed+" checks: "+error+"\n");finish(Activity.RESULT_CANCELED,failure);}}
}
