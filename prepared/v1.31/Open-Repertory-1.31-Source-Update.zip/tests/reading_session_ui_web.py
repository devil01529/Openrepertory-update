import os
"""Illustrated whole-drawer scrolling, menu-only reading controls and themed text."""
from pathlib import Path
import json,re
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/os.environ.get('OR_TEST_RESULTS','test-results/v1.27');checks=[]
def check(value,label):
 assert value,label
 checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def ready(p):
 p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
def menu(p):p.evaluate('OR.openReadingMenu()')
def close(p):p.evaluate('OR.dismissMenu();OR.dismissMenu()')
def contrast(colors):
 def lum(c):
  v=[int(x)/255 for x in re.findall(r'\d+',c)[:3]];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v];return sum(x*y for x,y in zip(v,[.2126,.7152,.0722]))
 a,b=map(lum,colors);return (max(a,b)+.05)/(min(a,b)+.05)
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
  p=b.new_page(viewport={'width':width,'height':height});errors=[];p.on('pageerror',lambda e:errors.append(str(e)));ready(p);p.evaluate('OR.showPage("repertory")')
  check(p.locator('#chapterTree img').count()>20,f'{width}: chapter pictures are restored')
  image=p.locator('#chapterTree img').first;p.wait_for_function('()=>document.querySelector("#chapterTree img").complete');check(image.evaluate('e=>e.naturalWidth>0&&e.getBoundingClientRect().width<=42'),f'{width}: chapter artwork loads at a compact square size')
  check(p.locator('#sidebar').evaluate('e=>getComputedStyle(e).overflowY==="auto"&&e.scrollHeight>e.clientHeight'),f'{width}: entire chapter drawer is the scroll surface')
  if height>480:
   before=p.locator('#chapterFilter').bounding_box()['y'];r=p.locator('#sidebar').bounding_box();p.mouse.move(r['x']+r['width']/2,r['y']+r['height']*.8);p.mouse.wheel(0,550);p.wait_for_timeout(250)
   check(p.locator('#chapterFilter').bounding_box()['y']<before-50,f'{width}: book controls and chapter filter move up with chapters')
  check(p.locator('#chapterTree').evaluate('e=>getComputedStyle(e).overflowY==="visible"'),f'{width}: chapter list has no nested scroll trap')
  check(all(p.locator('#'+ident).evaluate('e=>!!e.closest("#menuReadingPanel")') for ident in ['toggleAllRemedies','toggleBranches','finderToggle','readingPreferences']),f'{width}: all four former toolbar controls live in the reading menu')
  check(p.locator('.rep-reading-tools button:visible').count()==1,f'{width}: repertory top strip only shows the book selector')
  p.locator('#menuBtn').click();p.locator('#menuReadingButton').click();check(p.locator('#menuReadingPanel').is_visible(),f'{width}: root menu opens the named reading section')
  p.locator('#textSizeLarger').click();check(p.locator('#textSizeValue').inner_text()=='110%' and p.evaluate('OR.store.get("openrepertory_ui").textSize')==110,f'{width}: larger text is applied and saved')
  check(p.evaluate('parseFloat(getComputedStyle(document.documentElement).fontSize)>17'),f'{width}: browser text sizing changes the reading scale')
  p.locator('#textSizeSmaller').click();check(p.locator('#textSizeValue').inner_text()=='100%',f'{width}: smaller text reverses the size step')
  p.locator('#toggleAllRemedies').click();check(p.locator('#toggleAllRemedies').inner_text()=='Hide remedies',f'{width}: remedy visibility works from the menu')
  p.locator('#toggleBranches').click();check(p.locator('#toggleBranches').inner_text()=='Expand branches',f'{width}: branch visibility works from the menu')
  p.locator('#textSizeLarger').click();p.locator('#menuBack').click();check(p.locator('#menuHome').is_visible() and p.locator('#menuReadingButton').evaluate('e=>e===document.activeElement'),f'{width}: reading Back restores focus to its menu entry');p.locator('#menuClose').click()
  p.reload();p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000);menu(p);check(p.locator('#textSizeValue').inner_text()=='110%',f'{width}: saved non-default text size survives reload')
  for _ in range(3):p.locator('#textSizeLarger').click()
  check(p.locator('#textSizeValue').inner_text()=='140%' and p.locator('#textSizeLarger').is_disabled(),f'{width}: text size has a safe maximum')
  p.locator('#readingPreferences').click();check(p.locator('.modal').is_visible(),f'{width}: density/privacy remains reachable with enlarged text');p.locator('.modal-x').click();menu(p)
  for _ in range(6):p.locator('#textSizeSmaller').click()
  check(p.locator('#textSizeValue').inner_text()=='80%' and p.locator('#textSizeSmaller').is_disabled(),f'{width}: smaller text stops at the supported minimum');p.locator('#textSizeReset').click()
  check(p.locator('#textSizeValue').inner_text()=='100%',f'{width}: Reset restores normal size')
  if width==393:p.screenshot(path=str(O/'reading-menu.png'))
  p.locator('#finderToggle').click();check(p.evaluate('OR.state.page==="repertory"&&document.querySelector("#page-repertory").classList.contains("finder-open")') and p.locator('#menuPanel').is_hidden(),f'{width}: patient words closes menu and opens the existing finder')
  p.evaluate('OR.toggleRubric("ui-contrast","Mind","Synthetic contrast rubric",[{r:"Acon.",g:3},{r:"Bell.",g:1}],1,"manual");OR.showPage("analysis");OR.clinic.setAnalysisView("matrix")')
  for theme in ['light','dark']:
   p.evaluate('(t)=>[document.documentElement,document.body].forEach(e=>e.setAttribute("data-theme",t))',theme)
   disclaimer=p.locator('.analysis-disclaimer');colors=disclaimer.evaluate('e=>[getComputedStyle(e).color,getComputedStyle(e).backgroundColor]');check(contrast(colors)>=4.5,f'{width}/{theme}: analysis explanation text meets 4.5:1 contrast')
   check(disclaimer.evaluate('e=>parseFloat(getComputedStyle(e).fontSize)>=12'),f'{width}/{theme}: analysis explanation is readable text size')
   if width==393:p.screenshot(path=str(O/f'analysis-{theme}.png'))
  check(not errors,f'{width}: new reading workflows have no JavaScript errors');p.close()
 b.close()
(O/'reading-session-ui-tests.json').write_text(json.dumps(checks,indent=2));print('Reading/session UI checks passed:',len(checks))
