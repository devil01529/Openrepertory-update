import os
"""User-reported layout regressions and mixed-source clinical record identity."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/os.environ.get('OR_TEST_RESULTS','test-results/v1.27');O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,label):
 assert v,label
 checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def ready(p):
 p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
def search(p):
 p.evaluate('OR.showPage("repertory");OR.runSearch("abrupt")');p.wait_for_function('()=>OR.lastSearchStats&&document.querySelector("#rubricList").getAttribute("aria-busy")==="false"',timeout=90000)
def control(p,id):
 p.evaluate('OR.openReadingMenu()');p.locator('#'+id).click()
 if p.locator('.reading-dialog').count():p.locator('.reading-dialog .modal-x').click()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
  p=b.new_page(viewport={'width':width,'height':height});errors=[];p.on('pageerror',lambda e:errors.append(str(e)));ready(p)
  p.evaluate('OR.showPage("repertory")')
  check(not p.locator('#sidebar').evaluate('e=>e.classList.contains("collapsed")'),f'{width}: chapters open on entering repertory')
  p.locator('#chapterTree li[data-chapter-id]').first.click()
  check(p.locator('#sidebar').evaluate('e=>e.classList.contains("collapsed")'),f'{width}: choosing a chapter closes the chapter panel')
  check(p.locator('#toggleAllRemedies').inner_text()=='Show remedies' and not p.locator('#rubricList .remedies').first.is_visible(),f'{width}: all remedy lists start collapsed')
  control(p,'toggleAllRemedies')
  check(p.locator('#rubricList .remedies').first.is_visible() and p.locator('#toggleAllRemedies').inner_text()=='Hide remedies',f'{width}: one click shows remedies')
  check(p.locator('#rubricList .rem').first.evaluate('e=>parseFloat(getComputedStyle(e).lineHeight)<25&&["inline","inline-block"].includes(getComputedStyle(e).display)'),f'{width}: remedies use close inline spacing instead of tall flex rows')
  control(p,'toggleAllRemedies');check(not p.locator('#rubricList .remedies').first.is_visible(),f'{width}: second click hides all remedies')
  control(p,'readingPreferences');p.locator('#readingRemedies').select_option('shown');p.get_by_role('button',name='Apply',exact=True).click()
  check(p.locator('#rubricList .remedies').first.is_visible() and p.locator('#toggleAllRemedies').inner_text()=='Hide remedies',f'{width}: reading preferences agree with the global visibility control')
  control(p,'readingPreferences');p.locator('#readingRemedies').select_option('hidden');p.get_by_role('button',name='Apply',exact=True).click()
  check(not p.locator('#rubricList .remedies').first.is_visible(),f'{width}: remedy visibility can also be restored from reading preferences')
  search(p);p.locator('.rubric[data-rubric-uid="Mind||ABRUPT"] .add-btn').first.click();p.evaluate('OR.showPage("analysis")')
  if width<1000:
   check(p.locator('#analysis-tab-rubrics').is_visible(),f'{width}: Selected tab remains reachable in the single-pane analysis layout')
   p.locator('#analysis-tab-rubrics').click()
  else:p.evaluate('OR.clinic.setAnalysisView("rubrics")')
  summary=p.locator('.analysis-context').bounding_box();selected=p.locator('.selected-item').first.bounding_box()
  check(summary['height']<60,f'{width}: collapsed case header has no empty vertical block')
  check(selected['height']<190,f'{width}: selected rubric is a compact row')
  check(p.locator('.wt').first.evaluate('e=>{const a=[...e.children].map(x=>x.getBoundingClientRect());return a.every(x=>Math.abs(x.top-a[0].top)<2)}'),f'{width}: importance buttons remain in one horizontal row')
  check(p.locator('#page-analysis').evaluate('e=>Math.abs(e.getBoundingClientRect().width-e.parentElement.getBoundingClientRect().width)<2'),f'{width}: analysis occupies the available width')
  p.evaluate('OR.clinic.setAnalysisView("matrix")');check(p.locator('.grid-scroll').is_visible(),f'{width}: analysis matrix available without large rubric cards')
  p.screenshot(path=str(O/f'analysis-{width}.png'))
  p.evaluate('OR.showPage("repertory")');p.locator('#sourcePicker').click();p.wait_for_selector('.book-choice')
  check(p.locator('.book-choice').count()==7 and not p.locator('.rep-library-source,.audit-badge').count(),f'{width}: repertory picker has seven plain name rows without metadata clutter')
  check(p.locator('.book-choice').first.inner_text().splitlines()[0]=='Kent',f'{width}: Kent name omits backend/source branding')
  p.locator('[data-library-rep="tpb1846"]').click();p.wait_for_function('()=>OR.state.repertoryId==="tpb1846"',timeout=90000)
  check(p.locator('#sourcePicker').evaluate('e=>{const r=e.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&getComputedStyle(e).overflow==="hidden"}'),f'{width}: a long repertory name cannot cover neighbouring controls')
  p.locator('#chapterTree li[data-chapter-id]').first.click();p.screenshot(path=str(O/f'repertory-{width}.png'))
  check(not errors,f'{width}: no JavaScript errors');p.close()
 p=b.new_page(viewport={'width':393,'height':800});ready(p);p.evaluate('OR.setRepertory("kent")');search(p);p.locator('.rubric[data-rubric-uid="Mind||ABRUPT"] .add-btn').first.click()
 original=p.evaluate('JSON.stringify(OR.activeCase().analysis[0])');p.evaluate('OR.setRepertory("kent1897")');search(p)
 check(not p.evaluate('OR.hasRubric("Mind||ABRUPT")'),'same path in another book starts unselected')
 p.locator('.rubric[data-rubric-uid="Mind||ABRUPT"] .add-btn').first.click()
 check(p.evaluate('OR.activeCase().analysis.length')==2,'adding from another repertory is allowed in the same case')
 check(p.evaluate('JSON.stringify(OR.activeCase().analysis[0])')==original,'the original selection and grades remain byte-for-byte unchanged')
 check(p.evaluate('OR.activeCase().analysis.map(x=>x.sourceId)')==['kent','kent1897'],'each same-path selection retains its distinct source')
 check(p.evaluate('OR.saveCaseSnapshot(OR.activeCase())'),'mixed-source snapshot can be saved while browsing the second book')
 before=p.evaluate('JSON.stringify(OR.activeCase().analysis)');ranks=p.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))');p.reload();p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
 check(json.loads(p.evaluate('JSON.stringify(OR.activeCase().analysis)'))==json.loads(before),'both source identities and original grades survive reload')
 check(p.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')==ranks,'mixed-source ranking survives reload')
 p.evaluate('OR.showPage("analysis");OR.clinic.setAnalysisView("rubrics")');p.locator('.selected-item').nth(1).locator('.remove-btn').click()
 check(p.evaluate('OR.activeCase().analysis.length')==1 and p.evaluate('OR.activeCase().analysis[0]')==json.loads(original),'removing one same-path entry preserves the other book’s entry')
 # Clarke presence links remain eligible independently of the primary book.
 p.evaluate('OR.state.includeGrade1=false;window.__r=OR.rankCase({repertoryId:"kent",analysis:[{sourceId:"clarke",remedies:[{r:"A",g:1}],w:1},{sourceId:"kent",remedies:[{r:"A",g:3},{r:"B",g:1}],w:2}]})')
 check(p.evaluate('__r.length===1&&__r[0].count===2&&__r[0].score===7'),'mixed-source grade filter keeps Clarke presence links and applies Kent grades faithfully')
 p.evaluate('OR.activeCase().analysis=[{uid:"presence-ui",chapter:"Clinical",text:"Presence",sourceId:"clarke",remedies:[{r:"A",g:1}],w:1}];OR.renderAnalysis()')
 check(p.locator('#includeGrade1').is_checked() and p.locator('#includeGrade1').is_disabled() and not p.evaluate('OR.state.includeGrade1'),'presence-only case clearly shows all entries without overwriting the grade-filter preference')
 p.evaluate('OR.activeCase().analysis.push({uid:"graded-ui",chapter:"Mind",text:"Graded",sourceId:"kent",remedies:[{r:"A",g:3}],w:1});OR.renderAnalysis()')
 check(not p.locator('#includeGrade1').is_checked() and p.locator('#includeGrade1').is_enabled(),'mixed case restores the user’s grade-filter control')
 p.close();b.close()
(O/'compact-workspace-tests.json').write_text(json.dumps(checks,indent=2));print('Compact workspace checks passed:',len(checks))
