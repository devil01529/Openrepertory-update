"""Grades above Kent's three-level scale must survive save, snapshot and encrypted backup."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.31';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,s):
 assert v,s
 checks.append(s);print('PASS',s,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page(viewport={'width':393,'height':800})
 p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
 p.evaluate('OR.toggleRubric("higher-grade-fixture","Mind","Synthetic higher-grade fixture",[{r:"Acon.",g:4},{r:"Bell.",g:5}],2,"manual");OR.saveCaseSnapshot(OR.activeCase())')
 check(p.evaluate('OR.rankCase(OR.activeCase()).map(x=>x.score)')==[10,8],'Weighted analysis uses actual 5 and 4, not compressed grades')
 p.reload();p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
 check(p.evaluate('OR.activeCase().analysis[0].remedies.map(x=>x.g)')==[4,5],'Higher grades retained after persisted-case normalization')
 check(p.evaluate('OR.activeCase().snapshots[0].rubrics[0].remedies.map(x=>x.g)')==[4,5],'Higher grades retained in saved snapshot')
 p.evaluate('OR.showPage("analysis");OR.clinic.setAnalysisView("matrix")');check(p.locator('.cell.g4').count()>0 and p.locator('.cell.g5').count()>0,'Matrix shows separate 4 and 5 cells')
 check('3 = strongest' not in p.locator('.analysis-disclaimer').inner_text(),'Matrix does not mislabel 3 as highest for every book')
 result=p.evaluate("""async()=>{
 const data={app:'openrepertory',version:1,patients:{patients:{},activeId:null},cases:{cases:OR.state.cases,activeCaseId:OR.state.activeCaseId},mmNotes:{}};
 const encrypted=await ORBackup.encrypt(data,'test-only-strong-password');
 const restored=await ORBackup.decrypt(encrypted,'test-only-strong-password');
 const validated=OR.patients.validateBackup(restored);
 const c=validated.inC[validated.activeCaseId];
 const rejected=[];
 for(const grade of [0,6,2.5]){const bad=JSON.parse(JSON.stringify(restored));bad.cases.cases[validated.activeCaseId].analysis[0].remedies[0].g=grade;try{OR.patients.validateBackup(bad);rejected.push(false);}catch(e){rejected.push(true);}}
 return {encrypted:encrypted.startsWith('ORBK2.'),grades:c.analysis[0].remedies.map(x=>x.g),snapshot:c.snapshots[0].rubrics[0].remedies.map(x=>x.g),rejected};
 }""")
 check(result['encrypted'] and result['grades']==[4,5] and result['snapshot']==[4,5],'Encrypted backup round-trip and schema validation preserve grades 4 and 5')
 check(all(result['rejected']),'Backup rejects zero, out-of-range and fractional grades')
 # Use the existing export path so format/schema remain production-owned.
 p.evaluate('OR.patients.openBackup()')
 check(p.locator('.modal').is_visible(),'Backup UI remains available');p.keyboard.press('Escape')
 p.locator('#snapshotHistory').click();p.locator('[data-snap-restore]').click()
 check(p.evaluate('OR.activeCase().analysis[0].remedies.map(x=>x.g)')==[4,5],'Restoring a snapshot retains higher grades')
 b.close()
(O/'higher-grades.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2))
