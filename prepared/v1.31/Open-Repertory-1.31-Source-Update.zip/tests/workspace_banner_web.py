from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.29';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,s):
 assert v,s
 checks.append(s)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page(viewport={'width':393,'height':800})
 p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
 p.evaluate('window.__patients=OR.patientList;OR.patientList=()=>[{id:"synthetic",name:"Synthetic patient"}];OR.lifecycle.refresh()')
 check(p.locator('#backupReminder,#workRecovery').count()==0,'Patients without recent backup do not create top reminder')
 p.evaluate('OR.store.set("openrepertory_drafts",{sample:{context:{type:"patient"},values:{name:"Synthetic draft"}}});OR.lifecycle.refresh()')
 check(p.locator('#resumeDrafts').is_visible(),'Draft recovery remains available')
 p.locator('#resumeDrafts').click();check(p.locator('.modal').is_visible(),'Draft recovery dialog opens');p.keyboard.press('Escape')
 p.evaluate('OR.store.set("openrepertory_drafts",{});OR.store.set("openrepertory_pending_picker",true);OR.lifecycle.refresh()')
 check(p.locator('#resumePicker').is_visible(),'Interrupted import recovery remains available')
 p.evaluate('OR.store.set("openrepertory_pending_picker",null);OR.patientList=window.__patients;OR.lifecycle.refresh();OR.showPage("dashboard")')
 check(p.locator('#workRecovery').count()==0 and p.locator('#activeContext').is_hidden(),'Cleared recovery leaves a clean top frame')
 p.locator('[data-today=backup]').click();check(p.locator('.modal').is_visible(),'Backup remains available from Today')
 b.close()
(O/'workspace-banner.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2));print('PASS',len(checks))
