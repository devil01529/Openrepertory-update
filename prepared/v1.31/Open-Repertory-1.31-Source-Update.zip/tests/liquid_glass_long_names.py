"""Actual linked-patient Today card wrapping at the supported reading sizes."""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright

R=Path(__file__).resolve().parents[1]
O=R/os.environ.get('OR_TEST_RESULTS','test-results/v1.27')
O.mkdir(parents=True,exist_ok=True)
checks=[]
PATIENT='SYNTHETICLIQUIDGLASSPATIENTNAMEWITHOUTSPACESFORWRAPPINGVERIFICATION'
CASE='SYNTHETICCONSULTATIONCASEWITHOUTSPACESFORRESPONSIVECARDVERIFICATION'

def check(value,label):
    assert value,label
    checks.append({'test':label,'status':'passed'})
    print('PASS',label,flush=True)

def size(p,value):
    p.evaluate('OR.openReadingMenu()')
    p.locator('#textSizeReset').click()
    for _ in range(abs(value-100)//10):
        p.locator('#textSizeLarger' if value>100 else '#textSizeSmaller').click()
    assert p.locator('#textSizeValue').inner_text()==str(value)+'%'
    p.evaluate('OR.dismissMenu();OR.dismissMenu()')

with sync_playwright() as w:
    b=w.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
        p=b.new_page(viewport={'width':width,'height':height});errors=[]
        p.on('pageerror',lambda e:errors.append(str(e)))
        p.goto(os.environ.get('OR_TEST_URL','http://127.0.0.1:8765'))
        p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
        p.evaluate('OR.showPage("patients")')
        p.locator('#patientNew').click()
        p.locator('[data-k=name]').fill(PATIENT)
        p.get_by_role('button',name='Create patient',exact=True).click()
        p.locator('#patientTabs').wait_for()
        p.evaluate('(name)=>{const c=OR.activeCase();c.name=name;c.patientId=OR.patientList()[0].id;OR.saveCases();OR.showPage("dashboard")}',CASE)
        check(p.evaluate('OR.activeCase().patientId===OR.patientList()[0].id'),f'{width}: actual patient and active case are linked')
        root=p.locator('#dashboardRoot');card=p.locator('.resume-consultation')
        for value in [80,100,140]:
            prefix=f'{width}x{height}/{value}%'
            size(p,value);root.evaluate('e=>e.scrollTop=0')
            check(card.locator('h2').inner_text()==PATIENT,prefix+': full unbroken patient name is retained')
            check(card.locator('p').inner_text().startswith(CASE+' · '),prefix+': full unbroken case name is retained')
            check(card.evaluate('e=>e.scrollWidth<=e.clientWidth+1'),prefix+': consultation card has no horizontal content overflow')
            check(card.locator('h2').evaluate('e=>e.scrollWidth<=e.clientWidth+1') and card.locator('p').evaluate('e=>e.scrollWidth<=e.clientWidth+1'),prefix+': patient and case text wrap inside their own lines')
            check(p.evaluate('document.body.scrollWidth<=innerWidth+2'),prefix+': long names do not widen the app shell')
            r=root.bounding_box();p.mouse.move(r['x']+r['width']*.5,r['y']+r['height']*.5);p.mouse.wheel(0,10000);p.wait_for_timeout(150)
            check(root.evaluate('e=>e.scrollHeight<=e.clientHeight+1||e.scrollTop>0'),prefix+': Today fits the viewport or scrolls with a real wheel gesture when needed')
            check(p.locator('[data-today="sources"]').evaluate('e=>{const a=e.getBoundingClientRect(),r=e.closest("#dashboardRoot").getBoundingClientRect();return a.bottom<=r.bottom+1&&a.top>=r.top-1}'),prefix+': final Today action remains reachable above navigation')
            check(p.evaluate('OR.patientList()[0].name')==PATIENT and p.evaluate('OR.activeCase().name')==CASE,prefix+': sizing and scrolling preserve the stored patient and case names')
            if width==320 and value==140:
                root.evaluate('e=>e.scrollTop=0');p.screenshot(path=str(O/'glass-long-names-320-140.png'),animations='disabled')
        check(not errors,f'{width}: long-name workflow has no uncaught JavaScript errors')
        p.close()
    b.close()
(O/'liquid-glass-long-names-tests.json').write_text(json.dumps(checks,indent=2)+'\n')
print('Liquid Glass long-name checks passed:',len(checks))
