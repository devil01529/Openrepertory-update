from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.30';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,s):
 assert v,s
 checks.append(s)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w,h in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
  for theme in ['light','dark']:
   p=b.new_page(viewport={'width':w,'height':h});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
   p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
   p.evaluate('(t)=>{document.body.dataset.theme=t;document.documentElement.dataset.theme=t;OR.openMateriaRemedy("Abies-c.")}',theme)
   p.wait_for_selector('.mm-section-trigger',timeout=90000);p.wait_for_timeout(500)
   check(p.locator('#mmSectionPicker select').count()==0,'Native dropdown removed')
   original=p.locator('#mmSourceContent').inner_text();p.locator('.mm-section-trigger').click()
   check(p.locator('.mm-section-dialog').is_visible(),'App-rendered dialog opens')
   titles=p.locator('#mmSourceContent h5').all_text_contents();check(p.locator('.mm-section-option>span:first-child').all_text_contents()==titles,'All actual headings shown in source order')
   p.locator('.mm-section-search input').fill('zzzznoresult');check(p.locator('.mm-section-option:visible').count()==0 and p.locator('.mm-section-empty').is_visible(),'Search empty state')
   p.locator('.mm-section-search input').fill('');check(p.locator('.mm-section-option:visible').count()==len(titles),'Clear restores all headings')
   p.locator('.mm-section-option').last.click();check(p.locator('.mm-section-dialog').count()==0,'Choosing section closes dialog')
   check(p.evaluate('document.activeElement.tagName')=='H5' and p.locator('#mmDetail').evaluate('e=>e.scrollTop')>0,'Jump focuses heading and scrolls reader')
   p.locator('.mm-section-trigger').click();check(p.locator('.mm-section-option[aria-current=true]').inner_text().startswith(titles[-1]),'Selected section marked')
   p.keyboard.press('Escape');check(p.locator('.mm-section-trigger').evaluate('e=>e===document.activeElement'),'Dismiss restores trigger focus')
   for _ in range(3):p.locator('.mm-section-trigger').click();p.evaluate('OR.clinic.back()')
   check(p.locator('.modal-back').count()==0 and p.locator('#main').get_attribute('aria-hidden') is None,'Repeated Back clears overlays and accessibility state')
   p.evaluate('document.documentElement.style.fontSize="140%"');p.locator('.mm-section-trigger').click();p.locator('.mm-section-option').last.scroll_into_view_if_needed()
   check(p.locator('.mm-section-dialog').evaluate('e=>{let r=e.getBoundingClientRect();return r.left>=-1&&r.right<=innerWidth+1&&r.top>=-1&&r.bottom<=innerHeight+1&&e.scrollWidth<=e.clientWidth+1}'),'Large-font chooser fits viewport')
   check(p.locator('.mm-section-option').last.bounding_box()['height']>=44,'Comfortable touch targets')
   p.emulate_media(reduced_motion='reduce');check(p.locator('.mm-section-dialog').evaluate('e=>getComputedStyle(e).animationName')=='none','Reduced motion respected')
   if w==393:p.screenshot(path=str(O/f'section-picker-{theme}.png'))
   p.keyboard.press('Escape');check(p.locator('#mmSourceContent').inner_text()==original,'Source text unchanged by picker')
   check(not errors,'No uncaught exceptions');p.close()
 b.close()
(O/'section-picker.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2));print('PASS',len(checks))
