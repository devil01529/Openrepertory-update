from pathlib import Path
import json,zipfile,hashlib,subprocess
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.31';checks=[]
def check(v,s):
 assert v,s
 checks.append(s)
with zipfile.ZipFile(R/'releases/1.30/Open-Repertory-1.30.apk') as old,zipfile.ZipFile(R/'dist/Open-Repertory-Clarke-Dev.apk') as new:
 changed={'audit_report.json','source_registry.json','online_repertory_sources.json','kent_integrity_audit_v2.json'}
 olddata=[n for n in old.namelist() if n.startswith('assets/www/data/') and Path(n).name not in changed]
 check(all(old.read(n)==new.read(n) for n in olddata),'All earlier clinical datasets retained byte-for-byte, including Kent')
 check(old.read('classes.dex')==new.read('classes.dex'),'Native classes unchanged from 1.30')
 for key in ['boericke1906','bbcr1905_oorep','tpb1891']:
  n='assets/www/data/'+key+'.json';check(new.read(n)==(R/'apk'/n).read_bytes(),key+' APK data matches audited import')
 for n in new.namelist():
  if n.startswith('assets/www/js/') or n.startswith('assets/www/css/'):
   check(new.read(n)==(R/'apk'/n).read_bytes(),n+' matches tested assets')
 check(new.testzip() is None,'APK ZIP integrity')
 check(not any(n.endswith(('.p12','.keystore','.jks','.pdf')) or 'private' in n.lower() or 'firebase-config' in n.lower() for n in new.namelist()),'APK excludes signing keys, archived Firebase configuration and source PDFs')
 check(b'ClassicalChecks' not in new.read('classes.dex') and b'FixtureAuthView' not in new.read('classes.dex'),'Native test fixtures are excluded from APK')
 bt='/workspace/tools/android/android-15/'
 badging=lambda f:subprocess.check_output([bt+'aapt2','dump','badging',str(f)],text=True)
 a=badging(R/'dist/Open-Repertory-Clarke-Dev.apk');b=badging(R/'releases/1.30/Open-Repertory-1.30.apk')
 check("name='com.openrepertory.app.dev'" in a and "versionCode='32'" in a and "versionName='1.31-dev'" in a,'Package retained and Android version increased')
 cert=lambda f:next(x for x in subprocess.check_output([bt+'apksigner','verify','--print-certs',str(f)],text=True).splitlines() if 'certificate SHA-256 digest:' in x)
 check(cert(R/'dist/Open-Repertory-Clarke-Dev.apk')==cert(R/'releases/1.30/Open-Repertory-1.30.apk'),'Existing APK signing certificate retained')
 check({x for x in a.splitlines() if x.startswith('uses-permission:')}=={x for x in b.splitlines() if x.startswith('uses-permission:')},'No Android permission changes')
 results={}
 for name in ['higher-grades.json','classical-sources-web.json','materia-reader.json']:
  results[name]=json.loads((O/name).read_text())['passed']
 for name in ['source-switch-guard-tests.json','scoring-compatibility-tests.json','navigation-tree-tests.json','menu-web-tests.json','browser-reliability.json']:
  if (O/name).exists():results[name]=len(json.loads((O/name).read_text()))
 results['package-invariants']=len(checks)
 native=(O/'android-classical.txt');nativePassed=native.exists() and 'Classical native checks passed: 8' in native.read_text()
 if nativePassed:results['android-classical']=8
 upgrade=O/'android-upgrade.txt'
 upgradePassed=upgrade.exists() and 'Upgrade retention checks passed:' in upgrade.read_text() and 'FAILED' not in upgrade.read_text()
 if upgradePassed:results['android-update-retention-workflow']=1
 summary={'version':'1.31-dev','checks':results,'totalPassed':sum(results.values()),'apkSha256':hashlib.sha256((R/'dist/Open-Repertory-Clarke-Dev.apk').read_bytes()).hexdigest(),'unchangedEarlierDataAssets':len(olddata),'nativeClassicalTestsPassed':nativePassed,'androidUpgradeRetentionPassed':upgradePassed,'sourceAudit':json.loads((O/'classical-data-audit.json').read_text())}
 (O/'package-invariants.json').write_text(json.dumps(checks,indent=2));(O/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
 (R/'TEST_REPORT_1.31.md').write_text(f'''# Open Repertory 1.31 validation

{summary['totalPassed']} counted browser/package/native checks passed: {json.dumps(results)}.

Independent exhaustive source audit verifies every imported row, path, original parent, raw remedy association and weight against hashed cached API pages. It verifies scoring exclusions, duplicate handling, unique selection identities and direct reference targets. Kent files and {len(olddata)} earlier data assets match 1.30 byte for byte.

Browser workflows cover imported-book loading, chapter rendering, remedy aliases, search, source-specific selection, mixed-book analysis, persistence, references, conflicting-grade notices, grades 4/5, snapshots and encrypted backups. Legacy scoring matches the published 1.23 engine. Navigation and Materia Medica regressions passed. Native classes are unchanged from 1.30.

Android classical workflow suite passed: {nativePassed}. Upgrade retention workflow passed: {upgradePassed}. See attached test logs for emulator results (synthetic test records and access receipts only). No physical-device testing or printed-book scan certification is claimed, and source anomalies remain disclosed. No zero-bug guarantee.

APK SHA-256: `{summary['apkSha256']}`
''')
 print(json.dumps({k:v for k,v in summary.items() if k!='sourceAudit'},indent=2))
