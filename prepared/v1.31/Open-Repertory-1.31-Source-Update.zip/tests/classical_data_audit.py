"""Independent exhaustive audit of packaged classical data against cached source responses."""
from pathlib import Path
import json,hashlib,collections,os
R=Path(__file__).resolve().parents[1];D=R/'apk/assets/www/data';A=R/'source-material/repertory-comparison-20261024';C=Path(os.environ.get('OR_AUDIT_CACHE','/workspace/scratch/oorep-audit-20261024'));results={}
for name,want in json.loads((A/'kent-protected.json').read_text()).items():
 assert hashlib.sha256((D/name).read_bytes()).hexdigest()==want,name
for source,key in [('boericke','boericke1906'),('boen','tpb1891'),('bogboen','bbcr1905_oorep')]:
 p=D/(key+'.json')
 if not p.exists():raise AssertionError('Missing imported database: '+key)
 rep=json.loads(p.read_text());raw=json.loads((C/source/'rows.json').read_text());manifest=json.loads((C/source/'manifest.json').read_text())
 sourcePages={}
 assert {int(p) for p in manifest['pageSha256']}==set(range(manifest['pages']))
 for page,h in manifest['pageSha256'].items():
  f=C/source/f'{int(page):05}.json';assert hashlib.sha256(f.read_bytes()).hexdigest()==h
  response=json.loads(f.read_text())[0];assert response['currPage']==int(page)
  for group in response['results']:
   for item in group['subRubrics']:
    sid=str(item['rubric']['id']);assert sid not in sourcePages;sourcePages[sid]=item
 assert raw==sourcePages,'Raw row index must match hashed API pages'

 allrows=[x for ch in rep['chapters'] for r in ch['rubrics'] for x in [r]+r.get('sub',[])];rows=[x for x in allrows if not x.get('syntheticHeading')]
 assert len(rows)==len(raw)==manifest['total'];assert len({x['id'] for x in allrows})==len(allrows)
 assert len({ch['id'] for ch in rep['chapters']})==len(rep['chapters'])
 uids=[ch['name']+'||'+(r['text'] if x is r else r['text']+', '+x['text'].removeprefix('. ')) for ch in rep['chapters'] for r in ch['rubrics'] for x in [r]+r.get('sub',[])]
 assert len(set(uids))==len(uids),'Ambiguous app selection identity: '+key
 ids={x['id'] for x in rows};count=0;scored=0;conflicts=0;unsupported=0;repeated=0
 for row in rows:
  original=raw[row['sourceIds'][0]];r=original['rubric'];assert row['sourcePath']==r['fullPath'];assert row['sourceMotherId']==r.get('mother');assert row['sourceChapterId']==r['chapterId']
  expected=collections.Counter((x['remedy']['nameAbbrev'],x['weight'],x['remedy']['id']) for x in original['weightedRemedies'])
  actual=collections.Counter((x['r'],x['g'],x['sourceRemedyId']) for x in row['sourceRemedyRecords']);assert actual==expected
  byrem=collections.defaultdict(set)
  for abbr,grade,_ in expected:byrem[abbr].add(grade)
  eligible={a:next(iter(v)) for a,v in byrem.items() if len(v)==1 and 1<=next(iter(v))<=5}
  assert {x['r']:x['g'] for x in row['remedies']}==eligible
  assert len(row['remedies'])==len(eligible)
  assert {x['r'] for x in row.get('conflictingRemedies',[])}=={a for a,v in byrem.items() if len(v)>1}
  assert {x['r'] for x in row.get('ungradedRemedies',[])}=={a for a,v in byrem.items() if len(v)==1 and not 1<=next(iter(v))<=5}
  for link in row.get('references',[]):
   assert link['sourceId']==key
   if link.get('targetId'):assert link['targetId'] in ids
  count+=sum(expected.values());scored+=len(eligible);conflicts+=len(row.get('conflictingRemedies',[]));unsupported+=len(row.get('ungradedRemedies',[]));repeated+=sum(expected.values())-len(byrem)
 results[key]=dict(sourceRows=len(rows),sourceLinks=count,scoredLinks=scored,conflictingRemediesExcluded=conflicts,unsupportedWeightsExcluded=unsupported,duplicateLinksNotDoubleCounted=repeated,checks='Every source row, raw link, weight, parent identity, scoring eligibility and resolved reference checked')
O=R/'test-results/v1.31';O.mkdir(parents=True,exist_ok=True);(O/'classical-data-audit.json').write_text(json.dumps({'kentUnchanged':True,'sources':results},indent=2));print(json.dumps(results,indent=2))
