"""Repertory-only reading panel interactions, accessibility and motion."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.28';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,label):
 assert v,label
 checks.append(label)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w,h in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
  for theme in ['light','dark']:
   p=b.new_page(viewport={'width':w,'height':h});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
   p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR && OR.state.repertory',timeout=90000)
   p.evaluate('(t)=>{document.body.dataset.theme=t;document.documentElement.dataset.theme=t;OR.showPage("dashboard")}',theme)
   check(p.locator('#repertoryReadingButton').is_hidden(),'Today has no reading trigger')
   check(p.locator('#menuPanel #menuReadingPanel,#menuReading,#menuReadingButton').count()==0,'No reading controls in global menu')
   p.evaluate('OR.showPage("repertory")');p.locator('#repertoryReadingButton').click()
   check(p.locator('.reading-dialog').is_visible(),'Reading trigger opens dialog')
   check(p.locator('#menuPanel').is_hidden(),'Global menu remains closed')
   for _ in range(4):p.locator('#textSizeLarger').click()
   check(p.locator('#textSizeValue').inner_text()=='140%','Text size updates')
   p.locator('#glassEffects').uncheck();check(p.locator('body').get_attribute('data-glass-effects')=='off','Solid mode updates')
   for id in ['toggleAllRemedies','toggleBranches','glassEffects','readingPreferences']:
    p.locator('#'+id).scroll_into_view_if_needed();check(p.locator('#'+id).is_visible(),'Scrollable control '+id)
   check(p.evaluate('()=>{let e=document.querySelector(".reading-dialog"),r=e.getBoundingClientRect();return r.left>=-1&&r.right<=innerWidth+1&&r.top>=-1&&r.bottom<=innerHeight+1&&e.scrollWidth<=e.clientWidth+1}'),'Dialog fits viewport at 140%')
   p.keyboard.press('Escape');check(p.locator('.reading-dialog').count()==0 and p.locator('#repertoryReadingButton').evaluate('e=>e===document.activeElement'),'Escape closes and restores focus')
   for _ in range(5):
    p.locator('#repertoryReadingButton').click();p.evaluate('OR.clinic.back()')
   check(p.locator('.modal-back').count()==0 and p.locator('#main').get_attribute('aria-hidden') is None,'Repeated native Back leaves no overlay or hidden workspace')
   p.locator('#repertoryReadingButton').click();p.locator('#finderToggle').click()
   check(p.locator('.reading-dialog').count()==0 and p.locator('#aiInput').is_visible(),'Patient words closes panel and opens finder')
   p.locator('#repertoryReadingButton').click();p.locator('#readingPreferences').click()
   check(p.locator('.modal').count()==1 and p.locator('.reading-dialog').count()==0,'Density opens only one dialog');p.keyboard.press('Escape')
   p.locator('#repertoryReadingButton').click();p.evaluate('OR.showPage("analysis")')
   check(p.locator('.reading-dialog').count()==0 and p.locator('#repertoryReadingButton').is_hidden(),'Leaving repertory closes reading panel')
   p.reload();p.wait_for_function('()=>window.OR && OR.state.repertory',timeout=90000);p.evaluate('OR.showPage("repertory")');p.locator('#repertoryReadingButton').click()
   check(p.locator('#textSizeValue').inner_text()=='140%' and not p.locator('#glassEffects').is_checked(),'Settings survive reload')
   p.emulate_media(reduced_motion='reduce');check(p.locator('.reading-dialog').evaluate('e=>getComputedStyle(e).animationName')=='none','Reduced motion disables entrance')
   p.emulate_media(reduced_motion='no-preference');check(p.locator('.reading-dialog').evaluate('e=>getComputedStyle(e).animationName')=='reading-arrive','Lightweight entrance enabled')
   if w==393:
    p.evaluate('(t)=>{document.body.dataset.theme=t;document.documentElement.dataset.theme=t}',theme);p.wait_for_timeout(250);p.screenshot(path=str(O/f'reading-{theme}.png'))
   check(not errors,'No uncaught errors');p.close()
 b.close()
(O/'reading-panel.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2));print('PASS',len(checks))
