"""Clinical workflows with imported classical editions, including source anomalies."""
from pathlib import Path
import json,os
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.31';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,s):
 assert v,s
 checks.append(s);print('PASS',s,flush=True)
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page(viewport={'width':393,'height':800});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
 books=os.environ.get('OR_CLASSICAL_BOOKS','boericke1906,tpb1891,bbcr1905_oorep').split(',')
 for key in books:
  p.evaluate('OR.showPage("repertory")');p.locator('#sourcePicker').click();p.locator('[data-library-rep="'+key+'"]').click();p.wait_for_function('(key)=>OR.state.repertoryId===key',arg=key,timeout=90000)
  check(p.evaluate('OR.state.repertoryId')==key,key+': book loads')
  p.evaluate('OR.selectChapter(OR.state.repertory.chapters[0].id)')
  check(p.locator('#rubricList .rubric').count()>0,key+': chapter renders')
  p.locator('#rubricList .add-btn:not([disabled])').first.click()
  check(p.evaluate('OR.activeCase().analysis.at(-1).sourceId')==key,key+': selection retains source identity')
  p.evaluate('OR.runSearch("pain")');p.wait_for_function('()=>document.querySelector("#rubricList").getAttribute("aria-busy")==="false"',timeout=90000)
  check(p.locator('#rubricList .rubric').count()>0,key+': search returns rubrics')
  p.evaluate('OR.showPage("analysis");OR.clinic.setAnalysisView("matrix")')
  check(p.locator('.analysis-table, .matrix-table, .cell').count()>0,key+': analysis matrix renders')
 check(p.evaluate('OR.activeCase().analysis.length')==len(books),'Imported classical books coexist in one case')
 original=p.evaluate('OR.activeCase().analysis');p.reload();p.wait_for_function('()=>OR.state.repertory',timeout=90000)
 check(p.evaluate('OR.activeCase().analysis')==original,'All imported selections persist unchanged across reload')
 p.evaluate('OR.setRepertory("boericke1906")')
 p.evaluate('OR.runSearch("Illicium Anisatum")');p.wait_for_function('()=>document.querySelector("#rubricList").getAttribute("aria-busy")==="false"',timeout=90000)
 check(p.locator('#rubricList .rem[data-abbr="Anis."]').count()>0,'Source-recorded alternate remedy name resolves to its abbreviation')
 anomaly=p.evaluate('()=>{for(const c of OR.state.repertory.chapters)for(const r of c.rubrics)for(const x of [r,...(r.sub||[])])if(x.conflictingRemedies?.length)return {sourceId:OR.state.repertoryId,uid:c.name+"||"+(x===r?r.text:r.text+", "+x.text.replace(/^\\.\\s*/,"")),text:x.text};}')
 p.evaluate('(x)=>OR.openRubricLocation(x)',anomaly)
 check(p.locator('.source-ungraded').filter(has_text='Conflicting source grades').count()>0,'Conflicting source grades are visibly labelled')
 ref=p.evaluate('()=>{for(const c of OR.state.repertory.chapters)for(const r of c.rubrics)for(const x of [r,...(r.sub||[])])for(const ref of x.references||[])if(ref.targetId)return ref;}')
 p.evaluate('(ref)=>OR.openSourceReference(ref)',ref)
 check(p.locator('#rubricList .rubric').count()>0,'Resolved source cross-reference opens a rubric location')
 p.evaluate('OR.openSourceReference({sourceId:"boericke1906",label:"pain"})');p.wait_for_function('()=>document.querySelector("#rubricList").getAttribute("aria-busy")==="false"')
 check(p.locator('#rubricList .rubric').count()>0,'Unresolved cross-reference falls back to explicit search')
 p.locator('#sourcePicker').click();p.locator('.earlier-repertories summary').click();p.locator('[data-library-rep="bbcr"]').click();p.wait_for_function('()=>OR.state.repertoryId==="bbcr"',timeout=90000)
 check(p.evaluate('OR.activeCase().analysis')==original,'Opening earlier BBCR edition preserves saved imported selections')
 check(not errors,'Imported source workflows have no JavaScript exceptions');p.screenshot(path=str(O/'classical-sources.png'));b.close()
(O/'classical-sources-web.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2))
