"""Independent Liquid Glass visual safety and real clinical workflow regressions.

Run against the packaged web assets on OR_TEST_URL (default localhost:8765).
Fixtures are synthetic and use a fresh browser context per viewport.
"""
from pathlib import Path
import json, os, re
from playwright.sync_api import sync_playwright

R = Path(__file__).resolve().parents[1]
O = R / os.environ.get('OR_TEST_RESULTS', 'test-results/v1.27')
O.mkdir(parents=True, exist_ok=True)
URL = os.environ.get('OR_TEST_URL', 'http://127.0.0.1:8765')
checks = []

def check(value, label):
    assert value, label
    checks.append({'test': label, 'status': 'passed'})
    print('PASS', label, flush=True)

def ready(p):
    p.goto(URL)
    p.wait_for_function('()=>window.OR && OR.state.repertory', timeout=90000)

def close_menu(p):
    p.evaluate('OR.dismissMenu();OR.dismissMenu()')

def theme(p, value):
    p.evaluate('(t)=>[document.documentElement,document.body].forEach(e=>e.setAttribute("data-theme",t))', value)

def reading(p):
    p.evaluate('OR.openReadingMenu()')

def set_size(p, value):
    reading(p)
    p.locator('#textSizeReset').click()
    for _ in range(abs(value - 100) // 10):
        p.locator('#textSizeLarger' if value > 100 else '#textSizeSmaller').click()
    check(p.locator('#textSizeValue').inner_text() == f'{value}%', f'text sizing applies {value}% through the actual controls')

def geometry(p):
    return p.evaluate('''()=>{
      const panel=document.querySelector('#menuPanel'),r=panel.getBoundingClientRect(),issues=[];
      if(r.left<-.5||r.right>innerWidth+.5||r.top<-.5||r.bottom>innerHeight+.5)issues.push('panel outside viewport');
      for(const row of panel.querySelectorAll('.menu-item,#readingMenuControls button')){
        if(!row.getClientRects().length)continue;
        const b=row.getBoundingClientRect();
        if(b.height<43.5)issues.push('small action target');
        if(b.width>r.width+1)issues.push('action wider than panel');
        for(const label of row.querySelectorAll('b,small')){
          const t=label.getBoundingClientRect();
          if(t.left<b.left-.5||t.right>b.right+.5||t.bottom>b.bottom+.5)issues.push('label overflow');
        }
      }
      const content=panel.querySelector('.menu-content');
      if(content.scrollWidth>content.clientWidth+2)issues.push('horizontal menu overflow');
      return issues;
    }''')

def contrast(colors):
    def lum(c):
        rgb=[int(x)/255 for x in re.findall(r'[\d.]+',c)[:3]]
        linear=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb]
        return sum(v*w for v,w in zip(linear,[.2126,.7152,.0722]))
    a,b=map(lum,colors)
    return (max(a,b)+.05)/(min(a,b)+.05)

def effective_colors(p, selector):
    # Composite the element's background through its ancestors. Glass surfaces
    # may be translucent, but text remains fully opaque. Clinical tables use
    # opaque panels so the resulting contrast has a stable background.
    return p.locator(selector).first.evaluate('''e=>{
      const rgba=c=>(c.match(/[\\d.]+/g)||[]).map(Number);
      let bg=[255,255,255],chain=[],n=e;
      for(;n;n=n.parentElement)chain.unshift(n);
      for(const node of chain){const c=rgba(getComputedStyle(node).backgroundColor),a=c.length===4?c[3]:1;if(c.length>=3)bg=bg.map((v,i)=>c[i]*a+v*(1-a));}
      return [getComputedStyle(e).color,'rgb('+bg.map(Math.round).join(',')+')'];
    }''')

with sync_playwright() as w:
    b=w.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
        context=b.new_context(viewport={'width':width,'height':height},has_touch=True)
        p=context.new_page(); errors=[]
        p.on('pageerror',lambda e:errors.append(str(e)))
        ready(p)
        prefix=f'{width}x{height}'
        check(p.locator('body.liquid-glass').count()==1, prefix+': packaged workspace enables the glass design')
        check(p.locator('link[href="css/liquid-glass.css"]').count()==1, prefix+': glass stylesheet is loaded once after the clinical base')
        check(p.evaluate('document.body.scrollWidth<=innerWidth+2'), prefix+': shell has no horizontal page overflow')
        root=p.locator('#dashboardRoot'); rect=root.bounding_box()
        p.mouse.move(width/2,rect['y']+rect['height']*.6); p.mouse.wheel(0,5000); p.wait_for_timeout(200)
        check(root.evaluate('e=>e.scrollTop>0&&e.scrollHeight>e.clientHeight'), prefix+': Today still scrolls under the glass shell')
        check(p.locator('[data-today="sources"]').evaluate('e=>{const r=e.getBoundingClientRect(),v=e.closest("#dashboardRoot").getBoundingClientRect();return r.bottom<=v.bottom+1&&r.top>=v.top-1}'), prefix+': last Today action is reachable above navigation')
        if width==393:
            root.evaluate('e=>e.scrollTop=0');p.screenshot(path=str(O/'glass-today-light.png'),animations='disabled')
        p.evaluate('OR.showPage("repertory")')
        check(p.locator('#sidebar').evaluate('e=>getComputedStyle(e).overflowY==="auto"&&e.scrollHeight>e.clientHeight'),prefix+': illustrated chapter drawer retains its whole-surface scroller')
        check(p.locator('#chapterTree img').count()>20,prefix+': chapter artwork is retained')
        p.locator('#chapterTree .chapter-choice').first.click()
        check(p.locator('#sidebar').evaluate('e=>e.classList.contains("collapsed")'),prefix+': selecting a chapter closes its drawer')
        reading(p);p.locator('#toggleAllRemedies').click();close_menu(p)
        snapshot=p.evaluate('JSON.stringify([...document.querySelectorAll("#rubricList .rem")].slice(0,100).map(e=>[e.textContent,e.className]))')
        check(len(json.loads(snapshot))>10,prefix+': source remedies and grading styles are present')
        check(p.locator('#rubricList .rem.g2').count()>0 and p.locator('#rubricList .rem.g3').count()>0,prefix+': source grade two and grade three are independently represented')
        for mode in ['light','dark']:
            theme(p,mode)
            check(contrast(effective_colors(p,'.chapter-hero h2'))>=4.5,prefix+'/'+mode+': chapter heading remains readable')
            check(p.locator('#menuBtn').evaluate('e=>{const b=e.getBoundingClientRect(),d=e.querySelector(".dots").getBoundingClientRect();return Math.abs((b.left+b.width/2)-(d.left+d.width/2))<=1&&Math.abs((b.top+b.height/2)-(d.top+d.height/2))<=1}'),prefix+'/'+mode+': menu dots remain centered within their touch target')
            # Semantic grade identity must survive visual changes.
            check(p.evaluate('JSON.stringify([...document.querySelectorAll("#rubricList .rem")].slice(0,100).map(e=>[e.textContent,e.className]))')==snapshot,prefix+'/'+mode+': glass theme preserves remedy wording and grade classes')
            check(p.locator('#rubricList .rem.g3').first.evaluate('e=>getComputedStyle(e).fontWeight') in ['700','800','900'],prefix+'/'+mode+': highest grade remains bold')
            check(p.locator('#rubricList .rem.g2').first.evaluate('e=>getComputedStyle(e).fontStyle')=='italic',prefix+'/'+mode+': second grade remains italic')
            for size in [80,140]:
                set_size(p,size)
                check(not geometry(p),prefix+'/'+mode+f'/{size}%: reading menu fits and actions remain readable')
                p.locator('#readingPreferences').scroll_into_view_if_needed();p.locator('#readingPreferences').click()
                modal=p.locator('.modal'); box=modal.bounding_box()
                check(box['x']>=-.5 and box['x']+box['width']<=width+.5 and box['y']>=-.5 and box['y']+box['height']<=height+.5,prefix+'/'+mode+f'/{size}%: reading preferences stays inside the viewport')
                p.get_by_role('button',name='Apply',exact=True).scroll_into_view_if_needed()
                check(p.get_by_role('button',name='Apply',exact=True).is_visible(),prefix+'/'+mode+f'/{size}%: preference Apply remains reachable')
                p.locator('.modal-x').click()
            set_size(p,100);close_menu(p)
            if width==393:p.screenshot(path=str(O/f'glass-repertory-{mode}.png'),animations='disabled')
        # A real source selection must retain identity and produce the same ranks
        # before/after glass appearance and control changes.
        p.locator('#rubricList .rubric .add-btn').first.click()
        for mode in ['light','dark']:
            theme(p,mode)
            check(p.locator('#rubricList .add-btn.added').count()==1 and contrast(effective_colors(p,'#rubricList .add-btn.added'))>=4.5,prefix+'/'+mode+': actual added-rubric state retains readable selected-button contrast')
        original=p.evaluate('JSON.stringify(OR.activeCase().analysis)'); ranks=p.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')
        check(p.locator('#analysisShortcut').is_visible(),prefix+': icon-only analysis shortcut remains available after selecting a rubric')
        check(p.locator('#analysisShortcut').get_attribute('aria-label')=='Open analysis, 1 selected rubric',prefix+': analysis shortcut retains its accessible name')
        p.locator('#analysisShortcut').click()
        check(p.evaluate('OR.state.page')=='analysis',prefix+': clipboard shortcut opens analysis')
        p.evaluate('OR.clinic.setAnalysisView("rubrics")')
        check(p.locator('.selected-item').count()==1,prefix+': selected rubric remains present')
        for mode in ['light','dark']:
            theme(p,mode)
            check(p.locator('#analysisSelected>.panel-title').is_visible() and contrast(effective_colors(p,'#analysisSelected>.panel-title'))>=4.5,prefix+'/'+mode+': real Selected view Case rubrics heading remains readable')
            check(p.locator('#selectedCount').inner_text()=='1' and contrast(effective_colors(p,'#selectedCount'))>=4.5,prefix+'/'+mode+': actual selected-rubric count badge remains readable')
            check(contrast(effective_colors(p,'.selected-item .wt button.on'))>=4.5,prefix+'/'+mode+': current rubric importance has readable selected contrast')
            p.locator('.selected-item .wt button[data-w="2"]').click()
            check(p.locator('.selected-item .wt button.on').get_attribute('data-w')=='2' and p.evaluate('OR.activeCase().analysis[0].w')==2 and contrast(effective_colors(p,'.selected-item .wt button.on'))>=4.5,prefix+'/'+mode+': changing importance updates the real selected state with readable contrast')
            p.locator('.selected-item .wt button[data-w="1"]').click()
        p.evaluate('OR.clinic.setAnalysisView("matrix")')
        check(p.locator('.grid-scroll').is_visible(),prefix+': matrix remains reachable')
        for mode in ['light','dark']:
            theme(p,mode)
            colors=effective_colors(p,'.analysis-disclaimer')
            check(contrast(colors)>=4.5,prefix+'/'+mode+': analysis explanation retains readable contrast')
            check(p.evaluate('JSON.stringify(OR.activeCase().analysis)')==original and p.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')==ranks,prefix+'/'+mode+': appearance leaves selected source grades and calculated ranks unchanged')
            if width==393:p.screenshot(path=str(O/f'glass-analysis-{mode}.png'),animations='disabled')
        # Menu navigation and picker still operate above the new material layer.
        p.locator('#menuBtn').click()
        check(not geometry(p),prefix+': root tools menu stays inside the viewport')
        p.keyboard.press('Escape');check(p.locator('#menuPanel').is_hidden(),prefix+': Escape closes menu over analysis')
        p.evaluate('OR.showPage("repertory")');p.locator('#sourcePicker').click()
        check(p.locator('.book-choice').count()==7,prefix+': all seven repertories remain available')
        p.get_by_role('button',name='Close',exact=True).last.click()
        check(not errors,prefix+': glass workflows have no uncaught JavaScript errors')
        context.close()
    # The user's low-effects choice persists and works independently of engine
    # filter support. There is no need to sacrifice legibility for the effect.
    c=b.new_context(viewport={'width':393,'height':800});p=c.new_page();ready(p);reading(p)
    check(p.locator('#glassEffects').is_checked(),'glass effects start enabled')
    p.locator('#glassEffects').uncheck()
    check(p.locator('body').get_attribute('data-glass-effects')=='off' and p.evaluate('OR.store.get("openrepertory_ui").glassEffects') is False,'turning effects off applies and saves solid mode')
    for selector in ['#menuPanel','#bottomNav']:
        check(p.locator(selector).evaluate('e=>{const c=getComputedStyle(e);return (!c.backdropFilter||c.backdropFilter==="none")&&(!c.webkitBackdropFilter||c.webkitBackdropFilter==="none")}'),'solid mode removes blur from '+selector)
    p.reload();p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000);reading(p)
    check(not p.locator('#glassEffects').is_checked() and p.locator('body').get_attribute('data-glass-effects')=='off','solid mode survives reload')
    p.locator('#glassEffects').check()
    check(p.locator('body').get_attribute('data-glass-effects')=='on','glass effects can be restored')
    p.screenshot(path=str(O/'glass-reading-menu.png'),animations='disabled')
    # Removing enhancement @supports blocks exercises the same opaque base
    # cascade older WebViews receive, without pretending to emulate that engine.
    removed=p.evaluate('''()=>{
      const sheet=[...document.styleSheets].find(s=>s.href&&s.href.endsWith('/css/liquid-glass.css'));let n=0;
      for(let i=sheet.cssRules.length-1;i>=0;i--)if(sheet.cssRules[i].type===CSSRule.SUPPORTS_RULE){sheet.deleteRule(i);n++;}
      return n;
    }''')
    check(removed>0,'unsupported-filter simulation removes the progressive enhancement rules')
    for selector in ['#menuPanel','#bottomNav']:
        check(p.locator(selector).evaluate('e=>{const c=getComputedStyle(e),rgba=(c.backgroundColor.match(/[\\d.]+/g)||[]).map(Number);return (!c.backdropFilter||c.backdropFilter==="none")&&(!c.webkitBackdropFilter||c.webkitBackdropFilter==="none")&&(rgba.length===3||rgba[3]===1)}'),'no-filter fallback keeps '+selector+' opaque without blur')
    check(not geometry(p),'no-filter fallback retains readable menu layout')
    c.close()
    # Presentation protection stays opaque and patient data remain untouched.
    c=b.new_context(viewport={'width':393,'height':800});p=c.new_page();ready(p)
    p.evaluate('OR.showPage("patients")');p.locator('#patientNew').click();p.locator('[data-k=name]').fill('Synthetic glass privacy patient');p.get_by_role('button',name='Create patient',exact=True).click();p.locator('#patientTabs').wait_for()
    theme(p,'dark');check(contrast(effective_colors(p,'.file-head h2'))>=4.5,'dark patient file heading remains readable')
    p.evaluate('OR.showPage("patients")');before=p.evaluate('JSON.stringify(OR.patientList())');reading(p);p.locator('#readingPreferences').click();p.locator('#presentationMode').check();p.get_by_role('button',name='Apply',exact=True).click();p.evaluate('OR.showPage("patients")')
    check(p.locator('#presentationShield').is_visible() and p.locator('#patientList').is_hidden(),'presentation mode keeps clinical patient cards hidden under glass chrome')
    check(p.locator('#presentationShield').evaluate('e=>{const c=getComputedStyle(e),a=(c.backgroundColor.match(/[\\d.]+/g)||[]).map(Number);return c.opacity==="1"&&(a.length===3||a[3]===1)&&(!c.backdropFilter||c.backdropFilter==="none")}'),'presentation shield remains opaque without patient-revealing blur')
    check('Synthetic glass privacy patient' not in p.locator('#activeContext').inner_text(),'presentation context does not expose patient identity')
    p.locator('#exitPresentation').click();check(p.locator('#patientList').is_visible() and p.evaluate('JSON.stringify(OR.patientList())')==before,'leaving presentation restores the unchanged patient record')
    # Print cascade must remove decorative effects and not expose open menus.
    p.locator('#menuBtn').click();p.emulate_media(media='print')
    check(p.locator('#menuPanel').is_hidden(),'printing hides the glass tools overlay')
    check(p.evaluate('''()=>[...document.querySelectorAll('body *')].every(e=>{const c=getComputedStyle(e);return (!c.backdropFilter||c.backdropFilter==="none")&&c.boxShadow==="none"})'''),'printing removes blur and decorative shadows')
    p.emulate_media(media='screen');c.close()
    # Reduced-motion media preference must remove entrance animation/transitions.
    c=b.new_context(viewport={'width':393,'height':800},reduced_motion='reduce');p=c.new_page();ready(p);p.locator('#menuBtn').click()
    check(p.evaluate('''()=>['#menuPanel','#bottomNav'].every(s=>{const c=getComputedStyle(document.querySelector(s));return c.animationName==='none'&&c.transitionDuration.split(',').every(x=>parseFloat(x)<=.01)})'''),'reduced motion removes glass menu/navigation animation')
    p.screenshot(path=str(O/'glass-menu-reduced-motion.png'),animations='disabled');c.close()
    b.close()
(O/'liquid-glass-tests.json').write_text(json.dumps(checks,indent=2)+'\n')
print('Liquid Glass checks passed:',len(checks))
