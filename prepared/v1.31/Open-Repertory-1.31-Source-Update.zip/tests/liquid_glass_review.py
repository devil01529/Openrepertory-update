"""Independent visual review using screenshot-composited contrast, not raw rgba."""
from pathlib import Path
from io import BytesIO
from PIL import Image
import json,re
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.27';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(ok,label):
 assert ok,label
 checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def lum(rgb):
 v=[x/255 for x in rgb];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v];return sum(a*b for a,b in zip(v,[.2126,.7152,.0722]))
def ratio(a,b):
 x,y=sorted([lum(a),lum(b)]);return (y+.05)/(x+.05)
def colors(p,selector):
 e=p.locator(selector).first;e.scroll_into_view_if_needed();p.wait_for_timeout(30)
 d=e.evaluate('''e=>{let s=getComputedStyle(e);return {style:e.getAttribute('style'),color:s.color};}''');rect=e.bounding_box()
 e.evaluate("e=>e.style.setProperty('color','transparent','important')")
 im=Image.open(BytesIO(p.screenshot()));pixel=im.getpixel((int(rect['x']+rect['width']/2),int(rect['y']+rect['height']/2)))[:3]
 e.evaluate('(e,s)=>s===null?e.removeAttribute("style"):e.setAttribute("style",s)',d['style'])
 fg=[float(x) for x in re.findall(r'[\d.]+',d['color'])[:3]];return ratio(fg,pixel),pixel
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
  ctx=b.new_context(viewport={'width':width,'height':height});p=ctx.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
  for theme in ['light','dark','auto']:
   p.emulate_media(color_scheme='dark' if theme=='auto' else theme)
   p.evaluate('(t)=>[document.documentElement,document.body].forEach(e=>t==="auto"?e.removeAttribute("data-theme"):e.setAttribute("data-theme",t))',theme)
   p.evaluate('OR.showPage("dashboard")')
   for selector in ['#pageTitle','.bottom-nav button.active small','.bottom-nav button:not(.active) small']:
    cr,_=colors(p,selector);check(cr>=4.5,f'{width}/{theme}: screenshot-composited {selector} contrast {cr:.2f}')
   p.evaluate('OR.openReadingMenu()');p.locator('#textSizeReset').click()
   for _ in range(4):p.locator('#textSizeLarger').click()
   for selector in ['#menuTitle','#menuReadingPanel .small-note','.glass-option small']:
    if p.locator(selector).count():
     cr,_=colors(p,selector);check(cr>=4.5,f'{width}/{theme}/140%: actual menu text contrast {selector} {cr:.2f}')
   p.locator('#glassEffects').scroll_into_view_if_needed();check(p.locator('#glassEffects').is_visible(),f'{width}/{theme}/140%: last reading option reachable')
   check(p.locator('.menu-content').evaluate('e=>e.scrollWidth<=e.clientWidth+2'),f'{width}/{theme}/140%: no horizontal reading-menu overflow')
   p.locator('#glassEffects').uncheck();check(p.locator('#menuPanel').evaluate('e=>getComputedStyle(e).backdropFilter==="none"&&getComputedStyle(e).backgroundColor.startsWith("rgb(")'),f'{width}/{theme}: solid mode removes blur and transparency')
   p.locator('#glassEffects').check();p.locator('#textSizeReset').click();p.locator('#menuBack').click()
   cr,_=colors(p,'.mi-text small');check(cr>=4.5,f'{width}/{theme}: actual root menu subtitle contrast {cr:.2f}')
   p.locator('#menuClose').click();p.evaluate('OR.showPage("repertory")');p.locator('#chapterTree .chapter-choice').first.click()
   p.locator('#sidebarToggle').click();cr,_=colors(p,'.chapter-row.active small');check(cr>=4.5,f'{width}/{theme}: active chapter count contrast {cr:.2f}')
   p.evaluate('OR.openReadingMenu()');p.locator('#readingPreferences').click();p.locator('#presentationMode').check();p.locator('.modal-foot .primary-btn').click();p.evaluate('OR.showPage("dashboard")')
   check(p.locator('#presentationShield').evaluate('e=>!e.hidden&&getComputedStyle(e).opacity==="1"&&getComputedStyle(e).backgroundColor.startsWith("rgb(")&&getComputedStyle(e).backdropFilter==="none"'),f'{width}/{theme}: privacy shield remains opaque and unblurred')
   p.locator('#exitPresentation').click()
   check(p.locator('#presentationShield').is_hidden() and p.locator('.context-patient').inner_text()=='Unlinked case' and p.locator('.context-case').inner_text()=='Case 1',f'{width}/{theme}: shield exit restores active consultation labels immediately')
   p.evaluate('OR.openReadingMenu()');p.locator('#readingPreferences').click();p.locator('#presentationMode').check();p.locator('.modal-foot .primary-btn').click()
   p.evaluate('OR.openReadingMenu()');p.locator('#readingPreferences').click();p.locator('#presentationMode').uncheck();p.locator('.modal-foot .primary-btn').click()
   check(p.locator('#presentationShield').is_hidden() and p.locator('.context-patient').inner_text()=='Unlinked case' and p.locator('.context-case').inner_text()=='Case 1',f'{width}/{theme}: settings exit restores active consultation labels immediately')
   if width==393 and theme!='auto':p.screenshot(path=str(O/f'independent-today-{theme}.png'))
  p.emulate_media(reduced_motion='reduce');check(p.locator('.bottom-nav button').first.evaluate('e=>getComputedStyle(e).transitionDuration==="0s"'),f'{width}: reduced motion disables new transitions')
  p.emulate_media(media='print');check(p.locator('#toolbar').evaluate('e=>getComputedStyle(e).backdropFilter==="none"&&getComputedStyle(e).boxShadow==="none"'),f'{width}: print removes blur and shadows')
  check(not errors,f'{width}: no JavaScript errors during independent review');ctx.close()
 b.close()
(O/'liquid-glass-independent-review.json').write_text(json.dumps(checks,indent=2));print('Independent visual checks passed:',len(checks))
