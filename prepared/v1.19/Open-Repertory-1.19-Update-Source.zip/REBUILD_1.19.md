# Open Repertory 1.19 source overlay

Apply these files over the retained full clinical application source (including its existing apk/assets/www data and resources). This overlay includes maintained native classes, Android resources/configuration, web source, menu HTML, release tools and tests. Clinical databases are unchanged and are not duplicated here. The repository's android-updater directory is only the updater module; this archive includes the activity/menu integration as well.

Retain the existing Android keystore securely at build/development.p12; never generate a replacement for installed users. The build refuses to continue if it is missing. The separate metadata private key is also required to prepare future releases. Neither private key is included here. Follow UPDATE_OWNER_GUIDE.md for custody, tool setup, versioning, release preparation and free publication.

Install the pinned tools with setup_tools.py, install the existing tooling/package-lock.json dependencies using npm ci in tooling, then run bash build.sh from the full project root. Java, Python, Node and Python cryptography are prerequisites. Build versions come from release-config.json. The documented build.sh path is the tested release build; Gradle configuration is supplied for development but no Gradle wrapper is included.

See the current online test report at https://github.com/devil01529/Openrepertory-update/blob/main/TEST_REPORT_1.19.md for validation and remaining physical-device checks.
