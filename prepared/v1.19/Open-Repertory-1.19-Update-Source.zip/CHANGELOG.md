# 1.19-dev · Free signed APK updates

Add a native App updates screen with optional GitHub Release checks after workspace readiness, once per day, and immediate manual checks. Download on request with bounded streams, cancellation and private storage; validate independently signed release metadata, APK hash/size, package, version, certificate and Android compatibility. Share only the verified APK read-only with Android’s installer, retaining normal approval checks and encrypted records. Add owner/developer release tools and a publishing guide. Stop builds when the existing signing identity is unavailable. No Apper backend changes or clinical database changes.

# 1.18-dev · In-app owner approvals

Expose existing Apper approval controls from the native Owner profile. Add a compact manager bar and retain the clinical document when entering and returning. Successful approval checks no longer close the manager. Keep checks on resume, deny the native entry to Members, and exit on current-phone revocation or fresh loss of the Owner role. Preserve clinical assets, startup behavior, encrypted records and backend permissions. No schema or backend deployment change.

# 1.17-dev · Smoother automatic sign-in and first frame

Hide the access-page flash under a branded native Signing in… cover, preload access while Android unlock runs, reuse the access document on warm return/re-unlock, check receipts every 100 ms, and wait for the first prepared clinical frame before a short fade. Keep fresh access checks, denial recovery and local records. The user confirmed 1.16 live login works. No backend/clinical database changes.

# 1.16-dev · Live Apper access, Firebase archived

Replace active Firebase authentication/grants with Apper's hosted Owner/Member authentication and connected access-only tables. Add owner request review, approve/reject/revoke, operational audit, team management and phone receipt pages. The native gate pins the portal origin, validates fresh receipt/project/account/request/device bindings, rejects mock/invalid receipts and retains bounded encrypted offline approval. Preserve clinical data/assets, device fingerprint, signing identity and screenshots. Legacy record binding requires explicit owner confirmation and Android reauthentication. Update the guide and download delivery. Live public auth and anonymous denial are tested; private owner approval on the user's phone remains unverified.

# 1.15-dev · Approval synchronisation and owner phone action

Add automatic foreground pending checks, uncached REST reads, precise missing-document/UID/status/device diagnostics and copied exact document path. A verified configured owner can explicitly approve the current phone using an atomic server-enforced grant and audit write; normal users cannot invoke this action. Preserve clinical data, screenshots, encrypted records and account/device binding. Local REST, owner-portal, installed native and package checks pass; private project inspection and phone acceptance remain unverified. Aper integration is being investigated separately; no Aper backend is embedded or claimed.

# 1.14-dev · Recover verification and approval after Firebase denial

Keep resend-verification, request-approval and copy-details controls available on denied/backend/offline screens. Add safe Firebase error categories, preserve sign-in for recoverable backend configuration errors, distinguish a missing database from a missing grant, and reject unverified requests with a clear instruction. Add exact copyable UID/device metadata without credentials. Supply a phone-only Console guide with owner-pinned rules; Hosting is optional for Console approvals. Clinical web assets and databases are unchanged except a generated audit timestamp. Live Console publication and acceptance remain pending.

# 1.13-dev · User Firebase configuration

Pinned the user-supplied public Firebase project configuration and explicit owner UID. Prepared a configured deployment package and activation guide, retained the APK signing identity and raised version code to 14. No Analytics initialization, clinical code or data changes. Firebase deployment and live account acceptance remain pending.

# 1.12-dev · Compact UI and Firebase approval gate

Implemented verified email login, owner-only grants/dashboard, device matching, encrypted offline cache and native asset/bridge checks. Refined the user-marked header, chapter context and Materia Medica toolbar without changing clinical database bytes or scoring. Firebase emulator and Android fixture checks pass. Live project configuration/deployment still required; default setup build fails closed.

# 1.11-dev · Enable screenshots for UI review

Allow capture while unlocked and in the foreground, including after navigation and short background/resume. Keep locked/background windows protected. No new Android permissions or repertory database changes. Added APPROVED_ACCESS_PLAN.md; account approval is planned, not implemented.

# 1.10-dev · Additional scan review and missing remedy repairs

Reviewed all 45 previously pending abbreviation occurrences, corrected seven OCR spellings and restored Sabina/Malandrinum links. Added explicit notes for 43 unresolved printed identity occurrences and 197 individually verified styles. Preserved all existing numerical links and headings; source certification remains partial.

# 1.9-dev · Clarke print styles and graceful app icon

Added traceable source typography independently of presence scores, original-abbreviation display/search, style-review details, persistent source metadata and clearer Clarke analysis labels. Installed new book/botanical artwork with adaptive and themed launcher resources. Underlying remedy identities, links and scores unchanged.

# 1.8-dev · Compact repertory rows

Reduced row padding, remedy button height and transcription margins. Replaced wrapping row controls with explicit grid positions and safe text wrapping. Phone repertory opens at full width with Chapters available to open the sidebar. Underlying databases and scoring unchanged.

# 1.7-dev · Clarke source audit

Repairs source transcription, missing entries, parent paths, continued lists and remedy aliases. Adds reference navigation, source coverage and saved-case revision notices. See SOURCE_CROSSCHECK_REPORT.md for counts and incomplete verification scope.

## 1.6-dev · Clarke structured repertory

- Added Clarke 1904 Parts I–III as an offline structured repertory database with searchable rubrics and remedy links.
- Preserved source abbreviations, combined remedy identities, citations and qualified causation entries; did not infer strength grades.
- Added source-specific remedy names, review flags and disabled addition of empty headings.
- Preserved rubric citations across cases, snapshots, reload and export; used stable Clarke IDs to distinguish duplicate text headings.
- Added database, browser and Android instrumentation tests. No PDF reader or scan assets are bundled.

# 1.5-dev

Implements the six-area improvement plan: maintained native Android host; transactional per-record AES-GCM storage and legacy migration; startup corruption recovery preserving damaged files; durable encrypted drafts and export recovery; failed-write rollback; worker search; owned cancellable Gemini client; strict backup validation; accessible modals and complete report printing. Original historical data is preserved. See TEST_REPORT.md for verification and limits.

# 1.4-dev

Initial reconstructed side-by-side development package with restricted WebView, encrypted storage/backups, lazy corpus loading, source provenance and regression tests. Superseded by the maintained native host in 1.5-dev.
