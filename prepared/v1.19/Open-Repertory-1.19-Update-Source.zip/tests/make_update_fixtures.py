"""Prepare signed minimal APK fixtures; these never go to GitHub or real phones."""
from pathlib import Path
import subprocess,shutil
R=Path(__file__).resolve().parents[1];O=R/'build/update-fixtures';O.mkdir(parents=True,exist_ok=True)
bt=Path('/workspace/tools/android/android-15');platform='/workspace/tools/android/android-35/android.jar'
# Existing key signs only the matching fixture. Wrong signer uses a fresh isolated test key.
wrong=O/'wrong.p12'
if not wrong.exists():subprocess.run(['keytool','-genkeypair','-keystore',str(wrong),'-storepass','fixture-password','-alias','fixture','-keyalg','RSA','-validity','2','-dname','CN=Update Fixture'],check=True,capture_output=True)
for name,package,code,key,password in [('valid','com.openrepertory.app.dev',21,R/'build/development.p12','repertory-development'),('wrong-package','example.wrong.update',21,R/'build/development.p12','repertory-development'),('wrong-signer','com.openrepertory.app.dev',21,wrong,'fixture-password'),('old','com.openrepertory.app.dev',19,R/'build/development.p12','repertory-development')]:
    manifest=O/(name+'.xml');manifest.write_text(f'<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="{package}" android:versionCode="{code}" android:versionName="fixture"><uses-sdk android:minSdkVersion="23" android:targetSdkVersion="35"/><application android:label="Update test fixture"/></manifest>')
    unsigned=O/(name+'-unsigned.apk');aligned=O/(name+'-aligned.apk');apk=O/(name+'.apk')
    subprocess.run([str(bt/'aapt2'),'link','-I',platform,'--manifest',str(manifest),'-o',str(unsigned)],check=True)
    subprocess.run([str(bt/'zipalign'),'-f','4',str(unsigned),str(aligned)],check=True)
    subprocess.run([str(bt/'apksigner'),'sign','--ks',str(key),'--ks-pass','pass:'+password,'--out',str(apk),str(aligned)],check=True)
print('Prepared 4 minimal APK validation fixtures; never install them.')
