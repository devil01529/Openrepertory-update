from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.19';checks=[]
def check(value,label):
 assert value,label
 checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [320,393,768]:
  page=browser.new_page(viewport={'width':width,'height':850});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('http://127.0.0.1:8765');page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000)
  page.locator('#menuBtn').click();page.locator('#menuUpdates').click();check('Android app' in page.locator('body').inner_text(),f'{width}px web fallback clearly identifies native update availability')
  check(page.evaluate('document.documentElement.scrollWidth<=innerWidth'),f'{width}px update menu introduces no page overflow')
  page.evaluate("OR.setRepertory('clarke');OR.showPage('repertory')");page.wait_for_function("()=>OR.state.repertoryId==='clarke'")
  page.evaluate("OR.runSearch('acidity')");page.wait_for_function("()=>OR.lastSearchStats&&OR.lastSearchStats.query==='acidity'",timeout=30000)
  row=page.locator('[data-rubric-uid*="clarke-043-2150"]');check(row.locator('.source-italic').count()==4,f'{width}px Clarke typography and search remain intact')
  row.locator(':scope > .rubric-row > .add-btn').click();check(page.evaluate('OR.activeCase().analysis.length>0'),f'{width}px original add-to-analysis function remains usable')
  page.evaluate("OR.showPage('analysis')");check(not errors,f'{width}px no uncaught JavaScript errors')
  if width==393:page.screenshot(path=str(O/'clinical-after-update-menu.png'))
  page.close()
 browser.close()
(O/'update-web-tests.json').write_text(json.dumps(checks,indent=2));print('Update web checks passed:',len(checks))
