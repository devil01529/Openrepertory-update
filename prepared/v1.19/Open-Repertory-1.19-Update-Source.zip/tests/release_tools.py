"""Release preparation failures are checked before public publication."""
from pathlib import Path
import base64,importlib.util,json,subprocess,tempfile
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import padding,rsa
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.19';results=[]
spec=importlib.util.spec_from_file_location('prepare_release',R/'scripts/prepare_release.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
c=json.loads((R/'release-config.json').read_text());apk=R/'dist/Open-Repertory-Clarke-Dev.apk'
def check(v,label):
 assert v,label
 results.append({'test':label,'status':'passed'});print('PASS',label)
def rejects(action):
 try:action();return False
 except (ValueError,AssertionError):return True
with tempfile.TemporaryDirectory() as d:
 d=Path(d);key=rsa.generate_private_key(public_exponent=65537,key_size=2048);private=d/'private.pem';private.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));private.chmod(0o600)
 config=dict(c,manifestPublicKey=base64.b64encode(key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)).decode())
 notes=d/'notes.md';notes.write_text('Synthetic release preparation test')
 module.prepare(apk,private,notes,d/'output','v1.19',config)
 envelope=json.loads((d/'output/update.json').read_text());raw=base64.b64decode(envelope['payload']);key.public_key().verify(base64.b64decode(envelope['signature']),raw,padding.PKCS1v15(),hashes.SHA256())
 check(json.loads(raw)['apkUrl'].endswith('/v1.19/Open-Repertory-1.19.apk'),'prepared release signature and APK URL validate')
 check(sorted(p.name for p in (d/'output').iterdir())==['Open-Repertory-1.19.apk','RELEASE_NOTES.md','SHA256SUMS','update.json'],'prepared output contains only four public release files')
 check(rejects(lambda:module.inspect_apk(apk,dict(c,apkCertificateSha256='0'*64))),'wrong Android certificate is rejected')
 check(rejects(lambda:module.inspect_apk(apk,dict(c,versionCode=21))),'incorrect configured version is rejected')
 check(rejects(lambda:module.prepare(apk,private,notes,d/'bad','v1.19',c)),'incorrect metadata signing key is rejected')
 check(rejects(lambda:module.prepare(apk,private,notes,d/'bad','v1.20',config)),'release tag must match the APK version')
 notes.write_text('');check(rejects(lambda:module.prepare(apk,private,notes,d/'bad','v1.19',config)),'empty release notes are rejected')
 build=d/'build.sh';build.write_bytes((R/'build.sh').read_bytes());run=subprocess.run(['bash',str(build)],capture_output=True,text=True)
 check(run.returncode!=0 and 'refusing to create a replacement' in run.stderr and not (d/'build/development.p12').exists(),'missing Android signing key stops the build without generating a replacement')
(O/'release-tool-tests.json').write_text(json.dumps(results,indent=2));print('Release tool checks passed:',len(results))
