"""Verify delivery identity, clinical-data preservation and updater packaging."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.19';O.mkdir(parents=True,exist_ok=True)
A=R/'dist/Open-Repertory-Clarke-Dev.apk';old=Path('/workspace/.open-repertory-release/Open-Repertory-1.18-before-updater.apk');bt=Path('/workspace/tools/android/android-15');rows=[]
def check(ok,label):
 assert ok,label
 rows.append({'test':label,'status':'passed'});print('PASS',label)
with zipfile.ZipFile(A) as z,zipfile.ZipFile(old) as before:
 check(z.testzip() is None,'APK ZIP integrity')
 changed=[]
 for n in before.namelist():
  if not n.startswith('assets/www/'):continue
  if before.read(n)==z.read(n):continue
  if n in ['assets/www/index.html','assets/www/js/app.js']:continue
  if 'audit' in n and n.endswith('.json'):
   a=json.loads(z.read(n));b=json.loads(before.read(n))
   for k in ['generatedAt','builtAt','generated_at']:a.pop(k,None);b.pop(k,None)
   if a==b:continue
  changed.append(n)
 check(not changed,'all clinical assets unchanged except the update menu and generated audit time: '+str(changed))
 names=[n for n in before.namelist() if n.startswith('assets/www/data/') and not ('audit' in n)]
 check(all(z.read(n)==before.read(n) for n in names),f'all {len(names)} clinical database/text assets retain identical bytes')
 check(not any(n.endswith(('.p12','.jks','.pem','.keystore','.pdf')) or 'firebase-config' in n for n in z.namelist()),'APK excludes private keys, Firebase configuration and source PDF')
 dex=z.read('classes.dex')
 check(all(b in dex for b in [b'AppUpdates',b'UpdateFileProvider',b'releases/latest/download/update.json',b'SHA256withRSA']), 'signed updater and restricted installer provider are compiled into the APK')
 check(b'devil01529/Openrepertory-update' in dex and b'devil01529/open-repertory-update-' not in dex,'APK uses the selected public update repository only')
 check(all(b not in dex for b in [b'UpdateChecks',b'UpdateUiChecks',b'FixtureAuthView',b'synthetic-apper-owner',b'ghu_',b'ghp_',b'PRIVATE KEY',b'FirebaseAccess']), 'test fixtures, publishing credentials and retired Firebase client are excluded')
 check(b'preview--openrepertory-eminent.apper.so' in dex,'existing Apper approval endpoint is retained')
badging=subprocess.check_output([str(bt/'aapt2'),'dump','badging',str(A)],text=True)
check("name='com.openrepertory.app.dev'" in badging and "versionCode='20'" in badging and "versionName='1.19-dev'" in badging,'same package and increased version support in-place upgrade')
def cert(path):
 text=subprocess.check_output([str(bt/'apksigner'),'verify','--print-certs',str(path)],text=True)
 return next(s for s in text.splitlines() if 'certificate SHA-256 digest:' in s)
check(cert(A)==cert(old),'existing Android signing identity is retained')
previous=subprocess.check_output([str(bt/'aapt2'),'dump','badging',str(old)],text=True)
perms=lambda s:{v for v in s.splitlines() if v.startswith('uses-permission:')}
check(perms(badging)-perms(previous)=={"uses-permission: name='android.permission.REQUEST_INSTALL_PACKAGES'"},'only the required user-confirmed APK installation permission was added')
adb='/workspace/tools/android/platform-tools/adb';installed=subprocess.check_output([adb,'shell','pm','path','com.openrepertory.app.dev'],text=True).strip().removeprefix('package:');copy=O/'installed.apk';subprocess.run([adb,'pull',installed,str(copy)],check=True,capture_output=True)
check(hashlib.sha256(A.read_bytes()).digest()==hashlib.sha256(copy.read_bytes()).digest(),'installed and delivered APK hashes match');copy.unlink()
(O/'update-package-tests.json').write_text(json.dumps(rows,indent=2));print('Update package checks passed:',len(rows))
