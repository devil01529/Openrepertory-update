(function () {
  'use strict';
  const OR=window.OR,S=OR.state,$=OR.$,esc=OR.escapeHTML;
  let preferences={},analysisView='ranking',patientTab='overview',lastPage='dashboard';
  const readingPositions=new Map(),referenceHistory=[];
  const repKey=()=>[S.repertoryId,S.activeChapter?.name||S.activeChapter||'',S.query].join('|');
  const icon=(path)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
  const icons={dashboard:icon('<path d="m3 10 9-7 9 7v10H3Z"/><path d="M9 20v-7h6v7"/>'),repertory:icon('<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>'),analysis:icon('<rect x="5" y="5" width="14" height="17" rx="2"/><rect x="9" y="2" width="6" height="5" rx="1"/><path d="M9 12h6m-6 4h4"/>'),patients:icon('<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>'),mm:icon('<path d="M12 5C8 2 4 3 2 4v16c3-2 6-2 10 0 4-2 7-2 10 0V4c-3-1-6-2-10 1Z"/><path d="M12 5v15"/>')};
  function persist(){OR.store.set('openrepertory_ui',preferences);}
  function applyPreferences(){
    document.body.dataset.density=preferences.density==='compact'?'compact':'comfortable';
    document.body.classList.toggle('show-all-remedies',preferences.remedies==='all');
    document.body.classList.toggle('presentation-mode',!!preferences.presentation);
    if(preferences.presentation)$('page-repertory').classList.remove('finder-open');
    updatePrivacy();
  }
  function tabKeys(nav,activate){
    nav.addEventListener('keydown',event=>{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
      const tabs=[...nav.querySelectorAll('[role=tab]')];let i=tabs.indexOf(document.activeElement);if(i<0)return;
      event.preventDefault();i=event.key==='Home'?0:event.key==='End'?tabs.length-1:(i+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[i].focus();activate(tabs[i].dataset.view);
    });
  }
  function tabs(id,items,activate){
    const nav=document.createElement('nav');nav.id=id;nav.className='workspace-tabs';nav.setAttribute('role','tablist');
    nav.innerHTML=items.map(([value,label])=>`<button type="button" role="tab" data-view="${value}" aria-selected="false">${label}</button>`).join('');
    nav.addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b)activate(b.dataset.view);});tabKeys(nav,activate);return nav;
  }
  function selectTab(nav,value){nav.querySelectorAll('[role=tab]').forEach(b=>{const current=b.dataset.view===value;b.setAttribute('aria-selected',String(current));b.tabIndex=current?0:-1;});}
  function analysisChanged(){
    if(!$('analysisTabs'))return;
    const n=OR.activeCase()?.analysis.length||0;
    $('analysisTabs').querySelector('[data-view=rubrics]').textContent='Selected · '+n;
    $('analysisCaseSummary').textContent=(OR.activeCase()?.name||'Case')+' · '+n+' selected';
  }
  function setAnalysisView(view){
    analysisView=['rubrics','ranking','matrix'].includes(view)?view:'ranking';
    $('page-analysis').dataset.analysisView=analysisView;selectTab($('analysisTabs'),analysisView);
    $('analysisTabs').querySelectorAll('[role=tab]').forEach(b=>{b.id='analysis-tab-'+b.dataset.view;b.setAttribute('aria-controls',b.dataset.view==='rubrics'?'analysisSelected':'analysisResults');});
  }
  function patientView(view){
    patientTab=['overview','visits','cases','notes'].includes(view)?view:'overview';
    $('fileRoot').dataset.patientView=patientTab;
    if($('patientTabs'))selectTab($('patientTabs'),patientTab);
  }
  function patientRail(){
    const rail=$('patientRail');if(!rail)return;
    const current=OR.patients?.current();
    rail.innerHTML='<h2>Patients</h2><button type="button" id="railNewPatient" class="ghost-btn">＋ New patient</button>'+ (OR.patientList?.()||[]).map(p=>`<button type="button" data-patient="${esc(p.id)}" class="patient-rail-row ${p.id===current?.id?'active':''}"><b>${esc(p.name||'Unnamed patient')}</b><small>${p.visits?.length||0} visits · ${Object.values(S.cases).filter(c=>c.patientId===p.id).length} cases</small></button>`).join('');
    $('railNewPatient').onclick=()=>OR.patients.newPatient();
    rail.querySelectorAll('[data-patient]').forEach(b=>b.onclick=()=>{OR.flushPatientEdits?.();patientTab='overview';OR.patients.open(b.dataset.patient);});
  }
  let patientId=null;
  function patientRendered(patient){
    if(patient.id!==patientId){patientTab='overview';patientId=patient.id;}
    const nav=tabs('patientTabs',[['overview','Overview'],['visits','Visits'],['cases','Cases'],['notes','Notes']],patientView);
    $('saveInd').after(nav);
    nav.setAttribute('aria-label','Patient file sections');
    nav.querySelectorAll('[role=tab]').forEach(b=>b.setAttribute('aria-controls',{overview:'fileOverview',visits:'fileVisits',cases:'fileCases',notes:'fileNotes'}[b.dataset.view]));
    const add=document.createElement('button');add.type='button';add.className='primary-btn';add.textContent='＋ New visit';add.onclick=()=>{patientView('visits');OR.patients.newVisit(patient.id);};$('fileRoot').querySelector('.fh-actions').prepend(add);
    patientView(patientTab);patientRail();updateContext();
  }
  function updatePrivacy(){
    const shield=$('presentationShield');if(shield)shield.hidden=!(preferences.presentation&&['dashboard','patients','file'].includes(S.page));
    if(preferences.presentation){const p=$('activeContext').querySelector('.context-patient'),c=$('activeContext').querySelector('.context-case');if(p)p.textContent='Presentation mode';if(c)c.textContent='Patient identity hidden';const saved=$('activeContext').querySelector('.context-saved');if(saved)saved.textContent='Identities hidden · On this phone';}
  }
  function updateContext(){
    const c=OR.activeCase(),p=(OR.patientList?.()||[]).find(p=>p.id===c?.patientId);
    const patientLabel=$('activeContext').querySelector('.context-patient'),caseLabel=$('activeContext').querySelector('.context-case');
    if(patientLabel)patientLabel.textContent=p?.name||'Unlinked case';
    if(caseLabel)caseLabel.textContent=c?.name||'No active case';
    const visits=p?.visits||[],last=visits.slice().sort((a,b)=>b.date.localeCompare(a.date))[0];
    const state=document.createElement('span');state.className='context-saved';state.textContent=(last?'Visit '+last.date+' · ':'')+(OR.store.ok?'On this phone':'Save needs attention')+(c?.repertoryId&&c.repertoryId!==S.repertoryId?' · Case source: '+(S.repertories?.[c.repertoryId]?.title||c.repertoryId):'');
    $('activeContext').querySelector('.context-saved')?.remove();$('activeContext').appendChild(state);
    $('sourcePicker').textContent=S.repertory?.title||'Choose source';
    $('sourcePicker').title='Repertory source: '+(S.repertory?.title||'Loading');
    if(S.page==='file'&&OR.patients?.current()){
      const viewed=OR.patients.current();$('activeContext').querySelector('.context-patient').textContent=viewed.name||'Unnamed patient';
      if(c?.patientId!==viewed.id)$('activeContext').querySelector('.context-case').textContent='Viewing file · active case is separate';
    }
    updatePrivacy();
  }
  function contextDialog(){
    if(preferences.presentation){readingSettings();return;}

    const current=OR.activeCase(),items=Object.values(S.cases);
    OR.modal({title:'Patient and case',html:`<p>Choose the consultation you want to continue. Each case retains its repertory source.</p><label class="fld"><span>Case</span><select id="contextCase">${items.map(c=>`<option value="${esc(c.id)}" ${c.id===current?.id?'selected':''}>${esc(c.name)} · ${esc(c.patientId?OR.patientName(c.patientId):'Unlinked')} · ${c.analysis.length} rubrics</option>`).join('')}</select></label>`,actions:[{label:'Cancel'},{label:'New case',onClick:(_m,close)=>{close();$('caseNew').click();}},{label:'Open case',primary:true,onClick:m=>OR.openCase(m.querySelector('#contextCase').value)}]});
  }
  function readingSettings(){
    OR.modal({title:'Reading preferences',html:`<label class="fld"><span>Reading density</span><select id="readingDensity"><option value="comfortable">Comfortable</option><option value="compact">Compact</option></select></label><label class="fld"><span>Remedy lines</span><select id="readingRemedies"><option value="preview">Preview, expand when needed</option><option value="all">Show all entries</option></select></label><label class="presentation-option"><input id="presentationMode" type="checkbox"> Presentation mode: hide patient identities</label><p class="small-note">Patient screens and private remedy notes are hidden while presenting. Exports retain their original details. Reading presets preserve the complete source wording and grades.</p>`,actions:[{label:'Cancel'},{label:'Apply',primary:true,onClick:m=>{preferences.density=m.querySelector('#readingDensity').value;preferences.remedies=m.querySelector('#readingRemedies').value;preferences.presentation=m.querySelector('#presentationMode').checked;persist();applyPreferences();if(!preferences.presentation)OR.renderCaseSelect();}}],onMount:m=>{m.querySelector('#readingDensity').value=preferences.density||'comfortable';m.querySelector('#readingRemedies').value=preferences.remedies||'preview';m.querySelector('#presentationMode').checked=!!preferences.presentation;}});
  }
  function renderToday(){
    const root=$('dashboardRoot'),c=OR.activeCase(),patients=OR.patientList?.()||[],p=patients.find(p=>p.id===c?.patientId);
    const recent=patients.slice().sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)).slice(0,5);
    const cases=Object.values(S.cases).slice().reverse().slice(0,5),visits=(p?.visits||[]).slice().sort((a,b)=>b.date.localeCompare(a.date));
    const due=[];const today=new Date();today.setHours(0,0,0,0);
    patients.forEach(p=>(p.visits||[]).forEach(v=>{if(!v.followup||(p.visits||[]).some(x=>x.date>v.date))return;const days=Math.round((new Date(v.followup+'T00:00:00')-today)/86400000);if(days<=14)due.push({p,v,days});}));due.sort((a,b)=>a.days-b.days);
    root.innerHTML=`<div class="today-heading"><div><div class="eyebrow">CLINICAL WORKSPACE</div><h1>Today</h1></div><span class="muted">${esc(new Date().toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'short'}))}</span></div>
      <section class="resume-consultation"><div class="eyebrow">CONTINUE CONSULTATION</div><h2>${esc(p?.name||'Unlinked case')}</h2><p>${esc(c?.name||'No active case')} · ${c?.analysis.length||0} selected rubrics</p><div class="resume-meta">${esc(S.repertories?.[c?.repertoryId]?.title||S.repertory?.title||'Choose repertory')}${visits[0]?' · Last visit '+esc(visits[0].date):''}</div><div class="resume-actions"><button class="primary-btn" data-today="resume">Resume consultation →</button><button class="ghost-btn" data-today="repertory">Add rubric</button></div></section>
      <div class="today-shortcuts"><button class="ghost-btn" data-today="newpatient">＋ New patient</button><button class="ghost-btn" data-today="newvisit">＋ New visit</button><button class="ghost-btn" data-today="finder">Find rubrics</button></div>
      ${!patients.length&&!preferences.onboardingDismissed?'<section class="onboarding-card"><div><h2>Start a consultation</h2><p>Create a patient, record their words, then select source rubrics for analysis.</p></div><button class="ghost-btn" data-today="dismiss">Dismiss tips</button></section>':''}
      <div class="today-grid"><section class="dashboard-card"><div class="dashboard-card-head"><h3>Recent patients</h3><button class="mini-btn plain" data-today="patients">View all</button></div>${recent.map(p=>`<button class="dashboard-list-row" data-patient="${esc(p.id)}"><span><b>${esc(p.name||'Unnamed')}</b><small>${p.visits?.length||0} visits · Updated ${esc(new Date(p.updatedAt||p.createdAt).toLocaleDateString())}</small></span><span>›</span></button>`).join('')||'<p class="muted">No patients yet.</p>'}</section>
      <section class="dashboard-card"><h3>Recent cases</h3>${cases.map(c=>`<button class="dashboard-list-row" data-case="${esc(c.id)}"><span><b>${esc(c.name)}</b><small>${c.analysis.length} rubrics · ${esc(c.patientId?OR.patientName(c.patientId):'Unlinked')}</small></span><span>›</span></button>`).join('')}</section>
      <section class="dashboard-card"><h3>Follow-ups</h3>${due.slice(0,6).map(x=>`<button class="dashboard-list-row" data-patient="${esc(x.p.id)}"><span><b>${esc(x.p.name)}</b><small>${esc(x.v.followup)}</small></span><span>${x.days<0?(-x.days)+'d overdue':x.days===0?'Today':'In '+x.days+'d'}</span></button>`).join('')||'<p class="muted">No follow-ups due in the next 14 days.</p>'}</section>
      <section class="dashboard-card"><h3>Records and source trust</h3><p class="muted">${patients.length} patients · ${Object.keys(S.cases).length} cases. Records stay on this phone; keep an encrypted backup.</p><button class="ghost-btn" data-today="backup">Backup & restore</button><button class="ghost-btn" data-today="sources">Source catalogue & audit</button></section></div>`;
    root.querySelectorAll('[data-patient]').forEach(b=>b.onclick=()=>OR.patients.open(b.dataset.patient));root.querySelectorAll('[data-case]').forEach(b=>b.onclick=()=>OR.openCase(b.dataset.case));
    root.querySelectorAll('[data-today]').forEach(b=>b.onclick=()=>{switch(b.dataset.today){case'resume':if(c?.patientId)OR.patients.open(c.patientId);else OR.showPage(c?.analysis.length?'analysis':'repertory');break;case'newpatient':OR.patients.newPatient();break;case'newvisit':if(p)OR.patients.newVisit(p.id);else{OR.showPage('patients');OR.toast('Choose a patient to add a visit.');}break;case'finder':OR.showPage('repertory');OR.finder.focus();break;case'dismiss':preferences.onboardingDismissed=true;persist();renderToday();break;case'backup':OR.patients.openBackup();break;case'sources':$('repLibrary').click();break;default:OR.showPage(b.dataset.today);}});
  }
  function decorateRubric(div,row,r,context){
    const remedies=row.querySelector('.remedies');
    if((r.remedies?.length||0)>8){
      const button=document.createElement('button');button.type='button';button.className='remedy-expand';button.textContent='Show all '+r.remedies.length+' remedies';button.setAttribute('aria-expanded','false');
      button.onclick=()=>{const expanded=div.classList.toggle('remedies-expanded');button.textContent=expanded?'Collapse remedy list':'Show all '+r.remedies.length+' remedies';button.setAttribute('aria-expanded',String(expanded));};div.appendChild(button);remedies.classList.add('remedy-preview');
    }
    const button=document.createElement('button');button.type='button';button.className='rubric-source-button';button.textContent='Source ⓘ';button.setAttribute('aria-label','Source and references for '+context.fullPath);
    button.onclick=()=>{
      const refs=r.references||[],aliases=r.synonyms||[];
      OR.modal({title:'Rubric source and references',wide:true,html:`<p><b>${esc(S.repertory.title)}</b></p><p>${esc(context.chapterName+' › '+context.fullPath)}</p><p class="muted">${esc(r.sourceNote||r.sourcePath||'Database source: '+(S.repertory.source||'bundled source'))}</p><p class="small-note">Source IDs: ${esc((r.sourceIds||[r.id]).join(', '))}. ${S.repertoryId==='clarke'?'Printed italics are Prescriber references, not strength grades. Analysis counts presence.':'Grades are retained from the source database.'}</p>${aliases.length?'<h3>Source synonyms</h3><p>'+aliases.map(esc).join(' · ')+'</p>':''}<h3>Cross-references</h3>${refs.map((ref,i)=>`<button class="reference-link ghost-btn" type="button" data-ref="${i}">${esc(ref.kind==='synonym'?'Synonym: ':'See also: ')}${esc(ref.label)}</button>`).join('')||'<p class="muted">No structured cross-reference is recorded for this entry.</p>'}${r.sourceText?'<details><summary>Source transcription</summary><p>'+esc(r.sourceText)+'</p></details>':''}`,actions:[{label:'Close'}],onMount:(m,close)=>m.querySelectorAll('[data-ref]').forEach(b=>b.onclick=()=>{const ref=refs[+b.dataset.ref];close();OR.openSourceReference?.(ref);})});
    };div.appendChild(button);
    if(r.references?.length){const nav=document.createElement('div');nav.className='rubric-reference-links';r.references.forEach(ref=>{const b=document.createElement('button');b.type='button';b.textContent=(ref.kind==='synonym'?'Synonym: ':'See: ')+ref.label;b.onclick=()=>OR.openSourceReference?.(ref);nav.appendChild(b);});div.appendChild(nav);}
  }
  function beforePage(){
    if(lastPage==='repertory')readingPositions.set(repKey(),$('content').scrollTop);
    if(lastPage==='mm')readingPositions.set('mm-list',$('mmListPane').scrollTop);
    OR.flushPatientEdits?.();
  }
  function captureReference(){referenceHistory.push({source:S.repertoryId,chapter:S.activeChapter,query:S.query,scroll:$('content').scrollTop});$('referenceReturn').hidden=false;}
  async function returnReference(){
    const previous=referenceHistory.pop();if(!previous)return;
    if(previous.source!==S.repertoryId)await OR.setRepertory(previous.source);
    OR.showPage('repertory');
    if(previous.query){$('searchBox').value=previous.query;await OR.runSearch(previous.query);}
    else if(previous.chapter)OR.selectChapter(previous.chapter);
    requestAnimationFrame(()=>$('content').scrollTop=previous.scroll);$('referenceReturn').hidden=!referenceHistory.length;
  }
  function back(){
    const close=$('modalRoot').lastElementChild?.querySelector('.modal-x');if(close){close.click();return true;}
    if(S.page==='repertory'&&referenceHistory.length){returnReference();return true;}
    if(S.page==='mm'&&$('mmWrap').classList.contains('detail-open')){$('mmBack').click();return true;}
    if(S.page==='file'&&patientTab!=='overview'){patientView('overview');return true;}
    const destination={analysis:'repertory',file:'patients',diff:'mm',patients:'dashboard',mm:'dashboard',repertory:'dashboard'}[S.page];
    if(destination){OR.showPage(destination);return true;}return false;
  }
  function onPage(page){
    document.body.dataset.page=page;lastPage=page;
    if(page==='repertory'){const top=readingPositions.get(repKey());if(top!==undefined)requestAnimationFrame(()=>$('content').scrollTop=top);}
    if(page==='analysis'){analysisChanged();setAnalysisView(OR.activeCase()?.analysis.length?analysisView:'rubrics');}
    if(page==='mm'&&readingPositions.has('mm-list'))requestAnimationFrame(()=>$('mmListPane').scrollTop=readingPositions.get('mm-list'));
    if(page==='file')patientRail();updateContext();updatePrivacy();
  }
  // The existing engine owns records, scores and access. This layer owns presentation.
  OR.clinic={onPage,beforePage,renderToday,analysisChanged,patientRendered,patientView,updateContext,decorateRubric,setAnalysisView,captureReference,back};

  // Shared consultation frame and stable navigation.
  $('toolbar').after($('activeContext'));$('activeContext').onclick=contextDialog;
  $('bottomNav').querySelectorAll('[data-bottom-page]').forEach(b=>{b.querySelector('span').innerHTML=icons[b.dataset.bottomPage];});
  const source=document.createElement('button');source.type='button';source.id='sourcePicker';source.className='source-picker';source.onclick=()=>$('repLibrary').click();
  const command=document.createElement('div');command.id='repCommand';command.className='rep-command';command.appendChild($('sidebarToggle'));command.appendChild($('searchWrap'));
  const tools=document.createElement('div');tools.className='rep-reading-tools';tools.appendChild(source);tools.innerHTML+='<button id="finderToggle" type="button" class="ghost-btn" aria-expanded="false" aria-controls="aiBar">Patient words</button><button id="readingPreferences" type="button" class="ghost-btn" aria-label="Reading preferences">Aa</button>';
  // Appending HTML above re-creates the source button, so bind the final node.
  tools.querySelector('#sourcePicker').onclick=()=>$('repLibrary').click();
  const returnButton=document.createElement('button');returnButton.id='referenceReturn';returnButton.type='button';returnButton.className='ghost-btn';returnButton.textContent='← Previous rubric';returnButton.hidden=true;returnButton.onclick=returnReference;tools.prepend(returnButton);
  const reading=document.createElement('div');reading.className='rep-reading';[$('sidebar'),$('content'),$('infoPanel')].forEach(n=>reading.appendChild(n));
  $('page-repertory').appendChild(command);$('page-repertory').appendChild(tools);$('page-repertory').appendChild($('aiBar'));$('page-repertory').appendChild(reading);
  $('searchScope').options[0].textContent='Whole book';$('searchScope').options[1].textContent='Chapter';$('searchBox').placeholder='Search rubrics or remedies…';
  $('finderToggle').onclick=()=>{const open=$('page-repertory').classList.toggle('finder-open');$('finderToggle').setAttribute('aria-expanded',String(open));if(open)$('aiInput').focus();};
  const focusFinder=OR.finder.focus;OR.finder.focus=function(){ $('page-repertory').classList.add('finder-open');$('finderToggle').setAttribute('aria-expanded','true');return focusFinder.apply(this,arguments);};
  $('readingPreferences').onclick=readingSettings;
  const privacyShield=document.createElement('section');privacyShield.id='presentationShield';privacyShield.hidden=true;privacyShield.setAttribute('role','status');privacyShield.innerHTML='<h2>Presentation mode</h2><p>Patient screens are hidden while sharing the repertory and analysis.</p><button id="exitPresentation" type="button" class="primary-btn">Show my clinical workspace</button>';$('main').appendChild(privacyShield);
  $('exitPresentation').onclick=()=>{preferences.presentation=false;persist();applyPreferences();OR.renderCaseSelect();};
  const readingMenu=document.createElement('button');readingMenu.type='button';readingMenu.className='menu-item';readingMenu.id='menuReading';readingMenu.innerHTML='<span class="mi-ico">'+icon('<path d="M4 20 10 4l6 16M6 15h8m4-6h4m-2-2v11"/>')+'</span><span class="mi-text"><b>Reading & privacy</b><small>Density, remedy lines and presentation mode</small></span>';
  $('menuSettings').appendChild(readingMenu);readingMenu.onclick=()=>{OR.dismissMenu();OR.dismissMenu();readingSettings();};
  $('menuSettingsButton').querySelector('b').textContent='Settings';


  const analysis=$('page-analysis');
  const context=document.createElement('details');context.className='analysis-context';context.innerHTML='<summary id="analysisCaseSummary">Case and patient</summary>';context.appendChild($('caseBar'));context.appendChild($('casePatientBar'));
  const nav=tabs('analysisTabs',[['rubrics','Selected'],['ranking','Ranking'],['matrix','Matrix']],setAnalysisView);nav.setAttribute('aria-label','Analysis views');
  const work=document.createElement('div');work.className='analysis-workspace';work.appendChild($('analysisSelected'));work.appendChild($('analysisResults'));analysis.appendChild(work);
  const actions=document.createElement('div');actions.className='analysis-actions';['saveSnapshot','snapshotHistory','compareRemedies'].forEach(id=>actions.appendChild($(id)));
  const more=document.createElement('details');more.className='analysis-more';more.innerHTML='<summary>More actions</summary>';['copySummary','exportCase','printCase'].forEach(id=>more.appendChild($(id)));actions.appendChild(more);
  analysis.appendChild(context);analysis.appendChild(nav);analysis.appendChild(actions);analysis.appendChild(work);setAnalysisView('ranking');
  const rail=document.createElement('aside');rail.id='patientRail';rail.setAttribute('aria-label','Patients in this workspace');$('page-file').prepend(rail);
  const library=document.createElement('div');library.className='library-switch';library.innerHTML='<b>Remedy library</b><button type="button" class="ghost-btn" id="libraryCompare">Compare remedies</button>'; $('mmListPane').prepend(library);$('libraryCompare').onclick=()=>OR.showPage('diff');
  const originalBack=()=>{readingPositions.set('mm-list',$('mmListPane').scrollTop);};$('mmList').addEventListener('click',originalBack,true);
  OR.hooks.start.push(()=>{preferences=OR.store.get('openrepertory_ui')||{};applyPreferences();});
  function measureNavigation(){const height=innerWidth<700?$('bottomNav').getBoundingClientRect().height:0;document.documentElement.style.setProperty('--clinical-nav-height',height+'px');}
  measureNavigation();if(typeof ResizeObserver!=='undefined')new ResizeObserver(measureNavigation).observe($('bottomNav'));
  window.addEventListener('resize',()=>{measureNavigation();if(S.page==='analysis')setAnalysisView(analysisView);});
})();
