import os
"""User-facing navigation, accessibility, layout and retained workflow checks."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/os.environ.get('OR_TEST_RESULTS','test-results/v1.20');O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,label):
 assert v,label
 checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def ready(page):
 page.goto('http://127.0.0.1:8765');page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000)
def open_menu(page):
 if page.locator('#menuPanel').is_hidden():page.locator('#menuBtn').click()
 page.wait_for_timeout(160)
def geometry(page):return page.evaluate('''()=>{
 const panel=document.querySelector('#menuPanel'),r=panel.getBoundingClientRect(),issues=[];
 if(r.left<-.5||r.right>innerWidth+.5||r.top<-.5||r.bottom>innerHeight+.5)issues.push('panel outside viewport');
 const buttons=[...panel.querySelectorAll('.menu-item')].filter(e=>e.getClientRects().length);
 for(let i=1;i<buttons.length;i++){if(buttons[i-1].getBoundingClientRect().bottom>buttons[i].getBoundingClientRect().top+.5)issues.push('overlapping action rows');}
 for(const row of buttons){const box=row.getBoundingClientRect();if(box.height<44)issues.push('small touch target');for(const label of row.querySelectorAll('b,small')){const text=label.getBoundingClientRect();if(text.left<box.left-.5||text.right>box.right+.5||text.bottom>box.bottom+.5)issues.push('label overflow');}}
 return issues;
}''')
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(320,640),(360,780),(393,800),(412,915),(640,360),(768,850),(1280,900)]:
  page=browser.new_page(viewport={'width':width,'height':height});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));ready(page);open_menu(page)
  check(not geometry(page),f'{width}×{height}: menu stays inside the viewport with readable, non-overlapping touch targets')
  if width<700:check(page.locator('#menuHome .menu-item:visible').count()==7,f'{width}px: phone menu has seven grouped actions and no duplicated primary navigation')
  else:check(page.locator('#bottomNav [data-bottom-page]:visible').count()==5,f'{width}px: all five primary destinations remain available in the tablet/desktop rail')
  page.locator('#menuSettingsButton').scroll_into_view_if_needed();page.locator('#menuSettingsButton').click();check(page.locator('#menuSettings .menu-item:visible').count()==3 and not geometry(page),f'{width}px: settings is a separate readable settings view')
  page.locator('#menuBack').click();check(page.locator('#menuHome').is_visible(),f'{width}px: Settings Back returns to tools')
  page.locator('#menuClose').click();check(page.locator('#menuBtn').get_attribute('aria-expanded')=='false' and page.locator('#toolbar').get_attribute('aria-hidden') is None,f'{width}px: Close restores the workspace and accessibility state')
  check(not errors,f'{width}px: no uncaught navigation errors');page.close()
 page=browser.new_page(viewport={'width':393,'height':800});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));ready(page);open_menu(page)
 check(page.locator('#menuFinder').evaluate('e=>e===document.activeElement'),'opening the menu focuses its first clinical action')
 check(page.locator('#main').get_attribute('aria-hidden')=='true','screen readers cannot wander into the obscured clinical content')
 page.locator('#menuSettingsButton').focus();page.keyboard.press('Tab');check(page.locator('#menuClose').evaluate('e=>e===document.activeElement'),'Tab wraps within the menu')
 page.keyboard.press('Shift+Tab');check(page.locator('#menuSettingsButton').evaluate('e=>e===document.activeElement'),'Shift+Tab wraps within the menu')
 page.keyboard.press('Enter');check(page.locator('#menuTheme').evaluate('e=>e===document.activeElement'),'opening Settings moves focus to its first control')
 page.keyboard.press('Escape');check(page.locator('#menuHome').is_visible() and page.locator('#menuSettingsButton').evaluate('e=>e===document.activeElement'),'Escape returns from Settings and restores the initiating control')
 page.keyboard.press('Escape');check(page.locator('#menuPanel').is_hidden() and page.locator('#menuBtn').evaluate('e=>e===document.activeElement'),'Escape closes the menu and restores the opener')
 open_menu(page);page.mouse.click(10,300);check(page.locator('#menuPanel').is_hidden(),'tapping the backdrop closes the menu')
 open_menu(page);page.locator('#menuSettingsButton').click();page.locator('#menuClose').click();open_menu(page);check(page.locator('#menuHome').is_visible(),'a reopened menu starts in the main tools view')
 page.evaluate('OR.dismissMenu()');check(page.locator('#menuPanel').is_hidden(),'the native Back handler can dismiss the main menu')
 open_menu(page);page.locator('#menuSettingsButton').click();check(page.evaluate('OR.dismissMenu()') and page.locator('#menuHome').is_visible(),'the native Back handler returns from Settings before closing the menu');page.locator('#menuClose').click()
 for target in ['dashboard','repertory','analysis','patients','mm']:
  page.locator(f'[data-bottom-page="{target}"]').click();check(page.evaluate('OR.state.page')==target,f'primary bottom navigation still opens {target}')
 open_menu(page);page.locator('[data-page="file"]').click();check(page.evaluate('OR.state.page')=='file' and page.locator('[data-bottom-page="patients"]').get_attribute('aria-current')=='page','Patient file remains reachable and identifies Patients as its primary location')
 open_menu(page);page.locator('[data-page="diff"]').click();check(page.evaluate('OR.state.page')=='diff' and page.locator('[data-bottom-page="mm"]').get_attribute('aria-current')=='page','Compare remedies remains reachable under Library')
 open_menu(page);page.locator('#menuFinder').click();check(page.evaluate('OR.state.page')=='repertory' and page.locator('#aiInput').evaluate('e=>e===document.activeElement'),'Find rubrics still opens and focuses the patient-word finder')
 # Preserve native action routing without contacting account or AI services.
 page.evaluate('window.openrepertoryNative={openAccount(){window.testAccountCalls=(window.testAccountCalls||0)+1},openUpdates(){window.testUpdateCalls=(window.testUpdateCalls||0)+1},setSensitiveScreen(){}}')
 for selector,value in [('#menuAccount','testAccountCalls'),('#menuUpdates','testUpdateCalls')]:
  open_menu(page);page.locator(selector).click();check(page.evaluate('window.'+value)==1 and page.locator('#menuPanel').is_hidden(),selector+' still opens its existing native action and closes the menu')
 before=page.evaluate('JSON.stringify(OR.state.cases)');open_menu(page);page.locator('#menuSettingsButton').click()
 for theme in ['light','dark','auto']:
  page.locator('#menuTheme').click();check(page.evaluate("(OR.store.get('openrepertory_theme')||{}).t")==theme and page.locator('#menuSettings').is_visible(),'Appearance still selects and retains '+theme+' without leaving Settings')
 check(page.evaluate('JSON.stringify(OR.state.cases)')==before,'theme/menu changes do not alter clinical case data')
 page.locator('#menuOnlineAi').click();check(page.locator('.modal').is_visible() and 'Gemini' in page.locator('.modal').inner_text(),'Online AI opens its existing configuration dialog');page.locator('.modal-x').click()
 open_menu(page);page.locator('#menuBackup').click();check(page.locator('#bkSaveEnc').is_visible(),'Backup & restore opens its existing encrypted backup workflow');page.locator('.modal-x').click()
 # Large text/long patient names must wrap rather than collide.
 open_menu(page);page.add_style_tag(content='#menuPanel h2{font-size:30px}.menu-item b{font-size:28px}.menu-item small{font-size:23px}.menu-label{font-size:22px}')
 page.locator('#miFileSub').evaluate('e=>e.textContent="SyntheticPatientNameWithoutSpacesToTestWrapping"');check(not geometry(page),'200% menu text and a long patient name wrap without overlap or horizontal overflow')
 for selector in ['#menuFinder','[data-page="file"]','[data-page="diff"]','#menuAccount','#menuBackup','#menuUpdates','#menuSettingsButton']:
  page.locator('#menuPanel '+selector).scroll_into_view_if_needed();check(page.locator('#menuPanel '+selector).is_visible(),'large-text scrolling keeps '+selector+' reachable')
 page.locator('#menuClose').click();page.reload();page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000)
 for theme in ['light','dark']:
  page.evaluate('(t)=>{OR.store.set("openrepertory_theme",{t});location.reload()}',theme);page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000);open_menu(page);check(page.locator('#menuPanel').evaluate('e=>getComputedStyle(e).opacity')=='1' and not geometry(page),theme+' theme shows an opaque readable menu');page.screenshot(path=str(O/f'menu-{theme}.png'),animations='disabled');page.locator('#menuClose').click()
 check(not errors,'all menu actions finish without uncaught JavaScript errors');page.close()
 # Resizing while the menu is open preserves layout and safe focus.
 page=browser.new_page(viewport={'width':393,'height':800});ready(page);open_menu(page)
 page.set_viewport_size({'width':800,'height':360});page.wait_for_timeout(100);check(not geometry(page),'rotation repositions an open menu inside the available viewport');page.locator('#menuClose').click();page.close()
 browser.close()
(O/'menu-web-tests.json').write_text(json.dumps(checks,indent=2));print('Menu browser checks passed:',len(checks))
