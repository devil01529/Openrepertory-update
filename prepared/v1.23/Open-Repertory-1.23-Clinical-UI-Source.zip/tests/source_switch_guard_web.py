"""A shared chapter/path UID must never mutate a case belonging to another book."""
from pathlib import Path
import json,zipfile
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.23';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(value,label):
    assert value,label
    checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def ready(page):
    page.goto('http://127.0.0.1:8765');page.wait_for_function('()=>!!(window.OR&&OR.state.repertory)',timeout=60000)
def source(page,key):
    page.evaluate('(id)=>OR.setRepertory(id)',key);page.wait_for_function('(id)=>OR.state.repertoryId===id',arg=key,timeout=60000)
def search(page):
    page.evaluate('OR.showPage("repertory");OR.runSearch("abrupt")');page.wait_for_function('()=>OR.lastSearchStats&&document.querySelector("#rubricList").getAttribute("aria-busy")==="false"',timeout=60000)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for origin,foreign in [('kent','kent1897'),('kent1897','kent')]:
        page=browser.new_page(viewport={'width':393,'height':800});ready(page);source(page,origin);search(page)
        button=page.locator('.rubric[data-rubric-uid="Mind||ABRUPT"] .add-btn').first;button.click();before=page.evaluate('JSON.stringify(OR.activeCase())');ranking=page.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')
        check(page.evaluate('OR.hasRubric("Mind||ABRUPT")'),origin+': original rubric is selected in its owning source')
        source(page,foreign);search(page)
        check(not page.evaluate('OR.hasRubric("Mind||ABRUPT")'),origin+' → '+foreign+': foreign book does not inherit the Added state for the same UID')
        foreign_button=page.locator('.rubric[data-rubric-uid="Mind||ABRUPT"] .add-btn').first
        check('added' not in (foreign_button.get_attribute('class') or ''),foreign+': rendered Add control is source-aware')
        foreign_button.click()
        check(page.evaluate('JSON.stringify(OR.activeCase())')==before,'foreign same-path click preserves every saved case field')
        check(page.evaluate('JSON.stringify(OR.rankCase(OR.activeCase()))')==ranking,'foreign same-path click preserves the complete ranking and grades')
        page.evaluate('OR.toggleRubric("Mind||ABRUPT","Mind","ABRUPT",[],1,"manual")')
        check(page.evaluate('JSON.stringify(OR.activeCase())')==before,'direct/finder-style toggle cannot bypass the source guard')
        page.evaluate('OR.newCase("Synthetic independent book case",null)');check(not page.evaluate('OR.hasRubric("Mind||ABRUPT")'),'a new case starts with independent selection state')
        search(page);page.locator('.rubric[data-rubric-uid="Mind||ABRUPT"] .add-btn').first.click()
        check(page.evaluate('OR.activeCase().repertoryId')==foreign and page.evaluate('OR.activeCase().analysis.length')==1,'new source-locked case can select the same path independently')
        old_id=json.loads(before)['id'];page.evaluate('(id)=>OR.openCase(id)',old_id);page.wait_for_function('(id)=>OR.activeCase().id===id',arg=old_id)
        check(page.evaluate('OR.activeCase().repertoryId')==origin and page.evaluate('JSON.stringify(OR.activeCase())')==before,'returning to the original case restores its book and exact saved content')
        page.close()
    browser.close()
(O/'source-switch-guard-tests.json').write_text(json.dumps(checks,indent=2));print('Source switching regression checks passed:',len(checks))
