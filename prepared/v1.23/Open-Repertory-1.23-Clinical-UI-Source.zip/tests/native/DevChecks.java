package com.openrepertory.tests;
import android.app.*;
import android.content.*;
import android.os.*;
import android.webkit.*;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.net.Uri;
import org.json.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.concurrent.*;

public class DevChecks extends Instrumentation {
    Activity activity; WebView web; int passed; Bundle args;
    @Override public void onCreate(Bundle arguments) { args=arguments; super.onCreate(arguments); start(); }
    void check(boolean value,String name) throws Exception {
        if (!value) throw new Exception("FAIL: "+name);
        passed++; Bundle result=new Bundle();result.putString("stream","PASS "+name+"\n");sendStatus(0,result);
    }
    void unlockTestActivity(Class<?> base) throws Exception {
        Field authenticated=base.getDeclaredField("authenticated");authenticated.setAccessible(true);
        if(authenticated.getBoolean(activity))return;
        android.accessibilityservice.AccessibilityServiceInfo automationInfo=getUiAutomation().getServiceInfo();
        automationInfo.flags|=android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;getUiAutomation().setServiceInfo(automationInfo);
        long end=System.currentTimeMillis()+90000;int attempts=0;long lastAttempt=0;
        while(!authenticated.getBoolean(activity)&&System.currentTimeMillis()<end){
            AccessibilityNodeInfo entry=credentialEntry(getUiAutomation().getRootInActiveWindow());
            if(entry!=null&&attempts<2&&System.currentTimeMillis()-lastAttempt>6000){
                android.graphics.Rect bounds=new android.graphics.Rect();entry.getBoundsInScreen(bounds);entry.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                for(String command:new String[]{"input tap "+bounds.centerX()+" "+bounds.centerY(),"input keyevent 67 67 67 67 67 67 67 67","input keyevent 8 9 10 11","input keyevent 66"}){
                    try(InputStream in=new android.os.ParcelFileDescriptor.AutoCloseInputStream(getUiAutomation().executeShellCommand(command))){while(in.read()!=-1){}}
                }
                attempts++;lastAttempt=System.currentTimeMillis();
            }
            Thread.sleep(500);
        }
        if(!authenticated.getBoolean(activity))throw new Exception("Test activity remains locked");
    }
    AccessibilityNodeInfo credentialEntry(AccessibilityNodeInfo node){
        if(node==null)return null;String id=node.getViewIdResourceName();
        if("com.android.settings:id/password_entry".equals(id)||"com.android.systemui:id/pinEntry".equals(id))return node;
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo found=credentialEntry(node.getChild(i));if(found!=null)return found;}return null;
    }
    Object js(String script) throws Exception {
        CountDownLatch latch=new CountDownLatch(1);String[] raw=new String[1];
        runOnMainSync(() -> web.evaluateJavascript(script, result -> { raw[0]=result; latch.countDown(); }));
        if (!latch.await(45,TimeUnit.SECONDS)) throw new Exception("JavaScript callback timed out");
        return raw[0]==null?null:new JSONTokener(raw[0]).nextValue();
    }
    void waitJS(String expression,int seconds) throws Exception {
        long end=System.currentTimeMillis()+seconds*1000L;
        while(System.currentTimeMillis()<end) { if(Boolean.TRUE.equals(js(expression)))return;Object recovery=js("!!document.querySelector('#recoveryScreen')");if(Boolean.TRUE.equals(recovery))throw new Exception("Startup recovery screen was shown");Object error=js("document.querySelector('#persistentError') && document.querySelector('#persistentError').textContent");if(error instanceof String && ((String)error).length()>0)throw new Exception("Application error: "+error);Thread.sleep(250); }
        throw new Exception("Timeout: "+expression+"; status="+js("document.body.innerText.slice(-1500)"));
    }
    boolean clickNamed(AccessibilityNodeInfo node, String label) {
        if (node == null) return false;
        if ((node.getText() != null && label.equalsIgnoreCase(node.getText().toString())) || (node.getContentDescription() != null && label.equalsIgnoreCase(node.getContentDescription().toString()))) {
            AccessibilityNodeInfo target=node;
            for(int depth=0;target!=null&&depth<10;depth++,target=target.getParent())
                if(target.isClickable()&&target.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
        }
        for(int n=0;n<node.getChildCount();n++)if(clickNamed(node.getChild(n),label))return true;
        return false;
    }
    void clickDocumentControl(String label) throws Exception {
        long end=System.currentTimeMillis()+45000;
        while(System.currentTimeMillis()<end) {
            if(clickNamed(getUiAutomation().getRootInActiveWindow(),label))return;
            Thread.sleep(500);
        }
        throw new Exception("Document control not found: "+label+"; callback="+js("window.nativeExportResult"));
    }
    boolean equalJSON(Object a,Object b) throws Exception {
        if(a instanceof JSONObject && b instanceof JSONObject){JSONObject x=(JSONObject)a,y=(JSONObject)b;if(x.length()!=y.length())return false;java.util.Iterator<String> it=x.keys();while(it.hasNext()){String key=it.next();if(!y.has(key)||!equalJSON(x.get(key),y.get(key)))return false;}return true;}
        if(a instanceof JSONArray && b instanceof JSONArray){JSONArray x=(JSONArray)a,y=(JSONArray)b;if(x.length()!=y.length())return false;for(int i=0;i<x.length();i++)if(!equalJSON(x.get(i),y.get(i)))return false;return true;}
        return String.valueOf(a).equals(String.valueOf(b));
    }
    Object newStore(Class<?> type) throws Exception{return type.getConstructor(android.content.Context.class).newInstance(getTargetContext());}
    public static class DummyConnection extends java.net.HttpURLConnection {
        boolean disconnected;
        public DummyConnection() throws Exception{super(new java.net.URL("https://fixture.invalid"));}
        public void disconnect(){disconnected=true;}public boolean usingProxy(){return false;}public void connect(){}
    }
    @Override public void onStart() {
      Bundle result=new Bundle();
      try {
        activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Class<?> base=activity.getClass().getSuperclass();Field f=base.getDeclaredField("webView");f.setAccessible(true);web=(WebView)f.get(activity);
        runOnMainSync(()->activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT));
        check((activity.getApplicationInfo().flags&android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE)==0,"manifest is non-debuggable");
        boolean[] settings=new boolean[2];runOnMainSync(()->{settings[0]=!web.getSettings().getAllowFileAccess()&&!web.getSettings().getAllowContentAccess();settings[1]=!web.getSettings().getAllowUniversalAccessFromFileURLs();});
        check(settings[0]&&settings[1],"WebView file, content and universal file access disabled");
        waitJS("!!(window.OR && OR.state.repertory && OR.state.page==='dashboard')",180);
        unlockTestActivity(base);
        check(Boolean.TRUE.equals(js("ORStorage.native")),"real native record storage selected");
        Class<?> storeType=Class.forName("com.openrepertory.app.RecordStore",true,activity.getClassLoader());Method read=storeType.getMethod("read",String.class),close=storeType.getMethod("close");
        // MigrationChecks verifies an isolated legacy fixture. Active records may legitimately
        // differ from the retained legacy archive after edits, backup import or recovery.
        Object fresh;
        check(Boolean.TRUE.equals(js("OR.store.batch({openrepertory_native_test:{marker:'SYNTHETIC_NATIVE_RECORD_6912'},openrepertory_native_test2:{ok:true}})")),"native multi-record transaction commits");
        fresh=newStore(storeType);check("SYNTHETIC_NATIVE_RECORD_6912".equals(new JSONObject((String)read.invoke(fresh,"openrepertory_native_test")).getString("marker")),"fresh database reader decrypts committed data");close.invoke(fresh);
        check("error".equals(js("openrepertorySecure.writeBatch(JSON.stringify({'invalid_key':'bad'}))")),"invalid transaction rejected");
        check("SYNTHETIC_NATIVE_RECORD_6912".equals(js("OR.store.get('openrepertory_native_test').marker")),"rejected write retains committed data");
        File stored=new File(getTargetContext().getFilesDir(),"records-v2.db");byte[] bytes=new byte[(int)stored.length()];try(DataInputStream in=new DataInputStream(new FileInputStream(stored))){in.readFully(bytes);}
        check(!new String(bytes,"ISO-8859-1").contains("SYNTHETIC_NATIVE_RECORD_6912"),"SQLite file does not expose clinical plaintext");
        android.database.sqlite.SQLiteDatabase sql=android.database.sqlite.SQLiteDatabase.openDatabase(stored.getAbsolutePath(),null,android.database.sqlite.SQLiteDatabase.OPEN_READWRITE);
        byte[] original;
        try(android.database.Cursor rows=sql.rawQuery("SELECT cipher FROM records WHERE name=?",new String[]{"openrepertory_native_test"})){rows.moveToFirst();original=rows.getBlob(0);}
        byte[] damaged=original.clone();damaged[damaged.length-1]^=1;boolean rejected=false;
        try{
          sql.execSQL("UPDATE records SET cipher=? WHERE name=?",new Object[]{damaged,"openrepertory_native_test"});fresh=newStore(storeType);
          try{read.invoke(fresh,"openrepertory_native_test");}catch(InvocationTargetException error){rejected=error.getCause() instanceof javax.crypto.AEADBadTagException;}finally{close.invoke(fresh);}
        }finally{sql.execSQL("UPDATE records SET cipher=? WHERE name=?",new Object[]{original,"openrepertory_native_test"});sql.close();}
        check(rejected,"tampered encrypted row fails authentication");
        Method trusted=activity.getClass().getDeclaredMethod("trusted",Uri.class);trusted.setAccessible(true);
        check(Boolean.TRUE.equals(trusted.invoke(null,Uri.parse("https://appassets.androidplatform.net/assets/www/index.html")))&&Boolean.FALSE.equals(trusted.invoke(null,Uri.parse("https://evil.test/assets/www/index.html"))),"only expected HTTPS resource origin is accepted");
        js("OR.setRepertory('bbcr')");waitJS("OR.state.repertoryId==='bbcr'",120);js("localStorage.setItem('or.repertory','bbcr')");
        js("OR.showPage('repertory');OR.runSearch('fear')");waitJS("OR.lastSearchStats && OR.lastSearchStats.query==='fear'",180);
        check(Boolean.TRUE.equals(js("document.querySelector('#rubricList').textContent.length>0")),"Android async search renders results");
        check("worker".equals(js("OR.lastSearchStats.backend")),"Android query executes in a background worker");
        js("OR.openMateriaRemedy('Acon.')");waitJS("document.querySelector('#mmDetail').textContent.length>50",90);check(true,"materia medica renders");
        // Persist a draft on each input; rotation preserves the WebView and document.
        js("OR.showPage('patients');document.querySelector('#patientNew').click();document.querySelector('.modal [data-k=name]').value='NATIVE_DRAFT_15';document.querySelector('.modal [data-k=name]').dispatchEvent(new Event('input',{bubbles:true}))");
        check("NATIVE_DRAFT_15".equals(js("OR.drafts.list()['patient-new'].values.name")),"unsaved patient draft is encrypted before interruption");
        runOnMainSync(()->activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));Thread.sleep(1500);
        check(!activity.isDestroyed() && "NATIVE_DRAFT_15".equals(js("document.querySelector('.modal [data-k=name]').value")),"rotation preserves the activity and draft form");
        js("window.__nativeReloadGeneration='old'");runOnMainSync(()->web.reload());waitJS("typeof window.__nativeReloadGeneration==='undefined' && !!(window.OR && OR.state.repertory)",180);
        check("SYNTHETIC_NATIVE_RECORD_6912".equals(js("OR.store.get('openrepertory_native_test').marker")),"encrypted database survives complete WebView reload");
        js("OR.patients.resumeDraft('patient-new')");check("NATIVE_DRAFT_15".equals(js("document.querySelector('.modal [data-k=name]').value")),"draft resumes after a new document loads");
        js("document.querySelector('.modal .modal-x').click()");
        check(((Number)js("Object.keys(OR.drafts.list()).length")).intValue()==0,"explicit draft discard is persisted");
        Class<?> client=Class.forName("com.openrepertory.app.GeminiClient",true,activity.getClassLoader());
        Method status=client.getMethod("errorForStatus",int.class);
        check("invalid_key".equals(status.invoke(null,403))&&"rate_limited".equals(status.invoke(null,429))&&"provider_unavailable".equals(status.invoke(null,503)),"provider status fixtures map to recoverable errors");
        JSONObject models=new JSONObject("{\"models\":[{\"name\":\"models/gemini-2.5-flash-lite\",\"supportedGenerationMethods\":[\"generateContent\"]}]}");
        check("models/gemini-2.5-flash-lite".equals(client.getMethod("chooseModel",JSONObject.class).invoke(null,models)),"model discovery chooses supported text generation");
        JSONObject response=new JSONObject("{\"candidates\":[{\"content\":{\"parts\":[{\"text\":\"{\\\"concepts\\\":[]}\"}]}}]}");
        check(new JSONObject((String)client.getMethod("extract",JSONObject.class).invoke(null,response)).has("concepts"),"provider response fixture extracts structured concepts");
        Class<?> requestType=Class.forName("com.openrepertory.app.GeminiClient$Request",true,activity.getClassLoader());Object request=requestType.getConstructor().newInstance();Field connection=requestType.getDeclaredField("connection");connection.setAccessible(true);DummyConnection fixture=new DummyConnection();connection.set(request,fixture);requestType.getMethod("cancel").invoke(request);
        check(fixture.disconnected,"native cancellation disconnects the active transport");
        boolean cancelled=false;try{requestType.getMethod("check").invoke(request);}catch(InvocationTargetException e){cancelled=e.getCause() instanceof InterruptedIOException;}
        check(cancelled,"cancelled request cannot publish a later result");
        check(Boolean.TRUE.equals(js("openrepertoryNative.setGeminiKey('AIzaSy_SYNTHETIC_NOT_A_REAL_KEY_15')")),"synthetic API key is stored through the native encrypted bridge");
        check(Boolean.TRUE.equals(js("openrepertoryNative.hasGeminiKey()")),"stored API key is available without browser storage");
        check(Boolean.TRUE.equals(js("openrepertoryNative.clearGeminiKey()"))&&Boolean.FALSE.equals(js("openrepertoryNative.hasGeminiKey()")),"disconnect persists removal of the synthetic key");
        check(((Number)js("document.querySelectorAll('#persistentError').length")).intValue()==0,"no persistent application error");
        result.putString("stream","Native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
      }catch(Throwable e){result.putString("stream","FAILED after "+passed+" checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}
    }
}
