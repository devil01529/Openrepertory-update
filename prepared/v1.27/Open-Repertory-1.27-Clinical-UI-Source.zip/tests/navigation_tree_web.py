import os
"""Real scroll gestures and book/chapter/branch navigation regressions."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/os.environ.get('OR_TEST_RESULTS','test-results/v1.27');O.mkdir(parents=True,exist_ok=True);checks=[]
def check(value,label):
 assert value,label
 checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
def ready(p):
 p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
def swipe(p,session,x,y,end):
 session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
 for i in range(1,11):
  session.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':y+(end-y)*i/10}]});p.wait_for_timeout(20)
 session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});p.wait_for_timeout(350)
def control(p,id):
 p.evaluate('OR.openReadingMenu()');p.locator('#'+id).click()
 if p.locator('#menuPanel').is_visible():p.evaluate('OR.dismissMenu();OR.dismissMenu()')
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
  context=b.new_context(viewport={'width':width,'height':height},has_touch=True);p=context.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)));ready(p)
  root=p.locator('#dashboardRoot');rect=root.bounding_box();check(root.evaluate('e=>e.clientHeight<e.scrollHeight&&e.getBoundingClientRect().bottom<=innerHeight'),f'{width}: Today has a bounded scroll area')
  p.mouse.move(width/2,rect['y']+rect['height']/2);p.mouse.wheel(0,3000);p.wait_for_timeout(350)
  check(root.evaluate('e=>e.scrollTop>0'),f'{width}: Today scrolls with wheel')
  check(p.locator('[data-today="sources"]').evaluate('e=>{let r=e.getBoundingClientRect(),p=document.querySelector("#dashboardRoot").getBoundingClientRect();return r.bottom<=p.bottom+1&&r.top>=p.top}'),f'{width}: final Today action is reachable above navigation')
  root.evaluate('e=>e.scrollTop=0');session=context.new_cdp_session(p);swipe(p,session,width/2,rect['y']+rect['height']*.85,rect['y']+rect['height']*.15)
  check(root.evaluate('e=>e.scrollTop>0'),f'{width}: Today scrolls with touch swipe')
  p.evaluate('OR.showPage("repertory")');check(not p.locator('#repSelect').is_visible(),f'{width}: old native book select is unreachable')
  if height>480:
   p.locator('#repLibrary').click();check(p.locator('.book-choice').count()==7,f'{width}: chapter book button opens all seven app-styled choices');p.get_by_role('button',name='Close',exact=True).last.click()
  p.locator('#sourcePicker').click();check(p.locator('.book-choice').first.inner_text().splitlines()[0]=='Kent',f'{width}: toolbar opens the same short-name picker');p.get_by_role('button',name='Close',exact=True).last.click()
  check(p.locator('#chapterTree img').count()>20,f'{width}: chapter index restores the illustrated theme')
  p.locator('#chapterFilter').fill('mind');check(p.locator('#chapterTree li[data-chapter-id]:visible').count()==1,f'{width}: chapter filter narrows the current book')
  p.locator('#chapterFilter').fill('zzzz-no-chapter');check('No chapters match' in p.locator('#chapterFilterStatus').inner_text() and p.locator('#chapterTree li[data-chapter-id]:visible').count()==0,f'{width}: missing chapter filter reports an empty result')
  p.locator('#chapterFilterClear').click();check(p.locator('#chapterTree li[data-chapter-id]:visible').count()>20,f'{width}: clearing restores chapters')
  # Real keyboard navigation on semantic chapter buttons.
  first=p.locator('#chapterTree .chapter-choice').first;first.focus();p.keyboard.press('Enter');chapter=p.evaluate('OR.state.activeChapter')
  check(chapter is not None and p.locator('#sidebar').evaluate('e=>e.classList.contains("collapsed")'),f'{width}: Enter opens a chapter and closes the panel')
  p.locator('#sidebarToggle').click();p.locator('#chapterTree .chapter-choice').first.click()
  check(p.evaluate('OR.state.activeChapter')==chapter and p.locator('#sidebar').evaluate('e=>e.classList.contains("collapsed")'),f'{width}: reselecting current chapter keeps it open and closes panel')
  check(p.locator('#chapterTree [aria-current="true"]').count()==1,f'{width}: exactly one chapter is marked current')
  branch=p.locator('#rubricList .rubric-toggle:not(.none)').first;check(branch.count()>0,f'{width}: chapter has an expandable rubric branch')
  original=p.evaluate('JSON.stringify(OR.activeCase().analysis)');control(p,'toggleBranches')
  check(p.locator('#rubricList .rubric-toggle[aria-expanded="true"]').count()==0,f'{width}: one click collapses every rendered branch')
  # Re-render while collapsed: no sub-rubric DOM is materialised until expansion.
  p.evaluate('OR.selectChapter(OR.state.activeChapter)');check(p.locator('#rubricList .sub-list .rubric').count()==0,f'{width}: collapsed branches defer child rendering')
  control(p,'toggleBranches');check(p.locator('#rubricList .sub-list .rubric').count()>0 and p.locator('#rubricList .rubric-toggle[aria-expanded="false"]:not(.none)').count()==0,f'{width}: expand all restores paged child rubrics')
  branch=p.locator('#rubricList .rubric-toggle:not(.none)').first;branch.click();check(branch.get_attribute('aria-expanded')=='false',f'{width}: individual branch can close');branch.click();check(branch.get_attribute('aria-expanded')=='true',f'{width}: individual branch can reopen')
  check(p.evaluate('JSON.stringify(OR.activeCase().analysis)')==original,f'{width}: navigation controls do not alter case selections')
  p.screenshot(path=str(O/f'tree-{width}.png'));p.evaluate('OR.showPage("dashboard")');p.mouse.move(width/2,height*.6);p.mouse.wheel(0,3000);p.wait_for_timeout(300);check(root.evaluate('e=>e.scrollTop>0'),f'{width}: Today still scrolls after returning from repertory')
  if width==393:
   p.evaluate('document.documentElement.style.fontSize="22px"');p.mouse.wheel(0,5000);p.wait_for_timeout(350);check(root.evaluate('e=>e.scrollTop>0&&e.clientHeight<e.scrollHeight'), 'Today retains scrolling at enlarged text size')
  check(not errors,f'{width}: navigation has no JavaScript errors');context.close()
 b.close()
(O/'navigation-tree-tests.json').write_text(json.dumps(checks,indent=2));print('Navigation tree checks passed:',len(checks))
