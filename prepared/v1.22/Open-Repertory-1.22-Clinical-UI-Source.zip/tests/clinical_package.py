"""Check the final APK against the shipped 1.21 identity and clinical assets."""
from pathlib import Path
import json,zipfile,subprocess,hashlib
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.22';O.mkdir(parents=True,exist_ok=True);checks=[];A=R/'dist/Open-Repertory-Clarke-Dev.apk';B=R/'releases/1.21/Open-Repertory-1.21.apk';bt='/workspace/tools/android/android-15/'
def check(v,label):
    assert v,label
    checks.append({'test':label,'status':'passed'});print('PASS',label)
with zipfile.ZipFile(A) as new,zipfile.ZipFile(B) as old:
    check(new.testzip() is None,'final APK ZIP integrity')
    files=[n for n in old.namelist() if n.startswith('assets/www/data/') and 'audit' not in n and not n.endswith('source_registry.json')]
    check(all(new.read(n)==old.read(n) for n in files),f'all {len(files)} existing clinical data/text assets remain byte-identical')
    check(new.read('assets/www/data/kent_publicum_full.json')==old.read('assets/www/data/kent_publicum_full.json'),'legacy Publicum database is unchanged for existing source-locked cases')
    for name in ['kent_english_oorep.json','kent_oorep_audit.json','oorep_relationships.json']:
        check(new.read('assets/www/data/'+name)==(R/'apk/assets/www/data'/name).read_bytes(),'packaged '+name+' matches the exhaustively audited local artifact')
    check(not any(n.endswith(('.p12','.jks','.keystore','.pdf')) or 'private' in n.lower() or 'firebase-config' in n.lower() for n in new.namelist()),'APK excludes private keys, source PDFs and archived Firebase configuration')
    dex=new.read('classes.dex');check(not any(n in dex for n in [b'MenuChecks',b'FixtureAuthView',b'synthetic-apper-owner']),'emulator test fixtures are not shipped')
    check(all(n in dex for n in [b'devil01529/Openrepertory-update',b'preview--openrepertory-eminent.apper.so',b'SHA256withRSA',b'OR.clinic']),'signed updater, Apper endpoint and workspace Back routing remain present')
    html=new.read('assets/www/index.html').decode();shortcut=html.split('id="analysisShortcut"',1)[1].split('</button>',1)[0]
    check('<svg' in shortcut and '<span>Analysis</span>' not in shortcut and 'js/clinical-ui.js' in html and 'css/clinical.css' in html,'APK loads the clinical redesign and the icon-only clipboard markup')
    source=json.loads(new.read('assets/www/data/kent_english_oorep.json'));check(source['id']=='kent1897' and source['sourceSnapshot']['rows']==68742,'English Kent is a separate bundled book with its audited source-row count')
badging=lambda p:subprocess.check_output([bt+'aapt2','dump','badging',str(p)],text=True)
a=badging(A);b=badging(B)
check("name='com.openrepertory.app.dev'" in a and "versionCode='23'" in a and "versionName='1.22-dev'" in a,'same application package and increasing version support in-place upgrade')
cert=lambda p:next(line for line in subprocess.check_output([bt+'apksigner','verify','--print-certs',str(p)],text=True).splitlines() if 'certificate SHA-256 digest:' in line)
check(cert(A)==cert(B),'existing Android signing certificate retained')
perms=lambda value:{line for line in value.splitlines() if line.startswith('uses-permission:')}
check(perms(a)==perms(b),'no additional Android permissions')
P=Path('/workspace/open-repertory-public-updates/android-updater')
check(all((R/'native/com/openrepertory/app'/n).read_bytes()==(P/n).read_bytes() for n in ['AppUpdates.java','UpdateFileProvider.java']),'native signed download and installation implementation is unchanged')
(O/'clinical-package-tests.json').write_text(json.dumps(checks,indent=2));print('Clinical package checks passed:',len(checks))
