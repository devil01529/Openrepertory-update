package com.openrepertory.app;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import android.widget.Toast;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

/** Adds a restricted WebView, encrypted record transactions and Android document I/O.
 * The maintained parent validates Android device credentials. */
public class ImprovedActivity extends MainActivity {
    static final String HOST = "appassets.androidplatform.net";
    static final String HOME = "https://" + HOST + "/assets/www/index.html";
    static final int EXPORT = 7201, IMPORT = 7202, MAX = 16 * 1024 * 1024;
    private WebView view;
    private ValueCallback<Uri[]> fileCallback;
    private String exportId, exportText;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService ai = Executors.newFixedThreadPool(2);
    private final Map<String, Future<?>> tasks = new ConcurrentHashMap<>();
    private RecordStore vault;
    private GeminiClient gemini;
    private volatile boolean recoveryRequired;
    private final Map<String,GeminiClient.Request> connections = new ConcurrentHashMap<>();
    private volatile boolean destroyed;

    private ApperAccess access;
    private ApperAccessScreen accessScreen;
    private LaunchScreen launchScreen;
    private AppUpdates updates;
    private boolean workspaceReady, waitingForWorkspace, managingAccess;
    private int workspaceGeneration;
    private long workspaceStartedAt;
    private final Runnable workspacePoll=this::waitForWorkspace;
    private volatile boolean accessGranted;
    private volatile long approvalExpiresElapsed;
    private boolean clinicalInitialized, approvalForeground, migrationRequested;
    private final Handler approvalHandler=new Handler(Looper.getMainLooper());
    private final Runnable approvalRefresh=()->{if(approvalForeground&&authenticated)checkAccess();};
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);view=webView;
        try{updates=new AppUpdates(this,new AppUpdates.Host(){
            public boolean allowed(){return clinicalAllowed()&&approvalForeground&&!managingAccess;}
            public void beforeInstall(Runnable action){view.evaluateJavascript("window.OR&&OR.flushDrafts&&OR.flushDrafts()",ignored->{if(clinicalAllowed()&&approvalForeground&&!managingAccess)action.run();});}
        });}catch(Exception ignored){}
        try {
            access=new ApperAccess(this);
            accessScreen=new ApperAccessScreen(this,access.deviceId(),new ApperAccessScreen.Actions(){
                public void check(){checkAccess();}
                public void closeManager(){leaveOwnerManagement();}
                public void loading(){if(launchScreen!=null&&!clinicalAllowed())launchScreen.show("Signing in…","Checking your approved access");}
                public void interactionRequired(){if(authenticated&&!clinicalAllowed()&&launchScreen!=null)launchScreen.hide(false);}
                public void details(){showAccessDetails();}
                public void signOut(){signOutAccess();}
                public void receipt(JSONObject receipt,String nonce){receiveAccess(receipt,nonce);}
                public void unavailable(boolean network){
                    if(destroyed||!authenticated)return;
                    if(managingAccess&&network){if(launchScreen!=null)launchScreen.hide(false);accessScreen.show("Owner approvals are unavailable offline. Reconnect and tap Check / reload, or return to the repertory.");scheduleApproval(30000);return;}
                    if(network&&access.cachedAllowed())openClinical("Offline: using a previously verified approval (maximum 24 hours, same device boot).");
                    else {access.clear();blockClinical();accessScreen.show(network?"Apper is unreachable. Connect to the internet, then tap Check / reload.":"Sign in below, request access, then wait for the owner’s decision. If the form is blank, tap Check / reload.");scheduleApproval(15000);}
                }
            });
            ((android.widget.FrameLayout)view.getParent()).addView(accessScreen,new android.widget.FrameLayout.LayoutParams(-1,-1));
            accessScreen.setVisibility(android.view.View.INVISIBLE);
            launchScreen=new LaunchScreen(this,()->{if(clinicalAllowed()&&!managingAccess){workspaceReady=false;workspaceStartedAt=SystemClock.elapsedRealtime();view.reload();prepareWorkspace();}else {launchScreen.show("Signing in…","Checking your approved access");accessScreen.load();}});
            ((android.widget.FrameLayout)view.getParent()).addView(launchScreen,new android.widget.FrameLayout.LayoutParams(-1,-1));
            launchScreen.show("Open Repertory","Unlock your phone to continue");
            accessScreen.ensureLoaded();
        }catch(Exception error){new AlertDialog.Builder(this).setTitle("Access unavailable").setMessage("This device cannot initialize secure Apper access. Saved records have not been changed.").setPositiveButton("Close",(d,w)->finish()).setCancelable(false).show();}
    }
    private void checkAccess(){
        if(accessScreen==null||destroyed||!authenticated||!approvalForeground)return;
        if(!clinicalAllowed()){view.setVisibility(android.view.View.INVISIBLE);accessScreen.setVisibility(android.view.View.VISIBLE);}
        accessScreen.check();
    }
    private void receiveAccess(JSONObject receipt,String nonce){
        if(destroyed||!authenticated||!approvalForeground)return;
        try {
            String status=access.accept(receipt,nonce);
            if("approved".equals(status))openClinical("Apper approved this account and phone.");
            else if("migration".equals(status)){
                blockClinical();accessScreen.show("Owner approval is valid. Confirm migration of this phone’s existing records to your Apper owner account.");
                new AlertDialog.Builder(this).setTitle("Keep this phone’s existing records?")
                    .setMessage("This phone has records bound to the previous login service. Transfer their account binding to your approved Apper owner account ("+access.email()+")? Android will ask you to unlock again. Records are retained on this phone.")
                    .setPositiveButton("Keep records & continue",(d,w)->{migrationRequested=true;authenticated=false;accessScreen.setVisibility(android.view.View.INVISIBLE);requestUnlock();})
                    .setNegativeButton("Cancel",(d,w)->{access.clear();accessScreen.show("Migration cancelled. Existing records remain protected.");}).show();
            }else {
                blockClinical();
                String message="pending".equals(status)||"request".equals(status)?"Sign in, then tap Request access below. The owner must approve this account and phone.":
                    "records".equals(status)?"Access is approved, but this phone’s records belong to a different account. Sign in with their owner.":
                    "revoked".equals(status)?"The owner revoked access for this phone. Saved records remain encrypted.":
                    "rejected".equals(status)?"The owner declined this phone’s request. Contact the owner.":"Apper could not verify access. Sign in or reload; contact the owner if it persists.";
                accessScreen.show(message);scheduleApproval(15000);
            }
        }catch(Exception error){access.clear();blockClinical();accessScreen.show("Access could not be verified securely. Tap Check / reload.");scheduleApproval(30000);}
    }
    private void scheduleApproval(long delay){approvalHandler.removeCallbacks(approvalRefresh);if(approvalForeground)approvalHandler.postDelayed(approvalRefresh,delay);}
    private void openClinical(String message){
        if(!authenticated||!access.cachedAllowed()){blockClinical();return;}
        approvalExpiresElapsed=SystemClock.elapsedRealtime()+access.remainingApprovalMillis();accessGranted=true;
        if(managingAccess){
            if(access.owner()){
                view.setVisibility(android.view.View.INVISIBLE);accessScreen.setVisibility(android.view.View.VISIBLE);
                if(launchScreen!=null)launchScreen.hide(false);
                accessScreen.show("Owner profile · Decisions save directly in Apper.");scheduleApproval(15000);return;
            }
            managingAccess=false;accessScreen.setManager(false);
            Toast.makeText(this,"Owner permission is required to manage approvals",Toast.LENGTH_LONG).show();
        }
        accessScreen.setVisibility(android.view.View.GONE);
        if(!clinicalInitialized){workspaceReady=false;initializeClinical();}
        view.setVisibility(android.view.View.VISIBLE);
        if(workspaceReady){if(launchScreen!=null)launchScreen.hide(true);if(updates!=null)updates.checkAutomatically();}else prepareWorkspace();
        scheduleApproval(Math.max(1,Math.min(300000,access.remainingApprovalMillis())));
    }
    private void prepareWorkspace(){
        if(waitingForWorkspace)return;
        waitingForWorkspace=true;workspaceStartedAt=SystemClock.elapsedRealtime();workspaceGeneration++;
        if(launchScreen!=null)launchScreen.show("Opening your workspace…","Your records stay on this phone");
        waitForWorkspace();
    }
    private void waitForWorkspace(){
        if(destroyed||!waitingForWorkspace||!clinicalAllowed())return;
        final int expected=workspaceGeneration;
        view.evaluateJavascript("!!((window.OR&&OR.state&&OR.state.repertory)||document.getElementById('recoveryScreen')||document.getElementById('persistentError')&&document.getElementById('persistentError').textContent.trim())",value->{
            if(destroyed||expected!=workspaceGeneration||!waitingForWorkspace||!clinicalAllowed())return;
            if("true".equals(value)) {
                // Wait for the actual painted frame, rather than revealing a blank WebView.
                view.postVisualStateCallback(expected,new WebView.VisualStateCallback(){
                    @Override public void onComplete(long requestId){
                        if(destroyed||expected!=workspaceGeneration||!clinicalAllowed())return;
                        workspaceReady=true;waitingForWorkspace=false;
                        if(approvalForeground&&launchScreen!=null)launchScreen.hide(true);
                        if(updates!=null)updates.checkAutomatically();
                    }
                });
            }else if(SystemClock.elapsedRealtime()-workspaceStartedAt>60000){
                waitingForWorkspace=false;
                if(launchScreen!=null)launchScreen.problem("The workspace is taking longer to open","Your saved records have not been changed.");
            }else approvalHandler.postDelayed(workspacePoll,100);
        });
    }
    private void blockClinical(){
        if(updates!=null)updates.pause();
        managingAccess=false;if(accessScreen!=null)accessScreen.setManager(false);
        waitingForWorkspace=false;workspaceReady=false;workspaceGeneration++;approvalHandler.removeCallbacks(workspacePoll);
        if(launchScreen!=null)launchScreen.hide(false);
        accessGranted=false;view.setVisibility(android.view.View.INVISIBLE);if(accessScreen!=null)accessScreen.setVisibility(authenticated?android.view.View.VISIBLE:android.view.View.INVISIBLE);
        if(clinicalInitialized){cancelOnlineRequests();view.removeJavascriptInterface("openrepertoryNative");view.removeJavascriptInterface("openrepertorySecure");view.loadUrl("about:blank");clinicalInitialized=false;if(vault!=null){vault.close();vault=null;}}
    }
    private void showAccessDetails(){
        if(!authenticated||access==null)return;
        android.widget.TextView text=new android.widget.TextView(this);String details=access.details();text.setText(details);text.setTextIsSelectable(true);int p=Math.round(20*getResources().getDisplayMetrics().density);text.setPadding(p,p,p,p);
        android.widget.ScrollView scroll=new android.widget.ScrollView(this);scroll.addView(text);
        new AlertDialog.Builder(this).setTitle("Apper account & phone details").setView(scroll).setPositiveButton("Close",null)
            .setNeutralButton("Copy details",(d,w)->{android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Open Repertory access details",details));}).show();
    }
    private void signOutAccess(){
        Runnable logout=()->{blockClinical();access.clear();accessScreen.logout();accessScreen.show("Signed out. Records remain encrypted on this phone.");scheduleApproval(15000);};
        if(clinicalInitialized)view.evaluateJavascript("window.OR&&OR.flushDrafts&&OR.flushDrafts()",value->logout.run());else logout.run();
    }
    private void accountInfo(){
        runOnUiThread(()->{
            boolean owner=access.owner();
            new AlertDialog.Builder(this).setTitle(owner?"Owner profile":"Account & Apper access")
                .setMessage(access.email()+"\n"+(owner?"Manage who can use Open Repertory from this app. Approvals are tied to each account and phone.":"This phone requires the owner’s approval.")+"\nPatient records stay on this phone.")
                .setPositiveButton("Close",null)
                .setNeutralButton(owner?"Manage approvals":"Phone details",(d,w)->{if(owner)enterOwnerManagement();else showAccessDetails();})
                .setNegativeButton("Sign out",(d,w)->signOutAccess()).show();
        });
    }
    private void enterOwnerManagement(){
        if(!clinicalAllowed()||!access.owner()){Toast.makeText(this,"Only an approved owner can manage access",Toast.LENGTH_LONG).show();return;}
        // Flush drafts, then hide and retain the clinical document rather than destroying it.
        view.evaluateJavascript("window.OR&&OR.flushDrafts&&OR.flushDrafts()",ignored->{
            if(destroyed||!authenticated||!clinicalAllowed()||!access.owner())return;
            managingAccess=true;view.setVisibility(android.view.View.INVISIBLE);accessScreen.setVisibility(android.view.View.VISIBLE);
            if(launchScreen!=null)launchScreen.hide(false);
            accessScreen.openManager();checkAccess();
        });
    }
    private void leaveOwnerManagement(){
        if(!managingAccess)return;
        managingAccess=false;accessScreen.cancel();accessScreen.setManager(false);
        if(launchScreen!=null)launchScreen.show("Checking access…","Returning to your workspace");
        checkAccess();
    }
    @Override public void onBackPressed(){
        if(managingAccess){leaveOwnerManagement();return;}
        if(clinicalAllowed()&&clinicalInitialized){
            view.evaluateJavascript("!!(window.OR&&((OR.dismissMenu&&OR.dismissMenu())||(OR.clinic&&OR.clinic.back&&OR.clinic.back())))",handled->{if(!destroyed&&!"true".equals(handled))ImprovedActivity.super.onBackPressed();});
            return;
        }
        super.onBackPressed();
    }
    private boolean clinicalAllowed(){return accessGranted&&authenticated&&!destroyed&&SystemClock.elapsedRealtime()<approvalExpiresElapsed;}
    private void requireAccess(){if(!clinicalAllowed())throw new SecurityException("Owner approval required");}
    @Override protected void unlock(){
        super.unlock();if(accessScreen==null)return;view.setVisibility(android.view.View.INVISIBLE);accessScreen.setVisibility(android.view.View.VISIBLE);
        if(migrationRequested){migrationRequested=false;try{if(access.migrateLegacyOwner()){openClinical("Records retained.");return;}}catch(Exception ignored){}access.clear();}
        if(launchScreen!=null)launchScreen.show("Signing in…","Checking your approved access");
        accessScreen.ensureLoaded();checkAccess();
    }
    @Override protected void onResume(){super.onResume();approvalForeground=true;if(accessScreen!=null){accessScreen.resume();if(authenticated){if(launchScreen!=null)launchScreen.show("Signing in…","Checking your approved access");checkAccess();if(waitingForWorkspace)waitForWorkspace();}else {view.setVisibility(android.view.View.INVISIBLE);accessScreen.setVisibility(android.view.View.INVISIBLE);if(launchScreen!=null)launchScreen.show("Open Repertory","Unlock your phone to continue");}}}
    @Override protected void onPause(){super.onPause();approvalForeground=false;if(updates!=null)updates.pause();approvalHandler.removeCallbacks(approvalRefresh);if(accessScreen!=null)accessScreen.pause();approvalHandler.removeCallbacks(workspacePoll);}
    private void initializeClinical() {
        try {
            clinicalInitialized=true;
            vault = new RecordStore(this);
            gemini = new GeminiClient(this, vault);
            WebView.setWebContentsDebuggingEnabled(false);
            WebSettings s = view.getSettings();
            s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
            s.setAllowFileAccess(false); s.setAllowContentAccess(false);
            s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            s.setJavaScriptCanOpenWindowsAutomatically(false);
            if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
            view.setWebViewClient(new RestrictedClient());
            view.setWebChromeClient(new WebChromeClient() {
                @Override public boolean onShowFileChooser(WebView web, ValueCallback<Uri[]> callback, FileChooserParams params) {
                    if (fileCallback != null) fileCallback.onReceiveValue(null);
                    fileCallback = callback;
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
                        startActivityForResult(i, IMPORT);
                    } catch (Exception e) { callback.onReceiveValue(null); fileCallback = null; }
                    return true;
                }
            });
            view.addJavascriptInterface(new NativeBridge(), "openrepertoryNative");
            view.addJavascriptInterface(new SecureBridge(), "openrepertorySecure");
            view.loadUrl(HOME);
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("Unable to start securely")
                .setMessage("The development build could not initialize. Your saved files have not been changed.")
                .setPositiveButton("Close", (d,w) -> finish()).setCancelable(false).show();
        }
    }
    static boolean trusted(Uri u) {
        return u != null && "https".equals(u.getScheme()) && HOST.equals(u.getHost())
            && (u.getPort() == -1 || u.getPort() == 443) && u.getUserInfo() == null;
    }
    private boolean navigate(Uri u) {
        if (trusted(u) && u.getPath() != null && u.getPath().startsWith("/assets/www/")) return false;
        if (u != null && ("https".equals(u.getScheme()) || "http".equals(u.getScheme()))) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, u).addCategory(Intent.CATEGORY_BROWSABLE)); }
            catch (Exception e) { Toast.makeText(this, "No browser is available", Toast.LENGTH_SHORT).show(); }
        }
        return true;
    }
    private final class RestrictedClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return navigate(Uri.parse(url)); }
        @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return navigate(r.getUrl()); }
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return asset(r.getUrl()); }
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, String u) { return asset(Uri.parse(u)); }
        private WebResourceResponse asset(Uri u) {
            try {
                if(!clinicalAllowed())return denied();
                String p = u.getPath();
                if (!trusted(u) || p == null || !p.startsWith("/assets/www/") || p.contains("..") || p.contains("\\")) return denied();
                String relative = p.substring("/assets/".length());
                String mime = p.endsWith(".html") ? "text/html" : p.endsWith(".js") ? "application/javascript"
                    : p.endsWith(".css") ? "text/css" : p.endsWith(".json") ? "application/json"
                    : p.endsWith(".png") ? "image/png" : p.endsWith(".svg") ? "image/svg+xml" : "application/octet-stream";
                Map<String,String> headers = new HashMap<>();
                headers.put("X-Content-Type-Options", "nosniff");
                headers.put("Cache-Control", "no-cache");
                if(p.endsWith(".html"))headers.put("Content-Security-Policy","default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-src 'none'; object-src 'none'; worker-src 'self'; child-src 'self'");
                return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, getAssets().open(relative));
            } catch (Exception e) { return denied(); }
        }
        private WebResourceResponse denied() {
            return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
        }
    }
    private void complete(String id, Object result, String error) {
        runOnUiThread(() -> {
            if (destroyed || view == null) return;
            String js = "window.ORNativeComplete&&window.ORNativeComplete(" + JSONObject.quote(id) + ","
                + (result == null ? "null" : JSONObject.quote(String.valueOf(result))) + ","
                + (error == null ? "null" : JSONObject.quote(error)) + ")";
            view.evaluateJavascript(js, null);
        });
    }
    private void askExport(String id, String name, String text) {
        if (exportId != null) { complete(id, null, "Another export is already open"); return; }
        exportId = id; exportText = text;
        try {
            JSONObject pending = new JSONObject().put("name", name).put("text", text);
            try{vault.write(new JSONObject().put("openrepertory_pending_export", pending.toString()));}
            catch(Exception cannotRetain){Toast.makeText(this,"Keep the app open until the backup is saved.",Toast.LENGTH_LONG).show();}
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(name.endsWith(".orbk") ? "application/octet-stream" : "application/json");
            i.putExtra(Intent.EXTRA_TITLE, name.replaceAll("[^A-Za-z0-9._-]", "_"));
            startActivityForResult(i, EXPORT);
        } catch (Exception e) { exportId = null; exportText = null; complete(id, null, "No document provider is available"); }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == IMPORT && fileCallback != null) {
            fileCallback.onReceiveValue(result == RESULT_OK && data != null ? new Uri[]{data.getData()} : null);
            fileCallback = null;
            try { if (!recoveryRequired) vault.write(new JSONObject().put("openrepertory_pending_picker",JSONObject.NULL)); } catch (Exception ignored) {}
        }
        if (request == EXPORT && exportId != null) {
            final String id = exportId, text = exportText;
            exportId = null; exportText = null;
            if (result != RESULT_OK || data == null || data.getData() == null) {
                try { vault.write(new JSONObject().put("openrepertory_pending_export",JSONObject.NULL)); } catch (Exception ignored) {}
                complete(id, "cancelled", null); return;
            }
            final Uri destination = data.getData();
            io.execute(() -> {
                try {
                    try (OutputStream out = getContentResolver().openOutputStream(destination, "wt")) {
                        if (out == null) throw new IOException();
                        out.write(text.getBytes("UTF-8")); out.flush();
                    }
                    try{vault.write(new JSONObject().put("openrepertory_pending_export",JSONObject.NULL));}catch(Exception ignored){}
                    complete(id, "saved", null);
                } catch (Exception e) { complete(id, null, "Backup could not be saved. The encrypted export is retained for retry."); }
            });
        }
    }
    public final class SecureBridge {
        @JavascriptInterface public void printDocument() { requireAccess();
            runOnUiThread(() -> {
                try {
                    android.print.PrintManager manager = (android.print.PrintManager)getSystemService(PRINT_SERVICE);
                    manager.print("Open Repertory", view.createPrintDocumentAdapter("Open Repertory"), null);
                } catch (Exception e) { Toast.makeText(ImprovedActivity.this, "Printing is unavailable", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public String read(String key) { requireAccess();
            try { return vault.read(key); } catch (Exception e) { throw new IllegalStateException("Encrypted records could not be opened"); }
        }
        @JavascriptInterface public String writePatient(String json,String activeId){ requireAccess();try{vault.patchPatient(json,activeId);return "ok";}catch(Exception error){return "error";}}
        @JavascriptInterface public String writeBatch(String json) { requireAccess();
            try { vault.write(new JSONObject(json)); return "ok"; } catch (Exception e) { return "error"; }
        }
        @JavascriptInterface public void saveDocument(String id, String name, String text) { requireAccess();
            if (id == null || name == null || text == null || text.length() > MAX) { complete(id, null, "Backup exceeds the supported size"); return; }
            runOnUiThread(() -> askExport(id, name, text));
        }
        @JavascriptInterface public String storageHealth() { requireAccess();
            try { vault.health(); recoveryRequired = false; return "ok"; }
            catch (Exception e) { recoveryRequired = true; return "recovery_required"; }
        }
        @JavascriptInterface public void enterRecovery() { requireAccess(); recoveryRequired=true; }
        @JavascriptInterface public String restoreRecords(String raw) { requireAccess();
            if (!recoveryRequired) return "error";
            try {
                vault = vault.restore(new JSONObject(raw));
                gemini = new GeminiClient(ImprovedActivity.this, vault);
                recoveryRequired = false; return "ok";
            } catch (Exception e) { return "error"; }
        }
        @JavascriptInterface public String pendingExport() { requireAccess();
            try { String raw=vault.read("openrepertory_pending_export");return raw==null?null:new JSONObject(raw).optString("name"); }
            catch(Exception e){return null;}
        }
        @JavascriptInterface public void resumeExport(String id) { requireAccess();
            try { JSONObject pending=new JSONObject(vault.read("openrepertory_pending_export"));
                runOnUiThread(() -> { try { askExport(id,pending.getString("name"),pending.getString("text")); }catch(Exception e){complete(id,null,"Export could not be resumed");} });
            }catch(Exception e){complete(id,null,"No retained export is available");}
        }
        @JavascriptInterface public boolean discardExport() { requireAccess();
            try {vault.write(new JSONObject().put("openrepertory_pending_export",JSONObject.NULL));return true;}catch(Exception e){return false;}
        }
        @JavascriptInterface public void geminiAsync(String id, String prompt, boolean test) { requireAccess();
            if (id == null || !id.matches("[A-Za-z0-9_-]{1,80}") || prompt == null || prompt.length() > 20000 || tasks.size() >= 2) {
                complete(id, null, "Request is invalid or another search is running"); return;
            }
            GeminiClient.Request request = new GeminiClient.Request(); connections.put(id, request);
            FutureTask<Void> task = new FutureTask<>(() -> {
                try { String response=gemini.interpret(prompt,test,request); request.check(); complete(id,response,null); }
                catch (Exception e) {
                    try {
                        request.check();
                        String code = e instanceof GeminiClient.ProviderException ? ((GeminiClient.ProviderException)e).code : "network_error";
                        complete(id,new JSONObject().put("error",code).toString(),null);
                    } catch (Exception ignored) {}
                } finally { tasks.remove(id); connections.remove(id); }
                return null;
            });
            tasks.put(id, task); ai.execute(task);
        }
        @JavascriptInterface public void cancel(String id) { requireAccess();
            GeminiClient.Request request=connections.remove(id); if(request!=null)request.cancel();
            Future<?> task = tasks.remove(id); if (task != null) task.cancel(true);
        }
    }
    private void cancelOnlineRequests(){
        for(String id:new ArrayList<>(connections.keySet())){
            GeminiClient.Request request=connections.remove(id);if(request!=null)request.cancel();
            Future<?> task=tasks.remove(id);if(task!=null)task.cancel(true);
            complete(id,"{\"error\":\"cancelled\"}",null);
        }
    }
    public final class NativeBridge {
        @JavascriptInterface public void openUpdates(){requireAccess();runOnUiThread(()->{if(updates!=null&&clinicalAllowed()&&approvalForeground&&!managingAccess)updates.show();else Toast.makeText(ImprovedActivity.this,"Updates are currently unavailable. Reopen the app and retry.",Toast.LENGTH_LONG).show();});}
        @JavascriptInterface public void openAccount(){requireAccess();accountInfo();}
        @JavascriptInterface public boolean hasGeminiKey(){ requireAccess();return gemini.hasKey();}
        @JavascriptInterface public boolean setGeminiKey(String key){ requireAccess();boolean saved=gemini.saveKey(key);if(saved)cancelOnlineRequests();return saved;}
        @JavascriptInterface public boolean clearGeminiKey(){ requireAccess();cancelOnlineRequests();try{gemini.clearKey();return true;}catch(Exception ignored){return false;}}
        @JavascriptInterface public String getGeminiSaveError(){ requireAccess();return "storage_unavailable_or_invalid_key";}
        @JavascriptInterface public void setSensitiveScreen(boolean sensitive){ requireAccess();
            // Navigation must not re-enable the old global screenshot block.
            runOnUiThread(() -> updateCaptureProtection());
        }
    }
    @Override protected void onDestroy() {
        destroyed = true;
        if(updates!=null)updates.dispose();
        workspaceGeneration++;approvalHandler.removeCallbacks(workspacePoll);if(launchScreen!=null)launchScreen.dispose();
        if(accessScreen!=null)accessScreen.dispose();
        approvalHandler.removeCallbacks(approvalRefresh);
        for (GeminiClient.Request request : connections.values()) request.cancel();
        for (Future<?> task : tasks.values()) task.cancel(true);
        io.shutdownNow(); ai.shutdownNow();
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (view != null) { view.removeJavascriptInterface("openrepertorySecure"); view.destroy(); }
        if (vault != null) vault.close();
        super.onDestroy();
    }
}
