"""Source-first reader, notes, search, compact frame and accessibility regression."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.29';O.mkdir(parents=True,exist_ok=True);checks=[]
def check(v,label):
 assert v,label
 checks.append(label);print('PASS',label,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w,h in [(320,640),(393,800),(640,360),(768,850),(1280,900)]:
  for theme in ['light','dark']:
   p=b.new_page(viewport={'width':w,'height':h});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
   p.goto('http://127.0.0.1:8765');p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000)
   p.evaluate('(t)=>{document.body.dataset.theme=t;document.documentElement.dataset.theme=t;OR.showPage("dashboard")}',theme)
   check(p.locator('#activeContext').is_hidden(),'Top context strip removed')
   p.locator('[data-today=switch]').click();check(p.locator('.modal').is_visible(),'Case switching still available inside Today');p.keyboard.press('Escape')
   p.evaluate('OR.showPage("mm")');p.wait_for_function('()=>!document.getElementById("mmSourceFilter").disabled',timeout=90000)
   check(p.locator('.mm-source-filter-entry').count()==0,'Redundant introduction removed')
   if w==393:p.screenshot(path=str(O/f'materia-list-{theme}.png'))
   p.locator('#mmSearch').fill('zzzznonexistent');p.wait_for_timeout(250);check(p.locator('#mmList .empty-state').is_visible(),'Search empty state shown')
   p.locator('#mmClearSearch').click();check(p.locator('#mmSearch').input_value()=='' and p.locator('.mm-row').count()>0,'Clear search returns all remedies')
   p.locator('#mmSourceFilter').click();check(p.locator('#mmSourceFilter').get_attribute('aria-pressed')=='true','Source-only filter works')
   p.locator('#mmSearch').fill('acon');p.wait_for_timeout(250);p.locator('.mm-row').first.click();p.wait_for_selector('#mmSourceContent .oorep-mm-content',timeout=90000)
   check(p.locator('#mm-view-read').is_visible() and p.locator('#mm-view-case').is_hidden(),'Reader prioritises historical source text')
   original=p.locator('#mmSourceContent').inner_text()
   check(p.locator('#mmSectionPicker select option').count()>1,'Section navigation populated from actual source headings')
   p.locator('#mmSectionPicker select').select_option(index=1);check(p.locator('#mmDetail').evaluate('e=>e.scrollTop')>0,'Section selection scrolls the actual reader')
   p.locator('#mm-tab-notes').click();p.locator('#mmPersonalNotes').fill('Synthetic UI note — retain exactly.')
   p.locator('#mm-tab-read').click();check(p.locator('#mmSourceContent').inner_text()==original,'Tab switching preserves source text')
   p.locator('#mm-tab-case').click();check(p.locator('#mmFind').is_visible(),'Case view retains related rubric navigation')
   p.locator('#mm-tab-case').focus();p.keyboard.press('ArrowRight');check(p.locator('#mm-tab-notes').get_attribute('aria-selected')=='true','Keyboard tab navigation works')
   check(p.locator('#mmPersonalNotes').input_value()=='Synthetic UI note — retain exactly.','Notes survive view changes')
   p.evaluate('OR.refreshMateria()');check(p.locator('#mm-view-notes').is_visible(),'Refresh retains selected reader view')
   p.locator('#mm-tab-read').click()
   tabs=p.locator('.mm-source-tab')
   if tabs.count()>1:
    tabs.nth(1).click();check(p.locator('.mm-source-tab[aria-pressed=true]').count()==1,'Source selection has one active author');check(p.locator('#mmSectionPicker select option').count()>1,'Source switching rebuilds section navigation');tabs.first.click()
   p.evaluate('document.documentElement.style.fontSize="140%"')
   check(p.evaluate('()=>document.documentElement.scrollWidth<=innerWidth+1 && document.getElementById("mmDetail").scrollWidth<=document.getElementById("mmDetail").clientWidth+1'),'Large text has no horizontal reader overflow')
   if w==393:p.screenshot(path=str(O/f'materia-reader-{theme}.png'))
   p.evaluate('OR.clinic.back()');check(not p.locator('#mmWrap').evaluate('e=>e.classList.contains("detail-open")'),'Back restores remedy browser')
   check(p.locator('#mmSearch').input_value()=='acon','Back retains search query')
   p.reload();p.wait_for_function('()=>window.OR&&OR.state.repertory',timeout=90000);check(p.evaluate('Object.values(OR.mmNotes).includes("Synthetic UI note — retain exactly.")'),'Private note survives reload')
   check(not errors,'No uncaught UI exceptions');p.close()
 b.close()
(O/'materia-reader.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2));print('TOTAL',len(checks))
