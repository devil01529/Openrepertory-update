import json,time,pathlib
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1];out=root/'test-results/v1.12';results=[]
def wait(page,expr):
 end=time.monotonic()+60
 while time.monotonic()<end:
  if page.evaluate(expr):return
  page.wait_for_timeout(100)
 raise AssertionError(expr)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page()
 page.goto('http://127.0.0.1:8765');wait(page,'!!(window.OR&&OR.state.repertory)')
 page.evaluate("OR.toggleRubric('weighted_fixture','Mind','Synthetic weighted rubric',[{r:'Acon.',g:3}],3,'manual');OR.saveCaseSnapshot(OR.activeCase())")
 page.reload();wait(page,'!!(window.OR&&OR.state.repertory)')
 assert page.evaluate('OR.activeCase().snapshots[0].rubrics[0].weight')==3
 results.append({'test':'snapshot rubric weight survives persistence normalization','status':'passed'})
 before=page.evaluate('OR.activeCase().id');page.evaluate('OR.showPage("analysis")');page.locator('#snapshotHistory').click();page.locator('[data-snap-restore]').click();wait(page,'OR.activeCase().id!=='+json.dumps(before))
 assert page.evaluate('OR.activeCase().analysis[0].w')==3
 assert page.evaluate('OR.rankCase(OR.activeCase())[0].score')==9
 results.append({'test':'restored snapshot preserves rubric weight and independently expected score','status':'passed'})
 page.evaluate('OR.showPage("repertory");OR.runSearch("consol");OR.runSearch("")');assert page.locator('#rubricList').get_attribute('aria-busy')=='false'
 results.append({'test':'clearing an in-flight search clears busy accessibility state','status':'passed'})
 browser.close()
(out/'browser-snapshot-tests.json').write_text(json.dumps(results,indent=2));print('Snapshot/search-state checks passed:',len(results))
