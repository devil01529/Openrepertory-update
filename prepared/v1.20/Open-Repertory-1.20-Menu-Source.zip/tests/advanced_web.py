import json,pathlib,time
from playwright.sync_api import sync_playwright
out=(pathlib.Path(__file__).resolve().parents[1] / 'test-results/v1.12');results=[]
def wait(page, expr, seconds=30):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  if page.evaluate(expr):return
  page.wait_for_timeout(100)
 raise AssertionError('Timeout: '+expr)
def passed(name):results.append({'test':name,'status':'passed'});print('PASS',name,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':412,'height':915},accept_downloads=True)
 page=context.new_page();errors=[];requests=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
 page.goto('http://127.0.0.1:8765');wait(page,'!!(window.OR && OR.state.repertory)')
 for book in ['bbcr','knerr1897','tpb1846','boger1915','kent']:
  page.evaluate('(id)=>{OR.setRepertory(id)}',book);wait(page,'OR.state.repertoryId==='+json.dumps(book))
  assert page.evaluate('OR.state.repertory.chapters.length>0')
 passed('all five repertories load and switch')
 # Actual app scoring and source locking on rubric selection.
 page.evaluate('''() => {const c=OR.activeCase();c.analysis=[];delete c.repertoryId;OR.toggleRubric('test_kent','Mind','Synthetic A',[{r:'Acon.',g:3}],1,'manual');}''')
 page.evaluate('OR.setRepertory("bbcr")');wait(page,'OR.state.repertoryId==="bbcr"')
 page.evaluate('OR.toggleRubric("test_bbcr","Mind","Synthetic B",[{r:"Bell.",g:2}],1,"manual")')
 assert page.evaluate('OR.activeCase().analysis.length')==1
 assert page.evaluate('OR.activeCase().repertoryId')=='kent'
 passed('source locking prevents mixing rubrics from separate books')
 page.evaluate('OR.setRepertory("kent")');wait(page,'OR.state.repertoryId==="kent"')
 page.evaluate('OR.showPage("analysis")');page.locator('#saveSnapshot').click()
 assert page.evaluate('OR.activeCase().snapshots.length')==1
 passed('case snapshot saves rubric and ranking context')
 page.evaluate('OR.mmNotes["Nat-m."]="Synthetic remedy note";OR.saveMMNotes();OR.patients.openBackup()')
 page.locator('#bkEncPass').fill('test-password-123')
 with page.expect_download() as dl:page.locator('#bkSaveEnc').click()
 backup=out/'with-remedy-note.orbk';dl.value.save_as(backup)
 page.locator('#bkText').fill(backup.read_text());page.locator('#bkImportPass').fill('test-password-123');page.locator('#bkMerge').click()
 wait(page,'document.querySelector("#bkMsg").textContent.startsWith("Imported")')
 assert page.evaluate('OR.mmNotes["Nat-m."]')=='Synthetic remedy note'
 passed('backup restores remedy abbreviations containing punctuation and snapshots')
 # Atomic import must not change in-memory or durable state after failed commit.
 page.evaluate('''() => {const original=Storage.prototype.setItem;window.restoreStore=()=>Storage.prototype.setItem=original;Storage.prototype.setItem=()=>{throw new Error('storage full')};}''')
 before=page.evaluate('JSON.stringify(OR.state.cases)')
 page.locator('#bkMerge').click();wait(page,'document.querySelector("#bkMsg").textContent.includes("not saved")')
 assert page.evaluate('JSON.stringify(OR.state.cases)')==before
 page.evaluate('() => {restoreStore();return true;}')
 passed('failed import retains in-memory and committed records')
 # Reopen to clear failure display and check lazy classical text sharding.
 page.reload();wait(page,'!!(window.OR && OR.state.repertory)')
 page.evaluate('OR.openMateriaRemedy("Acon.")')
 wait(page,'document.querySelector("#mmDetail").textContent.length>100')
 wait(page,'performance.getEntriesByType("resource").some(r=>r.name.includes("/classics/"))')
 assert not any('/classics/' in u for u in requests[:7])
 classical=page.evaluate('performance.getEntriesByType("resource").filter(r=>r.name.includes("materia_medica_classics"))[0].decodedBodySize')
 assert classical<150000
 passed('large classical texts load as remedy shards rather than one 40MB file')
 # CSP is enforced in the actual page, with no test bypass flag.
 page.evaluate('''() => {window.inlineExecuted=false;const s=document.createElement('script');s.textContent='window.inlineExecuted=true';document.head.appendChild(s);}''')
 page.wait_for_timeout(100)
 assert page.evaluate('window.inlineExecuted') is False
 passed('content security policy blocks injected inline scripts')
 page.screenshot(path=str(out/'browser-materia.png'),full_page=True)
 assert not errors,errors
 passed('no uncaught errors across source, snapshot, backup and materia flows')
 context.close()
 # Native request dispatch tests use an explicitly mocked transport; native storage is tested separately on Android.
 context=browser.new_context()
 context.add_init_script('''window.mockCalls=[];window.openrepertorySecure={read:()=>null,writeBatch:()=>"ok",geminiAsync:(...args)=>window.mockCalls.push(args),cancel:id=>window.mockCalls.push(['cancel',id])};''')
 page=context.new_page();page.goto('http://127.0.0.1:8765');wait(page,'!!(window.OR && OR.state.repertory)')
 page.evaluate('''() => {const c=new AbortController();window.cancelResult='pending';ORNativeRequest('geminiAsync',['synthetic prompt',false],c.signal).then(()=>window.cancelResult='unexpected').catch(e=>window.cancelResult=e.code);c.abort();}''')
 wait(page,'window.cancelResult==="cancelled"')
 assert page.evaluate('window.mockCalls.some(x=>x[0]==="cancel")')
 passed('mocked online request cancellation propagates to native transport')
 browser.close()
(out/'advanced-browser-tests.json').write_text(json.dumps(results,indent=2))
