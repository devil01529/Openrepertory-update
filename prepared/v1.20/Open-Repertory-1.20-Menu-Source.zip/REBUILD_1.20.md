# Source overlay for Open Repertory 1.20

Apply over the retained full 1.19 clinical app source, preserving its database/text assets and the existing Android keystore. This overlay includes all maintained native classes, resources, web source, menu HTML/CSS, build/release tools and test source. Neither private signing key is included. Do not create a replacement Android key for installed users.

Version/package/public update configuration is in release-config.json. Build with bash build.sh after installing the pinned tools and tooling/package-lock.json dependencies. Use UPDATE_OWNER_GUIDE.md for signed release preparation and free GitHub publication. The retained metadata signing key is required for update.json. See TEST_REPORT_1.20.md in the repository for verification and device limits.
