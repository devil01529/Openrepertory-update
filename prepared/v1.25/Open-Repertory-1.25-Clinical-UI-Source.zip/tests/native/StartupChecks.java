package com.openrepertory.tests;

import android.app.*;
import android.content.*;
import android.os.*;
import android.webkit.*;
import android.view.View;
import com.openrepertory.app.*;
import org.json.*;
import java.lang.reflect.*;
import java.util.concurrent.*;

/** Emulator-only remote-page fixtures exercise the actual WebView receipt handoff. */
public class StartupChecks extends ApperChecks {
    static final class FixtureAuthView extends WebView {
        FixtureAuthView(android.content.Context context){super(context);}
        @Override public String getUrl(){return ApperAccess.ORIGIN+"/device";}
    }
    Object field(String name)throws Exception {Field f=activity.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(activity);}
    Object authJS(WebView browser,String script)throws Exception {
        CountDownLatch done=new CountDownLatch(1);String[] raw=new String[1];runOnMainSync(()->browser.evaluateJavascript(script,v->{raw[0]=v;done.countDown();}));
        if(!done.await(20,TimeUnit.SECONDS))throw new Exception("Auth script timed out");return raw[0]==null?null:new JSONTokener(raw[0]).nextValue();
    }
    void lifecycle(String method)throws Exception {
        Method m=activity.getClass().getDeclaredMethod(method);m.setAccessible(true);runOnMainSync(()->{try{m.invoke(activity);}catch(Exception e){throw new RuntimeException(e);}});
    }
    void ready()throws Exception {
        long end=SystemClock.elapsedRealtime()+300000;
        while(SystemClock.elapsedRealtime()<end){if(Boolean.TRUE.equals(field("workspaceReady"))){Thread.sleep(250);return;}Thread.sleep(100);}
        throw new Exception("No prepared first clinical frame; JS="+js("JSON.stringify({url:location.href,body:document.body&&document.body.innerText.slice(-1800),ready:document.readyState,hasOR:!!window.OR,source:window.OR&&OR.state&&OR.state.repertoryId})"));
    }
    @Override public void onStart(){Bundle result=new Bundle();try {
        if(!android.os.Build.FINGERPRINT.contains("generic")&&!android.os.Build.FINGERPRINT.contains("sdk"))throw new Exception("Emulator only");
        activity=startActivitySync(new Intent(Intent.ACTION_MAIN).setClassName("com.openrepertory.app.dev","com.openrepertory.app.ImprovedActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        Field w=MainActivity.class.getDeclaredField("webView");w.setAccessible(true);web=(WebView)w.get(activity);unlockTestActivity(MainActivity.class);
        ApperAccess access=(ApperAccess)field("access");
        getTargetContext().getSharedPreferences("openrepertory.vault-owner",0).edit().putString("uid",USER).putString("provider","apper").commit();
        ApperAccessScreen screen=(ApperAccessScreen)field("accessScreen");Field auth=ApperAccessScreen.class.getDeclaredField("browser");auth.setAccessible(true);WebView original=(WebView)auth.get(screen);
        WebView[] created=new WebView[1];runOnMainSync(()->created[0]=new FixtureAuthView(activity));WebView browser=created[0];
        runOnMainSync(()->{original.stopLoading();screen.removeView(original);original.destroy();browser.getSettings().setJavaScriptEnabled(true);browser.getSettings().setDomStorageEnabled(true);browser.getSettings().setUserAgentString("Mozilla/5.0 Chrome/120.0.0.0");screen.addView(browser,new android.widget.LinearLayout.LayoutParams(-1,0,1));browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){screen.check();}});});
        auth.set(screen,browser);
        LaunchScreen cover=(LaunchScreen)field("launchScreen");
        JSONObject fixture=receipt(access.deviceId());
        String page="<html><body>AUTH PAGE MUST STAY COVERED<script>window.calls=0;window.delay=1200;window.ORApperNative={result:null,check:function(args){window.calls++;var r="+fixture.toString()+";r.nonce=args.nonce;var self=this;setTimeout(function(){self.result=r},window.delay);}};</script></body></html>";
        // The supplied document exists only in this instrumentation package.
        final String html=page;
        runOnMainSync(()->{screen.cancel();browser.stopLoading();cover.show("Signing in…","Checking your approved access");browser.loadDataWithBaseURL(ApperAccess.ORIGIN+"/device",html,"text/html","UTF-8",null);});
        boolean[] overlay=new boolean[1];runOnMainSync(()->overlay[0]=cover.getVisibility()==View.VISIBLE);check(overlay[0],"startup is covered by the native signing-in screen");
        boolean blocked=false;try{((ImprovedActivity)activity).new SecureBridge().read("openrepertory_cases");}catch(SecurityException expected){blocked=true;}check(blocked,"the loading screen does not bypass account approval");
        ready();check(Boolean.TRUE.equals(js("!!(OR.state.repertory&&ORStorage.native)")),"actual WebView receipt opens the native clinical workspace");
        runOnMainSync(()->overlay[0]=cover.getVisibility()==View.GONE);check(overlay[0],"loader is removed after the first clinical frame is prepared");
        check(Boolean.TRUE.equals(field("workspaceReady")),"workspace readiness is tracked separately from approval");
        // Age only this synthetic pending-load fixture; no production timeout is shortened.
        js("window.__delayedRep=OR.state.repertory;OR.state.repertory=null");
        Field wr=activity.getClass().getDeclaredField("workspaceReady");wr.setAccessible(true);wr.setBoolean(activity,false);
        lifecycle("prepareWorkspace");Field started=activity.getClass().getDeclaredField("workspaceStartedAt");started.setAccessible(true);started.setLong(activity,SystemClock.elapsedRealtime()-61000);lifecycle("waitForWorkspace");long slowEnd=SystemClock.elapsedRealtime()+15000;while(!Boolean.TRUE.equals(field("workspaceSlow"))&&SystemClock.elapsedRealtime()<slowEnd)Thread.sleep(100);
        check(Boolean.TRUE.equals(field("workspaceSlow"))&&Boolean.TRUE.equals(field("waitingForWorkspace")),"slow-load feedback keeps polling instead of stranding the workspace");
        js("OR.state.repertory=window.__delayedRep");ready();
        check(Boolean.TRUE.equals(field("workspaceReady")),"a late-ready clinical document opens automatically without Retry");
        runOnMainSync(()->overlay[0]=cover.getVisibility()==View.GONE);check(overlay[0],"late readiness removes the loading cover after the approved surface is ready");

        js("window.__startupSentinel='retained';OR.showPage('repertory')");
        int calls=((Number)authJS(browser,"window.calls")).intValue();
        authJS(browser,"window.delay=15000");
        lifecycle("onPause");lifecycle("onResume");
        runOnMainSync(()->overlay[0]=cover.getVisibility()==View.VISIBLE);check(overlay[0],"returning to the app shows signing-in feedback during a fresh check");
        android.graphics.Bitmap[] capture=new android.graphics.Bitmap[1];
        runOnMainSync(()->{View root=activity.getWindow().getDecorView();capture[0]=android.graphics.Bitmap.createBitmap(root.getWidth(),root.getHeight(),android.graphics.Bitmap.Config.ARGB_8888);root.draw(new android.graphics.Canvas(capture[0]));});
        java.io.File file=new java.io.File(getTargetContext().getExternalCacheDir(),"startup-signing-in.png");try(java.io.FileOutputStream out=new java.io.FileOutputStream(file)){capture[0].compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}
        long end=SystemClock.elapsedRealtime()+20000;while(SystemClock.elapsedRealtime()<end){boolean[] visible=new boolean[1];runOnMainSync(()->visible[0]=cover.getVisibility()==View.VISIBLE);if(!visible[0])break;Thread.sleep(100);}
        check(((Number)authJS(browser,"window.calls")).intValue()>calls,"foreground return performs a new receipt request");
        check("retained".equals(js("window.__startupSentinel"))&&"repertory".equals(js("OR.state.page")),"warm return preserves the clinical document and current page");
        check(((Number)authJS(browser,"window.calls")).intValue()==calls+1,"warm return reuses the existing auth document without reloading it");
        authJS(browser,"window.delay=50");calls=((Number)authJS(browser,"window.calls")).intValue();lifecycle("unlock");Thread.sleep(1200);
        check(((Number)authJS(browser,"window.calls")).intValue()==calls+1,"Android re-unlock checks access without reloading the login page");
        check("retained".equals(js("window.__startupSentinel")),"re-unlock keeps the existing clinical workspace");
        JSONObject invalid=receipt(access.deviceId());invalid.put("mode","mock");receive(invalid);
        runOnMainSync(()->overlay[0]=cover.getVisibility()==View.GONE);check(overlay[0]&&!access.cachedAllowed(),"a denied check reveals the access screen instead of leaving an endless spinner");
        blocked=false;try{((ImprovedActivity)activity).new SecureBridge().read("openrepertory_cases");}catch(SecurityException expected){blocked=true;}check(blocked,"failed restoration still closes the clinical record bridge");
        runOnMainSync(()->{screen.cancel();browser.stopLoading();});
        result.putString("stream","Startup native checks passed: "+passed+"\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","FAILED after "+passed+" checks: "+e+"\n");finish(Activity.RESULT_CANCELED,result);}}
}
