"""Single-book analyses must retain published 1.23 scores under all methods."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'test-results/v1.25';checks=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);pages=[]
 for port in [8766,8765]:
  p=b.new_page();p.goto('http://127.0.0.1:'+str(port));p.wait_for_function('()=>OR.state.repertory',timeout=90000);pages.append(p)
 for book in ['kent','clarke']:
  for method in ['coverage','grade','weighted','classical']:
   for grade1 in [True,False]:
    case={'repertoryId':book,'analysis':[{'uid':'a','sourceId':book,'text':'A','w':1,'remedies':[{'r':'Acon.','g':1},{'r':'Bell.','g':3}]},{'uid':'b','sourceId':book,'text':'B','w':3,'remedies':[{'r':'Acon.','g':2},{'r':'Bell.','g':1},{'r':'Nat-m.','g':3}]},{'uid':'c','sourceId':book,'text':'C','w':2,'remedies':[{'r':'Nat-m.','g':1},{'r':'Bell.','g':2}]}]}
    args={'method':method,'grade1':grade1,'case':case}
    results=[p.evaluate('(x)=>{OR.state.scoreMethod=x.method;OR.state.includeGrade1=x.grade1;return OR.rankCase(x.case)}',args) for p in pages]
    assert results[0]==results[1],args
    label=f'{book} / {method} / include grade 1={grade1}: scores match published 1.23';checks.append({'test':label,'status':'passed'});print('PASS',label,flush=True)
 b.close()
(O/'scoring-compatibility-tests.json').write_text(json.dumps(checks,indent=2));print('Scoring compatibility checks passed:',len(checks))
